import http from 'node:http';import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import {createRequire} from 'node:module';import assert from 'node:assert/strict';import {fixture} from './fixtures/order-lookup-api.mjs';
const root=fileURLToPath(new URL('../',import.meta.url)),{chromium}=createRequire(import.meta.url)('C:/Users/kevin/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');let f;
const references=[];
const server=http.createServer(async(req,res)=>{try{
 const u=new URL(req.url,'http://localhost');
 if(u.pathname==='/api'){let body='';for await(const part of req)body+=part;if(body){const b=JSON.parse(body);if(b.action==='publicreference')references.push(b.reference);}
  const response=await f.handler(new Request('https://test.invalid'+req.url,{method:req.method,headers:{Origin:req.headers.origin||'',...(body?{'Content-Type':'text/plain;charset=utf-8'}:{})},...(body?{body}: {})}));res.writeHead(response.status,Object.fromEntries(response.headers));res.end(await response.text());return;}
 if(u.pathname==='/backend-config.js'){res.writeHead(200,{'Content-Type':'text/javascript'});res.end("window.ORIGINAL_STORE_API_URL=location.origin+'/api';");return;}
 const name=u.pathname.slice(1)||'facturas-pedidos.html';if(path.basename(name)!==name||name.includes('private')||!/^[-a-zA-Z0-9_.]+\.(html|js|css|png|svg|webp)$/.test(name)||!fs.existsSync(root+name)){res.writeHead(404);res.end();return;}
 const types={'.html':'text/html;charset=utf-8','.js':'text/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml'};res.writeHead(200,{'Content-Type':types[path.extname(name)]||'application/octet-stream'});res.end(fs.readFileSync(root+name));
 }catch(error){res.writeHead(500);res.end(error.message);}});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const url='http://127.0.0.1:'+server.address().port;f=fixture({env:{ORIGINAL_STORE_ALLOWED_ORIGINS:url}});
for(const [i,id]of ['PED-123456','FAC-1706050019060','FAC-PED-20261015000100-1234','DET-20261015000100-5678'].entries()){const invoice=id.startsWith('FAC-'),sheet=invoice?'Facturas':'Pedidos';f.data[sheet].rows.push({id:String(i+1),position:i+2,record:{[invoice?'ID Factura':'ID Pedido']:id,Fecha:'2026-10-15',Total:32000,Estado:'Registrado','Nombre Cliente':'PRIVATE-NAME','Productos JSON':JSON.stringify([{nombre:'Peluche de prueba',cantidad:1,precio:32000}])}});}
f.data.Configuracion.headers.push('Fecha Actualización');
const baseline=JSON.stringify(f.data),browser=await chromium.launch({channel:'msedge',headless:true});
try{
 const context=await browser.newContext();await context.route('**/*',route=>route.request().url().startsWith(url)?route.continue():route.abort());const page=await context.newPage();page.setDefaultTimeout(12000);const errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto(url+'/facturas-pedidos.html');
 for(const id of ['ped-123456','FAC-1706050019060','FAC-PED-20261015000100-1234','DET-20261015000100-5678']){
  await page.locator('#orders-phone-input').fill(id);await page.locator('#orders-submit-btn').click();await page.waitForFunction(id=>document.querySelector('#orders-results .order-id')?.textContent===id,id.toUpperCase());assert.ok(!(await page.locator('#orders-results').textContent()).includes('PRIVATE'));}
 console.log('PASS written order IDs, timestamp invoices, linked invoices and DET IDs found through the actual page and server');
 await page.locator('#orders-phone-input').fill('FAC-170605001906');await page.locator('#orders-submit-btn').click();await page.locator('.orders-empty').filter({hasText:'No encontramos'}).waitFor();
 const count=references.length;await page.locator('#orders-phone-input').fill('3222431225');await page.locator('#orders-submit-btn').click();await page.waitForFunction(()=>document.querySelector('#orders-status').textContent.includes('ID completo'));assert.equal(references.length,count);
 await page.evaluate(()=>{window.Html5Qrcode=class{async start(_camera,_options,callback){this.isScanning=true;window.testOrderQr=callback;}async stop(){this.isScanning=false;}};});
 await page.locator('#orders-scan-qr-btn').click();await page.waitForFunction(()=>typeof window.testOrderQr==='function');await page.evaluate(()=>testOrderQr('https://www.aloriginalstore.online/facturas-pedidos.html?buscar=FAC-PED-20261015000100-1234'));
 await page.waitForFunction(()=>document.querySelector('#orders-results .order-id')?.textContent==='FAC-PED-20261015000100-1234');
 await page.locator('#orders-scan-qr-btn').click();await page.evaluate(()=>testOrderQr('https://other.invalid/facturas-pedidos.html?buscar=FAC-1706050019060'));assert.equal(await page.locator('#orders-qr-dialog').evaluate(el=>el.open),true);assert.match(await page.locator('#orders-qr-error').textContent(),/no contiene/);await page.locator('#orders-qr-close').click();
 await page.goto(url+'/facturas-pedidos.html?buscar=FAC-1706050019060');await page.waitForFunction(()=>document.querySelector('#orders-results .order-id')?.textContent==='FAC-1706050019060');
 assert.equal(JSON.stringify(f.data),baseline);assert.equal(f.commits(),0);assert.deepEqual(errors,[]);console.log('PASS QR links, www alias, automatic lookup, partial/phone/foreign QR rejection, no personal data and zero writes');
}finally{await browser.close();server.closeAllConnections();await new Promise(r=>server.close(r));}
