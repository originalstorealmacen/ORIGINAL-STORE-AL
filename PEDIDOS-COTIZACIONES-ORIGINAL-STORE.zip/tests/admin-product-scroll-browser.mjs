import assert from 'node:assert/strict';import {createRequire} from 'node:module';import {server,start,writes,inventory} from './fixtures/admin-identity-server.mjs';
const {chromium}=createRequire(import.meta.url)('C:/Users/kevin/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const browser=await chromium.launch({channel:'msedge',headless:true}),url=await start();
const originalInventory=JSON.stringify(inventory),errors=[];
async function setup(mobile=false){
 const context=await browser.newContext(mobile?{viewport:{width:390,height:844},isMobile:true,hasTouch:true}:{});
 await context.route('**/*',async route=>{
  const address=route.request().url();
  if(address.startsWith(url))return route.continue();
  if(address.startsWith('https://accounts.google.com/gsi/client'))return route.fulfill({contentType:'text/javascript',body:`window.google={accounts:{id:{initialize(o){window.fixtureGoogle=o.callback;},renderButton(element){const b=document.createElement('button');b.type='button';b.textContent='Entrar prueba';b.onclick=()=>fixtureGoogle({credential:'fixture.'+btoa(JSON.stringify({email:'originalstorealmacen@gmail.com',exp:Math.floor(Date.now()/1000)+7200}))+'.signature'});element.append(b);}}}};`});
  return route.abort();
 });
 const page=await context.newPage();page.setDefaultTimeout(12000);await page.clock.install({time:new Date()});page.on('pageerror',e=>{errors.push(e.message);console.log('ERROR',e.message);});await page.goto(url);await page.getByRole('button',{name:'Entrar prueba',exact:true}).click();
 await page.waitForFunction(()=>document.getElementById('admin-main-content').style.display!=='none'&&window.OriginalStoreProductIdentity);
 await page.evaluate(()=>switchDashboardView('products','Productos'));await page.locator('#prod-id-producto').waitFor({state:'visible'});return {context,page};
}
try{
 const {page:pc}=await setup();await pc.setViewportSize({width:1700,height:1000});
 const left=pc.locator('#products-form-pane > .product-form-panel'),right=pc.locator('#products-form-pane > .product-preview-panel');
 await pc.evaluate(()=>document.querySelectorAll('#product-form details').forEach(el=>el.open=true));
 await pc.waitForFunction(()=>getComputedStyle(document.querySelector('.product-form-panel')).overflowY==='auto');
 await pc.waitForFunction(()=>document.querySelector('.product-form-panel').getBoundingClientRect().bottom<=innerHeight);
 const initial=await right.locator('#preview-img-el').boundingBox();const bounds=await left.boundingBox();
 await pc.mouse.move(bounds.x+bounds.width/2,bounds.y+250);await pc.mouse.wheel(0,750);
 await pc.waitForFunction(()=>document.querySelector('.product-form-panel').scrollTop>100);
 const after=await right.locator('#preview-img-el').boundingBox();assert.ok(Math.abs(initial.y-after.y)<2);assert.equal(await right.evaluate(el=>el.scrollTop),0);
 const leftPosition=await left.evaluate(el=>el.scrollTop),rb=await right.boundingBox();
 await pc.mouse.move(rb.x+rb.width/2,rb.y+200);await pc.mouse.wheel(0,450);
 await pc.waitForFunction(()=>document.querySelector('.product-preview-panel').scrollTop>0);assert.equal(await left.evaluate(el=>el.scrollTop),leftPosition);
 assert.ok(bounds.y+bounds.height<=1000);console.log('PASS desktop: left and preview scroll independently, image stays in place when scrolling the form');
 await pc.evaluate(()=>editarProducto(0));await pc.waitForFunction(()=>document.getElementById('products-form-pane').closest('#edit-product-modal'));
 await left.evaluate(el=>el.scrollTop=0);await right.evaluate(el=>el.scrollTop=0);
 await pc.waitForFunction(()=>{const grid=document.getElementById('products-form-pane').getBoundingClientRect(),card=document.querySelector('#edit-product-modal > .modal-card').getBoundingClientRect();return grid.bottom<=card.bottom+1;});
 const editBefore=await right.locator('#preview-img-el').boundingBox(),lb=await left.boundingBox();
 await pc.mouse.move(lb.x+lb.width/2,lb.y+150);await pc.mouse.wheel(0,600);await pc.waitForFunction(()=>document.querySelector('.product-form-panel').scrollTop>50);
 const editAfter=await right.locator('#preview-img-el').boundingBox();assert.ok(Math.abs(editBefore.y-editAfter.y)<2);assert.equal(await right.evaluate(el=>el.scrollTop),0);console.log('PASS edit dialog: both columns fit and remain independent');
 await pc.setViewportSize({width:390,height:844});await pc.waitForFunction(()=>document.getElementById('products-form-pane').style.getPropertyValue('--product-scroll-height')==='');
 assert.notEqual(await left.evaluate(el=>getComputedStyle(el).height),'0px');console.log('PASS mobile: independent desktop height removed');
 assert.deepEqual(writes,[]);assert.deepEqual(errors,[]);
}finally{await browser.close();server.closeAllConnections();await new Promise(r=>server.close(r));}
