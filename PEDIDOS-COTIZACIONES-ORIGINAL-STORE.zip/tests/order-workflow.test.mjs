import test from 'node:test';import assert from 'node:assert/strict';import {fixture} from './fixtures/order-lookup-api.mjs';
const auth={adminCredential:'TEST-GOOGLE-ID'},key='0123456789abcdef0123456789abcdef';
const request=(extra={})=>({action:'submitrequest',mode:'retail',idempotencyKey:key,cliente:{nombre:'Cliente de prueba',telefono:'3001234567'},items:[{idVariacion:'TEST-V1',cantidad:2,precio:1}],...extra});
const rows=f=>f.data.Pedidos.rows;
const config=(f,Clave,Valor)=>f.post({action:'setconfig',Clave,Valor,...auth});
const latest=(f,id)=>f.post({resource:'pedidos',action:'get',id,...auth}).then(r=>r.data);
test('retail request keeps server estimates, optional contact fields and an idempotent reference',async()=>{
 const f=fixture(),stock=f.data.Productos.rows[0].record.Cantidad;
 const first=await f.post(request());assert.equal(first.ok,true,JSON.stringify(first));const id=first.data['ID Pedido'];assert.match(id,/^COT-/);assert.equal(first.data['Tipo Solicitud'],'quote');assert.equal(first.data.Subtotal,2000);assert.equal(first.data['Precios Pendientes'],0);
 assert.equal(f.data.Facturas.rows.length,0);assert.equal(f.data.Productos.rows[0].record.Cantidad,stock);
 const repeat=await f.post(request());assert.equal(repeat.data['ID Pedido'],id);assert.equal(repeat.replayed,true);assert.equal(rows(f).length,1);
 const changed=await f.post(request({items:[{idVariacion:'TEST-V1',cantidad:3}]}));assert.equal(changed.ok,false);assert.equal(rows(f).length,1);
 const receipt=await f.post({action:'ordertempreceipt',receiptToken:repeat.receipt.token,orderId:id});assert.equal(receipt.ok,true);assert.equal(receipt.data['Nombre Cliente'],'Cliente de prueba');assert.ok(!JSON.stringify(receipt).includes('precioCatalogo'));assert.ok(!JSON.stringify(receipt).includes('Huella Solicitud'));
});
test('wholesale request uses wholesale server price without changing inventory or creating invoices',async()=>{
 const f=fixture(),result=await f.post(request({mode:'wholesale'}));assert.equal(result.ok,true,JSON.stringify(result));assert.match(result.data['ID Pedido'],/^MAY-/);assert.equal(result.data['Tipo Solicitud'],'wholesale');assert.equal(result.data.Subtotal,1400);assert.equal(f.data.Facturas.rows.length,0);assert.equal(f.data.Productos.rows[0].record.Cantidad,10);
});
test('hidden or missing prices remain pending rather than free',async()=>{
 const f=fixture();await config(f,'Mostrar_Precios_Minorista','0');const hidden=await f.post(request());assert.equal(hidden.ok,true);const line=hidden.data['Productos JSON'][0];assert.equal(line.precio,null);assert.equal(line.precioEstado,'Por cotizar');assert.equal(hidden.data['Precios Pendientes'],1);
 const receipt=await f.post({action:'ordertempreceipt',receiptToken:hidden.receipt.token,orderId:hidden.data['ID Pedido']});assert.equal(receipt.data['Productos JSON'][0].precio,null);assert.equal(receipt.data['Productos JSON'][0].precioCatalogo,undefined);
});
test('server checks accumulated references and invalid quantities before registration',async()=>{
 for(const items of [[{idVariacion:'TEST-V1',cantidad:6},{idVariacion:'TEST-V1',cantidad:6}],[{idVariacion:'TEST-V1',cantidad:0}],[{idVariacion:'TEST-V1',cantidad:1.5}],[{idVariacion:'MISSING',cantidad:1}]]){
  const f=fixture(),result=await f.post(request({items}));assert.equal(result.ok,false,JSON.stringify(result));assert.equal(rows(f).length,0);assert.equal(f.data.ComprobantesPrivados.rows.length,0);
 }
 const f=fixture(),r=await f.post(request({items:[{idVariacion:'TEST-V1',cantidad:2},{idVariacion:'TEST-V1',cantidad:3}]}));assert.equal(r.ok,true);assert.equal(r.data['Productos JSON'].length,1);assert.equal(r.data.Subtotal,5000);
});
test('review requires admin/version; acceptance converts the saved quote with the same reference and no side effects',async()=>{
 const f=fixture(),created=await f.post(request()),id=created.data['ID Pedido'];
 const edit={action:'reviewquote',orderId:id,expectedVersion:1,items:[{idVariacion:'TEST-V1',cantidad:3,precio:1300}]};
 assert.equal((await f.post(edit)).ok,false);
 const saved=await f.post({...edit,...auth});assert.equal(saved.ok,true,JSON.stringify(saved));assert.equal(saved.data['Version Pedido'],2);assert.equal(saved.data.Subtotal,3900);
 assert.equal((await f.post({...edit,...auth})).ok,false);
 assert.equal((await f.post({action:'convertquote',orderId:id,expectedVersion:2,...auth})).ok,false);
 const converted=await f.post({action:'convertquote',orderId:id,expectedVersion:2,accepted:true,...auth});assert.equal(converted.ok,true,JSON.stringify(converted));assert.equal(converted.data['ID Pedido'],id);assert.equal(converted.data['Tipo Solicitud'],'retail');assert.equal(converted.data['Version Pedido'],3);
 assert.equal(f.data.Productos.rows[0].record.Cantidad,10);assert.equal(f.data.Facturas.rows.length,0);assert.equal(rows(f).length,1);
 const receipt=await f.post({action:'ordertempreceipt',receiptToken:created.receipt.token,orderId:id});assert.equal(receipt.data.Subtotal,3900);assert.equal(receipt.data['Tipo Solicitud'],'retail');
});
test('conversion revalidates stock, catalog price and pending negotiated prices',async()=>{
 for(const reason of ['stock','price','pending']){
  const f=fixture(),r=await f.post(request()),id=r.data['ID Pedido'];await f.post({action:'reviewquote',orderId:id,expectedVersion:1,items:[{idVariacion:'TEST-V1',cantidad:2,precio:reason==='pending'?null:1200}],...auth});
  if(reason==='stock')f.data.Productos.rows[0].record.Cantidad=1;
  if(reason==='price')f.data.Productos.rows[0].record.Precio=1500;
  const result=await f.post({action:'convertquote',orderId:id,expectedVersion:2,accepted:true,...auth});assert.equal(result.ok,false,reason);assert.equal((await latest(f,id))['Tipo Solicitud'],'quote');assert.equal(f.data.Facturas.rows.length,0);
 }
});
test('generic admin paths cannot bypass review or invoice a pending quote',async()=>{
 const f=fixture(),r=await f.post(request()),id=r.data['ID Pedido'];
 for(const payload of [{resource:'pedidos',action:'editar',id,data:{'Estado Pedido':'Facturado'}},{resource:'pedidos',action:'batchsave',data:[{'ID Pedido':id,'Tipo Solicitud':'retail'}]},{resource:'facturas',action:'crear',data:{'ID Factura':'FAC-TEST','ID Pedido':id,Subtotal:1000}},{resource:'facturas',action:'batchsave',data:[{'ID Factura':'FAC-TEST','ID Pedido':id,Subtotal:1000}]}])assert.equal((await f.post({...payload,...auth})).ok,false);
 assert.equal(f.data.Facturas.rows.length,0);assert.equal((await latest(f,id))['Version Pedido'],1);
});
test('tracking accepts all project reference formats and omits personal data and internal pricing',async()=>{
 const f=fixture(),created=await f.post(request()),id=created.data['ID Pedido'];const track=await f.post({action:'publicreference',reference:id.toLowerCase()});assert.equal(track.orders.length,1);assert.equal(track.orders[0]['Tipo Solicitud'],'quote');assert.ok(!JSON.stringify(track).includes('3001234567'));assert.ok(!JSON.stringify(track).includes('Cliente de prueba'));assert.ok(!JSON.stringify(track).includes('precioCatalogo'));assert.ok(!JSON.stringify(track).includes('Huella Solicitud'));
 for(const ref of ['MAY-123456789-ABC','DET-123456789-ABC','FAC-MAY-123456789-ABC']){const invoice=ref.startsWith('FAC-'),table=f.data[invoice?'Facturas':'Pedidos'];table.rows.push({id:ref,position:table.rows.length+2,record:{[invoice?'ID Factura':'ID Pedido']:ref}});const found=await f.post({action:'publicreference',reference:ref});assert.equal((invoice?found.invoices:found.orders).length,1);}
 assert.equal((await f.post({action:'publicreference',reference:'3001234567'})).ok,false);
});
test('revision conflicts do not acknowledge or persist a request',async()=>{const f=fixture();f.setConflict();const r=await f.post(request());assert.equal(r.ok,false);assert.equal(rows(f).length,0);});
test('online checkout still creates a preference using canonical prices and accumulated quantities',async()=>{
 let preference;const f=fixture({env:{MERCADO_PAGO_ACCESS_TOKEN:'TEST-FAKE-PAYMENT-TOKEN'},fetcher:async(url,options)=>{if(String(url).includes('mercadopago.com/checkout/preferences')){preference=JSON.parse(options.body);return Response.json({id:'TEST-PREFERENCE',init_point:'https://www.mercadopago.com.co/checkout/test'});}return Response.json({});}});
 const r=await f.post({action:'createpreference',mode:'retail',cliente:{nombre:'Cliente',telefono:'3001234567'},items:[{idVariacion:'TEST-V1',cantidad:2,precio:1},{idVariacion:'TEST-V1',cantidad:1,precio:1}]});assert.equal(r.ok,true,JSON.stringify(r));assert.equal(preference.items.length,1);assert.equal(preference.items[0].unit_price,1000);assert.equal(preference.items[0].quantity,3);assert.equal(f.data.Facturas.rows.length,0);assert.equal(f.data.Productos.rows[0].record.Cantidad,10);assert.equal(rows(f).length,1);
});

test('simultaneous retries commit one request and recover its reference after a conflict',async()=>{
 const f=fixture(),results=await Promise.all([f.post(request()),f.post(request())]);assert.equal(rows(f).length,1);assert.ok(results.some(r=>r.ok));
 const retry=await f.post(request());assert.equal(retry.ok,true);assert.equal(retry.replayed,true);assert.equal(retry.data['ID Pedido'],rows(f)[0].record['ID Pedido']);assert.equal(f.data.ComprobantesPrivados.rows.length,1);
});
test('unknown prices and disabled payments cannot enter the payment gateway',async()=>{
 for(const scenario of ['hidden','disabled','pending']){
  let gatewayCalls=0;const f=fixture({env:{MERCADO_PAGO_ACCESS_TOKEN:'TEST-FAKE-TOKEN'},fetcher:async()=>{gatewayCalls++;return Response.json({id:'FAKE',init_point:'https://test.invalid/payment'});}});
  if(scenario==='hidden')await config(f,'Mostrar_Precios_Minorista','0');
  if(scenario==='disabled')await config(f,'Mercado_Pago_Publico_Activo','0');
  if(scenario==='pending'){f.data.Productos.rows[0].record.Precio=0;f.data.Productos.rows[0].record['Precio Mayor']=0;const quote=await f.post(request());assert.equal(quote.data['Productos JSON'][0].precio,null);assert.equal(quote.data['Precios Pendientes'],1);}
  const result=await f.post({action:'createpreference',mode:'retail',cliente:{nombre:'Cliente',telefono:'3001234567'},items:[{idVariacion:'TEST-V1',cantidad:1}]});assert.equal(result.ok,false,scenario);assert.equal(gatewayCalls,0,scenario);assert.equal(f.data.Facturas.rows.length,0);
 }
});
