import {createHandler} from '../../supabase/functions/original-store-api/server.js';
export function fixture(overrides={}){
  let state={revision:'1',properties:{BLYXU_ADMIN_EMAILS:'originalstorealmacen@gmail.com'},cache:{}};
  const names=['Productos','Clientes','Pedidos','Facturas','Favoritos','PedidosChina','Configuracion','CuentasPrivadas','SolicitudesAccesoPrivadas','ComprobantesPrivados'];
  const data=Object.fromEntries(names.map(name=>[name,{name,revision:'1',headers:name.includes('Privad')?['ID','Datos']:[],rows:[]}]));
  data.Productos.headers=['ID Variación','ID Producto','SKU','Nombre del Producto','Precio','Precio Mayor','Cantidad'];
  data.Productos.rows=[{id:'1',position:2,record:{'ID Variación':'TEST-V1','ID Producto':'TEST-P1',SKU:'TEST-V1','Nombre del Producto':'Prueba',Precio:1000,'Precio Mayor':700,Cantidad:10}}];
  data.Configuracion.headers=['Clave','Valor'];
  data.Configuracion.rows=[{id:'1',position:2,record:{Clave:'Google_Client_ID',Valor:'TEST-CLIENT'}}];
  let commits=0,conflict=false,clock=Date.now(),googleEmail='originalstorealmacen@gmail.com';
  async function fetcher(url,options={}){
    const target=String(url);
    if(overrides.fetcher&&target.startsWith('https://api.mercadopago.com/'))return overrides.fetcher(url,options);
    if(overrides.fetcher&&target.startsWith('https://www.googleapis.com/'))return overrides.fetcher(url,options);
    if(overrides.fetcher&&target==='https://oauth2.googleapis.com/token')return overrides.fetcher(url,options);
    if(target.startsWith('https://oauth2.googleapis.com/tokeninfo'))return Response.json({aud:'TEST-CLIENT',email_verified:true,iss:'https://accounts.google.com',exp:Date.now()/1000+3600,sub:'TEST-SUB',email:googleEmail});
    const method=target.split('/').at(-1),p=JSON.parse(options.body||'{}');
    if(method==='store_load_server')return Response.json({state,datasets:Object.values(data)});
    if(method==='store_read_server_state')return Response.json(state);
    if(method==='store_read_dataset')return Response.json(data[p.dataset_name]);
    if(method==='store_commit_server'){
      if(conflict||String(p.expected_revision)!==state.revision)return Response.json({code:'PT409'},{status:409});
      for(const c of p.changes)if(c.revision!==data[c.name].revision)return Response.json({code:'PT409'},{status:409});
      for(const c of p.changes){const table=data[c.name];table.headers=c.headers;for(const m of c.mutations){if(m.op==='insert')table.rows.push({id:String(table.rows.length+1),position:m.position,record:m.record});if(m.op==='update')table.rows.find(r=>r.id===m.id).record=m.record;if(m.op==='delete')table.rows=table.rows.filter(r=>r.id!==m.id);}if(c.mutations.length||c.headersChanged)table.revision=String(Number(table.revision)+1);}
      state={revision:String(Number(state.revision)+1),properties:p.server_properties,cache:p.server_cache};commits++;return Response.json({ok:true});
    }
    throw new Error('Unexpected test destination');
  }
  const env=name=>({...{ORIGINAL_STORE_API_ENABLED:'true',SUPABASE_SERVICE_ROLE_KEY:'TEST-SERVER-KEY'},...overrides.env}[name]);
  const handler=createHandler({env,fetcher,now:()=>clock});
  const post=body=>handler(new Request('https://test.invalid/functions/v1/original-store-api',{method:'POST',headers:{Origin:'https://aloriginalstore.online'},body:JSON.stringify(body)})).then(r=>r.json());
  return {handler,post,data,getState:()=>state,commits:()=>commits,setConflict:()=>{conflict=true;},advance:ms=>{clock+=ms;},setEmail:value=>{googleEmail=value;}};
}