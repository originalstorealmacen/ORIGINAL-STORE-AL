import http from 'node:http';import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
import {sharedScanAction} from '../../supabase/functions/original-store-api/shared-scan.js';
const root=fileURLToPath(new URL('../../',import.meta.url)),cache=new Map(),subscribers=new Map();
export const writes=[],calls=[];
export const inventory=[{ID:'EXISTING-V01',idVariacion:'EXISTING-V01',idProducto:'EXISTING',Nombre:'Existente de prueba',Precio:15000,Stock:8,'Codigo Barras':'BLYXU-EXISTING-V01'},{ID:'EXISTING-V02',idVariacion:'EXISTING-V02',idProducto:'EXISTING',Nombre:'Variante de prueba',Precio:18000,Stock:5,'Codigo Barras':'BLYXU-EXISTING-V02'}];
export const server=http.createServer(async(req,res)=>{try{
 const pathname=new URL(req.url,'http://localhost').pathname;
 if(pathname==='/api'){
  let raw='';for await(const part of req)raw+=part;const b={...Object.fromEntries(new URL(req.url,'http://localhost').searchParams),...JSON.parse(raw||'{}')};calls.push({action:b.action,resource:b.resource});
  if(/^scan/.test(b.action||'')){
   if(!b.adminCredential?.startsWith('fixture.')){res.writeHead(401);res.end(JSON.stringify({ok:false}));return;}
   const abort=new AbortController();res.on('close',()=>abort.abort());
   const result=await sharedScanAction({body:b,owner:'originalstorealmacen@gmail.com',cache:{get:k=>cache.get(k),put:(k,v)=>cache.set(k,v)},checkpoint:async()=>{},env:k=>({SUPABASE_URL:'https://fixture.invalid',SUPABASE_SERVICE_ROLE_KEY:'FIXTURE-ONLY'})[k],signal:abort.signal,
    fetcher:async(_u,o)=>{for(const m of JSON.parse(o.body).messages)for(const handler of subscribers.get(m.topic)||[])handler.onMessage(m.event,m.payload);return Response.json({});},
    subscribe:o=>{if(!subscribers.has(o.topic))subscribers.set(o.topic,new Set());subscribers.get(o.topic).add(o);setTimeout(o.onReady,5);return()=>subscribers.get(o.topic).delete(o);}});
   if(result instanceof Response){res.writeHead(200,Object.fromEntries(result.headers));for await(const part of result.body)res.write(part);res.end();}else{res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify(result));}return;
  }
  if(/^(crear|create|editar|update|batch.*|save|productbatch)$/.test(b.action||'')||(b.resource==='productos'&&!['','get','list','listar'].includes(b.action||''))){writes.push(b);res.writeHead(400);res.end(JSON.stringify({ok:false,error:'Test forbids saving products'}));return;}
  let result={ok:true,status:'success',data:[],notifications:[],pedidos:[],facturas:[],count:0};
  if(/get.?config/i.test(b.action||'')||b.resource==='configuracion')result={ok:true,status:'success',config:{Google_Client_ID:'FIXTURE-CLIENT',Auth_Admin_Mode:'google-bootstrap'}};
  else if(b.action==='adminsession')result={ok:b.adminCredential?.startsWith('fixture.')===true,status:'success',email:'originalstorealmacen@gmail.com'};
  else if(b.resource==='productos')result={ok:true,status:'success',data:inventory};
  res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify(result));return;
 }
 if(pathname==='/backend-config.js'){res.writeHead(200,{'Content-Type':'text/javascript'});res.end("window.ORIGINAL_STORE_API_URL=location.origin+'/api';");return;}
 const name=pathname==='/'?'administrativo.html':pathname.slice(1);
 if(path.basename(name)!==name||name.includes('private')||!/^[-a-zA-Z0-9_. ]+\.(html|js|css|svg|png|jpg|webp|ico)$/.test(name)||!fs.existsSync(root+name)){res.writeHead(404);res.end();return;}
 const types={'.html':'text/html;charset=utf-8','.js':'text/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml'};
 res.writeHead(200,{'Content-Type':types[path.extname(name)]||'application/octet-stream'});res.end(fs.readFileSync(root+name));
 }catch(error){if(!res.headersSent)res.writeHead(500);res.end(JSON.stringify({ok:false,error:error.message}));}});
export async function start(){await new Promise(r=>server.listen(0,'127.0.0.1',r));return 'http://127.0.0.1:'+server.address().port;}
