import http from 'node:http';import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import {createRequire} from 'node:module';import assert from 'node:assert/strict';import {fixture} from './fixtures/order-lookup-api.mjs';
const root=fileURLToPath(new URL('../',import.meta.url)),{chromium}=createRequire(import.meta.url)('C:/Users/kevin/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');let f;
const references=[];
const server=http.createServer(async(req,res)=>{try{
 const u=new URL(req.url,'http://localhost');
 if(u.pathname==='/api'){let body='';for await(const part of req)body+=part;if(body){const b=JSON.parse(body);if(b.action==='publicreference')references.push(b.reference);}
  const response=await f.handler(new Request('https://test.invalid'+req.url,{method:req.method,headers:{Origin:req.headers.origin||'',...(body?{'Content-Type':'text/plain;charset=utf-8'}:{})},...(body?{body}: {})}));res.writeHead(response.status,Object.fromEntries(response.headers));res.end(await response.text());return;}
 if(u.pathname==='/backend-config.js'){res.writeHead(200,{'Content-Type':'text/javascript'});res.end("window.ORIGINAL_STORE_API_URL=location.origin+'/api';");return;}
 const name=u.pathname.slice(1)||'administrativo.html';if(path.basename(name)!==name||name.includes('private')||!/^[-a-zA-Z0-9_.]+\.(html|js|css|png|svg|webp)$/.test(name)||!fs.existsSync(root+name)){res.writeHead(404);res.end();return;}
 const types={'.html':'text/html;charset=utf-8','.js':'text/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml'};res.writeHead(200,{'Content-Type':types[path.extname(name)]||'application/octet-stream'});res.end(fs.readFileSync(root+name));
 }catch(error){res.writeHead(500);res.end(error.message);}});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const url='http://127.0.0.1:'+server.address().port;f=fixture({env:{ORIGINAL_STORE_ALLOWED_ORIGINS:url+',https://aloriginalstore.online'}});

f.data.Productos.rows[0].record['Precio Mayor']=10000;
f.data.Productos.rows.push({id:'2',position:3,record:{'ID Variación':'AUTO-V01','ID Producto':'AUTO','Nombre del Producto':'Automático',Precio:0,'Precio Mayor':10000,Cantidad:8}});
assert.equal(fs.readFileSync(root+'retail-pricing-core.js','utf8'),fs.readFileSync(root+'supabase/functions/original-store-api/retail-pricing.js','utf8'));
const baseline=JSON.stringify(f.data.Productos.rows),errors=[],browser=await chromium.launch({channel:'msedge',headless:true});
async function setup(mobile=false){
 const context=await browser.newContext(mobile?{viewport:{width:390,height:844},isMobile:true,hasTouch:true}:{});
 await context.route('**/*',async route=>{
  const address=route.request().url();
  if(address.startsWith(url))return route.continue();
  if(address.startsWith('https://accounts.google.com/gsi/client'))return route.fulfill({contentType:'text/javascript',body:`window.google={accounts:{id:{initialize(o){window.fixtureGoogle=o.callback;},renderButton(element){const b=document.createElement('button');b.type='button';b.textContent='Entrar prueba';b.onclick=()=>fixtureGoogle({credential:'fixture.'+btoa(JSON.stringify({email:'originalstorealmacen@gmail.com',exp:Math.floor(Date.now()/1000)+7200}))+'.signature'});element.append(b);}}}};`});
  return route.abort();
 });
 const page=await context.newPage();page.setDefaultTimeout(12000);await page.clock.install({time:new Date()});page.on('pageerror',e=>{errors.push(e.message);console.log('ERROR',e.message);});await page.goto(url);await page.getByRole('button',{name:'Entrar prueba',exact:true}).click();
 await page.waitForFunction(()=>document.getElementById('admin-main-content').style.display!=='none'&&window.OriginalStoreProductIdentity);
 await page.evaluate(()=>switchDashboardView('products','Productos'));await page.locator('#prod-id-producto').waitFor({state:'visible'});return {context,page};
}
try{
 const {page}=await setup();
 await page.waitForFunction(()=>window.OriginalStoreRetailPricing&&document.getElementById('prod-precio').readOnly);
 await page.locator('#prod-precio-mayorista').fill('10000');
 await page.evaluate(()=>switchDashboardView('inventory','Inventario'));
 await page.locator('#retail-global-percent').fill('30');await page.locator('#retail-save-percent').click();
 await page.waitForFunction(()=>document.getElementById('retail-global-status').textContent.includes('30 % aplicado'));
 assert.equal(JSON.stringify(f.data.Productos.rows),baseline);
 assert.equal((await f.post({resource:'productos',action:'listar'})).data.find(p=>p['ID Variación']==='AUTO-V01').Precio,13000);
 await page.evaluate(()=>switchDashboardView('products','Productos'));
 assert.equal(await page.locator('#prod-precio').inputValue(),'13000');
 await page.locator('#prod-retail-mode').selectOption('manual');await page.locator('#prod-precio').fill('17000');
 await page.locator('#prod-precio-mayorista').fill('12000');assert.equal(await page.locator('#prod-precio').inputValue(),'17000');
 await page.locator('#prod-retail-mode').selectOption('porcentaje');assert.equal(await page.locator('#prod-precio').inputValue(),'15600');
 await page.locator('#btn-add-manual-variant').evaluate(b=>b.click());
 await page.locator('.var-retail-mode').waitFor();await page.locator('.var-retail-mode').selectOption('manual');await page.locator('.var-precio').fill('22000');
 assert.equal(await page.evaluate(()=>buildProductPayload().Precio),15600);
 const main=await page.evaluate(()=>normalizeProductPayloadForSubmit(buildProductPayload()));assert.equal(main['Modo Precio Minorista'],'porcentaje');
 const variant=await page.evaluate(()=>normalizeProductPayloadForSubmit(collectVariantPayloads()[0]));assert.equal(variant['Modo Precio Minorista'],'manual');assert.equal(variant.Precio,22000);
 await page.evaluate(()=>switchDashboardView('inventory','Inventario'));
 const choice=page.locator('[data-retail-product="AUTO-V01"]');await choice.locator('summary').click();await choice.locator('select').selectOption('manual');await choice.locator('input').fill('19000');await choice.locator('button').click();
 await page.waitForFunction(()=>[...document.querySelectorAll('[data-retail-product="AUTO-V01"] select')].some(x=>x.value==='manual'));
 await page.waitForFunction(()=>document.querySelector('[data-retail-product="AUTO-V01"] input')?.value==='19000');
 assert.equal((await f.post({resource:'productos',action:'listar'})).data.find(p=>p['ID Variación']==='AUTO-V01').Precio,19000);
 await page.locator('#retail-global-percent').fill('50');await page.locator('#retail-save-percent').click();await page.waitForFunction(()=>document.getElementById('retail-global-status').textContent.includes('50 % aplicado'));
 assert.equal((await f.post({resource:'productos',action:'listar'})).data.find(p=>p['ID Variación']==='AUTO-V01').Precio,19000);
 await page.evaluate(()=>switchDashboardView('products','Productos'));assert.equal(await page.locator('#prod-precio').inputValue(),'18000');assert.equal(await page.locator('.var-precio').inputValue(),'22000');
 assert.equal(f.data.Pedidos.rows.length,0);assert.equal(f.data.Facturas.rows.length,0);
 assert.deepEqual(errors,[]);
 await page.evaluate(()=>switchDashboardView('inventory','Inventario'));await page.screenshot({path:root+'.supabase-server-private/retail-inventory-desktop.png'});
 await page.setViewportSize({width:390,height:844});await page.evaluate(()=>switchDashboardView('inventory','Inventario'));await page.locator('#retail-global-percent').waitFor({state:'visible'});
 await page.screenshot({path:root+'.supabase-server-private/retail-inventory-mobile.png'});
 console.log('PASS actual admin and server: global markup, live preview, manual prices, independent variants, per-product fold, mobile controls; simulated records only, no orders/invoices.');
}finally{await browser.close();server.close();}
