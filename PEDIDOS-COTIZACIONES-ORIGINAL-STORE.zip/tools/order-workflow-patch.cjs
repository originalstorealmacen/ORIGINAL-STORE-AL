// Extends the existing controller without replacing its persistence, auth or payment paths.
module.exports=function(source){
 source=source.replace(/\r\n/g,'\n');
 const replace=(before,after)=>{if(!source.includes(before))throw Error('Order workflow integration point missing: '+before.slice(0,80));source=source.replace(before,after);};
 replace("      'Tipo Cliente',\n      'Teléfono',", "      'Tipo Cliente',\n      ...workflowHeaders,\n      'Teléfono',");
 replace("if (authorization.response) return json_(authorization.response);",`if (authorization.response) return json_(authorization.response);
    if (['submitrequest','reviewquote','convertquote'].includes(action)) {
      if(method !== 'POST') return json_({ok:false,error:'Utiliza POST.'});
      const result=await orderWorkflow(action,body,{
        list:()=>listRows_('Pedidos',{}),find:id=>getById_('Pedidos',id),
        catalog:(items,wholesale)=>securityCatalogItems_(items,wholesale),config:getConfigValue_,id:makeId_,
        create:data=>createOrder_(data),update:(id,data)=>updateRow_('Pedidos',id,data),
        safe:workflowSafeOrder_,receipt:(order,token)=>receiptRegister_(workflowReceiptOrder_(order),token),
        refreshReceipt:order=>{const row=receiptFind_(order['ID Pedido']);if(row){row.data.order=workflowReceiptOrder_(order);caWrite_('ComprobantesPrivados',row,row.data);receiptRowsMemo_=null;}}
      },authorization.admin);
      return json_(result);
    }`);
 replace("const publicActions = ['customerrecords'", "const publicActions = ['submitrequest','customerrecords'");
 replace("    if (method === 'POST') {\n      const data = body.data || body;",`    if (method === 'POST') {
      const data = body.data || body;
      protectWorkflowWrite({sheet:sheetName,action,data:Array.isArray(data)?data:{...data,__workflowTargetId:body.id},find:id=>getById_('Pedidos',id)});`);
 // All invoice write entry points, including individual updates and batch writes.
 replace("      const primaryId = String(getObjectValueByHeader_(rowObject, primaryHeader", "      if(sheetName === 'Facturas') workflowInvoiceGuard_(rowObject);\n      const primaryId = String(getObjectValueByHeader_(rowObject, primaryHeader");
 replace("  const row = headers.map(header => getObjectValueByHeader_(current, header, ''));", "  if(sheetName === 'Facturas') workflowInvoiceGuard_(current);\n  const row = headers.map(header => getObjectValueByHeader_(current, header, ''));");
 const appendStart=source.indexOf('function appendRow_'),appendIndex=source.indexOf("  const row = headers.map(header => getObjectValueByHeader_(rowObject, header, ''));",appendStart);
 if(appendIndex<0)throw Error('Append guard missing');source=source.slice(0,appendIndex)+"  if(sheetName === 'Facturas') workflowInvoiceGuard_(rowObject);\n"+source.slice(appendIndex);
 // Aggregate repeated references before both pricing and stock checks. Reject empty, invalid and unavailable variants.
 replace("  return items.map(function(item) {\n    const id = String(item.idVariacion", "  return aggregateLines(items).map(function(item) {\n    const id = String(item.idVariacion");
 replace("    const qty = Number(item.cantidad || item.qty || item.quantity || 1);", "    const qty = Number(item.cantidad ?? item.qty ?? item.quantity ?? 1);");
 replace("    let price = toNumber_(product[wholesale ? 'Precio Mayor' : 'Precio']);",`    const stock=Number(product.Cantidad ?? product.Stock ?? 0);
    if(!Number.isFinite(stock)||stock<qty||/inactivo|eliminado|borrador/i.test(product.Estado||''))throw Error('No hay existencias suficientes para '+id+'.');
    let price = toNumber_(product[wholesale ? 'Precio Mayor' : 'Precio']);`);
 // MP must never turn pending/hidden prices into zero-price checkout items.
 replace("  const items = securityCatalogItems_(Array.isArray(rawItems) ? rawItems : parseMaybeJson_(rawItems), false);",`  const items = securityCatalogItems_(Array.isArray(rawItems) ? rawItems : parseMaybeJson_(rawItems), false);
  if(['0','false'].includes(String(getConfigValue_('Mercado_Pago_Publico_Activo','1')).toLowerCase()) || ['1','true'].includes(String(getConfigValue_('Catalogo_Solo_WhatsApp','0')).toLowerCase()))return json_({ok:false,status:'error',error:'El pago en línea está deshabilitado. Solicita una cotización.'});
  if(['0','false'].includes(String(getConfigValue_('Mostrar_Precios_Minorista','1')).toLowerCase()) || items.some(item=>!Number.isFinite(item.precio)||item.precio<=0)) return json_({ok:false,status:'error',error:'Hay precios pendientes. Solicita una cotización.'});`);
 const helpers=`
function workflowReceiptOrder_(order){
 const copy={...order};delete copy['Clave Idempotencia'];delete copy['Huella Solicitud'];
 copy['Productos JSON']=parseMaybeJson_(order['Productos JSON']).map(item=>{const p={...item};delete p.precioCatalogo;return p;});return copy;
}
function workflowSafeOrder_(order){
 const copy=workflowReceiptOrder_(order);
 for(const key of ['Nombre Cliente','Teléfono','Telefono','Email','Dirección','Direccion','Ciudad','Nota Cliente','ID Cliente'])delete copy[key];return copy;
}
function workflowInvoiceGuard_(invoice){
 const existing=invoice['ID Factura']?getById_('Facturas',invoice['ID Factura']):null;
 const ref=invoice['ID Pedido']||existing?.['ID Pedido'];
 if(ref&&orderKind(getById_('Pedidos',String(ref))||{})==='quote')throw Error('Convierte primero la cotización aceptada antes de facturar.');
}
`;
 // Helpers stay inside createController's scope.
 const tail='return {handle:handleRequest_,changes:()=>Object.values(sbContext_).map(s=>s.changes())};';
 replace(tail,helpers+'\n'+tail);
 return "import {orderWorkflow,workflowHeaders,aggregateLines,protectWorkflowWrite,orderKind} from './order-workflow.js';\n"+source;
};
