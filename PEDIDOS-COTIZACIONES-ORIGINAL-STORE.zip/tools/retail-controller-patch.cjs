// Post-generation integration, kept separate from the legacy controller source.
module.exports = function retailControllerPatch(source) {
  source = source.replace(/\r\n/g, '\n');
  function replace(before, after) {
    if (!source.includes(before)) throw new Error('Retail pricing generator integration changed: ' + before.slice(0, 70));
    source = source.replace(before, after);
  }
  replace("      'Precio Mayor',", "      'Precio Mayor',\n      'Modo Precio Minorista',");
  replace('      const val = body.Valor || params.Valor;', "      const val = body.Valor ?? params.Valor;\n      if(key === RETAIL_PERCENT_KEY) {percentage(val);retailPercentCache=undefined;}");
  replace('    let value = data[key];', "    let value = data[key];\n    if(sheetName === 'Productos' && header === RETAIL_MODE_KEY && !['manual','porcentaje'].includes(value)) throw new Error('Elige precio manual o porcentaje.');");
  replace('  return obj;\n}\n\nfunction getObjectValueByHeader_', "  if(headers.includes('Precio') && headers.includes('Precio Mayor')) resolveRetailProduct_(obj);\n  return obj;\n}\n\nfunction getObjectValueByHeader_");
  // Resolve both full creates and merged partial updates before writing rows.
  for (const [object, indent] of [['existing.data', '        '], ['current', '      '], ['current', '  ']]) {
    const name = object === 'existing.data' || indent.length === 6 ? 'mergedRow' : 'row';
    const line = `${indent}const ${name} = headers.map(header => getObjectValueByHeader_(${object}, header, ''));`;
    replace(line, `${indent}if(sheetName === 'Productos') resolveRetailProduct_(${object});\n${line}`);
  }
  source = source.replace(/^(\s*)const row = headers\.map\(header => getObjectValueByHeader_\(rowObject, header, ''\)\);/gm, (line, spaces) => `${spaces}if(sheetName === 'Productos') resolveRetailProduct_(rowObject);\n${line}`);
  replace('/* @noble/hashes', `let retailPercentCache;
function resolveRetailProduct_(product){
  if(retailPercentCache === undefined) retailPercentCache = getConfigValue_(RETAIL_PERCENT_KEY,'0');
  return applyRetailPricing(product,retailPercentCache);
}
/* @noble/hashes`);
  return "import {applyRetailPricing,percentage,RETAIL_MODE_KEY,RETAIL_PERCENT_KEY} from './retail-pricing.js';\n" + source;
};
