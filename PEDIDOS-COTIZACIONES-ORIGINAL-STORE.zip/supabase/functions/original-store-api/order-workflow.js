import {createHash} from 'node:crypto';
const hash=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
export const workflowHeaders=['Tipo Solicitud','Origen Solicitud','Estado Cotizacion','Version Pedido','Clave Idempotencia','Huella Solicitud','Total Estimado','Precios Pendientes','Cliente Acepto','Fecha Aceptacion'];
export function orderKind(order={}){
 if(['wholesale','quote','retail'].includes(order['Tipo Solicitud']))return order['Tipo Solicitud'];
 if(/consulta|cotiza/i.test([order['Estado Pedido'],order['Método Contacto'],order['Metodo Contacto']].join(' ')))return 'quote';
 return /mayor|wholesale/i.test(order['Tipo Cliente']||'')?'wholesale':'retail';
}
export function aggregateLines(items){
 if(!Array.isArray(items)||!items.length||items.length>100)throw Error('Selecciona entre 1 y 100 referencias.');
 const map=new Map();
 for(const item of items){
  const id=String(item?.idVariacion??item?.['ID Variación']??item?.['ID Variacion']??item?.id??item?.sku??'').trim();
  const qty=Number(item?.cantidad??item?.qty??item?.quantity??1);
  if(!id||id.length>160||!Number.isSafeInteger(qty)||qty<1||qty>1000)throw Error('La referencia o la cantidad no es válida.');
  const prior=map.get(id);if(prior){prior.cantidad+=qty;if(prior.cantidad>1000)throw Error('La cantidad acumulada supera 1000 unidades.');}
  else map.set(id,{...item,idVariacion:id,cantidad:qty});
 }
 return [...map.values()];
}
const parse=value=>{if(Array.isArray(value))return value;try{return JSON.parse(value);}catch{return [];}};
const flag=(value,fallback=true)=>value===undefined||value===null||value===''?fallback:['true','1','si'].includes(String(value).toLowerCase());
function positivePrice(value){if(value===null||value===undefined||String(value).trim()==='')return null;const n=Number(value);if(!Number.isFinite(n)||n<=0||n>1e9)throw Error('Cada precio debe ser mayor que cero y no superar 1.000.000.000.');return Math.round(n*100)/100;}
function totals(items){const missing=items.filter(p=>p.precio===null).length,total=items.reduce((sum,p)=>sum+(p.precio??0)*p.cantidad,0);if(!Number.isFinite(total)||total>Number.MAX_SAFE_INTEGER)throw Error('El importe de la solicitud es demasiado grande.');return {'Productos JSON':JSON.stringify(items),Subtotal:total,'Total Estimado':total,'Precios Pendientes':missing,'Cantidad Total':items.reduce((sum,p)=>sum+p.cantidad,0)};}
export function protectWorkflowWrite({sheet,action,data,find}){
 const list=Array.isArray(data)?data:[data||{}];
 if(sheet==='Facturas')for(const input of list){const ref=input['ID Pedido']||input.idPedido;if(ref&&orderKind(find(String(ref))||{})==='quote')throw Error('Primero revisa y convierte la cotización aceptada antes de facturar.');}
 if(sheet==='Pedidos'&&['actualizar','update','editar','editproduct','estado','updateestado','batchsave','guardarlote','batch','crear','create','agregar',''].includes(action))for(const input of list){
  const ref=input['ID Pedido']||input.id||input.__workflowTargetId;const order=ref?find(String(ref)):null;
  if(order&&order['Version Pedido']&&['Productos JSON','Subtotal','Tipo Solicitud','Estado Cotizacion','Cliente Acepto','Version Pedido','Clave Idempotencia','Huella Solicitud'].some(k=>Object.hasOwn(input,k)))throw Error('Esta solicitud debe modificarse mediante su revisión con control de versión.');
  if(orderKind(input)==='quote'||(order&&orderKind(order)==='quote'))throw Error('Utiliza Revisar cotización para modificar esta solicitud.');
 }
}
export async function orderWorkflow(action,body,api,admin){
 if(!['submitrequest','reviewquote','convertquote'].includes(action))return null;
 try{
  if(action==='submitrequest'){
   const key=String(body.idempotencyKey||'');if(!/^[a-zA-Z0-9_-]{24,100}$/.test(key))throw Error('Falta la clave de reintento. Vuelve a abrir el resumen.');
   const c=body.cliente||{},name=String(c.nombre||'').trim(),phone=String(c.telefono||'').replace(/\D/g,'');
   if(!name||name.length>150||!/^\d{7,15}$/.test(phone))throw Error('Escribe tu nombre y un celular válido.');
   const clean={nombre:name,telefono:phone};for(const field of ['email','direccion','ciudad','nota'])clean[field]=String(c[field]||'').trim().slice(0,field==='nota'?2000:300);
   if(clean.email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(clean.email))throw Error('Revisa el correo o déjalo vacío.');
   const lines=aggregateLines(body.items),wholesale=body.mode==='wholesale';
   const digest=hash({customer:clean,wholesale,lines:lines.map(p=>({id:p.idVariacion,qty:p.cantidad})).sort((a,b)=>a.id.localeCompare(b.id))});
   const keyHash=hash(key),prior=api.list().find(p=>p['Clave Idempotencia']===keyHash);
   if(prior){if(prior['Huella Solicitud']!==digest)throw Error('La clave de reintento pertenece a otra selección. Revisa los productos antes de enviar.');return {ok:true,status:'success',data:api.safe(prior),receipt:api.receipt(prior,body.token),replayed:true};}
   const priced=api.catalog(lines,wholesale); // canonical server prices, promotions and accumulated stock
   const visible=wholesale||flag(api.config('Mostrar_Precios_Minorista','1'));
   const kind=wholesale?'wholesale':'quote'; // This endpoint is for requests; online purchases retain createpreference.
   const items=priced.map(p=>({...p,precio:visible&&Number(p.precio)>0?Number(p.precio):null,precioEstado:visible&&Number(p.precio)>0?(kind==='quote'?'Estimado':''):'Por cotizar',precioCatalogo:Number(p.precio)||0}));
   const order=api.create({'ID Pedido':api.id(wholesale?'MAY':'COT'),Fecha:new Date(),'Nombre Cliente':name,'Teléfono':phone,Email:clean.email,'Dirección':clean.direccion,Ciudad:clean.ciudad,'Nota Cliente':clean.nota,'Tipo Cliente':wholesale?'Mayor':'Detal','Tipo Solicitud':kind,'Origen Solicitud':kind,'Estado Cotizacion':kind==='quote'?'Pendiente':'','Estado Pedido':kind==='quote'?'Cotización pendiente':'Pedido mayorista pendiente','Método Contacto':'Solicitud registrada en el sistema','Stock Descontado':'NO','Version Pedido':1,'Clave Idempotencia':keyHash,'Huella Solicitud':digest,...totals(items)});
   return {ok:true,status:'success',data:api.safe(order),receipt:api.receipt(order,body.token)};
  }
  if(!admin)throw Error('Inicia sesión con una cuenta administradora.');
  const order=api.find(String(body.orderId||''));if(!order||orderKind(order)!=='quote')throw Error('La cotización no existe o ya fue convertida.');
  const version=Number(order['Version Pedido']||1);if(!Number.isInteger(body.expectedVersion)||body.expectedVersion!==version)throw Error('Otra persona modificó la cotización. Vuelve a abrirla antes de guardar.');
  if(action==='convertquote'&&body.accepted!==true)throw Error('Marca que el cliente aceptó antes de convertir la cotización.');
  // Convert exactly the last saved review. Unsaved browser edits cannot be silently accepted.
  if(action==='convertquote'&&order['Estado Cotizacion']!=='Revisada')throw Error('Guarda y revisa los precios de la cotización antes de convertir.');
  const raw=action==='reviewquote'?body.items:parse(order['Productos JSON']);
  const grouped=aggregateLines(raw);
  const catalog=api.catalog(grouped,false),prices=new Map();
  for(const p of raw){const k=String(p.idVariacion||p.id||p.sku||'').trim(),price=positivePrice(p.precio);if(prices.has(k)&&prices.get(k)!==price)throw Error('Una misma referencia tiene precios diferentes.');prices.set(k,price);}
  const items=catalog.map(p=>{
   const price=prices.get(p.idVariacion)??null,old=grouped.find(x=>x.idVariacion===p.idVariacion);
   if(action==='convertquote'){
    if(price===null)throw Error('Completa los precios pendientes antes de convertir.');
    if(Number(old.precioCatalogo)!==Number(p.precio))throw Error('El precio de catálogo cambió. Revisa nuevamente la cotización con el cliente.');
   }
   return {...p,precio:price,precioEstado:price===null?'Por cotizar':action==='convertquote'?'Confirmado':'Estimado',precioCatalogo:Number(p.precio)||0};
  });
  const converted=action==='convertquote';
  const updated=api.update(order['ID Pedido'],{...totals(items),'Version Pedido':version+1,'Estado Cotizacion':converted?'Aceptada':'Revisada','Tipo Solicitud':converted?'retail':'quote','Origen Solicitud':'quote','Estado Pedido':converted?'Pedido minorista pendiente':'Cotización revisada','Stock Descontado':'NO','Cliente Acepto':converted?'SI':'NO','Fecha Aceptacion':converted?new Date().toISOString():''});
  api.refreshReceipt(updated);
  return {ok:true,status:'success',data:updated};
 }catch(error){return {ok:false,status:'error',error:error.message};}
}
