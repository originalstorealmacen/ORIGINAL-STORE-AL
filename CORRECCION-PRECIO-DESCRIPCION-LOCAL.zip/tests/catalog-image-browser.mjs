import http from 'node:http';import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import {createRequire} from 'node:module';import assert from 'node:assert/strict';import {fixture} from './fixtures/order-lookup-api.mjs';
const root=fileURLToPath(new URL('../',import.meta.url)),{chromium}=createRequire(import.meta.url)('C:/Users/kevin/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');let f;
const references=[],submissions=[];let dropNext=false,paymentBody;
const server=http.createServer(async(req,res)=>{try{
 const u=new URL(req.url,'http://localhost');
 if(u.pathname==='/api'){let body='';for await(const part of req)body+=part;if(body){const b=JSON.parse(body);if(b.action==='publicreference')references.push(b.reference);if(b.action==='submitrequest')submissions.push(b);}
  const response=await f.handler(new Request('https://test.invalid'+req.url,{method:req.method,headers:{Origin:req.headers.origin||'',...(body?{'Content-Type':'text/plain;charset=utf-8'}:{})},...(body?{body}: {})}));if(body&&JSON.parse(body).action==='submitrequest'&&dropNext){dropNext=false;res.writeHead(503,{'Content-Type':'application/json'});res.end(JSON.stringify({ok:false,error:'Respuesta interrumpida después de registrar. Reintenta.'}));return;}res.writeHead(response.status,Object.fromEntries(response.headers));res.end(await response.text());return;}
 if(u.pathname==='/original-store-catalog-bootstrap.js'){res.writeHead(200,{'Content-Type':'text/javascript'});res.end('window.ORIGINAL_STORE_CATALOG_BOOTSTRAP={rows:[],config:{}};');return;}
 if(u.pathname==='/backend-config.js'){res.writeHead(200,{'Content-Type':'text/javascript'});res.end("window.ORIGINAL_STORE_API_URL=location.origin+'/api';");return;}
 if(u.pathname==='/mock-payment'){res.writeHead(200,{'Content-Type':'text/html'});res.end('<h1>Pago simulado</h1>');return;}
 const name=u.pathname.slice(1)||'administrativo.html';if(path.basename(name)!==name||name.includes('private')||!/^[-a-zA-Z0-9_.]+\.(html|js|css|png|svg|webp)$/.test(name)||!fs.existsSync(root+name)){res.writeHead(404);res.end();return;}
 const types={'.html':'text/html;charset=utf-8','.js':'text/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml'};res.writeHead(200,{'Content-Type':types[path.extname(name)]||'application/octet-stream'});res.end(fs.readFileSync(root+name));
 }catch(error){res.writeHead(500);res.end(error.message);}});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const url='http://127.0.0.1:'+server.address().port;f=fixture({env:{ORIGINAL_STORE_ALLOWED_ORIGINS:url+',https://aloriginalstore.online',MERCADO_PAGO_ACCESS_TOKEN:'TEST-FAKE-PAYMENT-TOKEN'},fetcher:async(target,options)=>{if(String(target).includes('mercadopago.com/checkout/preferences')){paymentBody=JSON.parse(options.body);return Response.json({id:'TEST-PREFERENCE',init_point:url+'/mock-payment'});}return Response.json({});}});

const errors=[],browser=await chromium.launch({channel:'msedge',headless:true});
const api=body=>f.post(body),auth={adminCredential:'TEST-GOOGLE-ID'};
async function setup(mobile=false){
 const context=await browser.newContext(mobile?{viewport:{width:390,height:844},isMobile:true,hasTouch:true}:{});
 await context.route('**/*',async route=>{
  const address=route.request().url();
  if(address.startsWith(url))return route.continue();
  if(address.startsWith('https://accounts.google.com/gsi/client'))return route.fulfill({contentType:'text/javascript',body:`window.google={accounts:{id:{initialize(o){window.fixtureGoogle=o.callback;},renderButton(element){const b=document.createElement('button');b.type='button';b.textContent='Entrar prueba';b.onclick=()=>fixtureGoogle({credential:'fixture.'+btoa(JSON.stringify({email:'originalstorealmacen@gmail.com',exp:Math.floor(Date.now()/1000)+7200}))+'.signature'});element.append(b);}}}};`});
  return route.abort();
 });
 const page=await context.newPage();page.setDefaultTimeout(12000);await page.clock.install({time:new Date()});page.on('pageerror',e=>{errors.push(e.message);console.log('ERROR',e.message);});await page.goto(url);await page.getByRole('button',{name:'Entrar prueba',exact:true}).click();
 await page.waitForFunction(()=>document.getElementById('admin-main-content').style.display!=='none'&&window.OriginalStoreProductIdentity);
 await page.evaluate(()=>switchDashboardView('products','Productos'));await page.locator('#prod-id-producto').waitFor({state:'visible'});return {context,page};
}
async function storefront(mobile=false){const context=await browser.newContext(mobile?{viewport:{width:390,height:844},isMobile:true,hasTouch:true}:{viewport:{width:1440,height:1000}});await context.route('**/*',route=>route.request().url().startsWith(url)?route.continue():route.abort());const page=await context.newPage();page.setDefaultTimeout(15000);page.on('pageerror',e=>{errors.push(e.message);console.log('PAGEERROR',e.message);});page.on('dialog',async d=>{console.log('DIALOG',d.message());await d.dismiss();});return {context,page};}
async function detail(page,wholesale=false){await page.goto(url+'/producto.html?ref=TEST-V1'+(wholesale?'&catalogo=mayorista':''));await page.waitForFunction(()=>document.querySelector('#btn-add-to-cart-detail')?.onclick&&allProducts.length>0);}
async function summary(page,wholesale=false){await page.goto(url+'/carrito.html?modo='+(wholesale?'mayorista':'minorista'));await page.waitForFunction(()=>cart.length>0&&document.getElementById('btn-cart-sec-checkout'));await page.locator('#cart-sec-nombre').fill('Cliente de prueba');await page.locator('#cart-sec-telefono').fill('3001234567');}
f.data.Productos.rows[0].record={'ID Variación':'GROUP-V01','ID Producto':'GROUP','Nombre del Producto':'Principal prueba',Precio:12000,'Precio Mayor':10000,Cantidad:0,'Imagen Principal':'https://lh3.googleusercontent.com/d/REGISTERED_MAIN=w1200'};
f.data.Productos.rows.push({id:'2',position:3,record:{'ID Variación':'GROUP-V02','ID Producto':'GROUP','Nombre del Producto':'Variante prueba',Precio:14000,'Precio Mayor':11000,Cantidad:10,'Imagen Principal':'https://lh3.googleusercontent.com/d/OTHER_VARIANT=w1200'}});
f.data.Productos.rows.push({id:'3',position:4,record:{'ID Variación':'BROKEN-V01','ID Producto':'BROKEN','Nombre del Producto':'Imagen fallida prueba',Precio:15000,'Precio Mayor':10000,Cantidad:5,'Imagen Principal':'https://lh3.googleusercontent.com/d/BROKEN_FILE=w1200'}});
const svg='<svg xmlns="http://www.w3.org/2000/svg" width="400" height="400"><rect width="400" height="400" fill="#cc99aa"/></svg>';
try{
 await api({action:'setconfig',Clave:'Mostrar_Precios_Minorista',Valor:'1',...auth});await api({action:'setconfig',Clave:'Mercado_Pago_Publico_Activo',Valor:'0',...auth});
 const {page,context}=await storefront();
 await context.route(/https:\/\/(lh3\.googleusercontent\.com|drive\.google\.com)\//,route=>route.request().url().includes('BROKEN_FILE')?route.fulfill({status:404,body:''}):route.fulfill({contentType:'image/svg+xml',body:svg}));
 await page.goto(url+'/index.html#coleccion');await page.waitForFunction(()=>allProducts.some(p=>p.idVariacion==='GROUP-V01'));
 const card=page.locator('#products-grid .product-card').filter({hasText:'Principal prueba'});await card.waitFor({state:'visible'});
 const image=card.locator('.product-card-img img');assert.match(await image.getAttribute('src'),/REGISTERED_MAIN/);assert.equal(await card.locator('.catalog-add-btn').textContent().then(x=>x.trim()),'Elegir variante');
 const chosen=await card.getAttribute('data-index');assert.equal(await page.evaluate(i=>allProducts[Number(i)].idVariacion,chosen),'GROUP-V01');
 const broken=page.locator('#products-grid .product-card').filter({hasText:'Imagen fallida prueba'}).locator('.product-card-img img');await broken.evaluate(el=>el.scrollIntoView({block:'center'}));await page.waitForFunction(()=>document.querySelector('img[data-image-unavailable="true"]'));
 assert.match(await broken.getAttribute('src'),/product-image-placeholder.svg/);assert.ok(!(await broken.getAttribute('src')).includes('1tab2v6'));
 for(const width of [360,390,768]){
  await page.setViewportSize({width,height:844});await card.evaluate(el=>el.scrollIntoView({block:'center'}));const estimate=card.locator('.product-price-estimate');await estimate.waitFor({state:'visible'});
  const sizes=await estimate.evaluate(el=>({small:parseFloat(getComputedStyle(el).fontSize),price:parseFloat(getComputedStyle(el.parentElement).fontSize)}));assert.ok(sizes.small<sizes.price);assert.ok(sizes.small<=11);
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1),false);
  const rect=await card.boundingBox();assert.ok(rect.x>=-1&&rect.x+rect.width<=width+1);
  assert.ok(await card.locator('.product-card-info').evaluate(el=>el.scrollWidth<=el.clientWidth+1));
 }
 await page.setViewportSize({width:390,height:844});await card.evaluate(el=>el.scrollIntoView({block:'center'}));await page.screenshot({path:root+'.supabase-server-private/catalog-image-mobile.png'});
 console.log('PASS catalogue: principal photo kept despite variant stock, explicit variant choice, same-file fallback then neutral placeholder, small estimates and no overflow at 360/390/768px');
 const {page:admin}=await setup();await admin.evaluate(()=>{window.pendingUploads={};uploadCarouselImage=file=>new Promise((resolve,reject)=>pendingUploads[file.name]={resolve,reject});});
 const png=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jV2kAAAAASUVORK5CYII=','base64');
 async function select(name){await admin.locator('#prod-image-file').setInputFiles({name,mimeType:'image/png',buffer:png});await admin.waitForFunction(name=>!!pendingUploads[name],name);}
 await admin.locator('#prod-imagen').evaluate(el=>{for(let p=el.parentElement;p;p=p.parentElement)if(p.tagName==='DETAILS')p.open=true;});
 const field=admin.locator('#prod-imagen');await field.fill('https://lh3.googleusercontent.com/d/OLD_IMAGE=w1200');await select('first.png');assert.equal(await field.getAttribute('data-upload-state'),'uploading');
 assert.match(await admin.evaluate(()=>{try{normalizeProductPayloadForSubmit(buildProductPayload());return '';}catch(e){return e.message;}}),/imagen principal/);
 await admin.evaluate(()=>pendingUploads['first.png'].resolve('https://lh3.googleusercontent.com/d/FIRST_IMAGE=w1200'));await admin.waitForFunction(()=>document.getElementById('prod-imagen').dataset.uploadState==='ready');assert.match(await field.inputValue(),/FIRST_IMAGE/);
 await select('failed.png');await admin.evaluate(()=>pendingUploads['failed.png'].reject(Error('Fallo simulado')));await admin.waitForFunction(()=>document.getElementById('prod-imagen').dataset.uploadState==='failed');assert.match(await field.inputValue(),/FIRST_IMAGE/);assert.equal(await field.evaluate(el=>el.validity.customError),true);assert.equal(await admin.locator('#preview-img-el').getAttribute('data-local-preview-src'),null);
 await field.fill('https://lh3.googleusercontent.com/d/MANUAL_IMAGE=w1200');assert.equal(await field.evaluate(el=>el.validity.customError),false);
 await select('older.png');await select('latest.png');await admin.evaluate(()=>pendingUploads['older.png'].resolve('https://lh3.googleusercontent.com/d/STALE_UPLOAD=w1200'));assert.ok(!(await field.inputValue()).includes('STALE_UPLOAD'));
 await admin.evaluate(()=>pendingUploads['latest.png'].resolve('https://lh3.googleusercontent.com/d/LATEST_UPLOAD=w1200'));await admin.waitForFunction(()=>document.getElementById('prod-imagen').value.includes('LATEST_UPLOAD'));
 const payload=await admin.evaluate(()=>{document.getElementById('prod-nombre').value='Nuevo registro imagen';document.getElementById('prod-stock-inicial').value='5';return normalizeProductPayloadForSubmit(buildProductPayload());});assert.match(payload['Imagen Principal'],/LATEST_UPLOAD/);assert.equal(payload.Imagen,payload['Imagen Principal']);
 const saved=await api({resource:'productos',action:'crear',data:payload,...auth});assert.equal(saved.ok,true,JSON.stringify(saved));const record=saved.data;assert.match(record['Imagen Principal'],/LATEST_UPLOAD/);
 await page.evaluate(()=>loadProducts({useCache:false,showLoading:false}));await page.waitForFunction(()=>allProducts.some(p=>p.Nombre==='Nuevo registro imagen'));const registered=page.locator('#products-grid .product-card').filter({hasText:'Nuevo registro imagen'});await registered.evaluate(el=>el.scrollIntoView({block:'center'}));await page.waitForFunction(()=>[...document.querySelectorAll('#products-grid .product-card')].find(el=>el.textContent.includes('Nuevo registro imagen'))?.querySelector('img')?.src.includes('LATEST_UPLOAD'));assert.match(await registered.locator('.product-card-img img').getAttribute('src'),/LATEST_UPLOAD/);
 await select('reset.png');await admin.evaluate(()=>resetProductForm());await admin.evaluate(()=>pendingUploads['reset.png'].resolve('https://lh3.googleusercontent.com/d/AFTER_RESET=w1200'));assert.equal(await field.inputValue(),'');assert.equal(f.data.Pedidos.rows.length,0);assert.equal(f.data.Facturas.rows.length,0);assert.deepEqual(errors,[]);
 console.log('PASS registration: pending/failed photos block saving, manual URL recovers, latest selection wins, saved photo matches catalogue, reset ignores late uploads; mocked products only');
}finally{await browser.close();server.close();}
