import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url));
const {chromium}=createRequire(import.meta.url)('C:/Users/kevin/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const real=process.argv.includes('--public-snapshot');
const snapshot=real?JSON.parse(fs.readFileSync(root+'.supabase-server-private/public-catalog-client-check.json','utf8')):{catalog:{data:[{'ID Variación':'CLIENT-V01','ID Producto':'CLIENT','Nombre del Producto':'Peluche de prueba','Categoría':'Peluches',Precio:22000,'Precio Mayor':15000,Cantidad:8,'Características del producto':'Peluche suave de 30 cm.','Imagen Principal':'https://lh3.googleusercontent.com/d/CLIENT_IMAGE=w1200'},{'ID Variación':'CLIENT2-V01','ID Producto':'CLIENT2','Nombre del Producto':'Accesorio sin descripción','Categoría':'Accesorios',Precio:5000,'Precio Mayor':3000,Cantidad:4,'Imagen Principal':'https://lh3.googleusercontent.com/d/CLIENT2_IMAGE=w1200'},{'ID Variación':'CLIENT3-V01','ID Producto':'CLIENT3','Nombre del Producto':'Producto por cotizar','Categoría':'Accesorios',Precio:0,Cantidad:4,'Características del producto':'Consulta las opciones disponibles.'}]},config:{status:'success',config:{Mostrar_Precios_Minorista:1,Mercado_Pago_Publico_Activo:0}}};
const rawRows=Array.isArray(snapshot.catalog)?snapshot.catalog:snapshot.catalog.data||snapshot.catalog.productos;
let legacy=false,reads=0,writes=0;
const server=http.createServer(async(req,res)=>{
 try{
  if(req.method!=='GET'){writes++;res.writeHead(405);res.end('Read-only customer check');return;}
  const u=new URL(req.url,'http://localhost');
  if(u.pathname==='/api'){reads++;res.setHeader('Content-Type','application/json');res.end(JSON.stringify(u.searchParams.get('action')==='get_config'?snapshot.config:snapshot.catalog));return;}
  if(u.pathname==='/backend-config.js'){res.setHeader('Content-Type','text/javascript');res.end("window.ORIGINAL_STORE_API_URL=location.origin+'/api';");return;}
  if(u.pathname==='/original-store-catalog-bootstrap.js'){res.setHeader('Content-Type','text/javascript');res.end('window.ORIGINAL_STORE_CATALOG_BOOTSTRAP={rows:[],config:{}}');return;}
  const name=u.pathname.slice(1)||'index.html';
  if(name!==path.basename(name)||/private|\.env/i.test(name)||!fs.existsSync(root+name)){res.writeHead(404);res.end();return;}
  const ext=path.extname(name);res.setHeader('Content-Type',({'.html':'text/html;charset=utf-8','.js':'text/javascript','.css':'text/css','.svg':'image/svg+xml'})[ext]||'application/octet-stream');
  let content=fs.readFileSync(root+name);
  if(legacy&&ext==='.html'){
   // Exact published product HTML omitted order-flow.js, leaving the sample title/$0.
   if(real&&name==='producto.html')content=fs.readFileSync(root+'.supabase-server-private/published-product-before-price-fix.html');
   content=content.toString().replace(/<script\b[^>]*src=["']order-flow\.js[^"']*["'][^>]*>\s*<\/script>/gi,'');
  }
  res.end(content);
 }catch(e){res.writeHead(500);res.end(e.message);}
});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+server.address().port;
const browser=await chromium.launch({channel:'msedge',headless:true});const errors=[];
try{
 for(const oldHtml of [true,false]){
  legacy=oldHtml;
  for(const mobile of [false,true]){
   const context=await browser.newContext({viewport:mobile?{width:390,height:844}:{width:1440,height:1000},...(mobile?{isMobile:true,hasTouch:true}:{})});
   await context.route('**/*',route=>{const req=route.request();if(!['GET','HEAD','OPTIONS'].includes(req.method())){writes++;return route.abort();}if(req.url().startsWith(origin))return route.continue();if(/drive\.google\.com|lh3\.googleusercontent\.com/.test(req.url()))return route.fulfill({contentType:'image/svg+xml',body:'<svg xmlns="http://www.w3.org/2000/svg" width="400" height="400"><rect width="400" height="400" fill="#c599aa"/></svg>'});return route.abort();});
   const catalog=await context.newPage();catalog.on('pageerror',e=>errors.push(e.stack));
   await catalog.goto(origin+'/index.html#coleccion');
   await catalog.evaluate(async()=>{await loadProducts({useCache:false,showLoading:false});await fetchSiteConfig({force:true});renderCatalogProducts();});
   await catalog.locator('#products-grid .product-card').first().waitFor();
   while(await catalog.locator('#products-grid .catalog-load-more').count())await catalog.locator('#products-grid .catalog-load-more').click();
   const cards=await catalog.locator('#products-grid .product-card').evaluateAll(nodes=>nodes.map(el=>({ref:el.dataset.productRef,name:el.querySelector('.product-card-name').textContent,price:el.querySelector('.product-price-current')?.textContent.replace(/estimado/g,'').trim()})));
   assert.ok(cards.length>0);
   // Use the actual card click for the first product; open every remaining card target in the detail tab.
   const detail=await context.newPage();detail.on('pageerror',e=>errors.push(e.stack));
   const [navigation]=await Promise.all([catalog.waitForURL('**/producto.html?*'),catalog.locator('#products-grid .product-card-info').first().click()]);
   await catalog.waitForFunction(()=>document.querySelector('#btn-add-to-cart-detail')?.onclick);
   assert.ok(!(await catalog.locator('#detail-name').textContent()).includes('Nombre del Producto'));
   let described=0,pending=0;
   for(const card of cards){
    assert.ok(card.ref,'Each card must identify the product by reference');
    await detail.goto(origin+'/producto.html?ref='+encodeURIComponent(card.ref));
    await detail.waitForFunction(()=>document.querySelector('#btn-add-to-cart-detail')?.onclick);
    const actual=await detail.evaluate(()=>({ref:new URLSearchParams(location.search).get('ref'),name:document.querySelector('#detail-name').textContent,price:document.querySelector('#detail-price').textContent,description:document.querySelector('#detail-desc').textContent,image:document.querySelector('#detail-img').getAttribute('src')}));
    assert.equal(actual.ref,card.ref);assert.equal(actual.name,card.name,card.ref);
    if(card.price)assert.ok(actual.price.includes(card.price),card.ref+': '+actual.price+' / '+card.price);else{assert.ok(actual.price==='Por cotizar'||/\$[1-9]/.test(actual.price));pending++;}
    const row=rawRows.find(p=>String(p['ID Variación']||p.idVariacion||p.SKU)===actual.ref);assert.ok(row,actual.ref);
    const desc=String(row['Características del producto']||row.Descripcion||row.descripcion||'').trim();
    assert.equal(actual.description,desc||'Sin descripcion disponible.',actual.ref);if(desc)described++;
    await detail.locator('.detail-description-accordion summary').click();assert.equal(await detail.locator('#detail-desc').isVisible(),true);
    assert.ok(!actual.price.includes('Cargando'));assert.ok(!actual.description.includes('Cargando detalles'));
    if(mobile)assert.equal(await detail.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1),false,actual.ref);
   }
   console.log(JSON.stringify({html:oldHtml?'published/missing module':'current',device:mobile?'mobile':'desktop',cards:cards.length,descriptions:described,withoutPrice:pending,status:'PASS'}));
   await context.close();
  }
 }
 assert.deepEqual(errors,[]);assert.equal(writes,0);console.log('PASS customer reads only; '+reads+' mocked public GETs; no products/orders saved');
}finally{await browser.close();server.close();}
