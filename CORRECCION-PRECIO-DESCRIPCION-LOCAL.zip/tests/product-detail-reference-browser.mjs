import http from 'node:http';import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import {createRequire} from 'node:module';import assert from 'node:assert/strict';import {fixture} from './fixtures/order-lookup-api.mjs';
const root=fileURLToPath(new URL('../',import.meta.url)),{chromium}=createRequire(import.meta.url)('C:/Users/kevin/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');let f;
const references=[],submissions=[];let dropNext=false,paymentBody;
const server=http.createServer(async(req,res)=>{try{
 const u=new URL(req.url,'http://localhost');
 if(u.pathname==='/api'){let body='';for await(const part of req)body+=part;if(body){const b=JSON.parse(body);if(b.action==='publicreference')references.push(b.reference);if(b.action==='submitrequest')submissions.push(b);}
  const response=await f.handler(new Request('https://test.invalid'+req.url,{method:req.method,headers:{Origin:req.headers.origin||'',...(body?{'Content-Type':'text/plain;charset=utf-8'}:{})},...(body?{body}: {})}));if(body&&JSON.parse(body).action==='submitrequest'&&dropNext){dropNext=false;res.writeHead(503,{'Content-Type':'application/json'});res.end(JSON.stringify({ok:false,error:'Respuesta interrumpida después de registrar. Reintenta.'}));return;}res.writeHead(response.status,Object.fromEntries(response.headers));res.end(await response.text());return;}
 if(u.pathname==='/original-store-catalog-bootstrap.js'){res.writeHead(200,{'Content-Type':'text/javascript'});res.end('window.ORIGINAL_STORE_CATALOG_BOOTSTRAP={rows:[],config:{}};');return;}
 if(u.pathname==='/backend-config.js'){res.writeHead(200,{'Content-Type':'text/javascript'});res.end("window.ORIGINAL_STORE_API_URL=location.origin+'/api';");return;}
 if(u.pathname==='/mock-payment'){res.writeHead(200,{'Content-Type':'text/html'});res.end('<h1>Pago simulado</h1>');return;}
 const name=u.pathname.slice(1)||'administrativo.html';if(path.basename(name)!==name||name.includes('private')||!/^[-a-zA-Z0-9_.]+\.(html|js|css|png|svg|webp)$/.test(name)||!fs.existsSync(root+name)){res.writeHead(404);res.end();return;}
 const types={'.html':'text/html;charset=utf-8','.js':'text/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml'};res.writeHead(200,{'Content-Type':types[path.extname(name)]||'application/octet-stream'});res.end(fs.readFileSync(root+name));
 }catch(error){res.writeHead(500);res.end(error.message);}});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const url='http://127.0.0.1:'+server.address().port;f=fixture({env:{ORIGINAL_STORE_ALLOWED_ORIGINS:url+',https://aloriginalstore.online',MERCADO_PAGO_ACCESS_TOKEN:'TEST-FAKE-PAYMENT-TOKEN'},fetcher:async(target,options)=>{if(String(target).includes('mercadopago.com/checkout/preferences')){paymentBody=JSON.parse(options.body);return Response.json({id:'TEST-PREFERENCE',init_point:url+'/mock-payment'});}return Response.json({});}});

const errors=[],browser=await chromium.launch({channel:'msedge',headless:true});
const api=body=>f.post(body),auth={adminCredential:'TEST-GOOGLE-ID'};
async function setup(mobile=false){
 const context=await browser.newContext(mobile?{viewport:{width:390,height:844},isMobile:true,hasTouch:true}:{});
 await context.route('**/*',async route=>{
  const address=route.request().url();
  if(address.startsWith(url))return route.continue();
  if(address.startsWith('https://accounts.google.com/gsi/client'))return route.fulfill({contentType:'text/javascript',body:`window.google={accounts:{id:{initialize(o){window.fixtureGoogle=o.callback;},renderButton(element){const b=document.createElement('button');b.type='button';b.textContent='Entrar prueba';b.onclick=()=>fixtureGoogle({credential:'fixture.'+btoa(JSON.stringify({email:'originalstorealmacen@gmail.com',exp:Math.floor(Date.now()/1000)+7200}))+'.signature'});element.append(b);}}}};`});
  return route.abort();
 });
 const page=await context.newPage();page.setDefaultTimeout(12000);await page.clock.install({time:new Date()});page.on('pageerror',e=>{errors.push(e.message);console.log('ERROR',e.message);});await page.goto(url);await page.getByRole('button',{name:'Entrar prueba',exact:true}).click();
 await page.waitForFunction(()=>document.getElementById('admin-main-content').style.display!=='none'&&window.OriginalStoreProductIdentity);
 await page.evaluate(()=>switchDashboardView('products','Productos'));await page.locator('#prod-id-producto').waitFor({state:'visible'});return {context,page};
}
async function storefront(mobile=false){const context=await browser.newContext(mobile?{viewport:{width:390,height:844},isMobile:true,hasTouch:true}:{viewport:{width:1440,height:1000}});await context.route('**/*',route=>route.request().url().startsWith(url)?route.continue():route.abort());const page=await context.newPage();page.setDefaultTimeout(15000);page.on('pageerror',e=>{errors.push(e.message);console.log('PAGEERROR',e.message);});page.on('dialog',async d=>{console.log('DIALOG',d.message());await d.dismiss();});return {context,page};}
async function detail(page,wholesale=false){await page.goto(url+'/producto.html?ref=TEST-V1'+(wholesale?'&catalogo=mayorista':''));await page.waitForFunction(()=>document.querySelector('#btn-add-to-cart-detail')?.onclick&&allProducts.length>0);}
async function summary(page,wholesale=false){await page.goto(url+'/carrito.html?modo='+(wholesale?'mayorista':'minorista'));await page.waitForFunction(()=>cart.length>0&&document.getElementById('btn-cart-sec-checkout'));await page.locator('#cart-sec-nombre').fill('Cliente de prueba');await page.locator('#cart-sec-telefono').fill('3001234567');}
f.data.Productos.rows[0].record={'ID Variación':'HELLO-V01','ID Producto':'HELLO','Nombre del Producto':'PELUCHE HELLO KITTY','Categoría':'Peluche',Precio:22000,'Precio Mayor':15000,Cantidad:8,'Imagen Principal':'https://lh3.googleusercontent.com/d/HELLO_PHOTO=w1200','Características del producto':'Peluche Hello Kitty suave de 30 cm.'};
f.data.Productos.rows.push({id:'2',position:3,record:{'ID Variación':'KUROMI-V01','ID Producto':'KUROMI','Nombre del Producto':'TERMO KUROMI','Categoría':'Botilos',Precio:48000,'Precio Mayor':35000,Cantidad:6,'Imagen Principal':'https://lh3.googleusercontent.com/d/KUROMI_PHOTO=w1200','Características del producto':'Termo Kuromi de 500 ml.'}});
const svg='<svg xmlns="http://www.w3.org/2000/svg" width="400" height="400"><rect width="400" height="400" fill="#cc99aa"/></svg>';
await api({action:'setconfig',Clave:'Mostrar_Precios_Minorista',Valor:'1',...auth});
await api({action:'setconfig',Clave:'Mercado_Pago_Publico_Activo',Valor:'0',...auth});
try{
 for(const mobile of [false,true]){
  const {context,page}=await storefront(mobile);await context.route(/https:\/\/(lh3\.googleusercontent\.com|drive\.google\.com)\//,r=>r.fulfill({contentType:'image/svg+xml',body:svg}));
  await page.goto(url+'/index.html#coleccion');await page.waitForFunction(()=>allProducts.length===2&&document.querySelectorAll('#products-grid .product-card').length===2);
  const card=page.locator('#products-grid .product-card').filter({hasText:'PELUCHE HELLO KITTY'});await card.waitFor({state:'visible'});
  if(mobile){await page.addStyleTag({content:'.product-card.reveal{opacity:1!important;transform:none!important}'});await card.screenshot({path:root+'.supabase-server-private/catalog-reference-mobile.png',animations:'disabled'});}
  // The visible cards belong to the previous array order while a background fetch updates the data.
  await page.evaluate(()=>{allProducts=[...allProducts].reverse();});
  await card.locator('.catalog-add-btn').click();assert.equal(await page.evaluate(()=>cart[0].idVariacion),'HELLO-V01');
  await card.locator('.product-card-img').click();await page.waitForURL('**/producto.html?ref=HELLO-V01*');
  await page.waitForFunction(()=>document.querySelector('#detail-name')?.textContent==='PELUCHE HELLO KITTY');
  assert.match(await page.locator('#detail-img').getAttribute('src'),/HELLO_PHOTO/);assert.equal(await page.locator('#detail-cat').textContent(),'Peluche');assert.match(await page.locator('#detail-price').textContent(),/22.000/);
  await page.locator('.detail-description-accordion summary').click();assert.equal(await page.locator('#detail-desc').textContent(),'Peluche Hello Kitty suave de 30 cm.');assert.equal(await page.locator('#detail-desc').isVisible(),true);
  if(mobile)await page.locator('#product-detail').screenshot({path:root+'.supabase-server-private/product-reference-mobile.png',animations:'disabled'});
  await page.evaluate(()=>{allProducts=[...allProducts].reverse();window.dispatchEvent(new CustomEvent('original-store-products-updated'));});assert.equal(await page.locator('#detail-name').textContent(),'PELUCHE HELLO KITTY');assert.match(await page.locator('#detail-img').getAttribute('src'),/HELLO_PHOTO/);
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1),false);
  // A previous tab preview and an incorrect numeric index must never override the requested reference.
  await page.evaluate(()=>sessionStorage.setItem(PRODUCT_DETAIL_PREVIEW_KEY,JSON.stringify({id:0,ref:'KUROMI-V01',mode:'retail',name:'TERMO KUROMI',image:'https://lh3.googleusercontent.com/d/KUROMI_PHOTO=w1200',savedAt:Date.now()})));
  await page.goto(url+'/producto.html?id=0&ref=HELLO-V01');await page.waitForFunction(()=>document.querySelector('#btn-add-to-cart-detail')?.onclick);
  assert.equal(await page.locator('#detail-name').textContent(),'PELUCHE HELLO KITTY');assert.match(await page.locator('#detail-img').getAttribute('src'),/HELLO_PHOTO/);
  await page.goto(url+'/producto.html?id=0&ref=KUROMI-V01');await page.waitForFunction(()=>document.querySelector('#detail-name')?.textContent==='TERMO KUROMI');assert.equal(await page.locator('#detail-desc').textContent(),'Termo Kuromi de 500 ml.');
  await page.goto(url+'/producto.html?id=0&ref=NO-EXISTE');await page.getByRole('heading',{name:'Producto no encontrado'}).waitFor();assert.equal(await page.locator('#btn-add-to-cart-detail').count(),0);assert.ok(!(await page.locator('body').innerText()).includes('Nombre del Producto'));
  console.log('PASS '+(mobile?'mobile':'desktop')+': stable reference after catalogue reorder, correct add-to-cart and full detail/description, background refresh, mismatched preview rejected, missing reference never falls back to another product');
 }
 const {context:cachedContext,page:cachedPage}=await storefront(true);
 await cachedContext.route(/https:\/\/(lh3\.googleusercontent\.com|drive\.google\.com)\//,r=>r.fulfill({contentType:'image/svg+xml',body:svg}));
 await cachedContext.addInitScript(()=>{
  localStorage.setItem('original_store_products_drive_v4:'+location.origin+'/api',JSON.stringify({savedAt:Date.now(),data:{products:[{idVariacion:'KUROMI-V01',Nombre:'TERMO KUROMI',Stock:6,Imagen:'https://lh3.googleusercontent.com/d/KUROMI_PHOTO=w1200'},{idVariacion:'HELLO-V01',Nombre:'PELUCHE HELLO KITTY',Stock:8,Precio:22000,Imagen:'https://lh3.googleusercontent.com/d/HELLO_PHOTO=w1200',Descripcion:''}],banners:[]}}));
 });
 await cachedContext.route('**/api?*',async r=>{await new Promise(resolve=>setTimeout(resolve,200));return r.continue();});
 await cachedPage.goto(url+'/producto.html?id=0&ref=HELLO-V01');await cachedPage.waitForFunction(()=>document.querySelector('#detail-desc')?.textContent==='Peluche Hello Kitty suave de 30 cm.');assert.equal(await cachedPage.locator('#detail-name').textContent(),'PELUCHE HELLO KITTY');assert.match(await cachedPage.locator('#detail-img').getAttribute('src'),/HELLO_PHOTO/);
 console.log('PASS stale mobile cache: refreshed description and identity remain correct despite old cache order');
 assert.deepEqual(errors,[]);assert.equal(f.data.Pedidos.rows.length,0);assert.equal(f.data.Facturas.rows.length,0);
}finally{await browser.close();server.close();}
