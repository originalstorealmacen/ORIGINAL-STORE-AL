const GOOGLE_SHEET_API = window.ORIGINAL_STORE_API_URL;

// Las credenciales administrativas se mantienen en memoria y se envían solo al servidor.
const adminNativeFetch = window.fetch.bind(window);
let secureAdminCredential = '';
// Expiry follows the credential; inactivity follows actual interaction.
function revokeAdminSession() {
    window.OriginalStoreSharedScan?.close();
    const token=secureAdminCredential;secureAdminCredential='';window.OriginalStoreAdminSession?.stop();
    if(token.startsWith('BLYXU-A3-'))adminNativeFetch(GOOGLE_SHEET_API,{method:'POST',headers:{'Content-Type':'text/plain;charset=utf-8'},body:JSON.stringify({action:'adminlogout',adminCredential:token}),keepalive:true}).catch(()=>{});
}
function logoutAdminSecurely(){window.OriginalStoreAdminSession?.save();revokeAdminSession();sessionStorage.removeItem('blyxu_admin_orders_invoices_cache_v2');location.href='index.html';}
let adminRefreshInProgress = false;
async function refreshAdministrator(button) {
    if (adminRefreshInProgress) return;
    if (!secureAdminCredential) { showToast('Inicia sesión para actualizar el administrador.', 'error'); return; }
    adminRefreshInProgress = true;
    const label = button?.textContent;
    if (button) { button.disabled = true; button.textContent = 'Actualizando…'; }
    try {
        siteConfigPromise = null;
        const jobs = [
            () => cargarInventario({force:true,silent:true,throwOnError:true}),
            () => cargarPedidos({force:true,throwOnError:true}),
            () => loadSiteConfigForAdmin({force:true,throwOnError:true}),
            () => window.refreshOrderNotifications?.({throwOnError:true}),
            () => typeof refreshCustomerAccessCount === 'function' ? refreshCustomerAccessCount({throwOnError:true}) : undefined
        ];
        if (document.getElementById('view-users')?.classList.contains('active')) jobs.push(() => loadCustomerUsers({throwOnError:true}));
        if (document.getElementById('pending-products-panel') && !document.getElementById('pending-products-panel').hidden) jobs.push(() => window.BlyxuPendingProducts?.refresh({throwOnError:true}));
        const names = ['inventario','pedidos y facturas','configuración','pedidos nuevos','solicitudes'];
        if(document.getElementById('view-users')?.classList.contains('active'))names.push('usuarios');
        if(document.getElementById('pending-products-panel') && !document.getElementById('pending-products-panel').hidden)names.push('pendientes');
        const results = await Promise.allSettled(jobs.map(job => Promise.resolve().then(job)));
        renderAdminDashboard();
        const failed = results.flatMap((result,index) => result.status === 'rejected' ? [names[index]] : []);
        showToast(failed.length ? 'No se pudo actualizar: '+failed.join(', ')+'. Revisa tu conexión e inténtalo de nuevo.' : 'Datos actualizados. Tu sesión sigue abierta.', failed.length ? 'error' : 'success');
    } finally {
        adminRefreshInProgress = false;
        if (button) { button.disabled = false; button.textContent = label; }
    }
}
window.logoutAdminSecurely=logoutAdminSecurely;
window.fetch = async function(input, options = {}) {
    const address = typeof input === 'string' ? input : input?.url;
    if (!address || address.split('?')[0] !== GOOGLE_SHEET_API || !secureAdminCredential) return adminNativeFetch(input, options);
    const url = new URL(address);
    let payload = Object.fromEntries(url.searchParams);
    if (options.body instanceof FormData || options.body instanceof URLSearchParams) payload = {...payload, ...Object.fromEntries(options.body)};
    else if (typeof options.body === 'string') payload = {...payload, ...JSON.parse(options.body)};
    if (!options.method || options.method.toUpperCase() === 'GET') payload.action = payload.action || 'get';
    payload.adminCredential = secureAdminCredential;
    const controller = new AbortController();
    const abort = () => controller.abort();
    if (options.signal?.aborted) abort();
    options.signal?.addEventListener('abort', abort, {once:true});
    const timeout = setTimeout(abort, 25000);
    try {
        const response = await adminNativeFetch(GOOGLE_SHEET_API, {...options,cache:'no-store',signal:controller.signal,method:'POST',mode:'cors',headers:{'Content-Type':'text/plain;charset=utf-8'},body:JSON.stringify(payload)});
        if (!response.ok) throw new Error('El servidor no respondió correctamente.');
        const result = await response.clone().json();
        if (result.ok === false || result.status === 'error') throw new Error(result.error || 'No se pudo completar la operación.');
        return response;
    } catch(error) {
        if(error.name === 'AbortError') throw new Error('La consulta tardó demasiado. Vuelve a actualizar los datos.');
        throw error;
    } finally {clearTimeout(timeout);options.signal?.removeEventListener('abort',abort);}
};
const GOOGLE_SHEET_PRODUCTS_URL = `${GOOGLE_SHEET_API}?resource=productos`;
let inventario = [];
const RETAIL_PRICE_VISIBILITY_KEY = 'blyxu_show_retail_prices';
const RETAIL_PRICE_CONFIG_KEY = 'Mostrar_Precios_Minorista';
const MERCADO_PAGO_ENABLED_CONFIG_KEY = 'Mercado_Pago_Publico_Activo';
const CONTACT_CONFIG_FIELDS = [
    ['Contacto_Dias', 'contact-config-days'],
    ['Contacto_Horarios', 'contact-config-hours'],
    ['Contacto_WhatsApp', 'contact-config-whatsapp'],
    ['Contacto_Facebook', 'contact-config-facebook'],
    ['Contacto_TikTok', 'contact-config-tiktok'],
    ['Contacto_Instagram', 'contact-config-instagram']
];
const WHATSAPP_CONFIG_FIELDS = [
    ['WhatsApp_Comercial', 'whatsapp-config-commerce']
];
const INVOICE_CONFIG_FIELDS = [
    ['Factura_Logo', 'inv-config-logo'],
    ['Factura_Empresa', 'inv-config-empresa'],
    ['Factura_NIT', 'inv-config-nit'],
    ['Factura_Direccion', 'inv-config-direccion'],
    ['Factura_Telefono', 'inv-config-telefono'],
    ['Factura_Email', 'inv-config-email']
];
const INVENTORY_CACHE_KEY = `blyxu_admin_inventory_cache_v3:${GOOGLE_SHEET_API}`;
const PUBLIC_PRODUCTS_CACHE_KEY = `original_store_products_drive_v4:${GOOGLE_SHEET_API}`;
const SITE_CONFIG_CACHE_KEY = `blyxu_site_config_cache_v1:${GOOGLE_SHEET_API}`;
const INVENTORY_BATCH_SIZE = 25;
const MAX_CAROUSEL_IMAGE_SIZE = 5 * 1024 * 1024;
const IMAGE_UPLOAD_MAX_EDGE = 1200;
const IMAGE_UPLOAD_QUALITY = 0.76;
const IMAGE_UPLOAD_FORMAT = 'image/webp';
const IMAGE_UPLOAD_EXTENSION = 'webp';
const JSPDF_CDN_URL = 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js';

let siteConfigPromise = null;
let inventoryRenderedRows = 0;
let inventoryRenderToken = 0;
let inventoryLoadMoreObserver = null;
let filteredInventario = [];
let adminInventorySearchQuery = '';
let adminInventoryCategoryFilter = 'todos';
let adminInventoryPdfSelectedCategoryKeys = null;
let isEditingProduct = false;
let inventoryFetchToken = 0;
let inventoryLoadingPromise = null;
const PRODUCT_CATEGORY_FIELD_KEYS = ['Categor\u00eda', 'Categoria', 'Categor\u00c3\u00ada', 'Categor\u00c3\u0192\u00c2\u00ada', 'categoria'];
const PRODUCT_PROMOTION_FIELD_KEYS = ['Promocion', 'Promoci\u00f3n', 'Promoci\u00c3\u00b3n', 'Promoci\u00c3\u0192\u00c2\u00b3n', 'promo', 'Promo'];
const PRODUCT_BARCODE_FIELD_KEYS = ['Codigo Barras', 'Codigo de Barras', 'C\u00f3digo de Barras', 'Codigo_Barras', 'codigoBarras', 'barcode', 'Barcode'];
const PRODUCT_COLOR_OPTIONS = [
    { name: 'Dorado', hex: '#d4a017' },
    { name: 'Plateado', hex: '#c0c0c0' },
    { name: 'Negro', hex: '#222222' },
    { name: 'Blanco', hex: '#ffffff', light: true },
    { name: 'Perla', hex: '#f5ead2', light: true },
    { name: 'Rosado', hex: '#f4a7b9' },
    { name: 'Fucsia', hex: '#ec4899' },
    { name: 'Rojo', hex: '#e53e3e' },
    { name: 'Azul', hex: '#38a7df' },
    { name: 'Turquesa', hex: '#45d3d0' },
    { name: 'Verde', hex: '#22c55e' },
    { name: 'Amarillo', hex: '#facc15' },
    { name: 'Morado', hex: '#9b2cfa' },
    { name: 'Cafe', hex: '#8b5e34' },
    { name: 'Multicolor', hex: 'linear-gradient(135deg,#e53e3e,#facc15,#22c55e,#38a7df,#9b2cfa)' }
];

function formatAdminMoney(value) {
    return '$' + (parseFloat(value) || 0).toLocaleString('es-CO', { minimumFractionDigits: 0 });
}

function normalizeBarcodeValue(value) {
    return String(value || '')
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-zA-Z0-9_-]+/g, '')
        .toUpperCase()
        .slice(0, 48);
}

function makeProductBarcode(idProducto, idVariacion) {
    const base = normalizeBarcodeValue(idVariacion || idProducto);
    return base ? `BLYXU-${base}` : '';
}

function getProductBarcode(product, fallback = '') {
    const stored = getProductField(product, PRODUCT_BARCODE_FIELD_KEYS, '');
    if (stored) return normalizeBarcodeValue(stored);
    const idProducto = getProductField(product, ['ID Producto', 'idProducto'], '');
    const idVariacion = getProductField(product, ['ID Variacion', 'ID Variación', 'idVariacion', 'ID', 'id'], '');
    return makeProductBarcode(idProducto, idVariacion) || fallback;
}

function setProductBarcodeAliases(payload, barcode) {
    const cleanBarcode = normalizeBarcodeValue(barcode || makeProductBarcode(
        payload?.['ID Producto'] || payload?.idProducto,
        payload?.['ID Variacion'] || payload?.['ID Variación'] || payload?.idVariacion || payload?.ID
    ));
    if (!cleanBarcode) return payload;
    payload['Codigo Barras'] = cleanBarcode;
    payload['Codigo de Barras'] = cleanBarcode;
    payload['Código de Barras'] = cleanBarcode;
    payload.Codigo_Barras = cleanBarcode;
    payload.codigoBarras = cleanBarcode;
    payload.Barcode = cleanBarcode;
    return payload;
}

function readAdminCachedSiteConfigValue(key, fallback = '') {
    if (window.storeConfig && window.storeConfig[key] !== undefined) return window.storeConfig[key];
    try {
        const cached = JSON.parse(localStorage.getItem(SITE_CONFIG_CACHE_KEY) || 'null');
        if (cached?.data && cached.data[key] !== undefined) return cached.data[key];
    } catch (error) {
        return fallback;
    }
    return fallback;
}

function getAdminPromotionDiscountPercent() {
    const titleInput = document.getElementById('promo-config-title');
    const promoTitle = titleInput?.value?.trim() || readAdminCachedSiteConfigValue('Promo_Title', '');
    const match = String(promoTitle || '').match(/(\d+)%/);
    if (match) {
        const percent = parseInt(match[1], 10);
        if (percent > 0 && percent < 100) return percent;
    }

    const promoDiscount = parseInt(readAdminCachedSiteConfigValue('Promo_Discount', ''), 10);
    if (promoDiscount > 0 && promoDiscount < 100) return promoDiscount;

    return 20;
}

function updateLivePreview() {
    const nombre = document.getElementById('prod-nombre')?.value || 'Nombre del Producto';
    const categoria = document.getElementById('prod-categoria')?.value || 'CATEGORÍA';
    const precio = document.getElementById('prod-precio')?.value || '0';
    const precioMayorista = document.getElementById('prod-precio-mayorista')?.value || '';
    const galleryUrls = getAdminGalleryUrls();
    const imagenUrl = document.getElementById('prod-imagen')?.value || galleryUrls[0] || 'https://lh3.googleusercontent.com/d/1OTHvWFph2u3qFQMQVhE5ghmSWjBSgBeW=w180';
    const estado = document.getElementById('prod-estado')?.value || 'Activo';
    const catalogo = document.getElementById('prod-catalogo')?.value || 'Ambos';
    const stock = Number(document.getElementById('prod-stock-inicial')?.value || 0);
    const descripcion = document.getElementById('prod-descripcion')?.value?.trim() || '';
    const color = document.getElementById('prod-color')?.value?.trim() || '';
    const estilo = document.getElementById('prod-estilo')?.value?.trim() || '';
    const medida = typeof getProductSizeValue === 'function' ? getProductSizeValue() : (document.getElementById('prod-tamano')?.value || '');
    if (typeof syncAllVariantAutoSizes === 'function') syncAllVariantAutoSizes();
    var idVar = document.getElementById('prod-id')?.value || '';
    var idProd = document.getElementById('prod-id-producto')?.value || '';
    const activeVariantPreviewRow = getActiveVariantPreviewRow();
    const previewImageUrl = activeVariantPreviewRow?.image || imagenUrl;

    var idBadge = document.getElementById('preview-id-badge');
    if (idBadge && (idProd || idVar)) {
        var idText = idProd ? 'ID: ' + idProd : '';
        if (idVar && idVar !== idProd) idText += ' | VAR: ' + idVar;
        if (idText) {
            idBadge.textContent = idText;
            idBadge.style.display = 'block';
            idBadge.style.background = 'rgba(0,0,0,0.6)';
            idBadge.style.fontSize = '9px';
            idBadge.style.right = '10px';
            idBadge.style.left = 'auto';
        }
    }

    const titleEl = document.getElementById('preview-title-el');
    const catEl = document.getElementById('preview-cat-el');
    if (titleEl) titleEl.textContent = nombre;
    if (catEl) catEl.textContent = categoria;

    const parsedPrecio = parseAmount(precio);
    const parsedMayorista = parseAmount(precioMayorista);

    const promoSelect = document.getElementById('prod-promocion');
    const promoScope = normalizePromotionValue(promoSelect?.value || 'FALSO');
    const discountPercent = promoScope !== 'FALSO' ? getAdminPromotionDiscountPercent() : 0;
    const discountFactor = discountPercent ? 1 - (discountPercent / 100) : 1;

    const retailApplies = discountPercent > 0 && (promoScope === 'Ambos' || promoScope === 'Minorista');
    const wholesaleApplies = discountPercent > 0 && (promoScope === 'Ambos' || promoScope === 'Mayorista');

    let priceHtml = '';
    if (parsedPrecio > 0) {
        if (retailApplies) {
            const promoPrice = Math.round(parsedPrecio * discountFactor);
            priceHtml = `<span style="color:#ffd969; text-shadow:0 0 12px rgba(255,217,105,.35);">${formatAdminMoney(promoPrice)}</span> <span style="font-size:12px; color:rgba(255,255,255,.38); text-decoration:line-through; margin-left:6px;">${formatAdminMoney(parsedPrecio)}</span> <span style="font-size:10px; color:#ffd969; border:1px solid rgba(255,217,105,.28); border-radius:4px; padding:2px 5px; margin-left:6px;">-${discountPercent}%</span>`;
        } else {
            priceHtml = formatAdminMoney(parsedPrecio);
        }
        if (parsedMayorista > 0) {
            const wholesaleText = wholesaleApplies
                ? `${formatAdminMoney(Math.round(parsedMayorista * discountFactor))} <span style="text-decoration:line-through; color:rgba(255,255,255,.35); margin-left:4px;">${formatAdminMoney(parsedMayorista)}</span> <span style="color:#ffd969; font-size:10px;">-${discountPercent}%</span>`
                : formatAdminMoney(parsedMayorista);
            priceHtml += ` <span style="font-size:11px; font-weight:600; color:var(--text-muted); margin-left:8px; border: 1px solid rgba(255,255,255,0.1); padding: 2px 6px; border-radius:4px;">Por mayor: ${wholesaleText}</span>`;
        }
    } else if (parsedMayorista > 0) {
        if (wholesaleApplies) {
            const promoWholesale = Math.round(parsedMayorista * discountFactor);
            priceHtml = `<span style="font-size:11px; font-weight:600; color:var(--text-muted); border: 1px solid rgba(255,255,255,0.1); padding: 2px 6px; border-radius:4px;">Por mayor: <span style="color:#ffd969;">${formatAdminMoney(promoWholesale)}</span> <span style="text-decoration:line-through; color:rgba(255,255,255,.35); margin-left:4px;">${formatAdminMoney(parsedMayorista)}</span> <span style="color:#ffd969; margin-left:4px;">-${discountPercent}%</span></span>`;
        } else {
            priceHtml = `<span style="font-size:11px; font-weight:600; color:var(--text-muted); border: 1px solid rgba(255,255,255,0.1); padding: 2px 6px; border-radius:4px;">Por mayor: ${formatAdminMoney(parsedMayorista)}</span>`;
        }
    } else {
        priceHtml = '$0';
    }
    const previewUsesWholesalePrice = catalogo === 'Mayorista' && parsedMayorista > 0;
    const previewBasePrice = previewUsesWholesalePrice ? parsedMayorista : (parsedPrecio || parsedMayorista);
    const previewPromoApplies = discountPercent > 0 && (
        previewUsesWholesalePrice
            ? (promoScope === 'Ambos' || promoScope === 'Mayorista')
            : (promoScope === 'Ambos' || promoScope === 'Minorista')
    );
    if (previewBasePrice > 0) {
        if (previewPromoApplies) {
            const promoPrice = Math.round(previewBasePrice * discountFactor);
            priceHtml = `${formatAdminMoney(promoPrice)} <span class="old">${formatAdminMoney(previewBasePrice)}</span>`;
        } else {
            priceHtml = formatAdminMoney(previewBasePrice);
        }
    } else {
        priceHtml = stock > 0 ? 'Precio por consultar' : 'Agotado por ahora';
    }
    const priceEl = document.getElementById('preview-price-el');
    if (priceEl) priceEl.innerHTML = priceHtml;
    const colorStrip = document.getElementById('preview-color-strip');
    const colorLabel = splitProductColorValues(color).map(getColorDisplayName).join(', ');
    if (colorStrip) {
        colorStrip.innerHTML = getPreviewColorDotsHtml(color);
        colorStrip.style.display = color ? 'flex' : 'none';
    }
    const colorText = document.getElementById('preview-color-text');
    if (colorText) colorText.textContent = colorLabel || 'Varios';
    const styleText = document.getElementById('preview-style-text');
    const styleRow = document.getElementById('preview-style-row');
    if (styleText) styleText.textContent = estilo || '';
    if (styleRow) styleRow.style.display = estilo ? 'flex' : 'none';
    const sizeRow = document.getElementById('preview-size-row');
    const stockValue = document.getElementById('preview-stock-value');
    if (stockValue) stockValue.textContent = stock > 0 ? 'Disponible' : 'Agotado por ahora';
    const stockAlert = document.getElementById('preview-stock-alert');
    if (stockAlert) {
        stockAlert.className = 'preview-stock-alert';
        if (stock <= 0) {
            stockAlert.textContent = 'Agotado';
            stockAlert.classList.add('is-out');
            stockAlert.style.display = 'inline-flex';
        } else if (stock <= 3) {
            stockAlert.textContent = 'Bajo stock';
            stockAlert.classList.add('is-low');
            stockAlert.style.display = 'inline-flex';
        } else {
            stockAlert.style.display = 'none';
        }
    }
    const measureLine = document.getElementById('preview-measure-line');
    if (measureLine) {
        measureLine.textContent = medida || '';
        if (sizeRow) sizeRow.style.display = medida ? 'flex' : 'none';
    }
    const descEl = document.getElementById('preview-product-desc');
    if (descEl) descEl.textContent = descripcion || 'Sin descripcion disponible.';
    const buyBtn = document.getElementById('preview-buy-btn');
    const consultBtn = document.getElementById('preview-consult-btn');
    const cartNote = document.getElementById('preview-cart-note');
    const hasVisiblePrice = previewBasePrice > 0;
    if (buyBtn) {
        buyBtn.disabled = stock <= 0;
        buyBtn.textContent = stock <= 0
            ? 'Agotado por ahora'
            : (hasVisiblePrice ? 'Añadir al Carrito' : 'Añadir a consulta general');
    }
    if (consultBtn) consultBtn.style.display = !hasVisiblePrice && stock > 0 ? 'inline-flex' : 'none';
    if (cartNote) cartNote.style.display = !hasVisiblePrice && stock > 0 ? 'block' : 'none';

    const imgEl = document.getElementById('preview-img-el');
    if (imgEl) {
        const currentSrc = imgEl.getAttribute('src');
        if (currentSrc !== previewImageUrl) {
            // Evitar parpadeo: solo actualizar si el origen realmente cambió
            imgEl.style.transition = 'opacity 0.2s';
            imgEl.style.opacity = '0.4';

            loadImageWithRetry(previewImageUrl, 3, 700).then(() => {
                const localPreviewSrc = imgEl.dataset.localPreviewSrc;
                imgEl.src = previewImageUrl;
                imgEl.style.opacity = '1';
                delete imgEl.dataset.localPreviewSrc;
                if (localPreviewSrc) URL.revokeObjectURL(localPreviewSrc);
            }).catch(() => {
                if (imgEl.dataset.localPreviewSrc) {
                    imgEl.src = imgEl.dataset.localPreviewSrc;
                    imgEl.style.opacity = '0.85';
                    return;
                }
                imgEl.src = 'https://lh3.googleusercontent.com/d/1tab2v6baqQeNF7qMPaXmevFX1Cfh063V=w900';
                imgEl.style.opacity = '0.3';
            });
        }
    }

    const badgeEl = document.getElementById('preview-badge-el');
    if (badgeEl) {
        if (estado === 'Agotado') {
            badgeEl.textContent = 'AGOTADO';
            badgeEl.style.display = 'block';
            badgeEl.style.background = 'rgba(239,68,68,0.85)';
        } else if (estado === 'Inactivo') {
            badgeEl.textContent = 'OCULTO';
            badgeEl.style.display = 'block';
            badgeEl.style.background = 'rgba(100,100,100,0.85)';
        } else {
            badgeEl.style.display = 'none';
        }
    }

    const setPreviewDetail = (id, value) => {
        const node = document.getElementById(id);
        if (node) node.textContent = value;
    };
    const galleryCount = (document.getElementById('prod-imagen')?.value ? 1 : 0) + galleryUrls.length;
    const variantParts = [colorLabel, estilo, medida].filter(Boolean);
    const promoText = promoScope === 'FALSO'
        ? 'No aplica'
        : `${promoScope} -${discountPercent || 0}%`;

    setPreviewDetail('preview-detail-state', estado);
    setPreviewDetail('preview-detail-id', idProd || 'Automatico');
    setPreviewDetail('preview-detail-catalog', catalogo);
    setPreviewDetail('preview-detail-stock', `${stock} ${stock === 1 ? 'unidad' : 'unidades'}`);
    setPreviewDetail('preview-detail-price', parsedPrecio > 0 ? formatAdminMoney(parsedPrecio) : '$0');
    setPreviewDetail('preview-detail-wholesale', parsedMayorista > 0 ? formatAdminMoney(parsedMayorista) : 'Sin precio');
    setPreviewDetail('preview-detail-variant', variantParts.length ? variantParts.join(' / ') : 'Sin color / talla');
    setPreviewDetail('preview-detail-gallery', galleryCount > 0 ? `${galleryCount} ${galleryCount === 1 ? 'imagen' : 'imagenes'}` : 'Sin imagen');
    setPreviewDetail('preview-detail-promo', promoText);
    setPreviewDetail('preview-detail-desc', descripcion || 'La descripcion aparecera aqui mientras escribes.');

    renderProductPreviewGallery(previewImageUrl);
    renderProductPreviewOptions(previewImageUrl);
    if (activeVariantPreviewRow) applyPreviewVariantRow(activeVariantPreviewRow);
}

function loadImageWithRetry(src, attempts = 2, delayMs = 500) {
    return new Promise((resolve, reject) => {
        if (!src) {
            reject(new Error('Imagen vacia'));
            return;
        }

        let attempt = 0;
        const tryLoad = () => {
            const tempImg = new Image();
            tempImg.onload = () => resolve(src);
            tempImg.onerror = () => {
                attempt += 1;
                if (attempt >= attempts) {
                    reject(new Error('No se pudo cargar la imagen'));
                    return;
                }
                setTimeout(tryLoad, delayMs);
            };
            tempImg.src = src;
        };

        tryLoad();
    });
}

function getProductField(product, fields, fallback = '') {
    const names = Array.isArray(fields) ? fields : [fields];

    // Exact match first
    for (const name of names) {
        if (product && product[name] !== undefined && product[name] !== null && product[name] !== '') {
            return product[name];
        }
    }

    // Fuzzy match for broken keys (spaces, accents, etc.)
    if (product) {
        for (const key in product) {
            const cleanKey = key.trim().normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
            for (const name of names) {
                const cleanName = name.trim().normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
                if (cleanKey === cleanName && product[key] !== undefined && product[key] !== null && product[key] !== '') {
                    return product[key];
                }
            }
        }
    }

    return fallback;
}

function getAdminImageTargetWidth(kindOrWidth = 'default') {
    if (typeof kindOrWidth === 'number') return Math.max(80, Math.min(kindOrWidth, 1800));
    const key = String(kindOrWidth || 'default');
    const widths = {
        thumb: 160,
        inventory: 220,
        card: 420,
        banner: 1400,
        default: 800
    };
    return widths[key] || widths.default;
}

function resizeAdminGoogleImageUrl(url, kindOrWidth = 'default') {
    const src = String(url || '').trim();
    if (!src || src.startsWith('data:') || src.startsWith('blob:')) return src;
    const width = getAdminImageTargetWidth(kindOrWidth);

    if (/drive\.google\.com\/thumbnail/i.test(src)) {
        try {
            const parsed = new URL(src);
            parsed.searchParams.set('sz', `w${width}`);
            return parsed.toString();
        } catch (_) {
            return src.replace(/([?&]sz=)w\d+/i, `$1w${width}`);
        }
    }

    if (/lh3\.googleusercontent\.com\/d\//i.test(src)) {
        if (/=w\d+(?:-h\d+)?(?:-[a-z-]+)?(?=([?#]|$))/i.test(src)) {
            return src.replace(/=w\d+(?:-h\d+)?(?:-[a-z-]+)?(?=([?#]|$))/i, `=w${width}`);
        }
        const queryIndex = src.search(/[?#]/);
        if (queryIndex >= 0) return `${src.slice(0, queryIndex)}=w${width}${src.slice(queryIndex)}`;
        return `${src}=w${width}`;
    }

    return src;
}

function normalizeImageUrl(value, imageSize = 'default') {
    if (!value) return '';

    if (Array.isArray(value)) {
        return normalizeImageUrl(value[0], imageSize);
    }

    if (typeof value === 'object') {
        return normalizeImageUrl(value.url || value.src || value.imagen || value.image || '', imageSize);
    }

    const raw = String(value).split('\n')[0].trim();
    if (!raw) return '';

    const firstUrl = raw.includes(',http') ? raw.split(',http')[0].trim() : raw;
    const driveMatch =
        firstUrl.match(/drive\.google\.com\/file\/d\/([^/]+)/) ||
        firstUrl.match(/drive\.google\.com\/thumbnail\?(?:[^&]+&)*id=([^&#]+)/) ||
        firstUrl.match(/[?&]id=([^&]+)/);

    if (firstUrl.includes('drive.google.com') && driveMatch && driveMatch[1]) {
        return `https://drive.google.com/thumbnail?id=${encodeURIComponent(driveMatch[1])}&sz=w${getAdminImageTargetWidth(imageSize)}`;
    }

    if (firstUrl.startsWith('//')) return `https:${firstUrl}`;

    return resizeAdminGoogleImageUrl(firstUrl, imageSize);
}

function parseAdminGalleryValue(value) {
    if (!value) return [];
    if (Array.isArray(value)) return value.map(normalizeImageUrl).filter(Boolean);
    if (typeof value === 'object') return [normalizeImageUrl(value)].filter(Boolean);

    const text = String(value || '').trim();
    if (!text) return [];

    try {
        const parsed = JSON.parse(text);
        return parseAdminGalleryValue(parsed);
    } catch (error) {
        return text
            .split(/[\r\n]+|,\s*(?=https?:\/\/|\/\/|data:image\/)/i)
            .map(normalizeImageUrl)
            .filter(Boolean);
    }
}

function stringifyAdminGallery(urls) {
    const cleaned = [];
    const seen = new Set();
    parseAdminGalleryValue(urls).forEach(url => {
        const normalized = normalizeImageUrl(url);
        if (!normalized || seen.has(normalized)) return;
        seen.add(normalized);
        cleaned.push(normalized);
    });
    return cleaned.length ? JSON.stringify(cleaned) : '';
}

function getInventoryProductImage(product, imageSize = 'inventory') {
    const directImage = getProductField(product, [
        'Imagen Principal',
        'Imagen_Principal',
        'imagenPrincipal',
        'Imagen',
        'imagen',
        'Foto',
        'foto',
        'URL Imagen',
        'Url Imagen',
        'url',
        'image',
        'directUrl',
        'src'
    ], '');
    const galleryValue = getProductField(product, [
        'Galeria JSON',
        'Galer\u00eda JSON',
        'Galeria',
        'galeria',
        'Galer\u00eda'
    ], product?.Galeria || '');
    const galleryImage = parseAdminGalleryValue(galleryValue)[0] || '';
    return normalizeImageUrl(directImage || galleryImage, imageSize) || 'https://lh3.googleusercontent.com/d/1OTHvWFph2u3qFQMQVhE5ghmSWjBSgBeW=w180';
}

function getInventoryImageFallbackUrl(source, imageSize = 'inventory') {
    const src = String(source || '');
    const driveMatch =
        src.match(/[?&]id=([^&#]+)/) ||
        src.match(/drive\.google\.com\/file\/d\/([^/]+)/) ||
        src.match(/lh3\.googleusercontent\.com\/d\/([^/?&#=]+)/);

    if (driveMatch?.[1] && !src.includes('lh3.googleusercontent.com')) {
        return `https://lh3.googleusercontent.com/d/${encodeURIComponent(driveMatch[1])}=w${getAdminImageTargetWidth(imageSize)}`;
    }

    return 'https://lh3.googleusercontent.com/d/1OTHvWFph2u3qFQMQVhE5ghmSWjBSgBeW=w180';
}

function handleInventoryImageError(img) {
    if (!img) return;
    const fallback = getInventoryImageFallbackUrl(img.currentSrc || img.src || img.dataset.src);
    if (fallback && fallback !== 'https://lh3.googleusercontent.com/d/1OTHvWFph2u3qFQMQVhE5ghmSWjBSgBeW=w180' && img.dataset.fallbackTried !== 'true') {
        img.dataset.fallbackTried = 'true';
        img.src = fallback;
        return;
    }
    img.onerror = null;
    img.src = 'https://lh3.googleusercontent.com/d/1OTHvWFph2u3qFQMQVhE5ghmSWjBSgBeW=w180';
}

function getAdminGalleryUrls() {
    return parseAdminGalleryValue(document.getElementById('prod-galeria')?.value || '');
}

function setAdminGalleryUrls(urls) {
    const input = document.getElementById('prod-galeria');
    if (input) input.value = stringifyAdminGallery(urls);
    renderProductGalleryManager();
}

function appendAdminGalleryUrls(urls) {
    const next = [...getAdminGalleryUrls(), ...parseAdminGalleryValue(urls)];
    setAdminGalleryUrls(next);
}

function cleanProductStyleValue(value) {
    const raw = String(value || '').trim();
    const clean = raw.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
    return ['ambos', 'minorista', 'mayorista', 'minorista y mayorista'].includes(clean) ? '' : raw;
}

function cleanMeasurementValue(value) {
    return String(value || '').trim().replace(',', '.');
}

function formatProductPhysicalSizeLabel(data) {
    const unit = data.unit || 'cm';
    if (unit === 'ml') {
        const capacity = cleanMeasurementValue(data.capacity || data.width);
        return capacity ? `Capacidad ${capacity} ml` : '';
    }
    const radius = cleanMeasurementValue(data.radius);
    if (radius) return `Radio ${radius} ${unit}`;

    const parts = [
        ['Ancho', cleanMeasurementValue(data.width)],
        ['Largo', cleanMeasurementValue(data.length)],
        ['Fondo', cleanMeasurementValue(data.depth)]
    ].filter(([, value]) => value);

    return parts.map(([label, value]) => `${label} ${value} ${unit}`).join(' x ');
}

function parseProductMeasurementText(value) {
    const text = String(value || '').trim();
    const parsed = {
        unit: '',
        width: '',
        length: '',
        depth: '',
        radius: ''
    };
    const unitMatch = text.match(/\b(cm|m3|ml|m)\b/i);
    if (unitMatch) parsed.unit = unitMatch[1].toLowerCase();
    Array.from(text.matchAll(/(ancho|largo|fondo|radio|capacidad)\s*[:\-]?\s*([\d.,]+)/gi)).forEach(match => {
        const label = normalizeSearchText(match[1]);
        const measure = match[2];
        if (label === 'ancho' || label === 'capacidad') parsed.width = measure;
        if (label === 'largo') parsed.length = measure;
        if (label === 'fondo') parsed.depth = measure;
        if (label === 'radio') parsed.radius = measure;
    });
    return parsed;
}

function getProductMeasurementFormData() {
    const kind = getInputValue('prod-size-kind');
    const textileSize = cleanMeasurementValue(getInputValue('prod-textile-custom')) || getInputValue('prod-textile-size');
    const unit = getInputValue('prod-measure-unit') || 'cm';
    const capacity = cleanMeasurementValue(getInputValue('prod-measure-capacity'));
    return {
        kind,
        unit,
        capacity,
        width: unit === 'ml' ? capacity : cleanMeasurementValue(getInputValue('prod-measure-width')),
        length: cleanMeasurementValue(getInputValue('prod-measure-length')),
        depth: cleanMeasurementValue(getInputValue('prod-measure-depth')),
        radius: cleanMeasurementValue(getInputValue('prod-measure-radius')),
        textileSize: textileSize.trim()
    };
}

function getProductSizeValue() {
    const data = getProductMeasurementFormData();
    if (data.kind === 'textil') return data.textileSize || getInputValue('prod-tamano');
    if (data.kind === 'medidas' || data.kind === 'liquido') return formatProductPhysicalSizeLabel(data) || getInputValue('prod-tamano');
    return getInputValue('prod-tamano');
}

function buildProductMeasurementPayload(data = getProductMeasurementFormData()) {
    return {
        'Tipo Medida': data.kind,
        TipoMedida: data.kind,
        'Unidad Medida': data.unit,
        UnidadMedida: data.unit,
        Ancho: data.width,
        Largo: data.length,
        Fondo: data.depth,
        Radio: data.radius,
        Capacidad: data.unit === 'ml' ? (data.capacity || data.width) : '',
        'Talla Textil': data.textileSize,
        TallaTextil: data.textileSize
    };
}

function updateProductMeasurementFields() {
    const data = getProductMeasurementFormData();
    const textilePanel = document.getElementById('prod-textile-size-fields');
    const physicalPanel = document.getElementById('prod-physical-size-fields');
    if (data.kind === 'liquido' && data.unit !== 'ml') {
        setInputValue('prod-measure-unit', 'ml');
        data.unit = 'ml';
    }
    if (textilePanel) textilePanel.classList.toggle('is-visible', data.kind === 'textil');
    if (physicalPanel) physicalPanel.classList.toggle('is-visible', data.kind === 'medidas' || data.kind === 'liquido');
    const measureGrid = document.getElementById('prod-measure-grid');
    if (measureGrid) measureGrid.classList.toggle('is-capacity', data.unit === 'ml' || data.kind === 'liquido');

    if (data.kind === 'textil' || data.kind === 'medidas' || data.kind === 'liquido') {
        setInputValue('prod-tamano', getProductSizeValue());
    }
    updateLivePreview();
}

function initProductMeasurementControls() {
    [
        'prod-size-kind',
        'prod-textile-size',
        'prod-textile-custom',
        'prod-measure-unit',
        'prod-measure-capacity',
        'prod-measure-width',
        'prod-measure-length',
        'prod-measure-depth',
        'prod-measure-radius'
    ].forEach(id => {
        const input = document.getElementById(id);
        if (!input) return;
        input.addEventListener('input', updateProductMeasurementFields);
        input.addEventListener('change', updateProductMeasurementFields);
    });
    updateProductMeasurementFields();
}

function normalizeGoogleProduct(product) {
    const styleValue = cleanProductStyleValue(getProductField(product, ['Estilo', 'estilo'], ''));
    const idVariacion = getProductField(product, ['ID Variacion', 'ID Variación', 'ID Variación', 'idVariacion', 'ID', 'id', 'SKU'], '');
    const idProducto = getProductField(product, ['ID Producto', 'ID Producto Madre', 'ID_Producto', 'ID_PRODUCTO', 'IdProducto', 'id_producto', 'idProducto'], '');
    const gallery = parseAdminGalleryValue(getProductField(product, ['Galeria JSON', 'Galería JSON', 'Galería JSON', 'Galeria', 'galeria'], ''));
    const imageUrl = normalizeImageUrl(getProductField(product, [
        'Imagen Principal',
        'Imagen_Principal',
        'imagenPrincipal',
        'Imagen',
        'imagen',
        'Foto',
        'foto',
        'URL Imagen',
        'Url Imagen',
        'url',
        'image',
        'directUrl',
        'src'
    ], gallery[0] || ''), 'inventory');
    return {
        ...product,
        ID: getProductField(product, ['ID Variacion', 'ID Variación', 'ID', 'id'], ''),
        idVariacion: getProductField(product, ['ID Variacion', 'ID Variación', 'ID', 'id'], ''),
        ID: idVariacion,
        idVariacion: idVariacion,
        idProducto: idProducto,
        Nombre: getProductField(product, ['Nombre del Producto', 'Nombre', 'Producto'], ''),
        Categoria: getProductField(product, PRODUCT_CATEGORY_FIELD_KEYS, ''),
        Precio: getProductField(product, ['Precio'], 0),
        Precio_Mayorista: getProductField(product, ['Precio Mayor', 'Precio Mayorista', 'Precio_Mayorista'], 0),
        Catalogo: getProductField(product, ['Catalogo', 'Catálogo', 'Catálogo', 'catalogo', 'Publicacion'], 'Ambos'),
        Stock: getProductField(product, ['Cantidad', 'Stock'], 0),
        Imagen: imageUrl,
        'Imagen Principal': imageUrl,
        Color: getProductField(product, ['Color'], ''),
        Stock_Inicial: getProductField(product, ['Stock Inicial', 'Stock_Inicial'], 0),
        Galeria: gallery,
        Descripcion: getProductField(product, ['Caracteristicas del producto', 'Características del producto', 'Descripcion'], ''),
        Tamano: getProductField(product, ['Tamano', 'Tamaño', 'Talla'], ''),
        TipoMedida: getProductField(product, ['Tipo Medida', 'TipoMedida'], ''),
        UnidadMedida: getProductField(product, ['Unidad Medida', 'UnidadMedida'], ''),
        Ancho: getProductField(product, ['Ancho'], ''),
        Largo: getProductField(product, ['Largo'], ''),
        Fondo: getProductField(product, ['Fondo'], ''),
        Radio: getProductField(product, ['Radio'], ''),
        Capacidad: getProductField(product, ['Capacidad'], ''),
        TallaTextil: getProductField(product, ['Talla Textil', 'TallaTextil'], ''),
        Estilo: styleValue,
        SKU: getProductField(product, ['SKU'], ''),
        CodigoBarras: getProductBarcode(product),
        Estado: getProductField(product, ['Estado'], 'Activo'),
        Promocion: getProductPromotionValue(product, false),
        Fecha_Creacion: getProductField(product, ['Fecha de Creacion', 'Fecha de Creación'], '')
    };
}

function isVisibleInventoryProduct(product) {
    var estado = (product.Estado || '').toUpperCase();
    var nombre = (product.Nombre || product.Producto || '').toUpperCase();
    return estado !== 'ELIMINADO' && !nombre.includes('[ELIMINADO]');
}

function isBannerInventoryProduct(product) {
    const category = normalizeSearchText(getProductField(product || {}, PRODUCT_CATEGORY_FIELD_KEYS, ''));
    const id = normalizeSearchText([
        getInventoryMotherId(product),
        getInventoryVariationId(product),
        product?.SKU
    ].join(' '));
    return category === 'banner' || /\bbanner\b/.test(id);
}

function getInventoryMotherId(product) {
    return String(getProductField(product, [
        'ID Producto',
        'ID Producto Madre',
        'ID_Producto',
        'ID_PRODUCTO',
        'IdProducto',
        'id_producto',
        'idProducto'
    ], '') || '').trim();
}

function getInventoryVariationId(product) {
    return String(getProductField(product, [
        'ID Variacion',
        'ID Variación',
        'ID Variación',
        'idVariacion',
        'ID',
        'id',
        'SKU'
    ], '') || '').trim();
}

function normalizeSearchText(value) {
    return String(value || '')
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .toLowerCase()
        .trim();
}

function normalizeInventoryCategoryWord(word) {
    const singularMap = {
        anillos: 'anillo',
        aretes: 'arete',
        collares: 'collar',
        pulseras: 'pulsera',
        dijes: 'dije',
        billeteras: 'billetera',
        monederos: 'monedero',
        bolsos: 'bolso',
        maletas: 'maleta',
        botillos: 'botillo',
        termos: 'termo',
        cepillos: 'cepillo',
        espejos: 'espejo',
        cosmetiqueras: 'cosmetiquera',
        maquillajes: 'maquillaje',
        caimanes: 'caiman',
        cadenas: 'cadena',
        escolares: 'escolar',
        juegos: 'juego',
        estuches: 'estuche',
        joyeros: 'joyero',
        llaveros: 'llavero',
        lamparas: 'lampara',
        relojes: 'reloj',
        peluches: 'peluche'
    };
    const cleanWord = normalizeSearchText(word).replace(/[^a-z0-9]+/g, '');
    if (!cleanWord) return '';
    if (singularMap[cleanWord]) return singularMap[cleanWord];
    if (cleanWord.length > 4 && cleanWord.endsWith('s')) return cleanWord.slice(0, -1);
    return cleanWord;
}

function normalizeInventoryCategoryKey(value) {
    const base = normalizeSearchText(value);
    if (base === 'todos' || base === 'all') return 'todos';
    return base
        .replace(/\s*\/\s*/g, '/')
        .split('/')
        .map(part => part
            .split(/\s+/)
            .map(normalizeInventoryCategoryWord)
            .filter(Boolean)
            .join(' '))
        .filter(Boolean)
        .join('/');
}

function formatInventoryCategoryLabel(value) {
    return String(value || '')
        .replace(/\s*\/\s*/g, ' / ')
        .replace(/\s+/g, ' ')
        .trim()
        .toLowerCase()
        .replace(/(^|[\s/])([a-záéíóúñ])/g, function (_, prefix, letter) {
            return prefix + letter.toUpperCase();
        });
}

function getInventoryCategoryGroups(options = {}) {
    const includeDefaults = options.includeDefaults !== false;
    const defaults = ['Collares', 'Pulseras', 'Aretes', 'Anillos', 'Sets', 'Dijes', 'BANNER'];
    const groups = new Map();

    function addCategory(rawCategory) {
        const raw = String(rawCategory || '').trim();
        if (!raw) return;
        const key = normalizeInventoryCategoryKey(raw);
        if (!key) return;
        if (!groups.has(key)) {
            groups.set(key, {
                key,
                label: formatInventoryCategoryLabel(raw),
                values: new Set()
            });
        }
        groups.get(key).values.add(raw);
    }

    if (includeDefaults) defaults.filter(value => !window.isInventoryDefaultCategoryRemoved?.(normalizeInventoryCategoryKey(value))).forEach(addCategory);
    (inventario || []).forEach(product => addCategory(product.Categoria || product.categoria));

    return Array.from(groups.values())
        .sort((a, b) => String(a.label).localeCompare(String(b.label), 'es', { sensitivity: 'base' }));
}

function inventorySearchBlob(product) {
    return normalizeSearchText([
        product.Nombre,
        product.Categoria,
        product.Catalogo,
        product.Color,
        product.Tamano,
        product.Estilo,
        product.SKU,
        product.CodigoBarras,
        getInventoryMotherId(product),
        getInventoryVariationId(product),
        product.Estado,
        product.Stock,
        product.Precio,
        product.Precio_Mayorista
    ].join(' '));
}

function scoreInventorySearch(product, query) {
    const q = normalizeSearchText(query);
    if (!q) return 1;

    const terms = q.split(/\s+/).filter(Boolean);
    const name = normalizeSearchText(product.Nombre);
    const category = normalizeSearchText(product.Categoria);
    const sku = normalizeSearchText(product.SKU || getInventoryVariationId(product) || getInventoryMotherId(product));
    const blob = inventorySearchBlob(product);

    if (!terms.every(term => blob.includes(term))) return 0;

    let score = 10;
    terms.forEach(term => {
        if (name.startsWith(term)) score += 60;
        else if (name.includes(term)) score += 35;
        if (category.includes(term)) score += 20;
        if (sku.includes(term)) score += 25;
    });

    return score;
}

async function postProductToGoogleSheets(data, isEditingOverride = null) {
    const editId = data?.__adminOriginalId || data?.originalId || data?.editId || null;
    data = normalizeProductPayloadForSubmit(data);
    if (!data['ID Producto']) {
        throw new Error('Falta ID Producto Madre. No se puede enviar al inventario.');
    }
    const isEditing = isEditingOverride !== null ? isEditingOverride : Boolean(data['ID Variacion'] || data.id || data.editId);
    const payload = {
        resource: 'productos',
        action: isEditing ? 'editar' : 'crear',
        data
    };
    if (editId) payload.id = editId;

    const res = await fetch(GOOGLE_SHEET_API, {
        method: 'POST',
        body: JSON.stringify(payload)
    });
    const result = await res.json();

    if (result && (result.ok || result.status === 'success')) {
        return result.data || result;
    }

    throw new Error(result?.error || result?.message || 'No se pudo guardar el producto');
}

async function postProductBatchToGoogleSheets(itemsList) {
    if (!itemsList || itemsList.length === 0) return [];
    
    const normalizedItems = itemsList.map(item => {
        const editId = item?.__adminOriginalId || item?.originalId || item?.editId || null;
        const normalized = normalizeProductPayloadForSubmit(item);
        if (editId) normalized.__adminOriginalId = editId;
        return normalized;
    });
    const payload = {
        resource: 'productos',
        action: 'batchsave',
        data: normalizedItems
    };

    const res = await fetch(GOOGLE_SHEET_API, {
        method: 'POST',
        body: JSON.stringify(payload)
    });
    const result = await res.json();

    if (result && (result.ok || result.status === 'success')) {
        return Array.isArray(result.data) ? result.data : [result.data || result];
    }

    throw new Error(result?.error || result?.message || 'No se pudo guardar el lote de productos');
}

async function saveProductListToGoogleSheets(itemsList, options = {}) {
    if (!itemsList || itemsList.length === 0) return [];

    try {
        return await postProductBatchToGoogleSheets(itemsList);
    } catch (batchError) {
        console.warn('Guardado por lote falló. Reintentando uno por uno:', batchError);
    }

    const saved = [];
    const failures = [];
    const fallbackEditOverride = options.fallbackEditOverride === undefined ? false : options.fallbackEditOverride;

    for (const item of itemsList) {
        try {
            const itemEditOverride = item && item.__adminForceCreate ? false : fallbackEditOverride;
            saved.push(await postProductToGoogleSheets(item, itemEditOverride));
        } catch (error) {
            const id = item?.['ID Variacion'] || item?.['ID Variación'] || item?.idVariacion || item?.SKU || item?.Nombre || 'sin ID';
            failures.push(`${id}: ${error.message || error}`);
        }
    }

    if (failures.length) {
        throw new Error('No se pudieron guardar algunos productos. ' + failures.join(' | '));
    }

    return saved;
}

function getFilteredInventory() {
    const query = normalizeSearchText(adminInventorySearchQuery);
    const categoryFilter = normalizeInventoryCategoryKey(adminInventoryCategoryFilter);
    const indexed = inventario
        .map((product, index) => ({ product, index }))
        .filter(item => !isBannerInventoryProduct(item.product) && isVisibleInventoryProduct(item.product));

    function getMid(p) {
        var id = getInventoryMotherId(p) || getInventoryVariationId(p);
        if (!id) {
            if (!p._fallbackId) p._fallbackId = 'no-id-' + Math.random().toString(36).substr(2, 9);
            id = p._fallbackId;
        }
        return id;
    }

    function isMother(p) {
        var idv = getInventoryVariationId(p);
        var idp = getInventoryMotherId(p);
        return !idp || !idv || idv === idp;
    }

    var grouped = new Map();
    indexed.forEach(function (item) {
        var mid = getMid(item.product);
        if (!grouped.has(mid)) grouped.set(mid, []);
        grouped.get(mid).push(item);
    });

    grouped.forEach(function (items) {
        items.sort(function (a, b) {
            var aIsMother = isMother(a.product) ? 1 : 0;
            var bIsMother = isMother(b.product) ? 1 : 0;
            return bIsMother - aIsMother;
        });
    });

    let groupEntries = Array.from(grouped.entries()).map(function (entry, groupOrder) {
        return { motherId: entry[0], items: entry[1], score: 1, groupOrder: groupOrder };
    });

    if (categoryFilter && categoryFilter !== 'todos') {
        groupEntries = groupEntries.filter(function (entry) {
            return entry.items.some(function (item) {
                return normalizeInventoryCategoryKey(item.product.Categoria) === categoryFilter;
            });
        });
    }

    if (query) {
        var scoresByMother = new Map();
        indexed.forEach(function (item) {
            var score = scoreInventorySearch(item.product, query);
            if (score <= 0) return;
            var mid = getMid(item.product);
            scoresByMother.set(mid, Math.max(scoresByMother.get(mid) || 0, score));
        });

        groupEntries = groupEntries
            .filter(function (entry) { return scoresByMother.has(entry.motherId); })
            .map(function (entry) {
                entry.score = scoresByMother.get(entry.motherId);
                return entry;
            })
            .sort(function (a, b) {
                return (b.score - a.score) || (a.groupOrder - b.groupOrder);
            });
    }

    var finalFlatList = [];
    groupEntries.forEach(function (entry) {
        var items = entry.items;
        var motherId = entry.motherId;

        var totalStock = items.reduce(function (s, item) { return s + (Number(item.product.Stock || item.product.Cantidad) || 0); }, 0);
        var prices = items.map(function (i) { return Number(i.product.Precio || 0); }).filter(function (p) { return p > 0; });
        var wholesalePrices = items.map(function (i) { return Number(i.product.Precio_Mayorista || i.product['Precio Mayor'] || 0); }).filter(function (p) { return p > 0; });
        var minPrice = prices.length ? Math.min.apply(null, prices) : 0;
        var maxPrice = prices.length ? Math.max.apply(null, prices) : 0;
        var minWholesalePrice = wholesalePrices.length ? Math.min.apply(null, wholesalePrices) : 0;
        var maxWholesalePrice = wholesalePrices.length ? Math.max.apply(null, wholesalePrices) : 0;

        function pushInventoryRow(item, isChild) {
            finalFlatList.push({
                product: item.product,
                index: item.index,
                isChild: isChild,
                groupSize: items.length,
                motherId: motherId,
                totalStock: totalStock,
                minPrice: minPrice,
                maxPrice: maxPrice,
                minWholesalePrice: minWholesalePrice,
                maxWholesalePrice: maxWholesalePrice
            });
        }

        if (items.length > 1) {
            pushInventoryRow(items[0], false);
            items.forEach(function (item) {
                pushInventoryRow(item, true);
            });
        } else {
            pushInventoryRow(items[0], false);
        }
    });

    return finalFlatList;
}

function el(id) {
    return document.getElementById(id);
}

function setInputValue(id, value = '') {
    const input = el(id);
    if (input) {
        input.value = value ?? '';
        syncColorPickerByInput(input);
    }
}

function setMotherProductId(value = '') {
    setInputValue('prod-id-producto', value);
    setInputValue('prod-id-producto-hidden', value);
}

function getInputValue(id) {
    return el(id)?.value?.trim() || '';
}

function splitProductColorValues(value) {
    return String(value || '')
        .split(',')
        .map(item => item.trim())
        .filter(Boolean);
}

function normalizeProductColorName(value) {
    const clean = normalizeSearchText(value);
    const option = PRODUCT_COLOR_OPTIONS.find(item => normalizeSearchText(item.name) === clean);
    return option ? option.name : String(value || '').trim();
}

function getProductColorOption(value) {
    const clean = normalizeSearchText(value);
    return PRODUCT_COLOR_OPTIONS.find(item => normalizeSearchText(item.name) === clean) || null;
}

function isHexColorValue(value) {
    return /^#[0-9a-f]{6}$/i.test(String(value || '').trim());
}

function normalizeHexColor(value) {
    const clean = String(value || '').trim();
    return isHexColorValue(clean) ? clean.toUpperCase() : '';
}

function getAdminColorHex(value) {
    const hex = normalizeHexColor(value);
    if (hex) return hex;
    const option = getProductColorOption(value);
    if (option) return option.hex;
    const clean = normalizeSearchText(value);
    const aliases = {
        gris: '#808080',
        plata: '#c0c0c0',
        plateada: '#c0c0c0',
        dorada: '#d4a017',
        oro: '#d4a017',
        marron: '#8b5e34',
        cafe: '#8b5e34',
        celeste: '#38a7df',
        transparente: '#f8fafc'
    };
    return aliases[clean] || '#888888';
}

function getColorDisplayName(value) {
    const option = getProductColorOption(value);
    if (option) return option.name;
    const hex = normalizeHexColor(value);
    return hex || String(value || '').trim();
}

function findColorPickerTarget(picker) {
    if (!picker) return null;
    const selector = picker.dataset.colorTarget || '';
    if (!selector) return null;
    return picker.closest('.form-group, .admin-panel, .var-edit-expanded, tr, body')?.querySelector(selector)
        || document.querySelector(selector);
}

function syncColorPicker(picker) {
    const target = findColorPickerTarget(picker);
    if (!target) return;
    const currentValues = splitProductColorValues(target.value).map(normalizeProductColorName);
    const customOptions = currentValues
        .filter(value => value && !getProductColorOption(value))
        .map(value => ({ name: value, hex: getAdminColorHex(value), light: normalizeHexColor(value).toLowerCase() === '#ffffff' }));
    const options = PRODUCT_COLOR_OPTIONS.concat(customOptions);
    const selectedSet = new Set(currentValues.map(value => normalizeSearchText(value)));
    const label = currentValues.length ? currentValues.map(getColorDisplayName).join(', ') : 'Sin color seleccionado';
    const supportsEyeDropper = typeof window !== 'undefined' && 'EyeDropper' in window;

    picker.innerHTML = options.map(option => {
        const active = selectedSet.has(normalizeSearchText(option.name));
        const classes = [
            'color-swatch-option',
            active ? 'is-selected' : '',
            option.light ? 'is-light' : ''
        ].filter(Boolean).join(' ');
        return `<button type="button" class="${classes}" style="--swatch:${option.hex};" data-color-value="${escapeHtml(option.name)}" title="${escapeHtml(option.name)}" aria-label="${escapeHtml(option.name)}" aria-pressed="${active ? 'true' : 'false'}"></button>`;
    }).join('') + `<span class="color-picker-value">${escapeHtml(label)}</span>`
        + `<span class="color-picker-actions">`
        + `<button type="button" class="color-custom-btn" title="A&ntilde;adir un color personalizado">+ Color</button>`
        + `<button type="button" class="color-eye-btn" title="${supportsEyeDropper ? 'Tomar color con gotero' : 'Gotero no disponible en este navegador'}">Gotero</button>`
        + `<input type="color" class="color-native-input" aria-label="Color personalizado">`
        + `</span>`;

    const applyCustomColor = color => {
        const hex = normalizeHexColor(color);
        if (!hex) return;
        const multiple = picker.dataset.colorMultiple === 'true';
        let next = splitProductColorValues(target.value).map(normalizeProductColorName);
        const exists = next.some(item => normalizeSearchText(item) === normalizeSearchText(hex));
        next = multiple
            ? (exists ? next : next.concat(hex))
            : [hex];
        target.value = next.join(', ');
        target.dispatchEvent(new Event('input', { bubbles: true }));
        target.dispatchEvent(new Event('change', { bubbles: true }));
        syncColorPicker(picker);
    };

    picker.querySelectorAll('.color-swatch-option').forEach(button => {
        button.addEventListener('click', () => {
            const multiple = picker.dataset.colorMultiple === 'true';
            const value = button.dataset.colorValue || '';
            let next = splitProductColorValues(target.value).map(normalizeProductColorName);
            const clean = normalizeSearchText(value);
            const exists = next.some(item => normalizeSearchText(item) === clean);
            if (multiple) {
                next = exists ? next.filter(item => normalizeSearchText(item) !== clean) : next.concat(value);
            } else {
                next = exists ? [] : [value];
            }
            target.value = next.join(', ');
            target.dispatchEvent(new Event('input', { bubbles: true }));
            target.dispatchEvent(new Event('change', { bubbles: true }));
            syncColorPicker(picker);
        });
    });

    const colorInput = picker.querySelector('.color-native-input');
    picker.querySelector('.color-custom-btn')?.addEventListener('click', () => colorInput?.click());
    colorInput?.addEventListener('input', event => applyCustomColor(event.target.value));
    picker.querySelector('.color-eye-btn')?.addEventListener('click', async () => {
        if (!supportsEyeDropper) {
            colorInput?.click();
            return;
        }
        try {
            const result = await new EyeDropper().open();
            applyCustomColor(result?.sRGBHex);
        } catch (error) {
            if (error?.name !== 'AbortError') colorInput?.click();
        }
    });
}

function syncColorPickerByInput(input) {
    if (!input?.id) return;
    document
        .querySelectorAll('.color-picker[data-color-target]')
        .forEach(picker => {
            if (picker.dataset.colorTarget === `#${input.id}`) syncColorPicker(picker);
        });
}

function initColorPickers(root = document) {
    root.querySelectorAll('.color-picker[data-color-target]').forEach(syncColorPicker);
}

function getColorSwatchesHtml(value) {
    const colors = splitProductColorValues(value);
    if (!colors.length) return '';
    return `<span class="inventory-color-dots">${colors.map(color => (
        `<span class="inventory-color-dot" style="--swatch:${getAdminColorHex(color)}" title="${escapeHtml(color)}"></span>`
    )).join('')}</span>`;
}

function generateMotherProductId() {
    const shortTime = Date.now().toString(36).toUpperCase().slice(-6);
    const randId = Math.floor(1000 + Math.random() * 9000);
    return `PROD-${shortTime}${randId}`;
}

function ensureProductHierarchyIds() {
    let idProducto = getInputValue('prod-id-producto');
    if (!idProducto) {
        idProducto = generateMotherProductId();
        setMotherProductId(idProducto);
    } else {
        setMotherProductId(idProducto);
    }

    let idVariacion = getInputValue('prod-id');
    if (!idVariacion || /^VAR-/i.test(idVariacion)) {
        idVariacion = `${idProducto}-V01`;
        setInputValue('prod-id', idVariacion);
    }

    updateProductBarcodeField();
    return { idProducto, idVariacion };
}

function updateProductBarcodeField(force = false) {
    const barcodeInput = document.getElementById('prod-barcode');
    if (!barcodeInput) return;
    const generated = makeProductBarcode(getInputValue('prod-id-producto'), getInputValue('prod-id'));
    const current = normalizeBarcodeValue(barcodeInput.value);
    const previousGenerated = normalizeBarcodeValue(barcodeInput.dataset.generatedBarcode || '');
    const scanModeEnabled = document.getElementById('prod-barcode-scan-mode')?.checked === true;
    const shouldUseGenerated = force || !scanModeEnabled || (scanModeEnabled && current && (barcodeInput.dataset.autoBarcode === '1' || current === previousGenerated));
    barcodeInput.dataset.generatedBarcode = generated;
    if (shouldUseGenerated) {
        barcodeInput.value = generated;
        barcodeInput.dataset.autoBarcode = '1';
    }
    updateProductQrPreview();
}

function updateProductQrPreview() {
    const barcodeInput = document.getElementById('prod-barcode');
    const image = document.getElementById('prod-generated-qr');
    const codeLabel = document.getElementById('prod-generated-qr-code');
    const code = normalizeBarcodeValue(getInputValue('prod-id-producto'));

    if (codeLabel) codeLabel.textContent = code || 'Generando referencia...';
    if (image) {
        image.hidden = !code;
        if (code) image.src = getInventoryQrImageUrl(code, 240);
    }
}

function setProductBarcodeScanMode(enabled) {
    const toggle = document.getElementById('prod-barcode-scan-mode');
    const panel = document.getElementById('prod-barcode-panel');
    const input = document.getElementById('prod-barcode');
    const hint = document.getElementById('prod-barcode-hint');
    const scanModeEnabled = Boolean(enabled);

    if (toggle) toggle.checked = scanModeEnabled;
    panel?.classList.toggle('is-visible', scanModeEnabled);

    if (!input) return;
    if (scanModeEnabled) {
        const generated = normalizeBarcodeValue(input.dataset.generatedBarcode || makeProductBarcode(getInputValue('prod-id-producto'), getInputValue('prod-id')));
        const current = normalizeBarcodeValue(input.value);
        if (!current || current === generated || input.dataset.autoBarcode === '1') {
            input.value = '';
        }
        input.dataset.autoBarcode = '0';
        if (hint) hint.textContent = 'Abre la camara: detecta el codigo en vivo y lo convierte automaticamente en el QR del producto.';
    } else {
        input.dataset.autoBarcode = '1';
        updateProductBarcodeField(true);
        if (hint) hint.textContent = 'Se genera solo para unir todas las variantes y asigna codigo interno automatico.';
    }
    updateProductQrPreview();
}

function syncScannedCodeToChildReference(code, sourceInput = null) {
    return window.OriginalStoreProductIdentity.applyCode(code, sourceInput || document.getElementById('prod-barcode'));
}

function initProductIdentityControls() {
    window.OriginalStoreProductIdentity.initialize({normalize:normalizeBarcodeValue,barcode:makeProductBarcode,inventory:()=>inventario,inventoryId:getInventoryVariationId,inventoryBarcode:getProductBarcode,mainBarcodeMode:()=>setProductBarcodeScanMode(true),qr:code=>getInventoryQrImageUrl(code,240),preview:()=>{updateProductQrPreview();updateLivePreview();},error:message=>showToast(message,'error')});
}

function initProductBarcodeField() {
    let barcodeInput = document.getElementById('prod-barcode');
    if (!barcodeInput) {
        const skuInput = document.getElementById('prod-sku');
        const skuGroup = skuInput?.closest('.form-group');
        if (!skuGroup) return;

        skuGroup.insertAdjacentHTML('afterend', `
            <div class="form-group admin-form-wide">
                <label>Codigo de barras</label>
                <div style="display:flex;gap:8px;align-items:center;">
                    <input type="text" class="form-control important-code-field" id="prod-barcode" name="Codigo Barras" placeholder="Automatico o escaneado">
                    <button type="button" class="admin-btn secondary" id="btn-scan-product-barcode" style="min-width:118px;">Detectar codigo</button>
                </div>
                <small class="field-hint">La camara se abre en vivo, detecta la marquilla y la convierte en el QR del producto.</small>
            </div>
        `);
        barcodeInput = document.getElementById('prod-barcode');
    }

    if (barcodeInput?.dataset.barcodeReady === '1') {
        updateProductBarcodeField();
        setProductBarcodeScanMode(document.getElementById('prod-barcode-scan-mode')?.checked);
        return;
    }
    if (barcodeInput) barcodeInput.dataset.barcodeReady = '1';

    barcodeInput?.addEventListener('input', () => {
        const scanModeEnabled = document.getElementById('prod-barcode-scan-mode')?.checked === true;
        barcodeInput.dataset.autoBarcode = scanModeEnabled && barcodeInput.value.trim() ? '0' : '1';
        updateProductQrPreview();
    });
    document.getElementById('prod-barcode-scan-mode')?.addEventListener('change', event => {
        setProductBarcodeScanMode(event.target.checked);
    });
    document.getElementById('btn-scan-product-barcode')?.addEventListener('click', () => {
        setProductBarcodeScanMode(true);
        openBarcodeScanner({
            targetInputId: 'prod-barcode',
            onDetected: code => {
                const input = document.getElementById('prod-barcode');
                if (input) {
                    input.value = normalizeBarcodeValue(code);
                    input.dataset.autoBarcode = '0';
                    setProductBarcodeScanMode(true);
                    syncScannedCodeToChildReference(code, input);
                    updateProductQrPreview();
                }
            }
        });
    });
    document.getElementById('btn-preview-product-qr')?.addEventListener('click', () => {
        window.openProductFormQrPreview?.();
    });

    ['prod-id-producto', 'prod-id'].forEach(id => {
        document.getElementById(id)?.addEventListener('input', () => updateProductBarcodeField());
        document.getElementById(id)?.addEventListener('change', () => updateProductBarcodeField());
    });
    updateProductBarcodeField();
    setProductBarcodeScanMode(false);
    updateProductQrPreview();
}

let activeBarcodeScannerStream = null;
let activeBarcodeScannerFrame = null;
let activeHtml5BarcodeScanner = null;
let html5QrcodeLoadPromise = null;
let barcodeScannerSession = 0;
let stopBarcodeFrameReader = null;
let barcodeCameraStopPromise = Promise.resolve();

function loadHtml5QrcodeLibrary() {
    if (typeof window.Html5Qrcode === 'function') return Promise.resolve(true);
    if (html5QrcodeLoadPromise) return html5QrcodeLoadPromise;

    html5QrcodeLoadPromise = new Promise((resolve, reject) => {
        const script = document.createElement('script');
        script.src = 'html5-qrcode.min.js?v=2.3.8-frame1';
        script.async = true;
        script.onload = () => resolve(typeof window.Html5Qrcode === 'function');
        script.onerror = () => reject(new Error('No se pudo cargar el lector compatible'));
        document.head.appendChild(script);
    }).catch(error => {
        html5QrcodeLoadPromise = null;
        throw error;
    });
    return html5QrcodeLoadPromise;
}

function closeBarcodeScanner() {
    stopBarcodeFrameReader?.();
    stopBarcodeFrameReader = null;
    barcodeScannerSession += 1;
    document.getElementById('barcode-scanner-modal')?.remove();
    if (activeBarcodeScannerFrame) {
        cancelAnimationFrame(activeBarcodeScannerFrame);
        activeBarcodeScannerFrame = null;
    }
    if (activeBarcodeScannerStream) {
        activeBarcodeScannerStream.getTracks().forEach(track => track.stop());
        activeBarcodeScannerStream = null;
    }
    if (activeHtml5BarcodeScanner) {
        const scanner = activeHtml5BarcodeScanner;
        activeHtml5BarcodeScanner = null;
        try {
            barcodeCameraStopPromise = Promise.resolve(scanner.stop?.())
                .catch(() => {})
                .finally(() => {
                    try { scanner.clear?.(); } catch (error) {}
                });
        } catch (error) {
            try { scanner.clear?.(); } catch (clearError) {}
        }
    }
}

function buildBarcodeScannerModal() {
    closeBarcodeScanner();
    const modal = document.createElement('div');
    modal.id = 'barcode-scanner-modal';
    modal.className = 'modal open';
    modal.innerHTML = `
        <div class="modal-card barcode-scanner-card">
            <div class="barcode-scanner-head">
                <div><span class="admin-kicker">Lectura automatica en vivo</span><h2>Detector inteligente</h2></div>
                <button type="button" class="admin-btn secondary" data-barcode-close>Cerrar</button>
            </div>
            <div class="barcode-scanner-status-wrap">
                <div id="barcode-scanner-status" class="barcode-scanner-status" aria-live="polite">Solicitando permiso de camara. En el celular selecciona Permitir.</div>
                <button type="button" class="admin-btn secondary barcode-camera-retry" id="barcode-camera-retry" hidden>Reintentar camara</button>
            </div>
            <label class="barcode-reader-mode">Tipo de lectura
                <select id="barcode-reader-mode" class="form-control" aria-label="Tipo de lectura"><option value="qr">QR de tickets</option><option value="auto">Automática — QR y barras</option><option value="compatible">Compatible — QR y barras</option></select>
            </label>
            <p class="barcode-phone-hint">Escanea desde el celular y pulsa Guardar como pendiente para completar el producto después en el PC. Mantén todas las barras visibles, el código enfocado y buena luz.</p>
            <button type="button" id="barcode-camera-refresh" class="admin-btn secondary">Actualizar cámaras</button>
            <div class="barcode-camera-picker" id="barcode-camera-picker" hidden>
                <label for="barcode-camera-select">Cámara en uso</label>
                <select id="barcode-camera-select" class="form-control" aria-label="Seleccionar cámara"></select>
            </div>
            <div class="barcode-scanner-stage">
                <video id="barcode-scanner-video" playsinline muted autoplay></video>
                <div id="barcode-scanner-reader"></div>
                <div class="barcode-scanner-guide" aria-hidden="true"><span></span></div>
            </div>
            <div class="barcode-live-readout" id="barcode-live-readout" aria-live="polite">
                <span>Buscando codigo...</span>
                <strong id="barcode-live-value">Apunta al codigo de barras o QR</strong>
                <small id="barcode-live-format">QR · EAN · UPC · CODE 128 · CODE 39 · ITF</small>
            </div>
            <div class="barcode-scanner-manual-row">
                <input class="form-control" id="barcode-scanner-manual" inputmode="text" autocomplete="off" placeholder="Referencia manual (respaldo)">
                <button type="button" class="admin-btn" id="barcode-scanner-use-manual">Confirmar</button>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    modal.addEventListener('click', event => {
        if (event.target === modal || event.target.closest('[data-barcode-close]')) closeBarcodeScanner();
    });
    return modal;
}

function getHtml5BarcodeFormats() {
    const formats = window.Html5QrcodeSupportedFormats;
    if (!formats) return [];
    return [
        formats.QR_CODE,
        formats.CODE_128,
        formats.CODE_39,
        formats.CODE_93,
        formats.CODABAR,
        formats.EAN_13,
        formats.EAN_8,
        formats.UPC_A,
        formats.UPC_E,
        formats.ITF
    ].filter(value => Number.isFinite(value));
}

function getBarcodeCameraErrorMessage(error) {
    const name = String(error?.name || '');
    const message = String(error?.message || error || '');
    if (!window.isSecureContext) {
        return 'La camara esta autorizada, pero el navegador la bloquea porque esta pagina no usa HTTPS. Abre Original Store desde su direccion segura.';
    }
    if (/NotAllowed|Permission|denied/i.test(`${name} ${message}`)) {
        if (isIosBarcodeDevice()) {
            return 'Safari no entrego acceso a la camara. Revisa Ajustes > Safari > Camara y pulsa Reintentar camara.';
        }
        if (!isMobileBarcodeDevice()) {
            return 'El navegador no entrego acceso a la webcam. Permite la cámara para este sitio y revisa en Windows: Configuración > Privacidad > Cámara.';
        }
        return 'El navegador no entrego acceso a la camara. Revisa el permiso de este sitio y pulsa Reintentar camara.';
    }
    if (/NotReadable|TrackStart|Could not start|Abort/i.test(`${name} ${message}`)) {
        return 'La camara esta permitida pero no pudo iniciar. Cierra otras apps que la usen y pulsa Reintentar camara.';
    }
    if (/NotFound|DevicesNotFound/i.test(`${name} ${message}`)) {
        return 'No se encontro una camara disponible en este dispositivo.';
    }
    if (/Overconstrained|ConstraintNotSatisfied/i.test(`${name} ${message}`)) {
        return 'La camara no acepta el modo solicitado. Pulsa Reintentar para abrirla en modo compatible.';
    }
    if (isIosBarcodeDevice()) {
        return 'El iPhone no entrego imagen. Abre Original Store directamente en Safari, cierra otras apps con camara y pulsa Reintentar.';
    }
    return 'No se pudo iniciar el video de la camara. Pulsa Reintentar camara o usa la referencia manual.';
}

function getBarcodeFormatLabel(format) {
    const normalized = String(format || '').trim().toLowerCase().replace(/[-\s]/g, '_');
    const labels = {
        qr_code: 'QR',
        qr: 'QR',
        code_128: 'CODE 128',
        code_39: 'CODE 39',
        code_93: 'CODE 93',
        codabar: 'CODABAR',
        ean_13: 'EAN-13',
        ean_8: 'EAN-8',
        upc_a: 'UPC-A',
        upc_e: 'UPC-E',
        itf: 'ITF'
    };
    return labels[normalized] || String(format || 'Codigo').toUpperCase();
}

function isMobileBarcodeDevice() {
    return isIosBarcodeDevice() || /Android|Mobile|IEMobile|Opera Mini/i.test(navigator.userAgent || '');
}

function getBarcodeVideoConstraints(deviceId = '') {
    const constraints = {
        width: { ideal: 1920 },
        height: { ideal: 1080 }
    };
    if (deviceId) {
        constraints.deviceId = { exact: deviceId };
    } else if (isMobileBarcodeDevice()) {
        constraints.facingMode = { ideal: 'environment' };
    }
    return constraints;
}

function getBasicBarcodeVideoConstraints(deviceId = '') {
    if (deviceId) return { deviceId: { exact: deviceId } };
    return isMobileBarcodeDevice() ? { facingMode: { ideal: 'environment' } } : true;
}

function getBarcodeScanBox(width, height) {
    const availableWidth = Math.max(180, width - 20);
    const availableHeight = Math.max(170, height - 20);
    return {
        width: Math.floor(Math.min(520, availableWidth, Math.max(260, width * 0.94))),
        height: Math.floor(Math.min(360, availableHeight, Math.max(190, height * 0.78)))
    };
}

function isIosBarcodeDevice() {
    return /iPad|iPhone|iPod/i.test(navigator.userAgent || '') ||
        (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
}

function pickRearBarcodeCamera(cameras = []) {
    const rearPattern = /back|rear|environment|trasera|posterior|arriere|ruck/i;
    return cameras.find(camera => rearPattern.test(String(camera?.label || ''))) || cameras[cameras.length - 1] || cameras[0] || null;
}

async function populateBarcodeCameraPicker(modal, selectedDeviceId = '') {
    const picker = modal?.querySelector('#barcode-camera-picker');
    const select = modal?.querySelector('#barcode-camera-select');
    if (!picker || !select || !navigator.mediaDevices?.enumerateDevices) return;
    const cameras = (await navigator.mediaDevices.enumerateDevices().catch(() => []))
        .filter(device => device.kind === 'videoinput');
    if (!cameras.length) { picker.hidden = true; return; }

    select.innerHTML = cameras.map((camera, index) => {
        const name = camera.label || `Cámara ${index + 1}`;
        return `<option value="${escapeHtml(camera.deviceId)}">${escapeHtml(name)}</option>`;
    }).join('');
    const current = cameras.some(camera => camera.deviceId === selectedDeviceId)
        ? selectedDeviceId
        : cameras[0].deviceId;
    select.value = current;
    picker.hidden = false;
}

async function optimizeBarcodeCameraStream(stream) {
    const [track] = stream?.getVideoTracks?.() || [];
    if (!track || typeof track.getCapabilities !== 'function' || typeof track.applyConstraints !== 'function') return;
    const capabilities = track.getCapabilities();
    const advanced = [];
    if (Array.isArray(capabilities.focusMode) && capabilities.focusMode.includes('continuous')) {
        advanced.push({ focusMode: 'continuous' });
    }
    if (typeof capabilities.zoom?.min === 'number' && typeof capabilities.zoom?.max === 'number') {
        const comfortableZoom = Math.min(capabilities.zoom.max, Math.max(capabilities.zoom.min, 1));
        advanced.push({ zoom: comfortableZoom });
    }
    if (!advanced.length) return;
    try {
        await track.applyConstraints({ advanced });
    } catch (error) {}
}

function attachBarcodeCameraStream(video, stream, { status, retryButton, scannerSession } = {}) {
    if (!video) throw new DOMException('Vista de camara no disponible', 'NotReadableError');
    video.muted = true;
    video.autoplay = true;
    video.playsInline = true;
    video.setAttribute('playsinline', '');
    video.setAttribute('webkit-playsinline', '');
    video.srcObject = stream;

    const startPlayback = () => {
        if (!video.paused) return;
        try {
            Promise.resolve(video.play()).catch(() => {});
        } catch (error) {}
    };
    if (video.readyState >= 1) startPlayback();
    else video.addEventListener('loadedmetadata', startPlayback, { once: true });

    window.setTimeout(() => {
        if (scannerSession !== barcodeScannerSession || !video.isConnected) return;
        if (video.videoWidth > 0 && video.videoHeight > 0) return;
        startPlayback();
        if (status) status.textContent = 'La camara esta abierta pero aun no entrega imagen. Pulsa Reintentar camara si continua en negro.';
        if (retryButton) retryButton.hidden = false;
    }, 4500);
}

function createStableBarcodeHandler({ status, readout, valueLabel, formatLabel, onConfirmed, stabilityWindowMs = 1600, confirmQrImmediately = false, normalizeValue = normalizeBarcodeValue, continuous = false }) {
    let candidate = '';
    let candidateHits = 0;
    let lastSeenAt = 0;
    let confirmed = false, previousCode = '', previousSeenAt = 0;

    return (rawCode, format = '') => {
        const cleanCode = normalizeValue(rawCode);
        const lastGap = Date.now() - previousSeenAt;
        if (cleanCode === previousCode) previousSeenAt = Date.now();
        if (confirmed) return !continuous;
        if (continuous && cleanCode === previousCode && lastGap < 1500) return false;
        if (!cleanCode) return false;

        const now = Date.now();
        if (candidate === cleanCode && now - lastSeenAt < stabilityWindowMs) {
            candidateHits += 1;
        } else {
            candidate = cleanCode;
            candidateHits = 1;
        }
        lastSeenAt = now;

        if (valueLabel) valueLabel.textContent = cleanCode;
        if (formatLabel) {
            formatLabel.textContent = `${getBarcodeFormatLabel(format)} · Verificando ${Math.min(candidateHits, 2)}/2`;
        }
        readout?.classList.add('is-detected');

        const validQr = confirmQrImmediately && getBarcodeFormatLabel(format) === 'QR';
        if (candidateHits < 2 && !validQr) {
            if (status) status.textContent = 'Codigo detectado. Mantenlo quieto un instante para confirmarlo.';
            return false;
        }

        confirmed = true;
        readout?.classList.add('is-confirmed');
        if (formatLabel) formatLabel.textContent = `${getBarcodeFormatLabel(format)} · Lectura confirmada`;
        if (status) status.textContent = 'Codigo confirmado. Generando su referencia QR...';
        if (continuous) {
            previousCode = cleanCode; previousSeenAt = Date.now();
            Promise.resolve().then(() => onConfirmed(cleanCode)).catch(error => {
                if (status) status.textContent = error.message || 'No se pudo enviar. Revisa la conexión.';
            }).finally(() => { confirmed = false; candidate = ''; candidateHits = 0; });
            return false;
        }
        if (validQr) onConfirmed(cleanCode);
        else window.setTimeout(() => onConfirmed(cleanCode), 180);
        return true;
    };
}

async function startHtml5BarcodeCamera(reader, video, status, handleDetectedCode, { preferredDeviceId = '', onCameraReady, qrOnly = false } = {}) {
    await loadHtml5QrcodeLibrary();
    if (typeof window.Html5Qrcode !== 'function') return false;
    if (video) video.style.display = 'none';
    if (reader) reader.style.display = 'block';
    const formatsToSupport = qrOnly ? [window.Html5QrcodeSupportedFormats.QR_CODE] : getHtml5BarcodeFormats();
    const scannerConfig = {
        fps: qrOnly && isMobileBarcodeDevice() ? 20 : (isMobileBarcodeDevice() ? (isIosBarcodeDevice() ? 10 : 15) : 8),
        // A smaller mobile QR region avoids decoding the entire camera image twice.
        ...(qrOnly && isMobileBarcodeDevice() ? { qrbox: (width, height) => {
            const side = Math.floor(Math.min(420, Math.min(width, height) * 0.85));
            return { width: side, height: side };
        }} : {}),
        disableFlip: qrOnly,
        videoConstraints: {
            ...getBarcodeVideoConstraints(preferredDeviceId),
            ...(qrOnly && isMobileBarcodeDevice() ? { width: { ideal: 1280 }, height: { ideal: 1280 }, aspectRatio: { ideal: 1 } } : {})
        }
    };
    const onScanSuccess = (decodedText, decodedResult) => {
        const detectedFormat = decodedResult?.result?.format?.formatName || decodedResult?.format?.formatName || '';
        handleDetectedCode(decodedText, detectedFormat);
    };

    let nativeQr = false;
    if (qrOnly && isMobileBarcodeDevice() && typeof window.BarcodeDetector?.getSupportedFormats === 'function') {
        try { nativeQr = (await window.BarcodeDetector.getSupportedFormats()).includes('qr_code'); }
        catch (_) { /* Keep the software reader when native support cannot be checked. */ }
    }

    const createScanner = () => {
        const instance = new window.Html5Qrcode('barcode-scanner-reader', {
            formatsToSupport,
            // QR supports hardware acceleration; the library falls back to its software reader.
            useBarCodeDetectorIfSupported: nativeQr
        });
        activeHtml5BarcodeScanner = instance;
        return instance;
    };
    const resetFailedScanner = scanner => {
        try { scanner.clear?.(); } catch (error) {}
        if (activeHtml5BarcodeScanner === scanner) activeHtml5BarcodeScanner = null;
        if (reader) reader.innerHTML = '';
    };

    let scanner = createScanner();
    let startError = null;
    const preferredConfig = preferredDeviceId || { facingMode: isMobileBarcodeDevice() ? 'environment' : 'user' };
    try {
        await scanner.start(preferredConfig, scannerConfig, onScanSuccess, () => {});
    } catch (error) {
        startError = error;
        resetFailedScanner(scanner);
        const cameras = typeof window.Html5Qrcode.getCameras === 'function'
            ? await window.Html5Qrcode.getCameras().catch(() => [])
            : [];
        const fallbackCamera = preferredDeviceId
            ? cameras.find(camera => camera.id === preferredDeviceId)
            : (isMobileBarcodeDevice() ? pickRearBarcodeCamera(cameras) : cameras[0]);
        scanner = createScanner();
        try {
            await scanner.start(fallbackCamera?.id || getBasicBarcodeVideoConstraints(preferredDeviceId), { ...scannerConfig, videoConstraints: undefined }, onScanSuccess, () => {});
            startError = null;
        } catch (fallbackError) {
            startError = fallbackError;
        }
    }
    if (startError) {
        resetFailedScanner(scanner);
        throw startError;
    }
    if (!reader?.isConnected) {
        try { await scanner.stop(); } catch (error) {}
        try { scanner.clear(); } catch (error) {}
        if (activeHtml5BarcodeScanner === scanner) activeHtml5BarcodeScanner = null;
        return true;
    }

    const scannerVideo = reader.querySelector('video');
    if (scannerVideo) {
        scannerVideo.muted = true;
        scannerVideo.autoplay = true;
        scannerVideo.playsInline = true;
        scannerVideo.setAttribute('playsinline', '');
        scannerVideo.setAttribute('webkit-playsinline', '');
        try { Promise.resolve(scannerVideo.play()).catch(() => {}); } catch (error) {}
    }
    if (status) {
        status.textContent = isIosBarcodeDevice()
            ? 'Camara trasera activa en iPhone. Manten el codigo centrado y con buena luz.'
            : (!isMobileBarcodeDevice()
                ? 'Webcam activa con lector compatible. Mantén el código horizontal, completo y enfocado. Puedes cambiar la cámara arriba.'
                : 'Camara activa. La lectura es automatica: ubica el codigo en el area iluminada, sin pegarlo tanto a la camara.');
    }
    await window.BlyxuQrCamera?.scanner(scanner, reader);
    await onCameraReady?.();
    if (!isMobileBarcodeDevice() && scannerVideo && window.BlyxuBarcodeFrames) {
        stopBarcodeFrameReader = window.BlyxuBarcodeFrames.start({ video: scannerVideo, container: reader.parentElement.parentElement, formats: formatsToSupport,
            onDetected: (text, format) => { if (!reader.isConnected) return; handleDetectedCode(text, format); } });
    }
    return true;
}

async function openBarcodeScanner({ targetInputId, onDetected, preferredDeviceId = '', scannerMode = 'auto', continuous = false, preserveRawValue = false, sharedRemote = false } = {}) {
    if(window.OriginalStoreSharedScan?.isPhone()&&!sharedRemote&&!preserveRawValue)return window.OriginalStoreSharedScan.openPhoneScanner();
    const modal = buildBarcodeScannerModal();
    modal.classList.toggle('barcode-scanner-qr-mode', scannerMode === 'qr');
    const scannerSession = barcodeScannerSession;
    const video = modal.querySelector('#barcode-scanner-video');
    const status = modal.querySelector('#barcode-scanner-status');
    const manualInput = modal.querySelector('#barcode-scanner-manual');
    const reader = modal.querySelector('#barcode-scanner-reader');
    const retryButton = modal.querySelector('#barcode-camera-retry');
    const cameraSelect = modal.querySelector('#barcode-camera-select');
    const modeSelect = modal.querySelector('#barcode-reader-mode');
    modeSelect.value = scannerMode;
    const readout = modal.querySelector('#barcode-live-readout');
    const valueLabel = modal.querySelector('#barcode-live-value');
    const formatLabel = modal.querySelector('#barcode-live-format');
    const useCode = async code => {
        const cleanCode = preserveRawValue ? String(code || '').trim().slice(0, 2048) : normalizeBarcodeValue(code);
        if (!cleanCode) return;
        if (typeof onDetected === 'function') {
            await onDetected(cleanCode);
        } else if (targetInputId) {
            const target = document.getElementById(targetInputId);
            if (target) target.value = cleanCode;
        }
        if (!continuous) { showToast('Referencia capturada', 'success'); closeBarcodeScanner(); }
        else if (status) status.textContent = 'Recibido en el computador. Escanea el siguiente código.';
    };
    const handleDetectedCode = createStableBarcodeHandler({
        status,
        readout,
        valueLabel,
        formatLabel,
        onConfirmed: code => { const pending=useCode(code);pending.catch(error=>{if(status)status.textContent=error.message;showToast(error.message,'error');});return pending; },
        stabilityWindowMs: isMobileBarcodeDevice() ? 1600 : 4000,
        confirmQrImmediately: scannerMode === 'qr',
        continuous,
        normalizeValue: preserveRawValue ? value => String(value || '').trim().slice(0, 2048) : normalizeBarcodeValue
    });

    modal.querySelector('#barcode-scanner-use-manual')?.addEventListener('click', () => useCode(manualInput?.value || '').catch(error => { status.textContent = error.message; }));
    manualInput?.addEventListener('keydown', event => {
        if (event.key === 'Enter') {
            event.preventDefault();
            useCode(manualInput.value).catch(error => { status.textContent = error.message; });
        }
    });
    const reopenWithCamera = deviceId => {
        openBarcodeScanner({ targetInputId, onDetected, preferredDeviceId: deviceId || '', scannerMode: modeSelect.value, continuous, preserveRawValue, sharedRemote });
    };
    retryButton?.addEventListener('click', () => {
        reopenWithCamera(preferredDeviceId);
    });
    cameraSelect?.addEventListener('change', () => reopenWithCamera(cameraSelect.value));
    modeSelect.addEventListener('change', () => reopenWithCamera(cameraSelect.value || preferredDeviceId));
    modal.querySelector('#barcode-camera-refresh').addEventListener('click', () => populateBarcodeCameraPicker(modal, cameraSelect.value || preferredDeviceId));
    const permissionHintTimer = setTimeout(() => {
        if (scannerSession === barcodeScannerSession && modal.isConnected && status) {
            status.textContent = 'La camara esta tardando en iniciar. Revisa el permiso del sitio o pulsa Reintentar camara.';
            if (retryButton) retryButton.hidden = false;
        }
    }, 6500);

    try {
        await barcodeCameraStopPromise;
        if (scannerSession !== barcodeScannerSession || !modal.isConnected) { clearTimeout(permissionHintTimer); return; }
        if (isMobileBarcodeDevice() && scannerMode !== 'compatible' && scannerMode !== 'qr' && 'BarcodeDetector' in window && navigator.mediaDevices?.getUserMedia) {
            const requestedFormats = ['code_128', 'code_39', 'ean_13', 'ean_8', 'upc_a', 'upc_e', 'itf', 'qr_code'];
            const supportedFormats = typeof BarcodeDetector.getSupportedFormats === 'function'
                ? await BarcodeDetector.getSupportedFormats()
                : requestedFormats;
            const detectorFormats = requestedFormats.filter(format => supportedFormats.includes(format));
            const detector = detectorFormats.length
                ? new BarcodeDetector({ formats: detectorFormats })
                : new BarcodeDetector();
            let stream;
            try {
                stream = await navigator.mediaDevices.getUserMedia({
                    video: getBarcodeVideoConstraints(preferredDeviceId),
                    audio: false
                });
            } catch (error) {
                if (!/Overconstrained|ConstraintNotSatisfied/i.test(String(error?.name || error || ''))) throw error;
                stream = await navigator.mediaDevices.getUserMedia({
                    video: getBasicBarcodeVideoConstraints(preferredDeviceId),
                    audio: false
                });
            }
            if (scannerSession !== barcodeScannerSession || !modal.isConnected) {
                stream.getTracks().forEach(track => track.stop());
                return;
            }
            activeBarcodeScannerStream = stream;
            await optimizeBarcodeCameraStream(activeBarcodeScannerStream);
            await window.BlyxuQrCamera?.stream(activeBarcodeScannerStream, modal.querySelector('.barcode-scanner-status-wrap'));
            attachBarcodeCameraStream(video, activeBarcodeScannerStream, { status, retryButton, scannerSession });
            await populateBarcodeCameraPicker(modal, stream.getVideoTracks()[0]?.getSettings?.().deviceId || preferredDeviceId);
            clearTimeout(permissionHintTimer);
            if (status) status.textContent = isMobileBarcodeDevice()
                ? 'Camara activa. La lectura es automatica: ubica el codigo en el area iluminada, sin pegarlo tanto a la camara.'
                : 'Webcam activa. La lectura es automatica: ubica el codigo centrado y con buena luz.';

            let lastDetectionAt = 0;
            const scan = async () => {
                if (!document.getElementById('barcode-scanner-modal')) return;
                const now = performance.now();
                if (now - lastDetectionAt < 90) {
                    activeBarcodeScannerFrame = requestAnimationFrame(scan);
                    return;
                }
                lastDetectionAt = now;
                try {
                    const codes = await detector.detect(video);
                    if (codes && codes.length) {
                        const detectedCode = codes[0];
                        if (handleDetectedCode(detectedCode.rawValue || detectedCode.rawText || '', detectedCode.format || '')) return;
                    }
                } catch (error) {}
                activeBarcodeScannerFrame = requestAnimationFrame(scan);
            };
            scan();
            return;
        }

        if (await startHtml5BarcodeCamera(reader, video, status, handleDetectedCode, {
            preferredDeviceId,
            qrOnly: scannerMode === 'qr',
            onCameraReady: () => populateBarcodeCameraPicker(modal, activeHtml5BarcodeScanner?.getRunningTrackSettings?.().deviceId || preferredDeviceId)
        })) {
            clearTimeout(permissionHintTimer);
            return;
        }
        throw new Error('Escaner no disponible');
    } catch (error) {
        let scannerError = error;
        const errorSignature = `${error?.name || ''} ${error?.message || error || ''}`;
        const canUseCompatibleReader = window.isSecureContext &&
            !/NotAllowed|Permission|denied|Security|NotReadable|TrackStart|NotFound|DevicesNotFound/i.test(errorSignature);

        if (canUseCompatibleReader) {
            if (activeBarcodeScannerStream) {
                activeBarcodeScannerStream.getTracks().forEach(track => track.stop());
                activeBarcodeScannerStream = null;
            }
            if (video) {
                video.srcObject = null;
                video.style.display = 'none';
            }
            try {
                if (await startHtml5BarcodeCamera(reader, video, status, handleDetectedCode, {
                    preferredDeviceId,
            onCameraReady: () => populateBarcodeCameraPicker(modal, activeHtml5BarcodeScanner?.getRunningTrackSettings?.().deviceId || preferredDeviceId)
                })) {
                    clearTimeout(permissionHintTimer);
                    return;
                }
            } catch (fallbackError) {
                scannerError = fallbackError;
            }
        }

        clearTimeout(permissionHintTimer);
        if (scannerSession !== barcodeScannerSession || !modal.isConnected) return;
        if (status) status.textContent = getBarcodeCameraErrorMessage(scannerError);
        if (retryButton) retryButton.hidden = false;
        if (video) video.style.display = 'none';
        if (reader) reader.style.display = 'none';
    }
}

window.scanBarcodeToElement = function (elementId) {
    openBarcodeScanner({
        targetInputId: elementId,
        onDetected: code => {
            const input = document.getElementById(elementId);
            if (input) {
                input.value = normalizeBarcodeValue(code);
                input.dataset.autoBarcode = '0';
                syncScannedCodeToChildReference(code, input);
            }
        }
    });
};

function getSubmittedStockValue(payload) {
    const candidates = [
        payload?.Stock,
        payload?.stock,
        payload?.Cantidad,
        payload?.['Stock Inicial'],
        payload?.Stock_Inicial
    ];
    const rawValue = candidates.find(value => value !== undefined && value !== null && String(value).trim() !== '');
    if (rawValue === undefined) return null;
    const stock = Number(rawValue);
    return Number.isFinite(stock) ? stock : null;
}

function shouldAutoMarkAsOutOfStock(estado) {
    const cleanEstado = String(estado || '')
        .trim()
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '');
    return !cleanEstado || cleanEstado === 'activo' || cleanEstado === 'disponible';
}

function applyAutomaticStockStatus(payload) {
    const stock = getSubmittedStockValue(payload);
    if (stock === 0 && shouldAutoMarkAsOutOfStock(payload.Estado)) {
        payload.Estado = 'Agotado';
    }
    return payload;
}

function syncProductStatusWithStockInput() {
    const stockInput = document.getElementById('prod-stock-inicial');
    const estadoInput = document.getElementById('prod-estado');
    if (!stockInput || !estadoInput) return;
    if (String(stockInput.value || '').trim() === '') return;
    const stock = Number(stockInput.value);
    if (Number.isFinite(stock) && stock === 0 && shouldAutoMarkAsOutOfStock(estadoInput.value)) {
        estadoInput.value = 'Agotado';
        updateLivePreview();
    }
}

function normalizeProductPayloadForSubmit(data) {
    assertProductImageUploadReady();
    for(const field of document.querySelectorAll('#variants-container .var-imagen')){if(!field.disabled&&field.validity.customError)throw new Error(field.validationMessage);}
    const payload = { ...(data || {}) };
    delete payload.__adminForceCreate;
    delete payload.__adminOriginalId;
    delete payload.originalId;
    delete payload.editId;
    const ids = ensureProductHierarchyIds();
    const idProducto = payload['ID Producto'] || payload['ID Producto Madre'] || payload.ID_Producto || payload.ID_PRODUCTO || payload.IdProducto || payload.id_producto || payload.idProducto || ids.idProducto;
    const catalogo = payload.Catalogo || payload['Catálogo'] || payload['Catálogo'] || getInputValue('prod-catalogo') || 'Ambos';
    const cantidad = payload.Cantidad ?? payload.Stock ?? payload.stock ?? payload['Stock Inicial'] ?? '';
    const idVariacion = payload['ID Variacion'] || payload['ID Variación'] || payload.idVariacion || payload.id || ids.idVariacion;
    const categoria = getProductField(payload, PRODUCT_CATEGORY_FIELD_KEYS, getInputValue('prod-categoria'));
    const promoSelect = document.getElementById('prod-promocion');
    const promocion = promoSelect
        ? promoSelect.value
        : getProductPromotionValue(payload, 'FALSO');

    payload['ID Producto'] = idProducto;
    payload['ID Producto Madre'] = idProducto;
    payload.ID_Producto = idProducto;
    payload.ID_PRODUCTO = idProducto;
    payload.IdProducto = idProducto;
    payload.id_producto = idProducto;
    payload.idProducto = idProducto;
    payload['ID Variacion'] = idVariacion;
    payload['ID Variación'] = idVariacion;
    payload.idVariacion = idVariacion;
    setProductBarcodeAliases(payload, getProductField(payload, PRODUCT_BARCODE_FIELD_KEYS, makeProductBarcode(idProducto, idVariacion)));
    payload.Catalogo = catalogo;
    payload['Catálogo'] = catalogo;
    payload['Catálogo'] = catalogo;
    payload.catalogo = catalogo;
    setProductCategoryAliases(payload, categoria);
    setProductPromotionAliases(payload, promocion);
    if (cantidad !== '') payload.Stock = cantidad;
    applyAutomaticStockStatus(payload);

    return window.OriginalStoreRetailPricing?.decorate(payload) || payload;
}

function setProductCategoryAliases(payload, categoria) {
    const cleanCategory = String(categoria || '').trim();
    payload.Categoria = cleanCategory;
    payload['Categor\u00eda'] = cleanCategory;
    payload['Categor\u00c3\u00ada'] = cleanCategory;
    payload['Categor\u00c3\u0192\u00c2\u00ada'] = cleanCategory;
    payload.categoria = cleanCategory;
    return payload;
}

function normalizePromotionValue(value) {
    if (value === true) return 'Ambos';
    if (value === false || value === null || value === undefined) return 'FALSO';
    const clean = String(value ?? '')
        .trim()
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '');

    if (['ambos', 'todos', 'verdadero', 'true', 'si', 's', '1', 'yes', 'activo', 'activa', 'ambas'].includes(clean)) {
        return 'Ambos';
    }
    if (['minorista', 'detal', 'retail', 'solo minorista', 'solo detal'].includes(clean)) {
        return 'Minorista';
    }
    if (['mayorista', 'mayor', 'wholesale', 'solo mayorista', 'solo mayor'].includes(clean)) {
        return 'Mayorista';
    }
    return 'FALSO';
}

function getProductPromotionValue(product, fallback = 'FALSO') {
    const rawValue = getProductField(product || {}, PRODUCT_PROMOTION_FIELD_KEYS, fallback);
    return normalizePromotionValue(rawValue);
}

function setProductPromotionAliases(payload, promocion) {
    const cleanPromotion = normalizePromotionValue(promocion);
    payload.Promocion = cleanPromotion;
    payload['Promoci\u00f3n'] = cleanPromotion;
    payload['Promoci\u00c3\u00b3n'] = cleanPromotion;
    payload['Promoci\u00c3\u0192\u00c2\u00b3n'] = cleanPromotion;
    payload.promo = cleanPromotion;
    return payload;
}

function buildGroupCategorySyncPayloads(idProducto, currentVariationId, categoria, promocion) {
    const motherId = String(idProducto || '').trim();
    const activeVariationId = String(currentVariationId || '').trim();
    const categoryValue = String(categoria || '').trim();
    if (!motherId || !categoryValue) return [];
    const promotionValue = getProductPromotionValue({ Promocion: promocion }, false);

    const seen = new Set();
    return inventario
        .filter(product => getInventoryMotherId(product) === motherId)
        .map(product => ({ product, variationId: getInventoryVariationId(product) }))
        .filter(item => {
            const variationId = item.variationId;
            const cleanVariationId = String(variationId || '').trim();
            if (!cleanVariationId || cleanVariationId === activeVariationId || seen.has(cleanVariationId)) return false;
            seen.add(cleanVariationId);
            return true;
        })
        .map(item => setProductCategoryAliases({
            ...item.product,
            'Fecha de Creaci\u00f3n': getProductField(item.product, ['Fecha de Creaci\u00f3n', 'Fecha de Creacion', 'Fecha_Creacion', 'Fecha de Creaci\u00c3\u00b3n', 'Fecha de Creaci\u00c3\u0192\u00c2\u00b3n'], ''),
            __adminOriginalId: item.variationId,
            'ID Variacion': item.variationId,
            'ID Variaci\u00f3n': item.variationId,
            'ID Producto': motherId,
            ID_Producto: motherId,
            idProducto: motherId
        }, categoryValue))
        .map(payload => setProductPromotionAliases(payload, promotionValue));
}

function buildProductPayload() {
    const ids = ensureProductHierarchyIds();
    const stock = Number(getInputValue('prod-stock-inicial') || 0);
    const stockInicial = stock;
    const idVariacion = ids.idVariacion;
    const idProducto = ids.idProducto;
    const nombre = getInputValue('prod-nombre');
    const categoria = getInputValue('prod-categoria');
    const descripcion = getInputValue('prod-descripcion');
    const imagen = getInputValue('prod-imagen');
    const measurementData = getProductMeasurementFormData();
    const tamano = getProductSizeValue();

    return {
        'ID Variacion': idVariacion,
        'ID Variación': idVariacion,
        'ID Producto': idProducto,
        ID_Producto: idProducto,
        'Nombre del Producto': nombre,
        Nombre: nombre,
        Categoria: categoria,
        Catalogo: getInputValue('prod-catalogo') || 'Ambos',
        'Categoría': categoria,
        'Catálogo': getInputValue('prod-catalogo') || 'Ambos',
        Precio: parseAmount(getInputValue('prod-precio')),
        'Precio Mayor': parseAmount(getInputValue('prod-precio-mayorista')),
        'Stock Inicial': stockInicial,
        Cantidad: stock,
        Stock: stock,
        Descripcion: descripcion,
        'Caracteristicas del producto': descripcion,
        Tamano: tamano,
        Talla: measurementData.kind === 'textil' ? measurementData.textileSize : tamano,
        'Tamaño': tamano,
        ...buildProductMeasurementPayload(measurementData),
        Color: getInputValue('prod-color'),
        Estilo: getProductStyleValue(),
        Promocion: normalizePromotionValue(document.getElementById('prod-promocion')?.value || 'FALSO'),
        'Imagen Principal': imagen,
        'Modo Imagen': 'propia',
        Imagen: imagen,
        'Galeria JSON': stringifyAdminGallery(getInputValue('prod-galeria')),
        'Galería JSON': stringifyAdminGallery(getInputValue('prod-galeria')),
        'Codigo Barras': getInputValue('prod-barcode') || makeProductBarcode(idProducto, idVariacion),
        SKU: getInputValue('prod-sku'),
        Estado: getInputValue('prod-estado') || 'Activo',
        'Fecha de Creación': getInputValue('prod-fecha-creacion') || new Date().toISOString()
    };
}

function splitVariationOptions(value) {
    const items = String(value || '')
        .split(',')
        .map(item => item.trim())
        .filter(Boolean);
    if (items.length > 1) {
        const prefixMatch = items[0].match(/^(.*\D)(\d+)$/);
        if (prefixMatch) {
            const prefix = prefixMatch[1];
            return items.map((item, index) => {
                if (index > 0 && /^\d+$/.test(item)) return prefix + item;
                return item;
            });
        }
    }
    return items.length ? items : [''];
}

function getSelectedVariationPrimaryField() {
    return getInputValue('variation-primary-field') || 'style';
}

function getVariationInputForField(field) {
    if (field === 'color') return getInputValue('variation-colors') || getInputValue('prod-color');
    if (field === 'size') return getInputValue('variation-sizes') || getInputValue('prod-tamano');
    return getInputValue('variation-styles') || getInputValue('prod-estilo');
}

function getVariationFieldFromInput() {
    const selected = getSelectedVariationPrimaryField();
    if (selected !== 'auto') return selected;
    if (getInputValue('variation-styles') || getInputValue('prod-estilo')) return 'style';
    if (getInputValue('variation-colors') || getInputValue('prod-color')) return 'color';
    if (getInputValue('variation-sizes') || getInputValue('prod-tamano')) return 'size';
    return 'style';
}

function getProductStyleValue(fallback = '') {
    return cleanProductStyleValue(getInputValue('prod-estilo')) || fallback;
}

function makeVariantSlug(value) {
    return String(value || 'VAR')
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-zA-Z0-9]+/g, '-')
        .replace(/^-+|-+$/g, '')
        .toUpperCase()
        .slice(0, 18) || 'VAR';
}

function getNextVariantId(idProducto) {
    if (window.OriginalStoreProductIdentity) return window.OriginalStoreProductIdentity.next(idProducto);
    const motherId = String(idProducto || '').trim();
    const usedNumbers = new Set();
    const escapedMother = motherId.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const variantPattern = new RegExp('^' + escapedMother + '-V(\\d+)$', 'i');

    function collect(value) {
        const id = String(value || '').trim();
        const match = id.match(variantPattern);
        if (match) usedNumbers.add(Number(match[1]));
    }

    inventario.forEach(function (product) {
        const mid = String(product.idProducto || product['ID Producto'] || '').trim();
        if (mid !== motherId) return;
        collect(product.idVariacion || product.ID || product['ID Variacion'] || product['ID Variación']);
    });

    document.querySelectorAll('#variants-container .var-id').forEach(function (input) {
        collect(input.value);
    });

    const motherVarId = getInputValue('prod-id');
    if (motherVarId) {
        collect(motherVarId);
    } else {
        usedNumbers.add(1);
    }

    let next = 1;
    while (usedNumbers.has(next)) next += 1;
    return `${motherId}-V${String(next).padStart(2, '0')}`;
}

function buildVariantPayloadFromCard(card) {
    const ids = ensureProductHierarchyIds();
    const variantId = card.querySelector('.var-id')?.value?.trim() || '';
    if (!variantId) return null;
    const stock = Number(card.querySelector('.var-stock')?.value || 0);
    const imagen = getVariantImageValue(card);
    const tamano = getVariantSizeValue(card);
    const color = card.querySelector('.var-color')?.value?.trim() || '';
    const estiloInput = card.querySelector('.var-estilo');
    const estilo = estiloInput ? cleanProductStyleValue(estiloInput.value) : getProductStyleValue();
    const variantMeasurementData = getVariantMeasurementData(card);

    return {
        __adminForceCreate: true,
        'ID Variacion': variantId,
        'ID Variación': variantId,
        'ID Producto': ids.idProducto,
        ID_Producto: ids.idProducto,
        idProducto: ids.idProducto,
        'Nombre del Producto': card.querySelector('.var-nombre')?.value?.trim() || getInputValue('prod-nombre'),
        Nombre: card.querySelector('.var-nombre')?.value?.trim() || getInputValue('prod-nombre'),
        Precio: parseAmount(card.querySelector('.var-precio')?.value || getInputValue('prod-precio')),
        'Precio Mayor': parseAmount(card.querySelector('.var-precio-mayor')?.value || getInputValue('prod-precio-mayorista')),
        Categoria: getInputValue('prod-categoria'),
        Catalogo: getInputValue('prod-catalogo') || 'Ambos',
        'Categoría': getInputValue('prod-categoria'),
        Cantidad: stock,
        Stock: stock,
        'Stock Inicial': stock,
        Descripcion: getInputValue('prod-descripcion'),
        'Caracteristicas del producto': getInputValue('prod-descripcion'),
        Tamano: tamano,
        Talla: tamano,
        'Tamaño': tamano,
        ...buildProductMeasurementPayload(variantMeasurementData),
        Color: color,
        Estilo: estilo,
        'Codigo Barras': card.querySelector('.var-barcode')?.value?.trim() || makeProductBarcode(ids.idProducto, variantId),
        SKU: card.querySelector('.var-sku')?.value?.trim() || '',
        'Modo Imagen': getVariantImageMode(card),
        Imagen: imagen,
        'Imagen Principal': imagen,
        'Galeria JSON': stringifyAdminGallery(getInputValue('prod-galeria')),
        'Galería JSON': stringifyAdminGallery(getInputValue('prod-galeria')),
        Promocion: normalizePromotionValue(document.getElementById('prod-promocion')?.value || 'FALSO'),
        Estado: getInputValue('prod-estado') || 'Activo',
        'Fecha de Creación': getInputValue('prod-fecha-creacion') || new Date().toISOString()
    };
}

function collectVariantPayloads() {
    const cards = Array.from(document.querySelectorAll('#variants-container .admin-panel'));
    return cards
        .filter(card => card.dataset.saved !== '1')
        .map(buildVariantPayloadFromCard)
        .filter(Boolean);
}

function setProductFormMode(isEditing) {
    isEditingProduct = isEditing;
    const title = el('product-form-title');
    const mode = el('product-form-mode');
    const btn = el('btn-save');
    if (title) title.textContent = isEditing ? 'Editar Producto' : 'Nuevo Producto';
    if (mode) mode.textContent = isEditing ? 'Editando' : 'Creando';
    if (btn) btn.textContent = isEditing ? 'Guardar cambios' : 'Guardar producto y variantes';
}

function updateProductImagePreviewBox(url) {
    const box = document.getElementById('prod-image-drop-zone');
    const placeholder = document.getElementById('prod-image-placeholder');
    const previewWrapper = document.getElementById('prod-image-preview-wrapper');
    const previewThumb = document.getElementById('prod-image-preview-thumb');
    
    if (!box || !placeholder || !previewThumb) return;
    
    const trimmed = String(url || '').trim();
    if (trimmed) {
        previewThumb.src = trimmed;
        if (previewWrapper) previewWrapper.style.display = 'flex';
        placeholder.style.display = 'none';
        box.classList.add('has-image');
    } else {
        previewThumb.src = '';
        if (previewWrapper) previewWrapper.style.display = 'none';
        placeholder.style.display = 'flex';
        box.classList.remove('has-image');
    }
}

function updateVariantImagePickerPreview(scope, url) {
    const card = scope?.closest?.('.admin-panel') || scope;
    if (!card) return;
    const zone = card.matches?.('.var-drop-zone') ? card : card.querySelector('.var-drop-zone');
    const placeholder = card.querySelector('.variant-image-placeholder');
    const previewWrapper = card.querySelector('.variant-image-preview-wrapper');
    const previewThumb = card.querySelector('.var-preview-thumb');
    const trimmed = String(url || '').trim();

    if (trimmed) {
        if (previewThumb) previewThumb.src = trimmed;
        if (previewWrapper) previewWrapper.style.display = 'flex';
        if (placeholder) placeholder.style.display = 'none';
        zone?.classList.add('has-image');
    } else {
        if (previewThumb) previewThumb.removeAttribute('src');
        if (previewWrapper) previewWrapper.style.display = 'none';
        if (placeholder) placeholder.style.display = 'flex';
        zone?.classList.remove('has-image');
    }
}

function setupVariantImagePicker(card) {
    const zone = card?.querySelector('.var-drop-zone');
    const fileInput = card?.querySelector('.var-image-file');
    const imageInput = card?.querySelector('.var-imagen');
    const changeBtn = card?.querySelector('.var-image-change-btn');
    const removeBtn = card?.querySelector('.var-image-remove-btn');
    const saveBtn = card?.querySelector('.btn-save-individual-variant');
    if (!zone || !fileInput || !imageInput) return;

    const setUploadingState = (isUploading) => {
        if (!saveBtn) return;
        if (isUploading) {
            saveBtn.dataset.readyText = saveBtn.textContent || 'Guardar esta Variante';
            saveBtn.disabled = true;
            saveBtn.textContent = 'Optimizando imagen...';
        } else {
            saveBtn.disabled = false;
            saveBtn.textContent = saveBtn.dataset.readyText || 'Guardar esta Variante';
            delete saveBtn.dataset.readyText;
        }
    };

    let uploadRevision=0;
    const handleFileSelection = async (file) => {
        if (!file || !file.type?.startsWith('image/')) {
            showToast('Por favor, selecciona un archivo de imagen', 'warning');
            return;
        }

        const revision=++uploadRevision;
        imageInput.dataset.uploadState='uploading';imageInput.setCustomValidity('Espera a que termine de cargar la foto de la variante.');
        const localUrl = URL.createObjectURL(file);
        updateVariantImagePickerPreview(card, localUrl);
        setUploadingState(true);
        showToast('Convirtiendo imagen a WebP y subiendo...');

        try {
            const uploadedUrl = await uploadCarouselImage(file);
            if(revision!==uploadRevision||!card.isConnected)return;
            imageInput.value = uploadedUrl;imageInput.dataset.uploadState='ready';imageInput.setCustomValidity('');
            imageInput.dispatchEvent(new Event('input'));
            updateVariantImagePickerPreview(card, uploadedUrl);
            showToast('Imagen de variante lista', 'success');
        } catch (err) {
            if(revision!==uploadRevision||!card.isConnected)return;
            imageInput.dataset.uploadState='failed';imageInput.setCustomValidity('La foto de la variante no terminó de cargar. Reintenta o usa la foto general.');
            updateVariantImagePickerPreview(card,imageInput.value);
            console.error(err);
            showToast('Error al subir imagen: ' + (err.message || err), 'error');
        } finally {
            URL.revokeObjectURL(localUrl);
            if(revision===uploadRevision&&card.isConnected){fileInput.value='';setUploadingState(false);}
        }
    };

    zone.addEventListener('click', (event) => {
        if (event.target.closest('.var-image-remove-btn') || event.target.closest('.var-image-change-btn')) return;
        fileInput.click();
    });
    changeBtn?.addEventListener('click', (event) => {
        event.stopPropagation();
        fileInput.click();
    });
    removeBtn?.addEventListener('click', (event) => {
        event.stopPropagation();
        imageInput.value = '';
        imageInput.dispatchEvent(new Event('input'));
        updateVariantImagePickerPreview(card, '');
    });
    fileInput.addEventListener('change', () => {
        const file = fileInput.files?.[0];
        if (file) handleFileSelection(file);
    });
    imageInput.addEventListener('input', event => {if(event.isTrusted){++uploadRevision;imageInput.setCustomValidity('');delete imageInput.dataset.uploadState;setUploadingState(false);}updateVariantImagePickerPreview(card,imageInput.value);updateLivePreview();});
    imageInput.addEventListener('change', () => updateVariantImagePickerPreview(card, imageInput.value));
    updateVariantImagePickerPreview(card, imageInput.value);
}

function getVariantAutoSizeValue() {
    return (typeof getProductSizeValue === 'function' ? getProductSizeValue() : '') || getInputValue('prod-tamano') || '';
}

function variantMeasurementMarkup() {
    return '<div class="variant-measure-fields admin-form-grid">' +
        '<div class="form-group"><label>Tipo de tamaño</label><select class="form-control var-size-kind"><option value="">Normal</option><option value="textil">Textil</option><option value="medidas">Medidas</option><option value="liquido">Líquidos / ml</option></select></div>' +
        '<div class="form-group var-textile-fields"><label>Talla textil</label><select class="form-control var-textile-size"><option value="">Seleccionar</option>'+['XS','S','M','L','XL','2XL','3XL'].map(x=>'<option>'+x+'</option>').join('')+'</select><label>Otra talla</label><input class="form-control var-textile-custom" placeholder="Ej: 4XL, talla única"></div>' +
        '<div class="measurement-grid var-measure-grid"><div class="form-group"><label>Unidad</label><select class="form-control var-measure-unit"><option>cm</option><option>m</option><option>m3</option><option>ml</option></select></div>' +
        [['capacity','Capacidad'],['width','Ancho'],['length','Largo'],['depth','Fondo'],['radius','Radio']].map(([key,label])=>'<div class="form-group var-dimension-'+key+'"><label>'+label+'</label><input type="number" min="0" step="0.01" class="form-control var-measure-'+key+'"></div>').join('')+'</div></div>';
}

function getVariantMeasurementData(card) {
    if ((card.querySelector('.var-size-mode')?.value || 'auto') === 'auto') return getProductMeasurementFormData();
    const val = name => card.querySelector('.var-'+name)?.value || '';
    const kind=val('size-kind'),unit=kind==='liquido'?'ml':(val('measure-unit')||'cm');
    return {kind,unit,capacity:val('measure-capacity'),width:unit==='ml'?val('measure-capacity'):val('measure-width'),length:val('measure-length'),depth:val('measure-depth'),radius:val('measure-radius'),textileSize:val('textile-custom')||val('textile-size')};
}

function syncVariantSizeField(card) {
    if (!card) return '';
    const custom = card.querySelector('.var-size-mode')?.value === 'custom';
    const input=card.querySelector('.var-tamano');if(!input)return getVariantAutoSizeValue();
    const controls=card.querySelector('.variant-measure-fields');if(controls)controls.hidden=!custom;
    const data=getVariantMeasurementData(card);
    if(data.kind==='liquido'&&custom)card.querySelector('.var-measure-unit').value='ml';
    const physical=['medidas','liquido'].includes(data.kind);
    const textile=card.querySelector('.var-textile-fields');if(textile)textile.hidden=data.kind!=='textil';
    const grid=card.querySelector('.var-measure-grid');if(grid)grid.hidden=!physical;
    card.querySelectorAll('[class*="var-dimension-"]').forEach(el=>el.hidden=(el.classList.contains('var-dimension-capacity')?data.unit!=='ml':data.unit==='ml'));
    input.readOnly=!custom||data.kind!=='';
    if(!custom)input.value=getVariantAutoSizeValue();
    else if(data.kind==='textil')input.value=data.textileSize;
    else if(physical)input.value=formatProductPhysicalSizeLabel(data);
    const hint=card.querySelector('.var-size-hint');if(hint)hint.textContent=custom?'Medidas propias de esta variante.':'Usa las medidas actuales del producto principal.';
    return input.value.trim();
}

function syncAllVariantAutoSizes() {
    document.querySelectorAll('#variants-container .admin-panel').forEach(card=>syncVariantSizeField(card));
}

function getVariantSizeValue(card) { return card ? syncVariantSizeField(card) : getVariantAutoSizeValue(); }

function getVariantImageMode(root) {
    const toggle=root.querySelector('.var-use-general-image,.ve-use-general-image');
    return toggle ? (toggle.checked?'general':'propia') : 'propia';
}
function getVariantImageValue(root) {
    return getVariantImageMode(root)==='general' ? getInputValue('prod-imagen') : (root.querySelector('.var-imagen,.ve-imagen')?.value?.trim()||'');
}
function syncVariantImageMode(root) {
    const general=getVariantImageMode(root)==='general';
    root.querySelectorAll('.variant-own-image').forEach(node=>node.hidden=general);
    const inherited=root.querySelector('.variant-general-preview');if(inherited)inherited.hidden=!general;
    const thumb=root.querySelector('.variant-general-preview img');if(thumb){const src=getInputValue('prod-imagen');if(src)thumb.src=src;else thumb.removeAttribute('src');}
    const field=root.querySelector('.var-imagen,.ve-imagen');if(field)field.disabled=general;
}

function openProductEntryStep(step) {
    const form=document.getElementById('product-form');if(!form)return;
    form.querySelectorAll('details.product-entry-fold').forEach(fold=>fold.open=fold===step);
    if(step?.id==='product-variants-step'){const options=document.getElementById('variation-options-panel');if(options)options.style.display='block';}
}
function initProductEntryWorkflow() {
    const form=document.getElementById('product-form');if(!form||form.dataset.workflowReady)return;form.dataset.workflowReady='1';
    form.addEventListener('toggle',event=>{
        if(!event.target.open)return;
        if(event.target.matches('details.product-entry-fold'))openProductEntryStep(event.target);
        if(event.target.matches('.variant-draft-fold'))form.querySelectorAll('.variant-draft-fold').forEach(fold=>{if(fold!==event.target)fold.open=false;});
    },true);
    form.querySelectorAll('[data-product-next-step]').forEach(button=>button.addEventListener('click',()=>openProductEntryStep(document.getElementById(button.dataset.productNextStep))));
    form.addEventListener('change',event=>{
        const root=event.target.closest('#variants-container .admin-panel,#variants-container .var-edit-expanded');
        if(root&&event.target.matches('.var-use-general-image,.ve-use-general-image')){syncVariantImageMode(root);updateLivePreview();}
        if(root&&event.target.matches('.var-size-kind,.var-measure-unit,.var-textile-size')){syncVariantSizeField(root);updateLivePreview();}
    });
    form.addEventListener('input',event=>{
        const root=event.target.closest('#variants-container .admin-panel');
        if(root&&event.target.matches('[class*="var-measure-"],.var-textile-custom')){syncVariantSizeField(root);updateLivePreview();}
        if(event.target.id==='prod-imagen')document.querySelectorAll('#variants-container .admin-panel,#variants-container .var-edit-expanded').forEach(syncVariantImageMode);
    });
}

function getVariantEditSizeValue(row) {
    if (!row) return '';
    const tamano = row.querySelector('.ve-tamano')?.value?.trim() || '';
    const kind = normalizeSearchText(row.querySelector('.ve-size-kind')?.value || '');
    const unit = kind === 'liquido' ? 'ml' : (row.querySelector('.ve-measure-unit')?.value || 'cm');
    if (kind === 'textil') {
        return row.querySelector('.ve-textile-size')?.value?.trim() || tamano;
    }
    if (kind === 'medidas' || kind === 'liquido') {
        return formatProductPhysicalSizeLabel({
            unit,
            capacity: row.querySelector('.ve-measure-capacity')?.value || '',
            width: unit === 'ml'
                ? (row.querySelector('.ve-measure-capacity')?.value || row.querySelector('.ve-measure-width')?.value || '')
                : (row.querySelector('.ve-measure-width')?.value || ''),
            length: row.querySelector('.ve-measure-length')?.value || '',
            depth: row.querySelector('.ve-measure-depth')?.value || '',
            radius: row.querySelector('.ve-measure-radius')?.value || ''
        }) || tamano;
    }
    return tamano;
}

function getVariantPreviewCardKey(card) {
    if (!card) return '';
    return card.dataset.previewKey || card.dataset.varid || card.id || card.querySelector('.ve-id, .var-id')?.value || '';
}

function setActiveVariantPreviewCard(card) {
    const container = document.getElementById('variants-container');
    const key = getVariantPreviewCardKey(card);
    if (!container || !key) return;
    container.dataset.activePreviewVariantKey = key;
}

function getActiveVariantPreviewKey() {
    return document.getElementById('variants-container')?.dataset.activePreviewVariantKey || '';
}

function getActiveVariantPreviewCard() {
    const focusedCard = document.activeElement?.closest?.('#variants-container .variant-edit-card, #variants-container .admin-panel');
    if (focusedCard) return focusedCard;

    const activeKey = getActiveVariantPreviewKey();
    if (!activeKey) return null;
    const cards = document.querySelectorAll('#variants-container .variant-edit-card, #variants-container .admin-panel');
    for (const card of cards) {
        if (getVariantPreviewCardKey(card) === activeKey) return card;
    }
    return null;
}

function getVariantEditorCardPreviewRow(card, index = 0, activeImage = '') {
    if (!card) return null;
    const baseImage = normalizeImageUrl(document.getElementById('prod-imagen')?.value || getAdminGalleryUrls()[0] || 'https://lh3.googleusercontent.com/d/1OTHvWFph2u3qFQMQVhE5ghmSWjBSgBeW=w180');
    const isSavedVariantCard = card.classList.contains('variant-edit-card');
    const key = getVariantPreviewCardKey(card);
    const activeKey = getActiveVariantPreviewKey();

    if (isSavedVariantCard) {
        const row = card.querySelector('.var-edit-expanded');
        if (!row) return null;
        const variantId = row.querySelector('.ve-id')?.value?.trim() || card.dataset.varid || `Variante ${index + 2}`;
        const color = row.querySelector('.ve-color')?.value || '';
        const measure = getVariantEditSizeValue(row);
        const style = cleanProductStyleValue(row.querySelector('.ve-estilo')?.value || '');
        const image = normalizeImageUrl(getVariantImageValue(row) || baseImage);
        const detail = [splitProductColorValues(color).map(getColorDisplayName).join(', '), style, measure].filter(Boolean).join(' / ');
        return {
            id: variantId,
            key,
            title: getInputValue('prod-nombre') || 'Nombre del Producto',
            label: getInputValue('prod-nombre') || variantId,
            detail,
            color,
            style,
            measure,
            price: row.querySelector('.ve-precio')?.value || getInputValue('prod-precio'),
            wholesale: row.querySelector('.ve-precio-mayorista')?.value || getInputValue('prod-precio-mayorista'),
            image,
            stock: Number(row.querySelector('.ve-stock')?.value || 0),
            active: key && key === activeKey || normalizeImageUrl(activeImage) === image
        };
    }

    const color = card.querySelector('.var-color')?.value || '';
    const measure = getVariantSizeValue(card);
    const style = cleanProductStyleValue(card.querySelector('.var-estilo')?.value || '');
    const image = normalizeImageUrl(getVariantImageValue(card) || baseImage);
    const title = card.querySelector('.var-nombre')?.value || getInputValue('prod-nombre') || `Variante ${index + 2}`;
    return {
        id: card.querySelector('.var-id')?.value || `Variante ${index + 2}`,
        key,
        title,
        label: title || `Variante ${index + 2}`,
        detail: [splitProductColorValues(color).map(getColorDisplayName).join(', '), style, measure].filter(Boolean).join(' / '),
        color,
        style,
        measure,
        price: card.querySelector('.var-precio')?.value || getInputValue('prod-precio'),
        wholesale: card.querySelector('.var-precio-mayor')?.value || getInputValue('prod-precio-mayorista'),
        image,
        stock: Number(card.querySelector('.var-stock')?.value || 0),
        active: key && key === activeKey || normalizeImageUrl(activeImage) === image
    };
}

function getActiveVariantPreviewRow() {
    const card = getActiveVariantPreviewCard();
    return card ? getVariantEditorCardPreviewRow(card) : null;
}

function getPreviewPriceInfo(precioValue, mayoristaValue, stockValue, catalogo, promoScope, discountPercent) {
    const parsedPrecio = parseAmount(precioValue);
    const parsedMayorista = parseAmount(mayoristaValue);
    const discountFactor = discountPercent ? 1 - (discountPercent / 100) : 1;
    const usesWholesale = catalogo === 'Mayorista' && parsedMayorista > 0;
    const basePrice = usesWholesale ? parsedMayorista : (parsedPrecio || parsedMayorista);
    const promoApplies = discountPercent > 0 && (
        usesWholesale
            ? (promoScope === 'Ambos' || promoScope === 'Mayorista')
            : (promoScope === 'Ambos' || promoScope === 'Minorista')
    );

    if (basePrice > 0) {
        if (promoApplies) {
            const promoPrice = Math.round(basePrice * discountFactor);
            return { html: `${formatAdminMoney(promoPrice)} <span class="old">${formatAdminMoney(basePrice)}</span>`, basePrice };
        }
        return { html: formatAdminMoney(basePrice), basePrice };
    }

    return { html: Number(stockValue || 0) > 0 ? 'Precio por consultar' : 'Agotado por ahora', basePrice: 0 };
}

function applyPreviewVariantRow(row) {
    if (!row) return;
    const catalogo = getInputValue('prod-catalogo') || 'Ambos';
    const promoScope = normalizePromotionValue(document.getElementById('prod-promocion')?.value || 'FALSO');
    const discountPercent = promoScope !== 'FALSO' ? getAdminPromotionDiscountPercent() : 0;
    const priceInfo = getPreviewPriceInfo(row.price, row.wholesale, row.stock, catalogo, promoScope, discountPercent);
    const stock = Number(row.stock || 0);
    const colorLabel = splitProductColorValues(row.color).map(getColorDisplayName).join(', ');

    const setText = (id, value) => {
        const node = document.getElementById(id);
        if (node) node.textContent = value;
    };

    setText('preview-title-el', row.title || row.label || 'Nombre del Producto');
    setText('preview-color-text', colorLabel || 'Varios');
    setText('preview-style-text', row.style || '');
    setText('preview-measure-line', row.measure || '');
    setText('preview-stock-value', stock > 0 ? 'Disponible' : 'Agotado por ahora');
    setText('preview-detail-stock', `${stock} ${stock === 1 ? 'unidad' : 'unidades'}`);
    setText('preview-detail-price', parseAmount(row.price) > 0 ? formatAdminMoney(parseAmount(row.price)) : '$0');
    setText('preview-detail-wholesale', parseAmount(row.wholesale) > 0 ? formatAdminMoney(parseAmount(row.wholesale)) : 'Sin precio');
    setText('preview-detail-variant', row.detail || 'Sin color / talla');
    if (row.id) setText('preview-detail-id', getInputValue('prod-id-producto') || row.id);

    const priceEl = document.getElementById('preview-price-el');
    if (priceEl) priceEl.innerHTML = priceInfo.html;

    const imgEl = document.getElementById('preview-img-el');
    if (imgEl && row.image && normalizeImageUrl(imgEl.getAttribute('src')) !== normalizeImageUrl(row.image)) {
        imgEl.src = row.image;
        imgEl.style.opacity = '1';
    }

    const colorStrip = document.getElementById('preview-color-strip');
    if (colorStrip) {
        colorStrip.innerHTML = getPreviewColorDotsHtml(row.color);
        colorStrip.style.display = row.color ? 'flex' : 'none';
    }

    const styleRow = document.getElementById('preview-style-row');
    if (styleRow) styleRow.style.display = row.style ? 'flex' : 'none';
    const sizeRow = document.getElementById('preview-size-row');
    if (sizeRow) sizeRow.style.display = row.measure ? 'flex' : 'none';

    const stockAlert = document.getElementById('preview-stock-alert');
    if (stockAlert) {
        stockAlert.className = 'preview-stock-alert';
        if (stock <= 0) {
            stockAlert.textContent = 'Agotado';
            stockAlert.classList.add('is-out');
            stockAlert.style.display = 'inline-flex';
        } else if (stock <= 3) {
            stockAlert.textContent = 'Bajo stock';
            stockAlert.classList.add('is-low');
            stockAlert.style.display = 'inline-flex';
        } else {
            stockAlert.style.display = 'none';
        }
    }

    const buyBtn = document.getElementById('preview-buy-btn');
    const consultBtn = document.getElementById('preview-consult-btn');
    const cartNote = document.getElementById('preview-cart-note');
    const hasVisiblePrice = priceInfo.basePrice > 0;
    if (buyBtn) {
        buyBtn.disabled = stock <= 0;
        buyBtn.textContent = stock <= 0 ? 'Agotado por ahora' : (hasVisiblePrice ? 'Añadir al Carrito' : 'Añadir a consulta general');
    }
    if (consultBtn) consultBtn.style.display = !hasVisiblePrice && stock > 0 ? 'inline-flex' : 'none';
    if (cartNote) cartNote.style.display = !hasVisiblePrice && stock > 0 ? 'block' : 'none';
    syncActivePreviewOptionCard(row);
}

function syncActivePreviewOptionCard(row) {
    if (!row) return;
    const panel = document.getElementById('preview-variant-panel');
    if (!panel || panel.style.display === 'none') return;

    const cards = Array.from(panel.querySelectorAll('.preview-variant-card'));
    if (!cards.length) return;

    let card = row.key
        ? cards.find(item => item.dataset.previewKey === row.key)
        : null;
    if (!card && row.image) {
        card = cards.find(item => normalizeImageUrl(item.dataset.previewUrl) === normalizeImageUrl(row.image));
    }
    if (!card) card = panel.querySelector('.preview-variant-card.active') || cards[0];

    cards.forEach(item => item.classList.toggle('active', item === card));
    card.dataset.previewUrl = row.image || '';
    if (row.key) card.dataset.previewKey = row.key;

    const img = card.querySelector('img');
    if (img) img.src = row.image || 'https://lh3.googleusercontent.com/d/1OTHvWFph2u3qFQMQVhE5ghmSWjBSgBeW=w180';

    const strong = card.querySelector('.preview-variant-copy strong');
    if (strong) strong.textContent = row.label || row.title || 'Variante';

    const detail = card.querySelector('.preview-variant-copy > span:first-of-type');
    if (detail) detail.textContent = row.detail || 'Sin atributos';

    const dots = card.querySelector('.preview-variant-copy > span:nth-of-type(2)');
    if (dots) dots.innerHTML = getPreviewColorDotsHtml(row.color);

    const stock = card.querySelector('.preview-variant-stock');
    if (stock) stock.textContent = `${Number(row.stock || 0)} und.`;
}

function getPreviewColorDotsHtml(value) {
    const colors = splitProductColorValues(value);
    if (!colors.length) return '';
    return colors.map(color => (
        `<span class="preview-color-dot" style="--swatch:${getAdminColorHex(color)}" title="${escapeHtml(getColorDisplayName(color))}"></span>`
    )).join('');
}

function getPreviewVariantRows(activeImage = '') {
    const baseImage = normalizeImageUrl(document.getElementById('prod-imagen')?.value || getAdminGalleryUrls()[0] || 'https://lh3.googleusercontent.com/d/1OTHvWFph2u3qFQMQVhE5ghmSWjBSgBeW=w180');
    const baseColor = getInputValue('prod-color');
    const baseMeasure = typeof getProductSizeValue === 'function' ? getProductSizeValue() : getInputValue('prod-tamano');
    const baseStyle = getProductStyleValue();
    const baseStock = Number(getInputValue('prod-stock-inicial') || 0);
    const activeKey = getActiveVariantPreviewKey();
    const rows = [{
        id: getInputValue('prod-id'),
        key: 'main-product',
        title: getInputValue('prod-nombre') || 'Nombre del Producto',
        label: getInputValue('prod-nombre') || 'Variante principal',
        detail: [splitProductColorValues(baseColor).map(getColorDisplayName).join(', '), baseStyle, baseMeasure].filter(Boolean).join(' / '),
        color: baseColor,
        style: baseStyle,
        measure: baseMeasure,
        price: getInputValue('prod-precio'),
        wholesale: getInputValue('prod-precio-mayorista'),
        image: baseImage,
        stock: baseStock,
        active: !activeKey && (!normalizeImageUrl(activeImage) || normalizeImageUrl(activeImage) === baseImage)
    }];

    document.querySelectorAll('#variants-container .variant-edit-card, #variants-container .admin-panel').forEach((card, index) => {
        const row = getVariantEditorCardPreviewRow(card, index, activeImage);
        if (row) rows.push(row);
    });

    return rows.filter(row => row.detail || row.image || row.label);
}

function renderProductPreviewOptions(activeImage = '') {
    const info = document.querySelector('#view-products .preview-product-info');
    if (!info) return;

    let panel = document.getElementById('preview-variant-panel');
    const rows = getPreviewVariantRows(activeImage);
    const shouldShow = rows.length > 1 || rows.some(row => row.color || row.detail);

    if (!shouldShow) {
        if (panel) {
            panel.innerHTML = '';
            panel.style.display = 'none';
        }
        return;
    }

    if (!panel) {
        panel = document.createElement('div');
        panel.id = 'preview-variant-panel';
        panel.className = 'preview-variant-panel';
        const actions = document.getElementById('preview-actions');
        if (actions) info.insertBefore(panel, actions);
        else info.appendChild(panel);
    }
    panel.style.display = 'block';

    const activeIndex = rows.findIndex(row => row.active);
    panel.innerHTML = `
        <span class="preview-panel-title">Opciones visibles</span>
        <div class="preview-variant-list">
            ${rows.map((row, index) => `
                <button type="button" class="preview-variant-card ${(activeIndex === -1 ? index === 0 : row.active) ? 'active' : ''}" data-preview-index="${index}" data-preview-key="${escapeHtml(row.key || '')}" data-preview-url="${escapeHtml(row.image || '')}">
                    <img src="${escapeHtml(row.image || 'https://lh3.googleusercontent.com/d/1OTHvWFph2u3qFQMQVhE5ghmSWjBSgBeW=w180')}" alt="" onerror="handleInventoryImageError(this)">
                    <span class="preview-variant-copy">
                        <strong>${escapeHtml(row.label || `Variante ${index + 1}`)}</strong>
                        <span>${escapeHtml(row.detail || 'Sin atributos')}</span>
                        <span>${getPreviewColorDotsHtml(row.color)}</span>
                    </span>
                    <span class="preview-variant-stock">${Number(row.stock || 0)} und.</span>
                </button>
            `).join('')}
        </div>
    `;
}

function renderProductPreviewGallery(activeUrl = '') {
    const galleryHost = document.querySelector('#view-products .preview-product-gallery');
    if (!galleryHost) return;

    let gallery = document.getElementById('preview-angle-gallery');
    const urls = [
        document.getElementById('prod-imagen')?.value || '',
        ...getAdminGalleryUrls()
    ]
        .map(normalizeImageUrl)
        .filter(Boolean)
        .filter((url, index, list) => list.indexOf(url) === index);

    galleryHost.classList.toggle('has-single-image', urls.length <= 1);

    if (urls.length <= 1) {
        if (gallery) {
            gallery.innerHTML = '';
            gallery.style.display = 'none';
        }
        return;
    }

    if (!gallery) {
        gallery = document.createElement('div');
        gallery.id = 'preview-angle-gallery';
        gallery.className = 'preview-angle-gallery';
        galleryHost.appendChild(gallery);
    } else if (gallery.parentElement !== galleryHost) {
        galleryHost.appendChild(gallery);
    }
    gallery.style.display = 'flex';

    const active = normalizeImageUrl(activeUrl || urls[0]);
    gallery.innerHTML = urls.map((url, index) => `
        <button type="button" class="preview-angle-thumb ${url === active ? 'active' : ''}" data-preview-url="${escapeHtml(url)}" aria-label="Vista ${index + 1}">
            <img src="${escapeHtml(url)}" alt="">
            <span>${index === 0 ? 'Principal' : 'Vista ' + (index + 1)}</span>
        </button>
    `).join('');
}

function renderProductGalleryManager() {
    const list = document.getElementById('prod-gallery-list');
    if (!list) return;

    const urls = getAdminGalleryUrls();
    if (!urls.length) {
        list.innerHTML = '<div class="angle-gallery-empty">Aun no hay fotos adicionales.</div>';
        renderProductPreviewGallery();
        return;
    }

    list.innerHTML = urls.map((url, index) => `
        <div class="angle-gallery-item" data-gallery-index="${index}">
            <img src="${escapeHtml(url)}" alt="Vista ${index + 1}" onerror="this.style.opacity='0.35'">
            <button type="button" class="angle-gallery-remove" data-gallery-remove="${index}" aria-label="Quitar foto">&times;</button>
            <span>Vista ${index + 2}</span>
        </div>
    `).join('');
    renderProductPreviewGallery();
}

function resetProductForm() {
    openProductEntryStep(document.getElementById('product-general-step'));
    resetProductImageUploadState();
    window.OriginalStoreSharedScan?.invalidate();
    const pendingForm = document.getElementById('product-form');
    if (pendingForm) delete pendingForm.dataset.pendingKey;
    const form = el('product-form');
    if (form) form.reset();
    window.OriginalStoreRetailPricing?.reset();
    if (form) delete form.dataset.originalVariationId;
    const variantsContainer = document.getElementById('variants-container');
    if (variantsContainer) delete variantsContainer.dataset.activePreviewVariantKey;
    
    setMotherProductId(generateMotherProductId());
    const currentMotherId = getInputValue('prod-id-producto');
    const childIdInput = document.getElementById('prod-id');
    if (childIdInput) delete childIdInput.dataset.scannedReference;
    setInputValue('prod-id', `${currentMotherId}-V01`);
    setProductBarcodeScanMode(false);
    updateProductBarcodeField();
    setInputValue('prod-fecha-creacion', '');
    setInputValue('prod-stock-inicial', '12');
    setInputValue('prod-stock', '12');
    setInputValue('prod-imagen', '');
    setInputValue('prod-galeria', '');
    setInputValue('prod-sku', '');
    updateProductImagePreviewBox('');
    renderProductGalleryManager();
    setInputValue('prod-catalogo', 'Ambos');
    setInputValue('prod-estado', 'Activo');
    setInputValue('prod-color', '');
    setInputValue('prod-estilo', '');
    setInputValue('prod-size-kind', '');
    setInputValue('prod-textile-size', '');
    setInputValue('prod-textile-custom', '');
    setInputValue('prod-measure-unit', 'cm');
    setInputValue('prod-measure-capacity', '');
    setInputValue('prod-measure-width', '');
    setInputValue('prod-measure-length', '');
    setInputValue('prod-measure-depth', '');
    setInputValue('prod-measure-radius', '');
    setInputValue('variation-styles', '');
    setInputValue('variation-sizes', '');
    setInputValue('variation-colors', '');
    setInputValue('variation-primary-field', 'style');
    const generatorSummary = document.getElementById('variation-generator-summary');
    if (generatorSummary) generatorSummary.textContent = 'Genera tarjetas editables para cada combinacion antes de guardar.';
    const variationPanel = document.getElementById('variation-options-panel');
    if (variationPanel) variationPanel.style.display = 'none';
    const variationFields = document.getElementById('variation-generator-fields');
    if (variationFields) variationFields.style.display = 'none';
    const promoSelect = document.getElementById('prod-promocion');
    if (promoSelect) promoSelect.value = 'FALSO';
    setProductFormMode(false);
    updateLivePreview();
    var badge = document.getElementById('variant-editing-badge');
    if (badge) badge.style.display = 'none';
    var vc = document.getElementById('variants-container');
    if (vc) vc.innerHTML = '';
    var grpBtn = document.getElementById('btn-save-group');
    if (grpBtn) grpBtn.remove();
    updateProductMeasurementFields();
    window.OriginalStoreProductIdentity?.adopt();
}

function updateCategoryOptions() {
    const list = el('admin-category-options');
    const select = el('prod-categoria');
    const inventorySelect = el('admin-inventory-category-filter');
    const categoryGroups = getInventoryCategoryGroups();

    if (list) {
        list.innerHTML = categoryGroups
            .map(group => `<option value="${escapeHtml(group.label)}"></option>`)
            .join('');
    }
    if (select && select.tagName === 'SELECT') {
        const current = select.value;
        select.innerHTML = categoryGroups
            .map(group => `<option value="${escapeHtml(group.label)}">${escapeHtml(group.label)}</option>`)
            .join('');
        if (current) select.value = current;
    }
    if (inventorySelect) {
        const current = inventorySelect.value || adminInventoryCategoryFilter || 'todos';
        const currentKey = current === 'todos' ? 'todos' : normalizeInventoryCategoryKey(current);
        const inventoryCategories = categoryGroups.filter(group => group.key !== 'banner');
        inventorySelect.innerHTML = '<option value="todos">Todas las categor&iacute;as</option>'
            + inventoryCategories.map(group => `<option value="${escapeHtml(group.key)}">${escapeHtml(group.label)}</option>`).join('');
        inventorySelect.value = inventoryCategories.some(group => group.key === currentKey) ? currentKey : 'todos';
        adminInventoryCategoryFilter = inventorySelect.value;
    }
    renderInventoryPdfCategoryPicker(categoryGroups);
    window.renderInventoryCategoryManager?.();
}

function getInventoryPdfCategoryGroups() {
    return getInventoryCategoryGroups({ includeDefaults: false })
        .filter(group => group.key && group.key !== 'banner');
}

function getSelectedInventoryPdfCategoryKeys() {
    const inputs = Array.from(document.querySelectorAll('[data-inventory-pdf-category]'));
    if (inputs.length) {
        return inputs
            .filter(input => input.checked)
            .map(input => input.value)
            .filter(Boolean);
    }
    const groups = getInventoryPdfCategoryGroups();
    return adminInventoryPdfSelectedCategoryKeys === null
        ? groups.map(group => group.key)
        : Array.from(adminInventoryPdfSelectedCategoryKeys);
}

function updateInventoryPdfCategorySummary() {
    const summary = document.getElementById('inventory-pdf-category-summary');
    if (!summary) return;
    const total = document.querySelectorAll('[data-inventory-pdf-category]').length;
    const selected = getSelectedInventoryPdfCategoryKeys().length;
    if (!total) {
        summary.textContent = 'Sin categorias disponibles';
    } else if (selected === total) {
        summary.textContent = 'Todas las categorias';
    } else if (selected === 0) {
        summary.textContent = 'Ninguna categoria seleccionada';
    } else {
        summary.textContent = `${selected} de ${total} categorias`;
    }
}

function renderInventoryPdfCategoryPicker(categoryGroups) {
    const list = document.getElementById('inventory-pdf-category-list');
    if (!list) return;

    const groups = getInventoryPdfCategoryGroups();
    const allKeys = groups.map(group => group.key);
    const selectedKeys = adminInventoryPdfSelectedCategoryKeys === null
        ? new Set(allKeys)
        : new Set(Array.from(adminInventoryPdfSelectedCategoryKeys).filter(key => allKeys.includes(key)));

    list.innerHTML = groups.map(group => {
        const checked = selectedKeys.has(group.key) ? ' checked' : '';
        return `<label class="inventory-pdf-category-check"><input type="checkbox" value="${escapeHtml(group.key)}" data-inventory-pdf-category${checked}> <span>${escapeHtml(group.label)}</span></label>`;
    }).join('');

    updateInventoryPdfCategorySummary();
}

function initInventoryPdfCategoryPicker() {
    const panel = document.getElementById('inventory-pdf-category-panel');
    if (!panel || panel.dataset.ready === 'true') return;
    panel.dataset.ready = 'true';

    panel.addEventListener('change', function (event) {
        if (!event.target.matches('[data-inventory-pdf-category]')) return;
        adminInventoryPdfSelectedCategoryKeys = new Set(getSelectedInventoryPdfCategoryKeys());
        updateInventoryPdfCategorySummary();
    });

    panel.addEventListener('click', function (event) {
        const action = event.target.closest('[data-inventory-pdf-categories-action]')?.dataset.inventoryPdfCategoriesAction;
        if (!action) return;
        const inputs = Array.from(panel.querySelectorAll('[data-inventory-pdf-category]'));
        const shouldCheck = action === 'all';
        inputs.forEach(input => { input.checked = shouldCheck; });
        adminInventoryPdfSelectedCategoryKeys = shouldCheck
            ? new Set(inputs.map(input => input.value).filter(Boolean))
            : new Set();
        updateInventoryPdfCategorySummary();
    });
}

function initAdminCustomCursor() {
    if (!window.matchMedia('(hover: hover) and (pointer: fine)').matches) return;
    if (document.getElementById('blyxu-cursor')) return;

    const cursor = document.createElement('div');
    cursor.id = 'blyxu-cursor';
    cursor.innerHTML = '<span class="cursor-dot"></span><span class="cursor-ring"></span>';
    document.body.appendChild(cursor);

    let x = window.innerWidth / 2;
    let y = window.innerHeight / 2;
    let ringX = x;
    let ringY = y;

    function move() {
        ringX += (x - ringX) * 0.2;
        ringY += (y - ringY) * 0.2;
        cursor.style.setProperty('--cursor-x', `${x}px`);
        cursor.style.setProperty('--cursor-y', `${y}px`);
        cursor.style.setProperty('--ring-x', `${ringX}px`);
        cursor.style.setProperty('--ring-y', `${ringY}px`);
        requestAnimationFrame(move);
    }

    window.addEventListener('mousemove', event => {
        x = event.clientX;
        y = event.clientY;
        cursor.classList.add('is-visible');
    }, { passive: true });

    window.addEventListener('mouseout', event => {
        if (!event.relatedTarget) cursor.classList.remove('is-visible');
    });

    document.addEventListener('mouseover', event => {
        const target = event.target;
        cursor.classList.toggle('is-hovering', Boolean(target?.closest?.('a, button, input, textarea, select, [role="button"], .sidebar-btn, .admin-btn, .form-control')));
    });

    move();
}

function initSettingsTabs() {
    const panel = document.querySelector('#view-settings > .admin-panel');
    if (!panel || panel.querySelector('.settings-tabs')) return;

    const definitions = [
        {
            id: 'contact',
            label: 'Contacto',
            items: [
                { title: 'Informacion de Contacto', formId: 'contact-config-form' },
                { title: 'WhatsApp Comercial', formId: 'whatsapp-config-form' }
            ]
        },
        {
            id: 'storefront',
            label: 'Portada',
            items: [
                { title: 'Banner Publicitario del Home', formId: 'home-ad-config-form' },
                { title: 'Carrusel de Inicio', formId: 'carousel-image-form' }
            ]
        },
        {
            id: 'promos',
            label: 'Promos',
            items: [
                { title: 'Banner Promocional Flotante', formId: 'promo-config-form' },
                { title: 'Promoción exclusiva mayorista', formId: 'wholesale-promo-config-form' },
                { title: 'Promociones para Clientes Registrados', formId: 'customer-promo-form' }
            ]
        },
        {
            id: 'payments',
            label: 'Pagos',
            items: [
                { title: 'Gestion de Metodos de Pago y QRs', formId: 'qr-config-form' }
            ]
        },
        {
            id: 'invoice',
            label: 'Factura',
            items: [
                { title: 'Configuracion de Factura y Remision', formId: 'invoice-config-form' }
            ]
        },
        {
            id: 'retail',
            label: 'Precios',
            items: [
                { title: 'Precios Minoristas', source: document.getElementById('toggle-retail-prices')?.closest('div') },
                { title: 'Mercado Pago público', source: document.getElementById('toggle-mercado-pago-public')?.closest('.retail-toggle-card') },
                { title: 'Catálogo con pedidos por WhatsApp', source: document.getElementById('toggle-catalog-whatsapp')?.closest('.retail-toggle-card') }
            ]
        }
    ];

    const tabs = document.createElement('div');
    tabs.className = 'settings-tabs';
    tabs.setAttribute('role', 'tablist');
    tabs.setAttribute('aria-label', 'Secciones de configuracion del sitio');

    const content = document.createElement('div');
    content.className = 'settings-tab-content';

    panel.insertBefore(tabs, panel.firstElementChild);
    panel.insertBefore(content, tabs.nextSibling);

    const sections = [];

    definitions.forEach(def => {
        const items = (def.items || [def])
            .map(item => ({
                ...item,
                source: item.source || document.getElementById(item.formId)
            }))
            .filter(item => item.source);
        if (!items.length) return;

        const section = document.createElement('section');
        section.className = 'settings-tab-panel';
        section.id = `settings-tab-${def.id}`;
        section.dataset.settingsTab = def.id;
        section.setAttribute('role', 'tabpanel');

        items.forEach(item => {
            const source = item.source;

            if (source.id === 'toggle-retail-prices' || source.querySelector?.('#toggle-retail-prices')) {
                source.classList.add('settings-retail-card');
                section.appendChild(source);
                return;
            }

            const wrapper = document.createElement('div');
            wrapper.className = 'settings-config-block';
            const heading = source.previousElementSibling?.tagName === 'H3'
                ? source.previousElementSibling
                : null;

            wrapper.appendChild(heading || Object.assign(document.createElement('h3'), { textContent: item.title || def.label }));
            wrapper.appendChild(source);
            section.appendChild(wrapper);
        });
        content.appendChild(section);

        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'settings-tab-btn';
        button.dataset.settingsTabTarget = def.id;
        button.setAttribute('role', 'tab');
        button.setAttribute('aria-controls', section.id);
        button.textContent = def.label;
        tabs.appendChild(button);

        sections.push({ id: def.id, button, section });
    });

    if (!sections.length) return;

    function activateSettingsTab(tabId) {
        const legacyMap = {
            home: 'storefront',
            carousel: 'storefront',
            promo: 'promos',
            customers: 'promos',
            whatsapp: 'contact'
        };
        const requestedTab = legacyMap[tabId] || tabId;
        const nextTab = sections.some(item => item.id === requestedTab) ? requestedTab : sections[0].id;
        sections.forEach(item => {
            const active = item.id === nextTab;
            item.button.classList.toggle('active', active);
            item.button.setAttribute('aria-selected', active ? 'true' : 'false');
            item.section.classList.toggle('active', active);
            item.section.hidden = !active;
        });
        try {
            localStorage.setItem('blyxu_admin_settings_tab', nextTab);
        } catch (error) {
            console.warn('No se pudo guardar la pestana activa:', error);
        }
    }

    sections.forEach(item => {
        item.button.addEventListener('click', () => activateSettingsTab(item.id));
    });
    window.activateSettingsTab = activateSettingsTab;

    let savedTab = '';
    try {
        savedTab = localStorage.getItem('blyxu_admin_settings_tab') || '';
    } catch (error) {
        savedTab = '';
    }
    activateSettingsTab(savedTab || sections[0].id);
}

function initLoginBokehBackgrounds() {
    document.querySelectorAll('.login-bokeh-canvas').forEach(canvas => canvas.remove());
    return;
    document.querySelectorAll('.login-bokeh-canvas').forEach(canvas => {
        const overlay = canvas.closest('.wholesale-overlay');
        if (overlay && !overlay.classList.contains('open') && overlay.style.display === 'none') return;
        if (canvas.dataset.ready === 'login-bokeh') {
            if (typeof canvas.__blyxuBokehStart === 'function') canvas.__blyxuBokehStart();
            return;
        }
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        canvas.dataset.ready = 'login-bokeh';

        const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        const lights = [];
        const count = 15;
        let width = 0;
        let height = 0;
        let dpr = 1;
        let rafId = 0;

        function isActive() {
            if (document.visibilityState === 'hidden') return false;
            if (!overlay) return true;
            if (overlay.style.display === 'none') return false;
            return overlay.classList.contains('open') || overlay.id === 'admin-login-screen';
        }

        function makeLight() {
            const size = Math.random() * 170 + 120;
            return {
                size,
                x: Math.random() * width,
                y: Math.random() * height,
                hue: 246 + Math.random() * 46,
                sat: 58 + Math.random() * 28,
                light: 26 + Math.random() * 22,
                alpha: .18 + Math.random() * .16,
                speed: .18 + Math.random() * .28,
                angleX: Math.random() * Math.PI * 2,
                angleY: Math.random() * Math.PI * 2
            };
        }

        function resize() {
            const rect = canvas.parentElement?.getBoundingClientRect();
            width = Math.max(320, rect?.width || window.innerWidth);
            height = Math.max(420, rect?.height || window.innerHeight);
            dpr = Math.min(window.devicePixelRatio || 1, 2);
            canvas.width = Math.round(width * dpr);
            canvas.height = Math.round(height * dpr);
            ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
            if (!lights.length) {
                for (let i = 0; i < count; i += 1) lights.push(makeLight());
            }
        }

        function drawLight(light) {
            const gradient = ctx.createRadialGradient(light.x, light.y, 0, light.x, light.y, light.size);
            gradient.addColorStop(0, `hsla(${light.hue}, ${light.sat}%, ${light.light + 28}%, ${light.alpha})`);
            gradient.addColorStop(.45, `hsla(${light.hue}, ${light.sat}%, ${light.light}%, ${light.alpha * .62})`);
            gradient.addColorStop(1, `hsla(${light.hue}, ${light.sat}%, ${light.light}%, 0)`);
            ctx.fillStyle = gradient;
            ctx.beginPath();
            ctx.arc(light.x, light.y, light.size, 0, Math.PI * 2);
            ctx.fill();
        }

        function tick() {
            if (!isActive()) {
                rafId = 0;
                return;
            }
            ctx.clearRect(0, 0, width, height);
            ctx.globalCompositeOperation = 'lighter';
            lights.forEach(light => {
                drawLight(light);
                if (!reduceMotion) {
                    light.x += Math.cos(light.angleX) * light.speed;
                    light.y += Math.sin(light.angleY) * light.speed;
                    light.angleX += .0022;
                    light.angleY += .0017;
                    if (light.x < -light.size) light.x = width + light.size;
                    if (light.x > width + light.size) light.x = -light.size;
                    if (light.y < -light.size) light.y = height + light.size;
                    if (light.y > height + light.size) light.y = -light.size;
                }
            });
            ctx.globalCompositeOperation = 'source-over';
            rafId = reduceMotion ? 0 : requestAnimationFrame(tick);
        }

        function start() {
            resize();
            if (!rafId) tick();
        }

        canvas.__blyxuBokehStart = start;
        window.addEventListener('resize', () => {
            if (isActive()) resize();
        }, { passive: true });
        document.addEventListener('visibilitychange', () => {
            if (isActive()) start();
        });
        start();
    });
}

document.addEventListener('DOMContentLoaded', () => {
    document.addEventListener('click', event => {
        const button = event.target.closest('.sidebar-btn[data-view]');
        if (!button) return;
        const label = button.textContent.replace(/^\s*[A-Z]{2}\s*/, '').trim() || 'Panel';
        switchDashboardView(button.dataset.view, label);
    });
    document.addEventListener('click', event => {
        const inventoryQrButton = event.target.closest('[data-inventory-action="qr"]');
        if (inventoryQrButton) {
            window.openInventoryQrTicket?.(inventoryQrButton.dataset.productKey || '');
            return;
        }
        const control = event.target.closest('[data-inventory-qr-action]');
        if (!control) return;
        const actions = {
            close: window.closeInventoryQrTicket,
            copy: window.copyInventoryQrReference,
            image: window.openInventoryQrImage,
            download: window.downloadInventoryQrLabel,
            whatsapp: window.shareInventoryQrLabel,
            print: window.printInventoryQrTicket
        };
        actions[control.dataset.inventoryQrAction]?.();
    });
    document.addEventListener('change', event => {
        if (event.target.matches('[data-qr-option], [data-qr-size]')) window.updateInventoryQrPreviewOptions?.();
    });
    document.addEventListener('input', event => {
        if (!event.target.matches('[data-qr-size]')) return;
        const input = event.target;
        if (input.value && input.checkValidity()) window.updateInventoryQrPreviewOptions?.();
    });
    // initAdminCustomCursor(); // Desactivado para evitar lag del cursor
    initLoginBokehBackgrounds();
    let adminHeavyFeaturesReady = false;
    function initAdminHeavyFeatures() {
        if (adminHeavyFeaturesReady) return;
        adminHeavyFeaturesReady = true;
        const initializers = [
            initOrdersAdminTabs,
            initSettingsTabs,
            initSettingsFolds,
            initProductEntryWorkflow,
            initChinaOrdersBuilder,
            initAdminCostCalculator,
            initRetailPriceToggle,
            initMercadoPagoPublicToggle,
            initCatalogWhatsAppToggle,
            initContactConfigAdmin,
            initWhatsAppConfigAdmin,
            initInvoiceConfigAdmin,
            initPromoConfigAdmin,
            initWholesalePromoConfigAdmin,
            initHomeAdConfigAdmin,
            initCustomerPromoAdmin,
            initQRConfigAdmin,
            initInventorySearch,
            initInventoryActions,
            initInventoryPdfExport,
            initCarouselImageAdmin,
            initProductImageUpload,
            initProductGalleryUpload,
            initColorPickers,
            initProductMeasurementControls,
            initProductBarcodeField,
            initProductIdentityControls,
            resetProductForm
        ];
        initializers.forEach(initializer => {
            try {
                initializer();
            } catch (error) {
                console.error('No se pudo inicializar un modulo administrativo:', error);
            }
        });
    }
    window.initAdminHeavyFeatures = initAdminHeavyFeatures;
    const settingsSidebarBtn = document.querySelector('.sidebar-btn[onclick*="settings"]');
    if (settingsSidebarBtn) {
        settingsSidebarBtn.innerHTML = '<span style="font-size:18px; width:24px;">&#9881;</span> Ajustes y Banner';
    }
    const adminPasswordInput = document.getElementById('admin-password');
    if (adminPasswordInput) adminPasswordInput.placeholder = 'Clave';
    const adminLoginButton = document.querySelector('#admin-login-form .admin-btn');
    if (adminLoginButton) adminLoginButton.textContent = 'Validar';

    // Delegación de eventos para drag & drop en variantes dinámicas
    document.addEventListener('dragover', (e) => {
        if (e.target.closest('.var-drop-zone')) {
            e.preventDefault();
            e.target.closest('.var-drop-zone').classList.add('drag-over');
        }
    });
    document.addEventListener('dragleave', (e) => {
        if (e.target.closest('.var-drop-zone')) {
            e.target.closest('.var-drop-zone').classList.remove('drag-over');
        }
    });
    document.addEventListener('drop', async (e) => {
        const zone = e.target.closest('.var-drop-zone');
        if (zone) {
            e.preventDefault();
            zone.classList.remove('drag-over');
            const file = e.dataTransfer.files[0];
            if (file && file.type.startsWith('image/')) {
                const card = zone.closest('.admin-panel');
                const input = card?.querySelector('.var-imagen') || zone.querySelector('.var-imagen');

                // Preview local
                const localUrl = URL.createObjectURL(file);
                updateVariantImagePickerPreview(card || zone, localUrl);

                try {
                    showToast('Subiendo variante...');
                    const url = await uploadCarouselImage(file);
                    if (input) {
                        input.value = url;
                        input.dispatchEvent(new Event('input'));
                    }
                    updateVariantImagePickerPreview(card || zone, url);
                    showToast('Imagen de variante lista', 'success');
                } catch (err) {
                    showToast('Error: ' + err.message, 'error');
                } finally {
                    URL.revokeObjectURL(localUrl);
                }
            }
        }
    });

    // Configurar listeners para la Vista Previa
    const inputsToWatch = [
        'prod-nombre', 'prod-categoria', 'prod-catalogo', 'prod-precio', 'prod-precio-mayorista',
        'prod-descripcion', 'prod-imagen', 'prod-galeria', 'prod-estado', 'prod-promocion',
        'prod-stock-inicial', 'prod-color', 'prod-estilo', 'prod-tamano', 'prod-size-kind',
        'prod-textile-size', 'prod-textile-custom', 'prod-measure-unit', 'prod-measure-capacity', 'prod-measure-width',
        'prod-measure-length', 'prod-measure-depth', 'prod-measure-radius', 'prod-id-producto',
        'prod-id', 'prod-sku'
    ];
    inputsToWatch.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.addEventListener('input', updateLivePreview);
            el.addEventListener('change', updateLivePreview);
        }
    });
    const stockInput = document.getElementById('prod-stock-inicial');
    if (stockInput) {
        stockInput.addEventListener('input', syncProductStatusWithStockInput);
        stockInput.addEventListener('change', syncProductStatusWithStockInput);
    }
    const estadoInput = document.getElementById('prod-estado');
    if (estadoInput) {
        estadoInput.addEventListener('change', syncProductStatusWithStockInput);
    }
    updateLivePreview(); // Actualización inicial



    // --- LOGIN LOGIC ---
    const loginForm = document.getElementById('admin-login-form');
    const loginError = document.getElementById('login-error');
    const loginScreen = document.getElementById('admin-login-screen');
    const mainContent = document.getElementById('admin-main-content');
    const ADMIN_ACCESS_CODE_LENGTH = 7;


    function syncAdminVaultState() {
        const passwordInput = document.getElementById('admin-password');
        const vault = loginScreen?.querySelector('[data-vault]');
        if (!vault || !passwordInput) return;
        const targetLength = ADMIN_ACCESS_CODE_LENGTH;
        const len = Math.min((passwordInput.value || '').trim().length, targetLength);
        const progress = Math.min(100, Math.round((len / targetLength) * 100));
        vault.style.setProperty('--vault-progress', progress + '%');
        const status = vault.querySelector('[data-vault-status]');
        if (status) status.textContent = len ? 'Verificando credenciales...' : 'Esperando clave segura';
    }

    function markAdminVaultDenied() {
        const vault = loginScreen?.querySelector('[data-vault]');
        if (!vault) return;
        vault.classList.remove('is-unlocking');
        vault.classList.add('is-denied');
        const status = vault.querySelector('[data-vault-status]');
        if (status) status.textContent = 'Clave incorrecta';
        setTimeout(function() { vault.classList.remove('is-denied'); syncAdminVaultState(); }, 520);
    }

    function playAdminVaultUnlock(done) {
        const vault = loginScreen?.querySelector('[data-vault]');
        if (!loginScreen || !vault) {
            done();
            return;
        }
        loginScreen.classList.add('vault-success');
        vault.classList.add('is-unlocking');
        vault.style.setProperty('--vault-progress', '100%');
        const status = vault.querySelector('[data-vault-status]');
        if (status) status.textContent = 'Acceso concedido';
        setTimeout(done, 1050);
    }
    const adminPasswordInputForVault = document.getElementById('admin-password');
    adminPasswordInputForVault?.addEventListener('input', syncAdminVaultState);
    syncAdminVaultState();


    if (loginForm) initializeAdminPasswordAccess(GOOGLE_SHEET_API,adminNativeFetch,loginForm,(credential,identity)=>{
        secureAdminCredential=credential;siteConfigPromise=null;
        window.OriginalStoreAdminSession.start(credential,identity);
        window.OriginalStoreSharedScan?.initialize({getCredential:()=>secureAdminCredential,fetcher:adminNativeFetch,openScanner:openBarcodeScanner,closeScanner:closeBarcodeScanner,barcodeMode:()=>setProductBarcodeScanMode(true),applyCode:(code,input)=>syncScannedCodeToChildReference(code,input),activity:()=>window.OriginalStoreAdminSession?.activity()});
        window.refreshOrderNotifications?.();
        initCustomerAccessNotifications();

        playAdminVaultUnlock(()=>{
            loginScreen.style.display='none';mainContent.style.display='';initAdminHeavyFeatures();renderAdminDashboard();
            Promise.allSettled([cargarInventario(),cargarPedidos()]).then(async()=>{await window.OriginalStoreAdminSession.restore();renderAdminDashboard();}).catch(()=>showToast('No se pudo recuperar el borrador. Se conserva en esta pestaña; vuelve a iniciar sesión.','error'));
            const editingModal=document.getElementById('edit-product-modal');if(document.getElementById('product-form')?.closest('#edit-product-modal'))editingModal?.classList.add('open');
        });
    });
    initializeOriginalStoreAdminSession();
    // -------------------

    document.getElementById('product-form').addEventListener('submit', async (e) => {
        e.preventDefault();

        try { window.OriginalStoreProductIdentity.assertValid(); } catch(error) { showToast(error.message,'error'); return; }
        const btn = document.getElementById('btn-save');
        btn.disabled = true;
        btn.textContent = 'Enviando...';
        ensureProductHierarchyIds();

        const rawPrecio = document.getElementById('prod-precio').value;
        const cleanPrecio = parseAmount(rawPrecio);
        const rawPrecioMayorista = document.getElementById('prod-precio-mayorista').value;
        const cleanPrecioMayorista = parseAmount(rawPrecioMayorista);

        const stock = Number(document.getElementById('prod-stock-inicial').value || 0);
        const estado = document.getElementById('prod-estado').value;

        const data = {
            'Nombre del Producto': document.getElementById('prod-nombre').value,
            Categoria: document.getElementById('prod-categoria').value,
            'Categoría': document.getElementById('prod-categoria').value,
            Precio: cleanPrecio,
            'Precio Mayor': cleanPrecioMayorista,
            'Stock Inicial': stock,
            Cantidad: stock,
            'Imagen Principal': document.getElementById('prod-imagen').value,
            Color: document.getElementById('prod-color').value,
            Estilo: getProductStyleValue(),
            Estado: estado
        };
        Object.assign(data, buildProductPayload());
        const originalVariationId = document.getElementById('product-form')?.dataset.originalVariationId || '';
        if (isEditingProduct && originalVariationId) data.__adminOriginalId = originalVariationId;
        const motherProductId = getInputValue('prod-id-producto') || ensureProductHierarchyIds().idProducto;
        data['ID Producto'] = motherProductId;
        data.ID_Producto = motherProductId;
        data.idProducto = motherProductId;

        async function proceedSubmit(finalData) {
            try {
                const variants = collectVariantPayloads();
                const groupCategoryUpdates = isEditingProduct
                    ? buildGroupCategorySyncPayloads(motherProductId, finalData['ID Variacion'] || finalData['ID Variación'] || originalVariationId, finalData.Categoria, finalData.Promocion)
                    : [];
                const itemsToSave = [finalData, ...groupCategoryUpdates, ...variants];
                
                const savedProducts = await saveProductListToGoogleSheets(itemsToSave, {
                    fallbackEditOverride: isEditingProduct ? true : false
                });
                const pendingKey = document.getElementById('product-form')?.dataset.pendingKey;
                if (pendingKey) {
                    try { await window.BlyxuPendingProducts?.complete(pendingKey); }
                    catch (_) { showToast('Producto guardado; no se pudo cerrar el pendiente. Actualiza la lista antes de retomarlo.', 'error'); }
                }
                clearPublicProductsCache();
                
                try {
                    mergeSavedProductsIntoInventory(savedProducts);
                } catch (renderError) {
                    console.warn('Producto guardado, pero no se pudo refrescar el inventario local:', renderError);
                }
                const savedQrTicket = getProductFormQrTicketData(finalData);
                const savedVariantsCount = savedProducts.length - 1;
                showToast(savedVariantsCount > 0 ? `Producto y ${savedVariantsCount} actualizacion(es) de variante guardados en Google Sheets` : 'Producto guardado en Google Sheets', 'success');
                window.OriginalStoreAdminSession.clearDraft();
                resetProductForm();
                showProductQrTicket(savedQrTicket);
                btn.disabled = false;
                btn.textContent = 'Guardar producto y variantes';
                const editModal = document.getElementById('edit-product-modal');
                if (editModal?.classList.contains('open') || editModal?.style.display === 'flex') {
                    cerrarModalEdicion();
                }
                setTimeout(function () { cargarInventario({ silent: true }); }, 1000);
            } catch (err) {
                showToast('Error: ' + err.message, 'error');
                btn.disabled = false;
                btn.textContent = 'Guardar / Enviar';
            }
        }

        proceedSubmit(data);
    });

    document.getElementById('btn-reset-product')?.addEventListener('click', ()=>{window.OriginalStoreAdminSession.clearDraft();resetProductForm();});

    const variantsContainer = document.getElementById('variants-container');
    const handleVariantPreviewActivity = event => {
        const card = event.target.closest?.('#variants-container .variant-edit-card, #variants-container .admin-panel');
        if (card) setActiveVariantPreviewCard(card);
    };
    variantsContainer?.addEventListener('focusin', event => {
        handleVariantPreviewActivity(event);
        updateLivePreview();
    });
    variantsContainer?.addEventListener('input', event => {
        handleVariantPreviewActivity(event);
        updateLivePreview();
    });
    variantsContainer?.addEventListener('change', event => {
        handleVariantPreviewActivity(event);
        updateLivePreview();
    });
    document.getElementById('variants-container')?.addEventListener('click', event => {
        handleVariantPreviewActivity(event);
        const removeBtn = event.target.closest('.var-remove-card-btn');
        if (!removeBtn) return;
        const removedCard = removeBtn.closest('.admin-panel');
        if (variantsContainer && removedCard && variantsContainer.dataset.activePreviewVariantKey === getVariantPreviewCardKey(removedCard)) {
            delete variantsContainer.dataset.activePreviewVariantKey;
        }
        removedCard?.remove();
        updateLivePreview();
    });

    document.getElementById('btn-add-variant')?.addEventListener('click', () => {
        document.getElementById('btn-add-manual-variant')?.click();
    });

    document.getElementById('btn-show-variation-generator')?.addEventListener('click', () => {
        const fields = document.getElementById('variation-generator-fields');
        if (fields) {
            openProductEntryStep(document.getElementById('product-variants-step'));
            fields.style.display = 'block';
            fields.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
    });

    document.getElementById('btn-add-manual-variant')?.addEventListener('click', () => {
        const container = document.getElementById('variants-container');
        if (!container) return;

        const ids = ensureProductHierarchyIds();
        if (!container.querySelector('table') && !container.querySelector('.admin-panel,.variant-edit-card')) {
            container.innerHTML = '';
        }

        const cardId = crypto.randomUUID();
        const autoVariantId = getNextVariantId(ids.idProducto);
        const barcodeInputId = `var-barcode-${cardId}`;
        const barcodeModeId = `var-barcode-mode-${cardId}`;
        
        const card = document.createElement('div');
        card.className = 'admin-panel';
        card.id = `variant-card-${cardId}`;
        card.style.cssText = `
            border-top: 4px solid var(--primary);
            padding: 24px;
            animation: fadeIn 0.4s ease;
            position: relative;
            background: rgba(255,255,255,0.02);
            margin-bottom: 20px;
        `;

        card.innerHTML = `
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px;">
                <h4 style="margin:0; font-size:12px; text-transform:uppercase; letter-spacing:1px; color:var(--primary); font-weight:800;">Nueva variante</h4>
                <button type="button" class="admin-btn secondary var-remove-card-btn" style="width:auto; padding:6px 12px; font-size:10px; border-radius:10px;">Cerrar / Quitar</button>
            </div>
            <div class="admin-form-grid">
                <div class="form-group product-id-field">
                    <div class="product-id-label-row">
                        <label>ID Variante / Hijo</label>
                        <label class="barcode-mode-toggle" title="Usar codigo real de la marquilla"><input type="checkbox" class="var-barcode-mode" id="${barcodeModeId}"> Escanear</label>
                    </div>
                    <input type="text" class="form-control var-id" value="${autoVariantId}" placeholder="Ej: ESTAMPADO-01">
                    <div class="product-barcode-compact var-barcode-panel">
                        <input type="text" class="form-control var-barcode" id="${barcodeInputId}" value="${makeProductBarcode(ids.idProducto, autoVariantId)}" placeholder="Escanea o escribe el codigo" data-auto-barcode="1" data-generated-barcode="${makeProductBarcode(ids.idProducto, autoVariantId)}">
                        <button type="button" class="admin-btn secondary" onclick="scanBarcodeToElement('${barcodeInputId}')">Escanear</button>
                    </div>
                    <small class="field-hint var-barcode-hint">Codigo interno automatico asignado.</small>
                </div>
                <div class="form-group">
                    <label>Nombre del Producto</label>
                    <input type="text" class="form-control var-nombre" placeholder="${getInputValue('prod-nombre')}" value="${getInputValue('prod-nombre')}">
                </div>
                <div class="form-group">
                    <label>Precio</label>
                    <input type="text" class="form-control var-precio" placeholder="${getInputValue('prod-precio')}" value="${getInputValue('prod-precio')}">
                </div>
                <div class="form-group">
                    <label>Precio Mayorista</label>
                    <input type="text" class="form-control var-precio-mayor" placeholder="${getInputValue('prod-precio-mayorista')}" value="${getInputValue('prod-precio-mayorista')}">
                </div>
                <div class="form-group">
                    <label>Estilo</label>
                    <input type="text" class="form-control var-estilo" value="${getInputValue('prod-estilo')}" placeholder="Ej: flor, corazon">
                </div>
                <div class="form-group variant-measure-group">
                    <label>Tamaño / Medida</label>
                    <div class="variant-size-control" style="display:grid; gap:8px;">
                        <select class="form-control var-size-mode">
                            <option value="auto">Usar medidas del principal</option>
                            <option value="custom">Ajustar manual</option>
                        </select>
                        <input type="text" class="form-control var-tamano" value="${escapeHtml(getVariantAutoSizeValue())}" readonly>
                        <small class="field-hint var-size-hint">Usa las medidas del principal.</small>${variantMeasurementMarkup()}
                    </div>
                </div>

                <div class="form-group">
                    <label>Color</label>
                    <input type="hidden" class="var-color">
                    <div class="color-picker" data-color-target=".var-color" aria-label="Seleccionar color de variante"></div>
                </div>
                <div class="form-group">
                    <label>Stock</label>
                    <input type="number" class="form-control var-stock" value="12">
                </div>
                <div class="form-group variant-image-field">
                    <label>Imagen de variante</label><label class="variant-image-switch"><input type="checkbox" class="var-use-general-image" checked role="switch"> Usar foto del producto general</label><div class="variant-general-preview"><img alt="Foto general"><small>Se usa la foto actual del producto principal.</small></div><div class="variant-own-image" hidden>
                    <input type="file" class="var-image-file" accept="image/*" style="display:none;">
                    <div class="var-drop-zone drop-zone variant-image-picker">
                        <div class="variant-image-placeholder">
                            <div class="upload-icon">&#128247;</div>
                            <strong>A&ntilde;adir o arrastrar imagen</strong>
                            <span>Haz clic para seleccionar archivo o arrastra una imagen aqui</span>
                        </div>
                        <div class="variant-image-preview-wrapper" style="display:none;">
                            <img class="var-preview-thumb" src="" alt="Vista previa">
                            <div class="variant-image-actions">
                                <button type="button" class="admin-btn var-image-change-btn">Cambiar</button>
                                <button type="button" class="admin-btn secondary var-image-remove-btn">Quitar</button>
                            </div>
                        </div>
                    </div>
                    <div class="image-url-row"><input type="text" class="form-control var-imagen" placeholder="O pega aqui la URL directa de la imagen (https://...)"><small class="field-hint">Esta será la foto propia de esta variante.</small></div></div>
                </div>
            </div>
            <button type="button" class="admin-btn btn-save-individual-variant" style="background:linear-gradient(135deg, #6C5CE7, #9B2CFA); margin-top:10px;">Guardar esta Variante</button>
        `;

        openProductEntryStep(document.getElementById('product-variants-step'));
        container.querySelectorAll('.variant-draft-fold').forEach(fold=>fold.open=false);
        card.innerHTML='<details class="variant-draft-fold" open><summary>'+escapeHtml(autoVariantId)+'</summary><div>'+card.innerHTML+'</div></details>';
        container.appendChild(card);
        syncVariantImageMode(card);
        initColorPickers(card);
        const variantIdInput = card.querySelector('.var-id');
        const variantBarcodeInput = card.querySelector('.var-barcode');
        const variantBarcodeMode = card.querySelector('.var-barcode-mode');
        const variantBarcodePanel = card.querySelector('.var-barcode-panel');
        const variantBarcodeHint = card.querySelector('.var-barcode-hint');
        const syncVariantBarcode = (force = false) => {
            if (!variantBarcodeInput) return;
            const generated = makeProductBarcode(getInputValue('prod-id-producto'), variantIdInput?.value || autoVariantId);
            const current = normalizeBarcodeValue(variantBarcodeInput.value);
            const previousGenerated = normalizeBarcodeValue(variantBarcodeInput.dataset.generatedBarcode || '');
            variantBarcodeInput.dataset.generatedBarcode = generated;
            const scanModeEnabled = variantBarcodeMode?.checked === true;
            if (force || !scanModeEnabled || (scanModeEnabled && current && (variantBarcodeInput.dataset.autoBarcode === '1' || current === previousGenerated))) {
                variantBarcodeInput.value = generated;
                variantBarcodeInput.dataset.autoBarcode = '1';
            }
        };
        const setVariantBarcodeMode = enabled => {
            const scanModeEnabled = Boolean(enabled);
            if (variantBarcodeMode) variantBarcodeMode.checked = scanModeEnabled;
            variantBarcodePanel?.classList.toggle('is-visible', scanModeEnabled);
            if (!variantBarcodeInput) return;
            if (scanModeEnabled) {
                const generated = normalizeBarcodeValue(variantBarcodeInput.dataset.generatedBarcode || makeProductBarcode(getInputValue('prod-id-producto'), variantIdInput?.value || autoVariantId));
                const current = normalizeBarcodeValue(variantBarcodeInput.value);
                if (!current || current === generated || variantBarcodeInput.dataset.autoBarcode === '1') {
                    variantBarcodeInput.value = '';
                }
                variantBarcodeInput.dataset.autoBarcode = '0';
                if (variantBarcodeHint) variantBarcodeHint.textContent = 'Escanea la marquilla real de esta variante.';
            } else {
                variantBarcodeInput.dataset.autoBarcode = '1';
                syncVariantBarcode(true);
                if (variantBarcodeHint) variantBarcodeHint.textContent = 'Codigo interno automatico asignado.';
            }
        };
        variantBarcodeInput?.addEventListener('input', () => {
            const scanModeEnabled = variantBarcodeMode?.checked === true;
            variantBarcodeInput.dataset.autoBarcode = scanModeEnabled && variantBarcodeInput.value.trim() ? '0' : '1';
        });
        variantBarcodeMode?.addEventListener('change', event => setVariantBarcodeMode(event.target.checked));
        variantIdInput?.addEventListener('input', () => syncVariantBarcode());
        variantIdInput?.addEventListener('change', () => syncVariantBarcode());
        setVariantBarcodeMode(false);
        const variantSizeMode = card.querySelector('.var-size-mode');
        variantSizeMode?.addEventListener('change', () => {
            syncVariantSizeField(card);
            updateLivePreview();
        });
        syncVariantSizeField(card);
        setupVariantImagePicker(card);
        updateLivePreview();
        card.scrollIntoView({ behavior: 'smooth', block: 'center' });

        // Evento de guardado para esta tarjeta específica
        card.querySelector('.btn-save-individual-variant').addEventListener('click', async (e) => {
            const btn = e.target;
            var motherId = ensureProductHierarchyIds().idProducto;
            if (!motherId) {
                showToast('Error: Debes especificar un ID Producto (Madre) antes de guardar una variante');
                btn.disabled = false;
                return;
            }
            btn.disabled = true;
            const originalText = btn.textContent;
            btn.textContent = 'Guardando...';
            const measurementData = getVariantMeasurementData(card);
            const variantTamano = getVariantSizeValue(card);
            const variantMeasurementData = {
                ...measurementData,
                textileSize: measurementData.kind === 'textil' && variantTamano ? variantTamano : measurementData.textileSize
            };

                const data = {
                    'ID Variacion': card.querySelector('.var-id').value,
                    'ID Variación': card.querySelector('.var-id').value,
                    'ID Producto': motherId,
                    ID_Producto: motherId,
                    'Nombre del Producto': card.querySelector('.var-nombre')?.value || getInputValue('prod-nombre'),
                    Nombre: card.querySelector('.var-nombre')?.value || getInputValue('prod-nombre'),
                    Precio: parseAmount(card.querySelector('.var-precio')?.value || getInputValue('prod-precio')),
                    'Precio Mayor': parseAmount(card.querySelector('.var-precio-mayor')?.value || getInputValue('prod-precio-mayorista')),
                    Categoria: getInputValue('prod-categoria'),
                    Catalogo: getInputValue('prod-catalogo') || 'Ambos',
                    'Categoría': getInputValue('prod-categoria'),
                    Cantidad: Number(card.querySelector('.var-stock')?.value || 12),
                    Stock: Number(card.querySelector('.var-stock')?.value || 12),
                    'Stock Inicial': Number(card.querySelector('.var-stock')?.value || 12),
                    Descripcion: getInputValue('prod-descripcion'),
                    'Caracteristicas del producto': getInputValue('prod-descripcion'),
                    Tamano: variantTamano,
                    Talla: variantTamano,
                    'Tamaño': variantTamano,
                    ...buildProductMeasurementPayload(variantMeasurementData),
                    Color: card.querySelector('.var-color')?.value || '',
                    Estilo: card.querySelector('.var-estilo') ? cleanProductStyleValue(card.querySelector('.var-estilo').value) : getProductStyleValue(),
                    'Codigo Barras': card.querySelector('.var-barcode')?.value || makeProductBarcode(motherId, card.querySelector('.var-id').value),
                    SKU: card.querySelector('.var-sku')?.value || '',
                    'Modo Imagen': getVariantImageMode(card),
                    Imagen: getVariantImageValue(card),
                    'Imagen Principal': getVariantImageValue(card),
                    'Galeria JSON': '',
                    'Galería JSON': '',
                    Estado: getInputValue('prod-estado') || 'Activo'
                };

            try {
                await postProductToGoogleSheets(data, false);
                clearPublicProductsCache();
                card.dataset.saved = '1';
                showToast('¡Variante guardada!');
                btn.style.background = '#00c853';
                btn.textContent = 'Guardado';
                setTimeout(() => {
                    btn.disabled = false;
                    btn.style.background = 'linear-gradient(135deg, #6C5CE7, #9B2CFA)';
                    btn.textContent = originalText;
                }, 3000);
                setTimeout(() => cargarInventario({ silent: true }), 1500);
            } catch (err) {
                console.error(err);
                showToast('Error al guardar variante: ' + (err.message || err), 'error');
                btn.disabled = false;
                btn.textContent = 'Reintentar';
            }
        });
    });

    document.getElementById('btn-generate-variations')?.addEventListener('click', () => {
        const addButton = document.getElementById('btn-add-manual-variant');
        const container = document.getElementById('variants-container');
        if (!addButton || !container) return;

        const primaryField = getVariationFieldFromInput();
        const primaryOptions = splitVariationOptions(getVariationInputForField(primaryField));
        const baseStyle = primaryField === 'style' ? '' : getInputValue('prod-estilo');
        const baseSize = primaryField === 'size' ? '' : getInputValue('prod-tamano');
        const baseColor = primaryField === 'color' ? '' : getInputValue('prod-color');
        const combinations = primaryOptions
            .map(value => ({
                styleValue: primaryField === 'style' ? value : baseStyle,
                sizeValue: primaryField === 'size' ? value : baseSize,
                colorValue: primaryField === 'color' ? value : baseColor
            }))
            .filter(combo => combo.styleValue || combo.sizeValue || combo.colorValue);

        if (!combinations.length) {
            showToast('Escribe al menos un estilo, tamaño o color para generar variantes');
            return;
        }

        container.innerHTML = '';
        const motherId = ensureProductHierarchyIds().idProducto;
        const firstCombo = combinations[0];
        const mainChildIdInput = document.getElementById('prod-id');
        if (mainChildIdInput?.dataset.scannedReference !== '1') {
            setInputValue('prod-id', `${motherId}-V01`);
        }
        setInputValue('prod-estilo', firstCombo.styleValue || '');
        setInputValue('prod-tamano', firstCombo.sizeValue || '');
        setInputValue('prod-color', firstCombo.colorValue || '');

        combinations.slice(1).forEach((combo, index) => {
            addButton.click();
            const card = container.lastElementChild;
            if (!card) return;
            const variantId = card.querySelector('.var-id').value;

            card.querySelector('.var-id').value = variantId;
            card.querySelector('.var-nombre').value = getInputValue('prod-nombre');
            card.querySelector('.var-estilo').value = combo.styleValue || getInputValue('prod-estilo');
            const sizeMode = card.querySelector('.var-size-mode');
            const sizeInput = card.querySelector('.var-tamano');
            if (sizeMode) sizeMode.value = primaryField === 'size' ? 'custom' : 'auto';
            if (sizeInput) sizeInput.value = combo.sizeValue || getVariantAutoSizeValue();
            syncVariantSizeField(card);
            card.querySelector('.var-color').value = combo.colorValue || getInputValue('prod-color');
            initColorPickers(card);
        });

        const summary = document.getElementById('variation-generator-summary');
        if (summary) summary.textContent = `${combinations.length} variante(s) hijas listas: V01 en la variante inicial y ${Math.max(combinations.length - 1, 0)} tarjeta(s) adicional(es).`;
        updateLivePreview();
        showToast(`${combinations.length} variacion(es) generadas`, 'success');
    });
});

function initSettingsFolds() {
    const root = document.getElementById('view-settings');
    if (!root) return;
    const contact = root.querySelector('#settings-tab-contact') || root;
    if (!document.getElementById('google-login-config-form')) {
        const form = document.createElement('form');
        form.id = 'google-login-config-form';
        form.innerHTML = '<div class="form-group"><label for="google-login-client-id">ID de cliente de Google</label><input class="form-control" id="google-login-client-id" placeholder="...apps.googleusercontent.com"><small class="field-hint">Crea un cliente OAuth de tipo Aplicación web en Google Cloud y autoriza el dominio de la tienda. Deja vacío para ocultar este método.</small></div><button class="admin-btn" type="submit">Guardar acceso con Google</button>';
        contact.appendChild(form);
        const field = form.querySelector('input');
        loadSiteConfigForAdmin().then(config => field.value = config.Google_Client_ID || '');
        form.addEventListener('submit', async event => {
            event.preventDefault();
            const value = field.value.trim();
            if (value && !/^[\w.-]+\.apps\.googleusercontent\.com$/.test(value)) { showToast('Revisa el ID de cliente de Google', 'error'); return; }
            const button = form.querySelector('button');
            button.disabled = true;
            try { await saveSiteConfig('Google_Client_ID', value, { throwOnError: true }); showToast('Acceso con Google guardado'); }
            catch (error) { showToast('No se pudo guardar el acceso con Google', 'error'); }
            finally { button.disabled = false; }
        });
    }
    const titles = {
        'google-login-config-form': 'Registro e inicio de sesión con Google',
        'home-ad-config-form': 'Banner de inicio', 'carousel-image-form': 'Carrusel de inicio',
        'contact-config-form': 'Horario y canales de contacto', 'whatsapp-config-form': 'WhatsApp comercial',
        'promo-config-form': 'Promoción minorista', 'wholesale-promo-config-form': 'Promoción mayorista',
        'customer-promo-form': 'Promoción de clientes registrados', 'invoice-config-form': 'Datos de facturación',
        'qr-config-form': 'Métodos de pago y acceso'
    };
    root.querySelectorAll('form, .retail-toggle-card').forEach(source => {
        if (source.closest('details.settings-fold')) return;
        const fold = document.createElement('details');
        fold.className = 'settings-fold';
        const summary = document.createElement('summary');
        summary.textContent = titles[source.id] || source.querySelector('strong, h3')?.textContent || 'Configuración';
        source.before(fold);
        fold.append(summary, source);
    });
    root.addEventListener('invalid', event => {
        let fold = event.target.closest('details');
        while (fold) { fold.open = true; fold = fold.parentElement?.closest('details'); }
    }, true);
}

function initRetailPriceToggle() {
    const toggle = document.getElementById('toggle-retail-prices');
    if (!toggle) return;
    const toggleLabel = toggle.closest('.settings-toggle-row');

    function renderState(enabled) {
        if (enabled === undefined) enabled = localStorage.getItem(RETAIL_PRICE_VISIBILITY_KEY) !== '0';
        toggle.checked = Boolean(enabled);
        toggle.setAttribute('aria-checked', enabled ? 'true' : 'false');
        if (toggleLabel) {
            toggleLabel.childNodes.forEach(node => {
                if (node.nodeType === Node.TEXT_NODE) node.textContent = enabled ? ' Activo' : ' Oculto';
            });
        }
        toggle.title = enabled ? 'Precios minoristas visibles' : 'Precios minoristas ocultos';
    }

    toggle.addEventListener('change', async () => {
        const nextEnabled = toggle.checked;
        localStorage.setItem(RETAIL_PRICE_VISIBILITY_KEY, nextEnabled ? '1' : '0');
        renderState(nextEnabled);
        await saveSiteConfig(RETAIL_PRICE_CONFIG_KEY, nextEnabled ? '1' : '0');
        window.storeConfig = {
            ...(window.storeConfig || {}),
            [RETAIL_PRICE_CONFIG_KEY]: nextEnabled ? '1' : '0'
        };
        showToast(nextEnabled ? 'Precios minoristas visibles' : 'Precios minoristas ocultos');
    });

    renderState();
    loadSiteConfigForAdmin().then(config => {
        if (config && config[RETAIL_PRICE_CONFIG_KEY] !== undefined) {
            const enabled = String(config[RETAIL_PRICE_CONFIG_KEY]) === '1';
            localStorage.setItem(RETAIL_PRICE_VISIBILITY_KEY, enabled ? '1' : '0');
            renderState(enabled);
        }
    });
}

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('product-form');
    form?.addEventListener('invalid', event => {
        let fold = event.target.closest('details');
        while (fold) {
            fold.open = true;
            fold = fold.parentElement?.closest('details');
        }
    }, true);
});

function initCatalogWhatsAppToggle() {
    const toggle = document.getElementById('toggle-catalog-whatsapp');
    if (!toggle) return;
    const key = 'Catalogo_Solo_WhatsApp';
    const renderState = enabled => {
        toggle.checked = enabled;
        toggle.setAttribute('aria-checked', String(enabled));
    };
    toggle.addEventListener('change', async () => {
        const enabled = toggle.checked;
        toggle.disabled = true;
        try {
            await saveSiteConfig(key, enabled ? '1' : '0', { throwOnError: true });
            window.storeConfig = { ...(window.storeConfig || {}), [key]: enabled ? '1' : '0' };
            renderState(enabled);
            showToast(enabled ? 'Catálogo con pedidos por WhatsApp activo' : 'Modo catálogo por WhatsApp desactivado');
        } catch (error) {
            renderState(!enabled);
            showToast('No se pudo guardar el modo catálogo por WhatsApp', 'error');
        } finally {
            toggle.disabled = false;
        }
    });
    loadSiteConfigForAdmin().then(config => renderState(String(config[key] || '0') === '1'));
}

function initMercadoPagoPublicToggle() {
    const toggle = document.getElementById('toggle-mercado-pago-public');
    if (!toggle) return;
    const toggleLabel = toggle.closest('.settings-toggle-row');

    function renderState(enabled) {
        if (enabled === undefined) enabled = true;
        toggle.checked = Boolean(enabled);
        toggle.setAttribute('aria-checked', enabled ? 'true' : 'false');
        if (toggleLabel) {
            toggleLabel.childNodes.forEach(node => {
                if (node.nodeType === Node.TEXT_NODE) node.textContent = enabled ? ' Activo' : ' Solo WhatsApp';
            });
        }
        toggle.title = enabled ? 'Mercado Pago visible en carrito publico' : 'Mercado Pago oculto; carrito finaliza por WhatsApp';
    }

    toggle.addEventListener('change', async () => {
        const nextEnabled = toggle.checked;
        renderState(nextEnabled);
        await saveSiteConfig(MERCADO_PAGO_ENABLED_CONFIG_KEY, nextEnabled ? '1' : '0');
        window.storeConfig = {
            ...(window.storeConfig || {}),
            [MERCADO_PAGO_ENABLED_CONFIG_KEY]: nextEnabled ? '1' : '0'
        };
        showToast(nextEnabled ? 'Mercado Pago publico activo' : 'Mercado Pago publico desactivado');
    });

    renderState();
    loadSiteConfigForAdmin().then(config => {
        if (config && config[MERCADO_PAGO_ENABLED_CONFIG_KEY] !== undefined) {
            renderState(String(config[MERCADO_PAGO_ENABLED_CONFIG_KEY]) !== '0');
        }
    });
}

async function loadSiteConfigForAdmin(options = {}) {
    if (options.force) siteConfigPromise = null;
    if (!siteConfigPromise) {
        const pending = fetch(GOOGLE_SHEET_API+'?action=get_config&_='+Date.now(), {cache:'no-store'})
            .then(res => res.json()).then(data => {
                if(data?.status !== 'success' || !data.config) throw new Error(data?.error || 'No se pudo cargar la configuración.');
                return data.config;
            });
        siteConfigPromise = pending;
        pending.catch(() => {if(siteConfigPromise === pending)siteConfigPromise=null;});
    }
    try {return await siteConfigPromise;}
    catch(err){console.warn('No se pudo cargar configuración:',err);if(options.throwOnError)throw err;return {};}
}

function updateSiteConfigCacheForAdmin(key, value) {
    if (/password|secret|token|clave/i.test(key)) return;
    try {
        const cached = JSON.parse(localStorage.getItem(SITE_CONFIG_CACHE_KEY) || 'null');
        const cachedData = cached && typeof cached === 'object' && cached.data && typeof cached.data === 'object'
            ? cached.data
            : {};

        localStorage.setItem(SITE_CONFIG_CACHE_KEY, JSON.stringify({
            savedAt: Date.now(),
            data: {
                ...cachedData,
                [key]: String(value ?? '')
            }
        }));
    } catch (error) {
        console.warn('No se pudo actualizar cache local de configuracion:', error);
    }
}

async function saveSiteConfig(key, value, options = {}) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 9000);
    try {
        const formData = new FormData();
        formData.append('action', 'set_config');
        formData.append('Clave', key);
        formData.append('Valor', value);

        await fetch(GOOGLE_SHEET_API, {
            method: 'POST',
            body: formData,
            mode: 'no-cors',
            signal: controller.signal
        });
        clearTimeout(timeout);
        updateSiteConfigCacheForAdmin(key, value);
        siteConfigPromise = null;
    } catch (err) {
        clearTimeout(timeout);
        console.error('No se pudo guardar configuración:', err);
        showToast('No se pudo guardar configuración en Google Sheets');
        if (options.throwOnError) throw err;
    }
}

function fillContactConfigForm(config) {
    CONTACT_CONFIG_FIELDS.forEach(([key, id]) => {
        const input = document.getElementById(id);
        if (input) input.value = key === 'Contacto_WhatsApp'
            ? (config?.[key] || config?.WhatsApp_Comercial || '')
            : (config?.[key] || (key === 'Contacto_Dias' ? 'Lunes a Sábado' : key === 'Contacto_Horarios' ? '10:00 a.m. - 7:00 p.m.' : ''));
    });
}

function initContactConfigAdmin() {
    const form = document.getElementById('contact-config-form');
    if (!form) return;

    loadSiteConfigForAdmin().then(fillContactConfigForm);

    form.addEventListener('submit', async e => {
        e.preventDefault();
        const btn = document.getElementById('btn-save-contact-config');
        const originalText = btn ? btn.textContent : '';
        if (btn) {
            btn.disabled = true;
            btn.textContent = 'Guardando...';
        }

        try {
            const savedConfig = {};
            await Promise.all(CONTACT_CONFIG_FIELDS.map(([key, id]) => {
                let value = document.getElementById(id)?.value?.trim() || '';
                if (key === 'Contacto_Dias' && !value) value = 'Lunes a Sábado';
                if (key === 'Contacto_Horarios' && !value) value = '10:00 a.m. - 7:00 p.m.';
                savedConfig[key] = value;
                return saveSiteConfig(key, value);
            }));
            const contactWhatsAppInput = document.getElementById('contact-config-whatsapp');
            const contactWhatsApp = normalizeWhatsAppPhone(contactWhatsAppInput?.value || '');
            if (contactWhatsApp) {
                if (contactWhatsAppInput) contactWhatsAppInput.value = contactWhatsApp;
                await saveSiteConfig('WhatsApp_Comercial', contactWhatsApp);
                savedConfig.WhatsApp_Comercial = contactWhatsApp;
                const commerceInput = document.getElementById('whatsapp-config-commerce');
                if (commerceInput) commerceInput.value = contactWhatsApp;
            }
            window.storeConfig = { ...(window.storeConfig || {}), ...savedConfig };
            showToast('Contacto actualizado');
        } catch (err) {
            console.error('No se pudo guardar contacto:', err);
            showToast('No se pudo guardar contacto');
        } finally {
            if (btn) {
                btn.disabled = false;
                btn.textContent = originalText || 'Guardar Contacto';
            }
        }
    });
}

function normalizeWhatsAppPhone(value) {
    return String(value || '').replace(/\D/g, '');
}

function fillWhatsAppConfigForm(config) {
    WHATSAPP_CONFIG_FIELDS.forEach(([key, id]) => {
        const input = document.getElementById(id);
        if (!input) return;
        input.value = config?.[key] || config?.Contacto_WhatsApp || '';
    });
}

function initWhatsAppConfigAdmin() {
    const form = document.getElementById('whatsapp-config-form');
    if (!form) return;

    loadSiteConfigForAdmin().then(fillWhatsAppConfigForm);

    form.addEventListener('submit', async e => {
        e.preventDefault();
        const btn = document.getElementById('btn-save-whatsapp-config');
        const originalText = btn ? btn.textContent : '';
        const phoneInput = document.getElementById('whatsapp-config-commerce');
        const phone = normalizeWhatsAppPhone(phoneInput?.value || '');

        if (!phone) {
            showToast('Ingresa un número de WhatsApp válido');
            return;
        }

        if (btn) {
            btn.disabled = true;
            btn.textContent = 'Guardando...';
        }

        try {
            if (phoneInput) phoneInput.value = phone;
            await Promise.all([
                saveSiteConfig('WhatsApp_Comercial', phone),
                saveSiteConfig('Contacto_WhatsApp', phone)
            ]);

            const contactInput = document.getElementById('contact-config-whatsapp');
            if (contactInput) contactInput.value = phone;
            showToast('WhatsApp comercial actualizado');
        } catch (err) {
            console.error('No se pudo guardar WhatsApp:', err);
            showToast('No se pudo guardar WhatsApp');
        } finally {
            if (btn) {
                btn.disabled = false;
                btn.textContent = originalText || 'Guardar WhatsApp';
            }
        }
    });
}

function fillInvoiceConfigForm(config) {
    INVOICE_CONFIG_FIELDS.forEach(([key, id]) => {
        const input = document.getElementById(id);
        if (input) input.value = config?.[key] || '';
    });
}

function initInvoiceConfigAdmin() {
    const form = document.getElementById('invoice-config-form');
    if (!form) return;

    loadSiteConfigForAdmin().then(fillInvoiceConfigForm);

    form.addEventListener('submit', async e => {
        e.preventDefault();
        const btn = document.getElementById('btn-save-invoice-config');
        const originalText = btn ? btn.textContent : '';
        if (btn) {
            btn.disabled = true;
            btn.textContent = 'Guardando...';
        }

        try {
            await Promise.all(INVOICE_CONFIG_FIELDS.map(([key, id]) => {
                const value = document.getElementById(id)?.value?.trim() || '';
                return saveSiteConfig(key, value);
            }));
            
            window.storeConfig = window.storeConfig || {};
            INVOICE_CONFIG_FIELDS.forEach(([key, id]) => {
                window.storeConfig[key] = document.getElementById(id)?.value?.trim() || '';
            });
            
            showToast('Configuración de factura actualizada');
        } catch (err) {
            console.error('No se pudo guardar configuración de factura:', err);
            showToast('No se pudo guardar la configuración');
        } finally {
            if (btn) {
                btn.disabled = false;
                btn.textContent = originalText || 'Guardar Ajustes de Factura';
            }
        }
    });
}

const PROMO_CONFIG_FIELDS = [
    ['Promo_Enabled', 'promo-config-enabled'],
    ['Promo_Title', 'promo-config-title'],
    ['Promo_Discount', 'promo-config-discount'],
    ['Promo_Date', 'promo-config-date'],
    ['Promo_Message', 'promo-config-message']
];

function fillPromoConfigForm(config) {
    if (!config) return;
    window.storeConfig = window.storeConfig || {};
    PROMO_CONFIG_FIELDS.forEach(([key, id]) => {
        window.storeConfig[key] = config[key] || '';
        const input = document.getElementById(id);
        if (input) {
            if (input.type === 'checkbox') {
                input.checked = config[key] === 'true';
            } else {
                input.value = config[key] || '';
            }
        }
    });
    renderPromoAdminPreview();
    updateLivePreview();
}

function getPromoAdminValues() {
    return {
        enabled: document.getElementById('promo-config-enabled')?.checked === true,
        title: document.getElementById('promo-config-title')?.value?.trim() || 'Oferta Original Store',
        discount: document.getElementById('promo-config-discount')?.value?.trim() || '',
        message: document.getElementById('promo-config-message')?.value?.trim() || 'Aprovecha nuestros descuentos especiales.',
        date: document.getElementById('promo-config-date')?.value?.trim() || ''
    };
}

function formatPromoCountdownParts(dateValue) {
    const target = new Date(dateValue).getTime();
    if (!dateValue || Number.isNaN(target)) {
        return [
            ['--', 'Days'],
            ['--', 'Hrs'],
            ['--', 'Mins'],
            ['--', 'Secs']
        ];
    }
    const diff = Math.max(0, target - Date.now());
    const days = Math.floor(diff / 86400000);
    const hours = Math.floor((diff % 86400000) / 3600000);
    const mins = Math.floor((diff % 3600000) / 60000);
    const secs = Math.floor((diff % 60000) / 1000);
    return [
        [String(days).padStart(2, '0'), 'Days'],
        [String(hours).padStart(2, '0'), 'Hrs'],
        [String(mins).padStart(2, '0'), 'Mins'],
        [String(secs).padStart(2, '0'), 'Secs']
    ];
}

function renderPromoAdminPreview() {
    const preview = document.getElementById('promo-admin-preview');
    if (!preview) return;
    const values = getPromoAdminValues();
    const discountText = values.discount ? `-${String(values.discount).replace(/[^\d]/g, '') || values.discount}%` : 'Promo';
    preview.classList.toggle('is-disabled', !values.enabled);
    preview.innerHTML = `
        <div class="promo-admin-preview-card">
            <div class="promo-admin-preview-badge">${escapeHtml(discountText)}</div>
            <div class="promo-admin-preview-copy">
                <strong>${escapeHtml(values.title)}</strong>
                <span>${escapeHtml(values.message)}</span>
            </div>
            <div class="promo-admin-preview-countdown">
                ${formatPromoCountdownParts(values.date).map(([value, label]) => `
                    <div><strong>${escapeHtml(value)}</strong><span>${escapeHtml(label)}</span></div>
                `).join('')}
            </div>
        </div>
    `;
}

let promoAdminPreviewFrame = null;

function schedulePromoAdminPreview() {
    if (promoAdminPreviewFrame) cancelAnimationFrame(promoAdminPreviewFrame);
    promoAdminPreviewFrame = requestAnimationFrame(() => {
        renderPromoAdminPreview();
        updateLivePreview();
        promoAdminPreviewFrame = null;
    });
}

function initWholesalePromoConfigAdmin() {
    const form = document.getElementById('wholesale-promo-config-form');
    if (!form) return;
    const fields = [['Enabled', 'enabled'], ['Title', 'title'], ['Discount', 'discount'], ['Date', 'date'], ['Message', 'message']];
    const input = suffix => document.getElementById('wholesale-promo-config-' + suffix);
    input('discount').required = true;
    input('date').required = true;
    const preview = () => {
        const target = document.getElementById('wholesale-promo-admin-preview');
        if (target) target.textContent = `${input('title').value || 'Oferta mayorista'} · -${input('discount').value || '0'}% · ${input('message').value} · Hasta ${input('date').value || 'seleccionar fecha final'}`;
    };
    form.addEventListener('input', preview);
    loadSiteConfigForAdmin().then(config => {
        fields.forEach(([key, suffix]) => {
            if (suffix === 'enabled') input(suffix).checked = String(config['Wholesale_Promo_' + key]) === 'true';
            else input(suffix).value = suffix === 'date' ? String(config['Wholesale_Promo_' + key] || '').replace(/-05:00$/, '') : (config['Wholesale_Promo_' + key] || '');
        });
        preview();
    });
    form.addEventListener('submit', async event => {
        event.preventDefault();
        if (input('enabled').checked && Date.parse(input('date').value + '-05:00') <= Date.now()) {
            showToast('Selecciona una fecha final futura para la promoción mayorista', 'error');
            return;
        }
        const button = form.querySelector('button[type="submit"], #btn-save-wholesale-promo-config');
        if (button) button.disabled = true;
        try {
            // Desactivar primero evita publicar una promoción parcialmente guardada.
            await saveSiteConfig('Wholesale_Promo_Enabled', 'false', { throwOnError: true });
            for (const [key, suffix] of fields.filter(([key]) => key !== 'Enabled')) {
                const value = input(suffix).value.trim();
                await saveSiteConfig('Wholesale_Promo_' + key, suffix === 'date' && value ? value + '-05:00' : value, { throwOnError: true });
            }
            await saveSiteConfig('Wholesale_Promo_Enabled', input('enabled').checked ? 'true' : 'false', { throwOnError: true });
            showToast('Promoción mayorista guardada');
        } catch (error) {
            showToast('No se pudo guardar la promoción mayorista', 'error');
        } finally {
            if (button) button.disabled = false;
        }
    });
}

function initPromoConfigAdmin() {
    const form = document.getElementById('promo-config-form');
    if (!form) return;

    loadSiteConfigForAdmin().then(fillPromoConfigForm);

    PROMO_CONFIG_FIELDS.forEach(([, id]) => {
        const input = document.getElementById(id);
        if (!input) return;
        input.addEventListener('input', schedulePromoAdminPreview);
        input.addEventListener('change', schedulePromoAdminPreview);
    });

    form.addEventListener('submit', async e => {
        e.preventDefault();
        const btn = document.getElementById('btn-save-promo-config');
        const originalText = btn ? btn.textContent : '';
        if (btn) {
            btn.disabled = true;
            btn.textContent = 'Guardando...';
        }

        try {
            const savedConfig = {};
            await Promise.all(PROMO_CONFIG_FIELDS.map(([key, id]) => {
                const input = document.getElementById(id);
                let value = '';
                if (input) {
                    if (input.type === 'checkbox') {
                        value = input.checked ? 'true' : 'false';
                    } else {
                        value = input.value.trim();
                    }
                }
                savedConfig[key] = value;
                return saveSiteConfig(key, value);
            }));
            window.storeConfig = { ...(window.storeConfig || {}), ...savedConfig };
            renderPromoAdminPreview();
            updateLivePreview();
            showToast('Banner promocional guardado correctamente');
        } catch (error) {
            console.error('Error guardando banner promocional:', error);
            showToast('Error al guardar: ' + error.message, true);
        } finally {
            if (btn) {
                btn.disabled = false;
                btn.textContent = originalText;
            }
        }
    });
}

const HOME_AD_CONFIG_FIELDS = [
    ['Home_Ad_Enabled', 'home-ad-config-enabled'],
    ['Home_Ad_Kicker', 'home-ad-config-kicker'],
    ['Home_Ad_Title', 'home-ad-config-title'],
    ['Home_Ad_Message', ['home-ad-config-message', 'home-ad-config-text']],
    ['Home_Category_Seconds', 'home-category-config-seconds'],
    ['Home_Ad_Image', 'home-ad-config-image'],
    ['Home_Ad_Cta', 'home-ad-config-cta'],
    ['Home_Ad_Link', 'home-ad-config-link']
];

const CUSTOMER_PROMO_CONFIG_FIELDS = [
    ['Promo_Clientes_Enabled', 'customer-promo-enabled'],
    ['Promo_Clientes_Discount', 'customer-promo-discount'],
    ['Promo_Clientes_Title', 'customer-promo-title'],
    ['Promo_Clientes_Expire', 'customer-promo-expire']
];

function getConfigFieldElement(fieldIds) {
    const ids = Array.isArray(fieldIds) ? fieldIds : [fieldIds];
    for (const id of ids) {
        const input = document.getElementById(id);
        if (input) return input;
    }
    return null;
}

function updateHomeAdImagePreview(src) {
    const preview = document.getElementById('home-ad-image-preview');
    if (!preview) return;

    const rawSrc = String(src || '').trim();
    const imageUrl = rawSrc.startsWith('blob:') ? rawSrc : normalizeImageUrl(rawSrc);
    if (!imageUrl) {
        preview.classList.add('is-empty');
        preview.innerHTML = '<span>Sin imagen para mostrar</span>';
        return;
    }

    preview.classList.remove('is-empty');
    preview.innerHTML = `<img src="${escapeHtml(imageUrl)}" alt="Vista previa del banner promocional" onerror="this.parentElement.classList.add('is-empty');this.parentElement.innerHTML='<span>No se pudo cargar la imagen</span>';">`;
}

function fillHomeAdConfigForm(config) {
    if (!config) return;
    window.storeConfig = window.storeConfig || {};
    HOME_AD_CONFIG_FIELDS.forEach(([key, id]) => {
        window.storeConfig[key] = config[key] || '';
        const input = getConfigFieldElement(id);
        if (!input) return;
        if (input.type === 'checkbox') {
            input.checked = config[key] === undefined ? true : config[key] !== 'false';
        } else {
            input.value = config[key] || '';
        }
    });
    updateHomeAdImagePreview(config.Home_Ad_Image || '');
}

function initHomeAdConfigAdmin() {
    const form = document.getElementById('home-ad-config-form');
    if (!form) return;

    loadSiteConfigForAdmin().then(fillHomeAdConfigForm);

    const fileInput = document.getElementById('home-ad-config-file');
    const imageInput = document.getElementById('home-ad-config-image');
    let localPreviewUrl = '';

    imageInput?.addEventListener('input', () => {
        if (localPreviewUrl) {
            URL.revokeObjectURL(localPreviewUrl);
            localPreviewUrl = '';
        }
        updateHomeAdImagePreview(imageInput.value);
    });

    fileInput?.addEventListener('change', async () => {
        const file = fileInput.files?.[0];
        if (!file) return;
        const previousPlaceholder = imageInput?.placeholder || '';
        try {
            if (localPreviewUrl) URL.revokeObjectURL(localPreviewUrl);
            localPreviewUrl = URL.createObjectURL(file);
            updateHomeAdImagePreview(localPreviewUrl);
            if (imageInput) imageInput.placeholder = 'Optimizando imagen...';
            const uploadedUrl = await uploadCarouselImage(file, 'banners');
            if (imageInput) imageInput.value = uploadedUrl;
            updateHomeAdImagePreview(uploadedUrl);
            if (localPreviewUrl) {
                URL.revokeObjectURL(localPreviewUrl);
                localPreviewUrl = '';
            }
            showToast('Imagen del banner subida correctamente');
        } catch (error) {
            console.error('Error subiendo imagen del banner del home:', error);
            showToast('No se pudo subir la imagen del banner', true);
            updateHomeAdImagePreview(imageInput?.value || '');
        } finally {
            if (imageInput) imageInput.placeholder = previousPlaceholder || 'https://...';
            fileInput.value = '';
        }
    });

    form.addEventListener('submit', async e => {
        e.preventDefault();
        const btn = document.getElementById('btn-save-home-ad-config');
        const originalText = btn ? btn.textContent : '';
        if (btn) {
            btn.disabled = true;
            btn.textContent = 'Guardando...';
        }

        try {
            const savedConfig = {};
            const saveJobs = [];
            HOME_AD_CONFIG_FIELDS.forEach(([key, id]) => {
                const input = getConfigFieldElement(id);
                if (!input) return;
                const value = input.type === 'checkbox'
                    ? (input.checked ? 'true' : 'false')
                    : input.value.trim();
                savedConfig[key] = value;
                saveJobs.push(saveSiteConfig(key, value));
            });
            await Promise.all(saveJobs);
            window.storeConfig = { ...(window.storeConfig || {}), ...savedConfig };
            clearPublicProductsCache();
            showToast('Banner del home guardado correctamente');
        } catch (error) {
            console.error('Error guardando banner del home:', error);
            showToast('Error al guardar banner del home: ' + error.message, true);
        } finally {
            if (btn) {
                btn.disabled = false;
                btn.textContent = originalText || 'Guardar Banner del Home';
            }
        }
    });
}

function initCustomerPromoAdmin() {
    // Account activation and recovery are managed from the notification bell.
    const form = document.getElementById('customer-promo-form');
    if (!form) return;

    function fillCustomerPromoForm(config) {
        CUSTOMER_PROMO_CONFIG_FIELDS.forEach(([key, id]) => {
            const input = document.getElementById(id);
            if (!input) return;
            const value = config?.[key] || '';
            if (input.type === 'checkbox') {
                input.checked = String(value).trim() === 'true';
            } else {
                input.value = value;
            }
        });
    }

    loadSiteConfigForAdmin().then(fillCustomerPromoForm);

    form.addEventListener('submit', async event => {
        event.preventDefault();
        const btn = document.getElementById('btn-save-customer-promo');
        const originalText = btn ? btn.textContent : '';
        const enabled = document.getElementById('customer-promo-enabled')?.checked ? 'true' : 'false';
        const discount = document.getElementById('customer-promo-discount')?.value.trim() || '0';
        const title = document.getElementById('customer-promo-title')?.value.trim() || '';
        const expires = document.getElementById('customer-promo-expire')?.value.trim() || '';

        if (enabled === 'true' && Number(discount) <= 0) {
            showToast('Ingresa un descuento mayor a 0 para activar la promoción', 'warning');
            return;
        }

        if (btn) {
            btn.disabled = true;
            btn.textContent = 'Guardando...';
        }

        try {
            const savedConfig = {
                Promo_Clientes_Enabled: enabled,
                Promo_Clientes_Discount: discount,
                Promo_Clientes_Title: title,
                Promo_Clientes_Expire: expires
            };

            await Promise.all(Object.entries(savedConfig).map(([key, value]) => saveSiteConfig(key, value)));
            window.storeConfig = { ...(window.storeConfig || {}), ...savedConfig };
            showToast(enabled === 'true' ? 'Promoción general para registrados guardada' : 'Promoción general desactivada', 'success');
        } catch (error) {
            console.error('Error guardando promocion general de clientes:', error);
            showToast('Error al guardar promoción: ' + error.message, 'error');
        } finally {
            if (btn) {
                btn.disabled = false;
                btn.textContent = originalText || 'Guardar promoción general';
            }
        }
    });
}

function initCustomerPrivateKeys(){
    const promo=document.getElementById('customer-promo-form');if(!promo||document.getElementById('customer-key-admin'))return;
    const box=document.createElement('details');box.id='customer-key-admin';box.className='admin-section-card';box.style.padding='20px';
    box.innerHTML=`<summary>Llaves privadas de clientes</summary><p>El cliente verá sus pedidos, facturas, favoritos y beneficios. La llave vence en 30 días. Renovarla invalida la anterior.</p><form class="admin-form-grid" style="margin-top:16px;display:grid;gap:14px"><label>Celular del cliente<input class="form-control" name="telefono" type="tel" required></label><label style="display:flex;gap:10px;align-items:center"><input name="confirmed" type="checkbox" required>Verifiqué la identidad y que este celular corresponde al cliente.</label><button class="admin-btn" type="submit">Generar / renovar llave</button><button class="admin-btn" type="button" data-revoke>Revocar acceso</button><p role="status"></p><div data-result hidden><label>Llave privada (se muestra una sola vez)<textarea class="form-control" readonly data-key></textarea></label><button class="admin-btn" type="button" data-copy>Copiar llave para entregarla al cliente</button><p>Entrar en blyxu.online → Mi cuenta. Entrega la llave solo al cliente verificado.</p></div></form>`;
    promo.before(box);const form=box.querySelector('form'),status=form.querySelector('[role=status]'),result=form.querySelector('[data-result]'),key=form.querySelector('[data-key]');
    const run=async action=>{result.hidden=true;key.value='';status.textContent='Procesando…';const buttons=form.querySelectorAll('button');buttons.forEach(b=>b.disabled=true);
        try{const response=await fetch(GOOGLE_SHEET_API,{method:'POST',headers:{'Content-Type':'text/plain;charset=utf-8'},body:JSON.stringify({action,telefono:form.elements.telefono.value,confirmed:form.elements.confirmed.checked})}),data=await response.json();if(!data.ok)throw new Error(data.error||'No se pudo completar.');status.textContent=action==='customerkeyissue'?`Llave de ${data.cliente.nombre} preparada. Entrega privada pendiente.`:'Acceso revocado.';if(data.key){key.value=data.key;result.hidden=false;}}
        catch(error){status.textContent=error.message;}finally{buttons.forEach(b=>b.disabled=false);}};
    form.onsubmit=event=>{event.preventDefault();run('customerkeyissue');};
    form.querySelector('[data-revoke]').onclick=()=>{if(form.elements.telefono.reportValidity())run('customerkeyrevoke');};
    form.querySelector('[data-copy]').onclick=async()=>{try{await navigator.clipboard.writeText(key.value);status.textContent='Llave copiada. Entrégala por un canal privado al cliente.';}catch(error){key.select();status.textContent='Selecciona y copia la llave.';}};
}

function createPaymentMethodCard(data = { name: '', type: 'key', value: '', image: '', instructions: '' }, index) {
    const card = document.createElement('details');
    card.className = 'payment-method-card';
    card.style.cssText = 'border: 1px solid rgba(168, 85, 247, 0.25); border-radius: 16px; padding: 20px; background: rgba(255,255,255,0.02); position: relative; display: grid; grid-template-columns: 1fr; gap: 12px; margin-bottom: 16px;';
    card.dataset.index = index;
    
    card.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid rgba(255,255,255,0.05); padding-bottom:8px;">
            <strong style="color:#ffd969; font-size:14px;">Método #${index + 1}</strong>
            <button type="button" class="btn-delete-payment-method" style="background:none; border:none; color:#ef4444; cursor:pointer; font-size:14px; font-weight:700;">Eliminar</button>
        </div>
        <div class="admin-form-grid" style="grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 0;">
            <div class="form-group">
                <label>Nombre del Banco / Método</label>
                <input type="text" class="form-control pm-name" value="${escapeHtml(data.name || '')}" placeholder="Ej: Nequi, Daviplata, Bancolombia" required>
            </div>
            <div class="form-group">
                <label>Tipo de Método</label>
                <select class="form-control pm-type" required>
                    <option value="key" ${data.type === 'key' ? 'selected' : ''}>Llave / Cuenta / Número (Texto)</option>
                    <option value="qr" ${data.type === 'qr' ? 'selected' : ''}>Código QR (Imagen)</option>
                    <option value="both" ${data.type === 'both' ? 'selected' : ''}>Ambos (Texto + QR)</option>
                </select>
            </div>
        </div>
        <div class="admin-form-grid" style="grid-template-columns: 1fr; gap: 12px; margin-bottom: 0;">
            <div class="form-group pm-value-group" style="${data.type === 'qr' ? 'display:none;' : ''}">
                <label>Número de Cuenta, Celular o Llave</label>
                <input type="text" class="form-control pm-value" value="${escapeHtml(data.value || '')}" placeholder="Ej: 3123456789 o Cta Ahorros 123-...">
            </div>
            <div class="form-group pm-image-group" style="${data.type === 'key' ? 'display:none;' : ''}">
                <label>Código QR (Arrastra la imagen o pon la URL)</label>
                <div style="height:120px; background:rgba(0,0,0,0.2); border:2px dashed rgba(155,44,250,0.2); border-radius:12px; display:flex; align-items:center; justify-content:center; margin-bottom:8px; overflow:hidden; position:relative;" class="pm-image-preview drop-zone">
                    ${data.image ? `<img src="${data.image}" style="width:100%; height:100%; object-fit:contain; border-radius:8px;">` : `<span style="font-size:11px; color:rgba(255,255,255,0.2); z-index:1;">Arrastra el QR aquí</span>`}
                </div>
                <input type="url" class="form-control pm-image-url" value="${escapeHtml(data.image || '')}" placeholder="URL del QR (Auto generada al subir)">
                <input type="file" class="form-control pm-image-file" accept="image/*" style="margin-top:8px;">
            </div>
            <div class="form-group">
                <label>Instrucciones de Pago (Opcional)</label>
                <input type="text" class="form-control pm-instructions" value="${escapeHtml(data.instructions || '')}" placeholder="Ej: Enviar captura por WhatsApp">
            </div>
        </div>
    `;
    
    const methodSummary = document.createElement('summary');
    const methodName = document.createElement('strong');
    const updateMethodName = () => {
        methodName.textContent = `Método #${Number(card.dataset.index) + 1} · ${card.querySelector('.pm-name').value.trim() || 'Nuevo método'}`;
    };
    methodSummary.appendChild(methodName);
    const methodBody = document.createElement('div');
    methodBody.className = 'payment-method-body';
    while (card.firstChild) methodBody.appendChild(card.firstChild);
    card.append(methodSummary, methodBody);
    card.open = !data.name;
    updateMethodName();
    card.querySelector('.pm-name').addEventListener('input', updateMethodName);
    const typeSelect = card.querySelector('.pm-type');
    const valueGroup = card.querySelector('.pm-value-group');
    const imageGroup = card.querySelector('.pm-image-group');
    
    typeSelect.addEventListener('change', () => {
        const val = typeSelect.value;
        if (val === 'key') {
            valueGroup.style.display = 'block';
            imageGroup.style.display = 'none';
        } else if (val === 'qr') {
            valueGroup.style.display = 'none';
            imageGroup.style.display = 'block';
        } else {
            valueGroup.style.display = 'block';
            imageGroup.style.display = 'block';
        }
    });
    
    const previewZone = card.querySelector('.pm-image-preview');
    const urlInput = card.querySelector('.pm-image-url');
    const fileInput = card.querySelector('.pm-image-file');
    const setQrUploadState = (isUploading) => {
        card.dataset.qrUploading = isUploading ? '1' : '0';
        if (fileInput) fileInput.disabled = isUploading;
        previewZone.style.opacity = isUploading ? '0.75' : '1';
    };
    const renderQrPreview = (url, isLocal = false) => {
        previewZone.innerHTML = `<img src="${escapeHtml(url)}" style="width:100%; height:100%; object-fit:contain; border-radius:8px;${isLocal ? ' opacity:0.7;' : ''}">`;
    };
    const uploadQrFile = async (file) => {
        if (!file || !file.type.startsWith('image/')) {
            showToast('Selecciona una imagen valida para el QR', true);
            return;
        }

        let localUrl = '';
        try {
            setQrUploadState(true);
            localUrl = URL.createObjectURL(file);
            renderQrPreview(localUrl, true);
            const uploadedUrl = await uploadCarouselImage(file, 'logos');
            urlInput.value = uploadedUrl;
            renderQrPreview(uploadedUrl);
            showToast('QR subido correctamente');
        } catch (error) {
            console.error('Error subiendo QR:', error);
            showToast('Error al subir QR: ' + error.message, true);
        } finally {
            if (localUrl) URL.revokeObjectURL(localUrl);
            setQrUploadState(false);
        }
    };

    setupDragAndDrop(previewZone, (url) => {
        urlInput.value = url;
        renderQrPreview(url);
    }, (localUrl) => {
        setQrUploadState(true);
        renderQrPreview(localUrl, true);
    }, () => {
        setQrUploadState(false);
    });

    fileInput?.addEventListener('change', () => {
        const file = fileInput.files?.[0];
        uploadQrFile(file).finally(() => {
            fileInput.value = '';
        });
    });
    
    urlInput.addEventListener('input', () => {
        const url = urlInput.value.trim();
        if (url) {
            previewZone.innerHTML = `<img src="${escapeHtml(url)}" style="width:100%; height:100%; object-fit:contain; border-radius:8px;" onerror="this.parentElement.innerHTML='<span style=\x22font-size:11px;color:#ef4444;\x22>No se pudo cargar la imagen</span>'">`;
        } else {
            previewZone.innerHTML = `<span style="font-size:11px; color:rgba(255,255,255,0.2); z-index:1;">Arrastra el QR aquí</span>`;
        }
    });

    card.querySelector('.btn-delete-payment-method').addEventListener('click', () => {
        card.remove();
        reindexPaymentMethods();
    });

    return card;
}

function reindexPaymentMethods() {
    const container = document.getElementById('payment-methods-container');
    if (!container) return;
    const cards = container.querySelectorAll('.payment-method-card');
    cards.forEach((card, index) => {
        card.dataset.index = index;
        const indexLabel = card.querySelector('strong');
        if (indexLabel) indexLabel.textContent = `Método #${index + 1} · ${card.querySelector('.pm-name')?.value.trim() || 'Nuevo método'}`;
    });
}

function initQRConfigAdmin() {
    const form = document.getElementById('qr-config-form');
    if (!form) return;

    // Llenar campos con la config actual
    loadSiteConfigForAdmin().then(config => {
        if (!config) return;
        
        // Contraseña
        const passInput = document.getElementById('qr-config-password');
        if (passInput) passInput.value = config['QR_Password'] || '';
        
        // Métodos de pago (Cargar de QR_Payments_JSON o fallback a QR_Image)
        let methods = [];
        if (config['QR_Payments_JSON']) {
            try {
                methods = JSON.parse(config['QR_Payments_JSON']);
            } catch(e) {
                console.error("Error parsing QR_Payments_JSON:", e);
            }
        } else if (config['QR_Image']) {
            methods = [{
                name: 'Código QR de Pago',
                type: 'qr',
                value: '',
                image: config['QR_Image'],
                instructions: 'Escanea el código QR desde tu aplicación bancaria'
            }];
        }
        
        const container = document.getElementById('payment-methods-container');
        if (container) {
            container.innerHTML = '';
            methods.forEach((method, idx) => {
                container.appendChild(createPaymentMethodCard(method, idx));
            });
        }
    });

    // Evento para añadir método de pago
    const addBtn = document.getElementById('btn-add-payment-method');
    if (addBtn) {
        addBtn.onclick = () => {
            const container = document.getElementById('payment-methods-container');
            if (container) {
                const index = container.querySelectorAll('.payment-method-card').length;
                container.appendChild(createPaymentMethodCard({ name: '', type: 'key', value: '', image: '', instructions: '' }, index));
            }
        };
    }

    form.addEventListener('submit', async e => {
        e.preventDefault();
        const btn = document.getElementById('btn-save-qr-config');
        const originalText = btn ? btn.textContent : '';
        if (btn) {
            btn.disabled = true;
            btn.textContent = 'Guardando...';
        }

        const container = document.getElementById('payment-methods-container');
        const methods = [];
        if (container) {
            const cards = container.querySelectorAll('.payment-method-card');
            const uploadingCards = Array.from(cards).filter(card => card.dataset.qrUploading === '1');
            if (uploadingCards.length) {
                showToast('Espera a que termine de subir el QR antes de guardar', true);
                if (btn) {
                    btn.disabled = false;
                    btn.textContent = originalText;
                }
                return;
            }

            cards.forEach(card => {
                const name = card.querySelector('.pm-name').value.trim();
                const type = card.querySelector('.pm-type').value;
                const value = card.querySelector('.pm-value').value.trim();
                const image = card.querySelector('.pm-image-url').value.trim();
                const instructions = card.querySelector('.pm-instructions').value.trim();
                if (name) {
                    methods.push({ name, type, value, image, instructions });
                }
            });
        }

        const missingQrImage = methods.find(method => (method.type === 'qr' || method.type === 'both') && !method.image);
        if (missingQrImage) {
            showToast(`Falta subir o pegar la URL del QR para ${missingQrImage.name}`, true);
            if (btn) {
                btn.disabled = false;
                btn.textContent = originalText;
            }
            return;
        }

        const firstQrImage = methods.find(method => method.image)?.image || '';

        try {
            await Promise.all([
                saveSiteConfig('QR_Password', document.getElementById('qr-config-password')?.value.trim() || ''),
                saveSiteConfig('QR_Payments_JSON', JSON.stringify(methods)),
                saveSiteConfig('QR_Image', firstQrImage) // Retrocompatibilidad
            ]);
            showToast('Configuración de pagos guardada correctamente');
        } catch (error) {
            console.error('Error guardando QR:', error);
            showToast('Error al guardar: ' + error.message, true);
        } finally {
            if (btn) {
                btn.disabled = false;
                btn.textContent = originalText;
            }
        }
    });
}

function fileToBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result || '').split(',')[1] || '');
        reader.onerror = () => reject(reader.error || new Error('No se pudo leer la imagen'));
        reader.readAsDataURL(file);
    });
}

function loadImageFile(file) {
    return new Promise((resolve, reject) => {
        const url = URL.createObjectURL(file);
        const img = new Image();
        img.onload = () => {
            URL.revokeObjectURL(url);
            resolve(img);
        };
        img.onerror = () => {
            URL.revokeObjectURL(url);
            reject(new Error('No se pudo preparar la imagen'));
        };
        img.src = url;
    });
}

function canvasToBlob(canvas, type, quality) {
    return new Promise((resolve, reject) => {
        canvas.toBlob(blob => {
            if (blob) resolve(blob);
            else reject(new Error('No se pudo comprimir la imagen'));
        }, type, quality);
    });
}

async function prepareImageForUpload(file, assetType = 'imagenes') {
    if (file.type === 'image/gif') {
        return file;
    }

    const img = await loadImageFile(file);
    const scale = Math.min(1, (assetType === 'banners' ? 1600 : assetType === 'logos' ? 800 : IMAGE_UPLOAD_MAX_EDGE) / Math.max(img.naturalWidth || img.width, img.naturalHeight || img.height));
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round((img.naturalWidth || img.width) * scale));
    canvas.height = Math.max(1, Math.round((img.naturalHeight || img.height) * scale));

    const ctx = canvas.getContext('2d');
    if (!ctx) {
        throw new Error('No se pudo preparar la imagen');
    }
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

    let blob = await canvasToBlob(canvas, IMAGE_UPLOAD_FORMAT, IMAGE_UPLOAD_QUALITY);
    if (blob.size > MAX_CAROUSEL_IMAGE_SIZE) {
        blob = await canvasToBlob(canvas, IMAGE_UPLOAD_FORMAT, 0.68);
    }
    if (blob.size > MAX_CAROUSEL_IMAGE_SIZE) {
        blob = await canvasToBlob(canvas, IMAGE_UPLOAD_FORMAT, 0.55);
    }
    if (blob.size > MAX_CAROUSEL_IMAGE_SIZE) {
        throw new Error('La imagen sigue pesando mas de 5 MB despues de comprimirla');
    }

    const cleanName = String(file.name || 'imagen').replace(/\.[^.]+$/, '') || 'imagen';
    return new File([blob], `${cleanName}.${IMAGE_UPLOAD_EXTENSION}`, { type: IMAGE_UPLOAD_FORMAT });
}

async function uploadCarouselImage(file, assetType = 'imagenes') {
    if (!file) return '';
    if (!file.type.startsWith('image/')) {
        throw new Error('Selecciona un archivo de imagen valido');
    }

    const uploadFile = await prepareImageForUpload(file, assetType);
    if (uploadFile.size > MAX_CAROUSEL_IMAGE_SIZE) {
        throw new Error('La imagen pesa mas de 5 MB');
    }

    const base64Data = await fileToBase64(uploadFile);
    const res = await fetch(GOOGLE_SHEET_API, {
        method: 'POST',
        body: JSON.stringify({
            action: 'upload_image',
            fileName: uploadFile.name,
            mimeType: uploadFile.type,
            assetType,
            base64Data
        })
    });
    const result = await res.json();

    if (!(result && (result.ok || result.status === 'success'))) {
        throw new Error(result?.error || result?.message || 'No se pudo subir la imagen');
    }

    const uploadedUrl = normalizeImageUrl(result.url || result.data?.url || '');
    if (!uploadedUrl) {
        throw new Error('Google Drive no devolvio la URL de la imagen');
    }

    return uploadedUrl;
}

/**
 * Configura el comportamiento de Arrastrar y Soltar en un elemento
 */
function setupDragAndDrop(containerId, onFileProcessed, onLocalPreview, onUploadEnd) {
    const container = typeof containerId === 'string' ? document.getElementById(containerId) : containerId;
    if (!container) return;

    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        container.addEventListener(eventName, e => {
            e.preventDefault();
            e.stopPropagation();
        }, false);
    });

    ['dragenter', 'dragover'].forEach(eventName => {
        container.addEventListener(eventName, () => container.classList.add('drag-over'), false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        container.addEventListener(eventName, () => container.classList.remove('drag-over'), false);
    });

    container.addEventListener('drop', async (e) => {
        const dt = e.dataTransfer;
        const file = dt.files[0];

        if (file && file.type.startsWith('image/')) {
            try {
                // Notificar preview local inmediata si existe el callback
                if (typeof onLocalPreview === 'function') {
                    const localUrl = URL.createObjectURL(file);
                    onLocalPreview(localUrl, file);
                }

                const imageUrl = await uploadCarouselImage(file);
                onFileProcessed(imageUrl, file);
                showToast('Imagen subida con éxito', 'success');
            } catch (err) {
                console.error(err);
                showToast('Error al subir imagen: ' + err.message, 'error');
            } finally {
                if (typeof onUploadEnd === 'function') {
                    onUploadEnd(file);
                }
            }
        } else {
            showToast('Por favor, arrastra solo archivos de imagen', 'warning');
        }
    }, false);
}

let productImageUploadRevision=0;
function resetProductImageUploadState(){
    productImageUploadRevision++;
    const field=document.getElementById('prod-imagen');if(field){field.setCustomValidity('');delete field.dataset.uploadState;}
    const preview=document.getElementById('preview-img-el');if(preview)delete preview.dataset.localPreviewSrc;
    const status=document.getElementById('product-image-upload-status');if(status)status.textContent='';
    const save=document.getElementById('btn-save');if(save?.dataset.readyText){save.disabled=false;save.textContent=save.dataset.readyText;delete save.dataset.readyText;}
}
function assertProductImageUploadReady(){
    const field=document.getElementById('prod-imagen');
    if(['uploading','failed'].includes(field?.dataset.uploadState))throw Error('La imagen principal no está lista. Vuelve a subirla o pega un enlace antes de guardar.');
}
function initProductImageUpload() {
    const dropZone = document.getElementById('prod-image-drop-zone');
    const fileInput = document.getElementById('prod-image-file');
    const imageInput = document.getElementById('prod-imagen');
    const removeBtn = document.getElementById('prod-image-remove-btn');
    const changeBtn = document.getElementById('prod-image-change-btn');

    if (!dropZone || !fileInput) return;

    const status=document.createElement('p');status.id='product-image-upload-status';status.className='field-hint';status.setAttribute('role','status');imageInput?.closest('.image-url-row')?.after(status);
    imageInput?.addEventListener('input',event=>{if(event.isTrusted){resetProductImageUploadState();updateProductImagePreviewBox(imageInput.value);updateLivePreview();}});
    const handleFileSelection = async (file) => {
        if (!file || !file.type.startsWith('image/')) {
            showToast('Por favor, selecciona un archivo de imagen', 'warning');
            return;
        }

        const ticket=++productImageUploadRevision;
        imageInput.dataset.uploadState='uploading';imageInput.setCustomValidity('Espera a que termine la subida de la imagen principal.');status.textContent='Subiendo la imagen principal a Drive…';
        const localUrl = URL.createObjectURL(file);
        updateProductImagePreviewBox(localUrl);

        const imgEl = document.getElementById('preview-img-el');
        if (imgEl) {
            imgEl.src = localUrl;
            imgEl.dataset.localPreviewSrc = localUrl;
            imgEl.style.opacity = '0.7';
        }

        const saveBtn = document.getElementById('btn-save');
        if (saveBtn) {
            if(!saveBtn.dataset.readyText)saveBtn.dataset.readyText = saveBtn.textContent || 'Guardar producto';
            saveBtn.disabled = true;
            saveBtn.textContent = 'Optimizando imagen...';
        }

        showToast('Convirtiendo imagen a WebP y subiendo...');
        try {
            const uploadedUrl = await uploadCarouselImage(file);
            if(ticket!==productImageUploadRevision)return;
            imageInput.dataset.uploadState='ready';imageInput.setCustomValidity('');
            if(imgEl)delete imgEl.dataset.localPreviewSrc;
            if (imageInput) {
                imageInput.value = uploadedUrl;
                imageInput.dispatchEvent(new Event('input'));
            }
            updateProductImagePreviewBox(uploadedUrl);updateLivePreview();status.textContent='Imagen principal subida a Drive.';
            showToast('Imagen subida con éxito', 'success');
        } catch (err) {
            if(ticket!==productImageUploadRevision)return;
            imageInput.dataset.uploadState='failed';imageInput.setCustomValidity('La imagen no se pudo subir. Vuelve a subirla o pega un enlace antes de guardar.');
            if(imgEl)delete imgEl.dataset.localPreviewSrc;
            updateProductImagePreviewBox(imageInput.value);updateLivePreview();status.textContent='No se guardó la nueva imagen. Vuelve a subirla o pega un enlace antes de guardar.';
            console.error(err);
            showToast('Error al subir imagen: ' + (err.message || err), 'error');
        } finally {
            URL.revokeObjectURL(localUrl);
            if (saveBtn && ticket===productImageUploadRevision) {
                saveBtn.disabled = false;
                saveBtn.textContent = saveBtn.dataset.readyText || 'Guardar producto';
                delete saveBtn.dataset.readyText;
            }
            if(ticket===productImageUploadRevision)fileInput.value = '';
        }
    };

    dropZone.addEventListener('click', (e) => {
        if (e.target.closest('#prod-image-remove-btn') || e.target.closest('input')) return;
        fileInput.click();
    });

    if (changeBtn) {
        changeBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            fileInput.click();
        });
    }

    fileInput.addEventListener('change', () => {
        const file = fileInput.files?.[0];
        if (file) handleFileSelection(file);
    });

    if (removeBtn) {
        removeBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            resetProductImageUploadState();
            if (imageInput) {
                imageInput.value = '';
                imageInput.dispatchEvent(new Event('input'));
            }
            updateProductImagePreviewBox('');
        });
    }

    if (imageInput) {
        imageInput.addEventListener('input', (e) => {
            updateProductImagePreviewBox(e.target.value);
            renderProductPreviewGallery(e.target.value);
        });
    }

    setupDragAndDrop('prod-image-drop-zone', (url) => {
        if (imageInput) {
            imageInput.value = url;
            imageInput.dispatchEvent(new Event('input'));
        }
        updateProductImagePreviewBox(url);
    }, (localUrl) => {
        updateProductImagePreviewBox(localUrl);
        const imgEl = document.getElementById('preview-img-el');
        if (imgEl) {
            imgEl.src = localUrl;
            imgEl.dataset.localPreviewSrc = localUrl;
            imgEl.style.opacity = '0.7';
        }
        const saveBtn = document.getElementById('btn-save');
        if (saveBtn) {
            saveBtn.dataset.readyText = saveBtn.textContent || 'Guardar producto';
            saveBtn.disabled = true;
            saveBtn.textContent = 'Optimizando imagen...';
        }
        showToast('Convirtiendo imagen a WebP y subiendo...');
    }, () => {
        const saveBtn = document.getElementById('btn-save');
        if (saveBtn) {
            saveBtn.disabled = false;
            saveBtn.textContent = saveBtn.dataset.readyText || 'Guardar producto';
            delete saveBtn.dataset.readyText;
        }
    });
}

function initProductGalleryUpload() {
    const dropZone = document.getElementById('prod-gallery-drop-zone');
    const fileInput = document.getElementById('prod-gallery-files');
    const list = document.getElementById('prod-gallery-list');
    const urlInput = document.getElementById('prod-gallery-url-input');
    const addUrlBtn = document.getElementById('btn-add-gallery-url');
    const galleryInput = document.getElementById('prod-galeria');

    if (!dropZone || !fileInput) return;

    async function uploadGalleryFiles(files) {
        const selected = Array.from(files || []).filter(file => file.type && file.type.startsWith('image/'));
        if (!selected.length) {
            showToast('Selecciona imagenes validas para la galeria', 'warning');
            return;
        }

        const saveBtn = document.getElementById('btn-save');
        const previousText = saveBtn?.textContent || 'Guardar producto';
        if (saveBtn) {
            saveBtn.disabled = true;
            saveBtn.textContent = `Subiendo ${selected.length} foto(s)...`;
        }

        try {
            const uploadedUrls = [];
            for (const file of selected) {
                uploadedUrls.push(await uploadCarouselImage(file));
            }
            appendAdminGalleryUrls(uploadedUrls);
            showToast(`${uploadedUrls.length} foto(s) agregadas a la galeria`, 'success');
        } catch (error) {
            console.error('Error subiendo galeria de producto:', error);
            showToast('No se pudieron subir todas las fotos: ' + (error.message || error), 'error');
        } finally {
            if (saveBtn) {
                saveBtn.disabled = false;
                saveBtn.textContent = previousText;
            }
            fileInput.value = '';
        }
    }

    dropZone.addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', () => uploadGalleryFiles(fileInput.files));

    ['dragenter', 'dragover'].forEach(eventName => {
        dropZone.addEventListener(eventName, event => {
            event.preventDefault();
            event.stopPropagation();
            dropZone.classList.add('drag-over');
        });
    });

    ['dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, event => {
            event.preventDefault();
            event.stopPropagation();
            dropZone.classList.remove('drag-over');
        });
    });

    dropZone.addEventListener('drop', event => {
        uploadGalleryFiles(event.dataTransfer?.files);
    });

    list?.addEventListener('click', event => {
        const removeBtn = event.target.closest('[data-gallery-remove]');
        if (!removeBtn) return;
        const removeIndex = Number(removeBtn.dataset.galleryRemove);
        const next = getAdminGalleryUrls().filter((_, index) => index !== removeIndex);
        setAdminGalleryUrls(next);
    });

    addUrlBtn?.addEventListener('click', () => {
        const url = normalizeImageUrl(urlInput?.value || '');
        if (!url) {
            showToast('Pega una URL valida para agregarla', 'warning');
            return;
        }
        appendAdminGalleryUrls([url]);
        if (urlInput) urlInput.value = '';
        showToast('URL agregada a la galeria', 'success');
    });

    urlInput?.addEventListener('keydown', event => {
        if (event.key === 'Enter') {
            event.preventDefault();
            addUrlBtn?.click();
        }
    });

    galleryInput?.addEventListener('input', renderProductGalleryManager);

    document.querySelector('#view-products .preview-container')?.addEventListener('click', event => {
        const trigger = event.target.closest('.preview-angle-thumb, .preview-variant-card');
        if (!trigger) return;
        const src = trigger.dataset.previewUrl || '';
        const imgEl = document.getElementById('preview-img-el');
        if (imgEl && src) {
            imgEl.src = src;
            imgEl.style.opacity = '1';
        }
        if (trigger.classList.contains('preview-angle-thumb')) {
            document.querySelectorAll('.preview-angle-thumb').forEach(item => item.classList.remove('active'));
            trigger.classList.add('active');
        }
        if (trigger.classList.contains('preview-variant-card')) {
            document.querySelectorAll('.preview-variant-card').forEach(item => item.classList.remove('active'));
            trigger.classList.add('active');
            document.querySelectorAll('.preview-angle-thumb').forEach(item => item.classList.toggle('active', item.dataset.previewUrl === src));
            const rows = getPreviewVariantRows(src);
            const selectedIndex = Number(trigger.dataset.previewIndex || 0);
            const selectedRow = rows[selectedIndex] || rows.find(row => normalizeImageUrl(row.image) === normalizeImageUrl(src));
            const variantsContainer = document.getElementById('variants-container');
            if (variantsContainer) {
                if (selectedRow?.key && selectedRow.key !== 'main-product') {
                    variantsContainer.dataset.activePreviewVariantKey = selectedRow.key;
                } else {
                    delete variantsContainer.dataset.activePreviewVariantKey;
                }
            }
            applyPreviewVariantRow(selectedRow);
        }
    });

    renderProductGalleryManager();
}

function initCarouselImageAdmin() {
    const form = document.getElementById('carousel-image-form');
    const fileInput = document.getElementById('carousel-file');
    const imageUrlInput = document.getElementById('carousel-image-url');
    const preview = document.getElementById('carousel-preview');
    const titleInput = document.getElementById('carousel-title');
    const descriptionInput = document.getElementById('carousel-description');
    const modeInput = document.getElementById('carousel-mode');
    const btn = document.getElementById('btn-save-carousel');
    if (!form || !fileInput || !imageUrlInput || !preview || !btn) return;
    if (form.dataset.carouselAdminReady === 'true') return;
    form.dataset.carouselAdminReady = 'true';

    const fixedHomeBannerId = 'BANNER-HOME-01';
    let pendingCarouselFiles = [];
    if (modeInput) {
        if (modeInput.tagName === 'SELECT' && !modeInput.options.length) {
            modeInput.innerHTML = `
                <option value="add">A&ntilde;adir al carrusel</option>
                <option value="replace">Reemplazar portada principal</option>
            `;
        }
        modeInput.value = 'add';
    }
    form.classList.add('carousel-admin-form');
    preview.classList.add('carousel-upload-zone');
    fileInput.style.display = 'none';
    fileInput.closest('.form-group')?.classList.add('carousel-native-file-group');

    if (!form.querySelector('.carousel-admin-intro')) {
        const intro = document.createElement('div');
        intro.className = 'carousel-admin-intro';
        intro.innerHTML = `
            <div>
                <span>Carrusel principal</span>
                <strong>Agrega imagenes para que el banner rote en el inicio</strong>
                <p>Selecciona varias imagenes a la vez o arrastralas aqui. Cada imagen se guarda como un slide independiente.</p>
            </div>
            <button type="button" class="admin-btn carousel-pick-btn" id="carousel-pick-files-btn">A&ntilde;adir imagenes</button>
        `;
        form.insertBefore(intro, preview);
    }

    if (!form.querySelector('.carousel-selected-note')) {
        const note = document.createElement('div');
        note.className = 'carousel-selected-note';
        note.id = 'carousel-selected-note';
        note.textContent = 'Sin imagenes seleccionadas';
        preview.insertAdjacentElement('afterend', note);
    }

    const pickFilesBtn = document.getElementById('carousel-pick-files-btn');
    const selectedNote = document.getElementById('carousel-selected-note');
    let bannerManager = document.getElementById('carousel-banner-manager');
    if (!bannerManager) {
        bannerManager = document.createElement('div');
        bannerManager.id = 'carousel-banner-manager';
        bannerManager.className = 'carousel-banner-manager';
        bannerManager.innerHTML = `
            <div class="carousel-admin-intro">
                <div>
                    <span>Banners subidos</span>
                    <strong>Imagenes activas en el carrusel</strong>
                    <p>Revisa lo que ya esta publicado y limpia el carrusel si quieres empezar de nuevo.</p>
                </div>
                <button type="button" class="admin-btn" id="btn-clear-carousel">Limpiar banners</button>
            </div>
            <div class="carousel-uploaded-list" id="carousel-uploaded-list"></div>
        `;
        preview.insertAdjacentElement('afterend', bannerManager);
    }
    const clearCarouselBtn = document.getElementById('btn-clear-carousel');
    const uploadedBannersList = document.getElementById('carousel-uploaded-list');
    let editingCarouselBannerId = '';

    function getCarouselBannerRecordId(banner) {
        return getInventoryVariationId(banner) || banner?.idVariacion || banner?.ID || banner?.['ID Variacion'] || '';
    }

    function getCarouselBannerImage(banner) {
        return normalizeImageUrl(banner?.Imagen || banner?.['Imagen Principal'] || banner?.imagen || banner?.Foto || '');
    }

    function getCarouselBannerTitle(banner, fallback = 'Original Store') {
        return banner?.Nombre || banner?.['Nombre del Producto'] || fallback;
    }

    function getCarouselBannerDescription(banner) {
        return banner?.Descripcion || banner?.['Caracteristicas del producto'] || banner?.Color || '';
    }

    function getCarouselBannerById(id) {
        const cleanId = String(id || '').trim();
        return (Array.isArray(inventario) ? inventario : []).find(item => getCarouselBannerRecordId(item) === cleanId);
    }

    async function deactivateCarouselBanner(banner) {
        const id = getCarouselBannerRecordId(banner);
        if (!id) throw new Error('No se encontro el ID del banner');
        const motherId = getInventoryMotherId(banner) || banner?.['ID Producto'] || id;
        await postProductToGoogleSheets({
            ...banner,
            __adminOriginalId: id,
            'ID Variacion': id,
            'ID Variaci\u00f3n': id,
            idVariacion: id,
            'ID Producto': motherId,
            ID_Producto: motherId,
            idProducto: motherId,
            Categoria: 'BANNER',
            categoria: 'BANNER',
            Estado: 'Inactivo'
        }, true);
    }

    function getBannerRecordId(banner) {
        return banner?.idVariacion || banner?.ID || banner?.['ID Variacion'] || banner?.['ID Variación'] || banner?.['ID Variación'] || '';
    }

    function getActiveCarouselBanners() {
        return (Array.isArray(inventario) ? inventario : [])
            .filter(item => String(item.Categoria || item.categoria || '').toUpperCase() === 'BANNER')
            .filter(item => String(item.Estado || item.estado || 'Activo').toLowerCase() !== 'inactivo')
            .filter(item => getCarouselBannerImage(item));
    }

    function renderUploadedBanners() {
        if (!uploadedBannersList) return;
        const banners = getActiveCarouselBanners();
        clearCarouselBtn?.toggleAttribute('disabled', !banners.length);
        if (!banners.length) {
            uploadedBannersList.innerHTML = '<div class="carousel-uploaded-empty">No hay banners activos todavia.</div>';
            return;
        }

        uploadedBannersList.innerHTML = banners.map((banner, index) => {
            const image = getCarouselBannerImage(banner);
            const name = getCarouselBannerTitle(banner, `Banner ${index + 1}`);
            const id = getCarouselBannerRecordId(banner) || 'Sin ID';
            return `
                <article class="carousel-uploaded-item" data-banner-id="${escapeHtml(id)}">
                    <img src="${escapeHtml(image)}" alt="${escapeHtml(name)}" onerror="this.style.opacity='.35'">
                    <div>
                        <strong>${escapeHtml(name)}</strong>
                        <span>${escapeHtml(id)}</span>
                    </div>
                    <div class="carousel-uploaded-actions">
                        <button type="button" class="admin-btn secondary" data-carousel-banner-action="edit" data-banner-id="${escapeHtml(id)}">Cambiar</button>
                        <button type="button" class="admin-btn secondary" data-carousel-banner-action="delete" data-banner-id="${escapeHtml(id)}">Eliminar</button>
                    </div>
                </article>
            `;
        }).join('');
    }
    window.renderUploadedBanners = renderUploadedBanners;

    uploadedBannersList?.addEventListener('click', async event => {
        const actionBtn = event.target.closest('[data-carousel-banner-action]');
        if (!actionBtn) return;
        const id = actionBtn.dataset.bannerId || '';
        const banner = getCarouselBannerById(id);
        if (!banner) {
            showToast('No se encontro ese banner en inventario', 'warning');
            return;
        }

        if (actionBtn.dataset.carouselBannerAction === 'edit') {
            editingCarouselBannerId = id;
            form.dataset.editingBannerId = id;
            imageUrlInput.value = getCarouselBannerImage(banner);
            if (titleInput) titleInput.value = getCarouselBannerTitle(banner, '');
            if (descriptionInput) descriptionInput.value = getCarouselBannerDescription(banner);
            if (modeInput) modeInput.value = 'add';
            pendingCarouselFiles = [];
            renderCarouselPreview(imageUrlInput.value);
            btn.textContent = 'Guardar cambios del banner';
            form.scrollIntoView({ behavior: 'smooth', block: 'center' });
            showToast('Banner cargado para cambiar', 'success');
            return;
        }

        if (!confirm('Quieres eliminar este banner del carrusel?')) return;
        const originalText = actionBtn.textContent;
        actionBtn.disabled = true;
        actionBtn.textContent = 'Eliminando...';
        try {
            await deactivateCarouselBanner(banner);
            inventario = (Array.isArray(inventario) ? inventario : []).map(item => (
                getCarouselBannerRecordId(item) === id ? { ...item, Estado: 'Inactivo' } : item
            ));
            renderUploadedBanners();
            clearPublicProductsCache();
            showToast('Banner eliminado del carrusel', 'success');
        } catch (error) {
            console.error(error);
            showToast(error.message || 'No se pudo eliminar el banner', 'error');
            actionBtn.disabled = false;
            actionBtn.textContent = originalText;
        }
    });

    clearCarouselBtn?.addEventListener('click', async () => {
        const banners = getActiveCarouselBanners();
        if (!banners.length) {
            showToast('No hay banners activos para limpiar', 'warning');
            return;
        }
        if (!confirm(`Quieres desactivar ${banners.length} banner${banners.length === 1 ? '' : 's'} del carrusel?`)) return;

        const originalText = clearCarouselBtn.textContent;
        clearCarouselBtn.disabled = true;
        clearCarouselBtn.textContent = 'Limpiando...';
        try {
            for (const banner of banners) {
                await deactivateCarouselBanner(banner);
                continue;
                const id = getBannerRecordId(banner);
                await postProductToGoogleSheets({
                    ...banner,
                    'ID Variacion': id,
                    'ID Variación': id,
                    'ID Producto': banner.idProducto || banner['ID Producto'] || id,
                    ID_Producto: banner.idProducto || banner['ID Producto'] || id,
                    Estado: 'Inactivo'
                }, true);
            }
            inventario = (Array.isArray(inventario) ? inventario : []).map(item => (
                String(item.Categoria || item.categoria || '').toUpperCase() === 'BANNER'
                    ? { ...item, Estado: 'Inactivo' }
                    : item
            ));
            renderUploadedBanners();
            clearPublicProductsCache();
            showToast('Carrusel limpiado correctamente', 'success');
            setTimeout(() => cargarInventario({ silent: true }).then(renderUploadedBanners), 1200);
        } catch (error) {
            console.error(error);
            showToast(error.message || 'No se pudieron limpiar los banners', 'error');
        } finally {
            clearCarouselBtn.disabled = false;
            clearCarouselBtn.textContent = originalText;
        }
    });

    const openFilePicker = (event) => {
        event?.preventDefault();
        event?.stopPropagation();
        fileInput.click();
    };
    pickFilesBtn?.addEventListener('click', openFilePicker);
    preview.addEventListener('click', openFilePicker);

    ['dragenter', 'dragover'].forEach(eventName => {
        preview.addEventListener(eventName, (event) => {
            event.preventDefault();
            event.stopPropagation();
            preview.classList.add('drag-over');
        });
    });

    ['dragleave', 'drop'].forEach(eventName => {
        preview.addEventListener(eventName, (event) => {
            event.preventDefault();
            event.stopPropagation();
            preview.classList.remove('drag-over');
        });
    });

    function updateCarouselSelectedNote(count) {
        if (!selectedNote) return;
        selectedNote.textContent = count
            ? `${count} imagen${count === 1 ? '' : 'es'} lista${count === 1 ? '' : 's'} para guardar`
            : 'Sin imagenes seleccionadas';
    }

    function makeCarouselBannerId() {
        return 'BANNER-' + Date.now().toString(36).toUpperCase() + '-' + Math.floor(1000 + Math.random() * 9000);
    }

    function renderCarouselPreview(src) {
        preview.innerHTML = `<img src="${src}" alt="Preview carrusel">`;
        updateCarouselSelectedNote(src ? 1 : 0);
    }

    function renderCarouselPreviewList(files) {
        const imageFiles = Array.from(files || []).filter(file => file && file.type?.startsWith('image/'));
        if (!imageFiles.length) {
            preview.innerHTML = '<div class="carousel-empty-preview"><strong>Arrastra tus banners aqui</strong><span>o usa el boton A&ntilde;adir imagenes</span></div>';
            updateCarouselSelectedNote(0);
            return;
        }

        const columns = Math.min(imageFiles.length, 4);
        preview.innerHTML = `<div class="carousel-preview-grid" style="grid-template-columns:repeat(${columns}, minmax(0, 1fr));"></div>`;
        const grid = preview.querySelector('div');
        imageFiles.slice(0, 8).forEach(file => {
            const reader = new FileReader();
            reader.onload = () => {
                const img = document.createElement('img');
                img.src = reader.result;
                img.alt = 'Preview carrusel';
                grid?.appendChild(img);
            };
            reader.readAsDataURL(file);
        });
        updateCarouselSelectedNote(imageFiles.length);
    }
    renderCarouselPreviewList([]);
    renderUploadedBanners();

    function buildCarouselBannerPayload(imageUrl, options = {}) {
        const index = options.index || 0;
        const total = options.total || 1;
        const bannerId = options.bannerId || makeCarouselBannerId();
        const baseTitle = titleInput?.value?.trim() || 'Original Store';
        const title = total > 1 ? `${baseTitle} ${index + 1}` : baseTitle;
        const description = descriptionInput?.value?.trim() || '';

        return {
            'ID Variacion': bannerId,
            'ID Variación': bannerId,
            idVariacion: bannerId,
            'ID Producto': bannerId,
            ID_Producto: bannerId,
            idProducto: bannerId,
            'Nombre del Producto': title,
            Nombre: title,
            Categoria: 'BANNER',
            categoria: 'BANNER',
            Catalogo: 'Ambos',
            'Categoría': 'BANNER',
            Precio: 0,
            'Precio Mayor': 0,
            'Stock Inicial': 1,
            Stock: 1,
            Cantidad: 1,
            'Imagen Principal': imageUrl,
            Imagen_Principal: imageUrl,
            Imagen: imageUrl,
            imagen: imageUrl,
            image: imageUrl,
            url: imageUrl,
            Color: description,
            'Caracteristicas del producto': description,
            Descripcion: description,
            Estilo: 'Inicio',
            Estado: 'Activo'
        };
    }

    async function deactivateOtherHomeBanners(activeId) {
        let source = Array.isArray(inventario) ? inventario : [];
        if (!source.length) {
            try {
                const res = await fetch(GOOGLE_SHEET_PRODUCTS_URL + '&_=' + Date.now(), { cache: 'no-store' });
                const data = await res.json();
                source = normalizeInventoryList(Array.isArray(data) ? data : (data.data || data.productos || []));
            } catch (error) {
                console.warn('No se pudieron leer banners actuales antes de reemplazar:', error);
                source = [];
            }
        }

        const banners = source.filter(item => {
            const category = String(item.Categoria || item.categoria || '').toUpperCase();
            const id = item.idVariacion || item.ID || item['ID Variacion'] || item['ID Variación'] || '';
            return category === 'BANNER' && id && id !== activeId;
        });

        for (const banner of banners) {
            const id = banner.idVariacion || banner.ID || banner['ID Variacion'] || banner['ID Variación'];
            try {
                await postProductToGoogleSheets({
                    ...banner,
                    'ID Variacion': id,
                    'ID Variación': id,
                    'ID Producto': banner.idProducto || banner['ID Producto'] || id,
                    ID_Producto: banner.idProducto || banner['ID Producto'] || id,
                    Estado: 'Inactivo'
                }, true);
            } catch (error) {
                console.warn('No se pudo desactivar banner anterior:', id, error);
            }
        }
    }

    fileInput.addEventListener('change', () => {
        const files = Array.from(fileInput.files || []).filter(file => file && file.type.startsWith('image/'));
        pendingCarouselFiles = files;
        if (!files.length) {
            renderCarouselPreviewList([]);
            return;
        }

        renderCarouselPreviewList(files);
    });

    imageUrlInput.addEventListener('input', () => {
        const url = imageUrlInput.value.trim();
        if (url) {
            preview.innerHTML = `<img src="${escapeHtml(url)}" alt="Preview carrusel" onerror="this.parentElement.innerHTML='<span>No se pudo cargar la URL</span>'">`;
            pendingCarouselFiles = [];
            updateCarouselSelectedNote(1);
        }
    });

    preview.addEventListener('drop', (event) => {
        event.preventDefault();
        event.stopImmediatePropagation();
        preview.classList.remove('drag-over');
        const files = Array.from(event.dataTransfer?.files || []).filter(file => file && file.type.startsWith('image/'));
        if (!files.length) {
            showToast('Arrastra solo imagenes para el carrusel', 'warning');
            return;
        }
        pendingCarouselFiles = files;
        renderCarouselPreviewList(files);
        showToast(`${files.length} imagen${files.length === 1 ? '' : 'es'} lista${files.length === 1 ? '' : 's'} para guardar`, 'success');
    });

    form.addEventListener('submit', async (event) => {
        event.preventDefault();
        event.stopImmediatePropagation();
        const originalText = btn.textContent;
        let finalButtonText = originalText;
        btn.disabled = true;
        btn.textContent = 'Guardando banner...';

        try {
            const files = pendingCarouselFiles.length
                ? pendingCarouselFiles
                : Array.from(fileInput.files || []).filter(file => file && file.type.startsWith('image/'));
            const mode = modeInput?.value || 'add';
            const editingBannerId = form.dataset.editingBannerId || editingCarouselBannerId;
            const imageUrls = [];

            if (files.length) {
                for (let index = 0; index < files.length; index += 1) {
                    btn.textContent = `Optimizando imagen ${index + 1} de ${files.length}...`;
                    const uploadedUrl = await uploadCarouselImage(files[index], 'banners');
                    imageUrls.push(uploadedUrl);
                }
                imageUrlInput.value = imageUrls[0] || '';
            } else {
                const imageUrl = imageUrlInput.value.trim();
                if (imageUrl) imageUrls.push(imageUrl);
            }

            if (!imageUrls.length) {
                throw new Error('Sube una o varias imagenes, o pega una URL');
            }

            if (editingBannerId && imageUrls.length > 1) {
                throw new Error('Para cambiar un banner existente, selecciona solo una imagen');
            }

            if (!editingBannerId && mode === 'replace') {
                await deactivateOtherHomeBanners(fixedHomeBannerId);
            }

            const bannerPayloads = imageUrls.map((imageUrl, index) => buildCarouselBannerPayload(imageUrl, {
                index,
                total: imageUrls.length,
                bannerId: editingBannerId || (mode === 'replace' && index === 0 ? fixedHomeBannerId : makeCarouselBannerId())
            }));

            btn.textContent = bannerPayloads.length > 1 ? 'Guardando banners...' : 'Guardando banner...';
            if (editingBannerId) {
                bannerPayloads[0].__adminOriginalId = editingBannerId;
                await postProductToGoogleSheets(bannerPayloads[0], true);
            } else if (bannerPayloads.length === 1) {
                await postProductToGoogleSheets(bannerPayloads[0], false);
            } else {
                await saveProductListToGoogleSheets(bannerPayloads, { fallbackEditOverride: false });
            }

            const plural = bannerPayloads.length === 1 ? '' : 's';
            showToast(editingBannerId ? 'Banner actualizado correctamente' : (mode === 'replace' ? 'Portada de inicio actualizada' : `${bannerPayloads.length} banner${plural} anadido${plural} al carrusel`), 'success');
            form.reset();
            editingCarouselBannerId = '';
            delete form.dataset.editingBannerId;
            finalButtonText = 'Guardar banner';
            pendingCarouselFiles = [];
            if (modeInput) modeInput.value = 'add';
            renderCarouselPreviewList([]);
            inventario = editingBannerId
                ? (Array.isArray(inventario) ? inventario : []).map(item => getCarouselBannerRecordId(item) === editingBannerId ? normalizeGoogleProduct(bannerPayloads[0]) : item)
                : bannerPayloads.concat(Array.isArray(inventario) ? inventario : []);
            renderUploadedBanners();
            clearPublicProductsCache();
            setTimeout(() => cargarInventario({ silent: true }).then(renderUploadedBanners), 2000);
        } catch (error) {
            console.error(error);
            showToast(error.message || 'No se pudo guardar el banner');
        } finally {
            btn.disabled = false;
            btn.textContent = finalButtonText;
        }
    });

    form.addEventListener('submit-old-disabled', async (event) => {
        event.preventDefault();
        const originalText = btn.textContent;
        btn.disabled = true;
        btn.textContent = 'Guardando banner...';

        try {
            const file = fileInput.files?.[0];
            let imageUrl = imageUrlInput.value.trim();
            if (file) {
                btn.textContent = 'Optimizando imagen...';
                imageUrl = await uploadCarouselImage(file, 'banners');
                imageUrlInput.value = imageUrl;
            }

            if (!imageUrl) {
                throw new Error('Sube una imagen o pega una URL');
            }

            const title = titleInput.value.trim() || 'Original Store';
            const description = descriptionInput.value.trim();
            const mode = modeInput?.value || 'replace';
            const bannerId = mode === 'replace' ? fixedHomeBannerId : makeCarouselBannerId();
            const bannerPayload = {
                'ID Variacion': bannerId,
                'ID Variación': bannerId,
                idVariacion: bannerId,
                'ID Producto': bannerId,
                ID_Producto: bannerId,
                idProducto: bannerId,
                'Nombre del Producto': title,
                Nombre: title,
                Categoria: 'BANNER',
                categoria: 'BANNER',
                Catalogo: 'Ambos',
                'Categoría': 'BANNER',
                Precio: 0,
                'Precio Mayor': 0,
                'Stock Inicial': 1,
                Stock: 1,
                Cantidad: 1,
                'Imagen Principal': imageUrl,
                Imagen_Principal: imageUrl,
                Imagen: imageUrl,
                imagen: imageUrl,
                image: imageUrl,
                url: imageUrl,
                Color: description,
                'Caracteristicas del producto': description,
                Descripcion: description,
                Estilo: 'Inicio',
                Estado: 'Activo'
            };

            if (mode === 'replace') {
                await deactivateOtherHomeBanners(bannerId);
            }

            await postProductToGoogleSheets(bannerPayload, false);

            showToast(mode === 'replace' ? 'Imagen de inicio actualizada' : 'Banner añadido al carrusel de inicio', 'success');
            form.reset();
            if (modeInput) modeInput.value = 'replace';
            preview.innerHTML = '<span>Selecciona una imagen para previsualizarla</span>';
            // Borrar cache público para que el cambio se vea de inmediato
            clearPublicProductsCache();
            setTimeout(() => cargarInventario({ silent: true }), 2000);
        } catch (error) {
            console.error(error);
            showToast(error.message || 'No se pudo guardar el banner');
        } finally {
            btn.disabled = false;
            btn.textContent = originalText;
        }
    });

    // Configurar Drag & Drop para Banner
    setupDragAndDrop('carousel-preview', (url, file) => {
        imageUrlInput.value = url;
        const reader = new FileReader();
        reader.onload = () => {
            renderCarouselPreview(reader.result);
        };
        reader.readAsDataURL(file);
    });
}

function initInventorySearch() {
    const input = document.getElementById('admin-inventory-search');
    const categorySelect = document.getElementById('admin-inventory-category-filter');

    let searchTimer = null;
    if (input) {
        input.addEventListener('input', () => {
            clearTimeout(searchTimer);
            searchTimer = setTimeout(() => {
                adminInventorySearchQuery = input.value;
                renderInventoryInBatches();
            }, 180);
        });
    }

    if (categorySelect) {
        adminInventoryCategoryFilter = categorySelect.value || 'todos';
        categorySelect.addEventListener('change', () => {
            adminInventoryCategoryFilter = categorySelect.value || 'todos';
            renderInventoryInBatches();
        });
    }
}

function initInventoryActions() {
    const tbody = document.getElementById('inventory-tbody');
    if (!tbody || tbody.dataset.actionsReady === 'true') return;
    tbody.dataset.actionsReady = 'true';

    tbody.addEventListener('click', function (e) {
        const btn = e.target.closest('[data-inventory-action]');
        if (!btn) return;

        const action = btn.dataset.inventoryAction;
        const key = btn.dataset.productKey || '';
        const motherId = btn.dataset.motherId || '';

        if (action === 'load-more') {
            loadMoreInventoryBatch();
            return;
        }

        if (action === 'toggle') {
            toggleVariants(motherId, btn);
            return;
        }

        if (action === 'edit') {
            const index = getInventoryIndexByKey(key);
            if (index === -1) {
                showToast('No se encontro el producto para editar', 'error');
                return;
            }
            editarProducto(index);
            return;
        }

        if (action === 'qr') {
            openInventoryQrTicket(key);
            return;
        }

        if (action === 'delete') {
            eliminarProductoPorClave(key);
            return;
        }

        if (action === 'delete-group') {
            eliminarGrupo(motherId);
        }
    });
}

function normalizeInventoryList(rawProducts) {
    return (Array.isArray(rawProducts) ? rawProducts : [])
        .map(normalizeGoogleProduct)
        .filter(isVisibleInventoryProduct)
        .reverse();
}

function mergeSavedProductsIntoInventory(savedProducts) {
    var products = (Array.isArray(savedProducts) ? savedProducts : [savedProducts])
        .filter(Boolean)
        .map(normalizeGoogleProduct);

    if (!products.length) return;

    var byKey = new Map();
    products.concat(inventario || []).forEach(function (product) {
        var key = getInventoryProductKey(product);
        if (key && !byKey.has(key)) {
            byKey.set(key, product);
        }
    });

    inventario = Array.from(byKey.values());
    adminInventorySearchQuery = '';
    var searchInput = document.getElementById('admin-inventory-search');
    if (searchInput) searchInput.value = '';
    writeInventoryCache(inventario);
    updateCategoryOptions();
    renderInventoryInBatches();
}

function readInventoryCache() {
    try {
        var cached = JSON.parse(localStorage.getItem(INVENTORY_CACHE_KEY) || 'null');
        return cached && Array.isArray(cached.data)
            ? cached.data.map(normalizeGoogleProduct).filter(isVisibleInventoryProduct)
            : [];
    } catch (e) {
        return [];
    }
}

function writeInventoryCache(list) {
    try {
        localStorage.setItem(INVENTORY_CACHE_KEY, JSON.stringify({
            savedAt: Date.now(),
            data: list
        }));
    } catch (e) {
        console.warn('No se pudo guardar cache de inventario:', e.message);
    }
}

function clearPublicProductsCache() {
    try {
        localStorage.removeItem(PUBLIC_PRODUCTS_CACHE_KEY);
        localStorage.setItem('original_store_catalog_revision:' + GOOGLE_SHEET_API, Date.now() + '-' + Math.random());
        localStorage.removeItem('blyxu_products_cache_v2');
        localStorage.removeItem(SITE_CONFIG_CACHE_KEY);
    } catch (e) {
        console.warn('No se pudo limpiar cache publico:', e.message);
    }
}

function paintInventory(list) {
    const tbody = document.getElementById('inventory-tbody');
    inventario = Array.isArray(list) ? list : [];
    updateCategoryOptions();

    if (!tbody) return;

    if (inventario.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;">No hay productos en el inventario.</td></tr>';
        renderAdminDashboard();
        return;
    }

    renderInventoryInBatches();
    renderAdminDashboard();
}

async function cargarInventario(options) {
    options = options || {};
    if (inventoryLoadingPromise && !options.force) return inventoryLoadingPromise;

    const loadInventory = async () => {
    const tbody = document.getElementById('inventory-tbody');
    const currentToken = ++inventoryFetchToken;
    const canKeepCurrentRows = inventario.length > 0;

    try {
        if (!canKeepCurrentRows) {
            var cachedList = readInventoryCache();
            if (cachedList.length) {
                paintInventory(cachedList);
                if (typeof renderQuickSaleResults === 'function') renderQuickSaleResults();
            }
        }

        if (tbody && !canKeepCurrentRows && inventario.length === 0) {
            tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;padding:40px;"><div style="display:flex;align-items:center;justify-content:center;gap:12px;"><div class="spinner" style="width:20px;height:20px;border-width:2px;"></div><span style="font-size:13px;color:rgba(255,255,255,0.4);">Cargando inventario...</span></div></td></tr>';
        }

        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 20000);
        let res;
        try {
            res = await fetch(GOOGLE_SHEET_PRODUCTS_URL + '&_=' + Date.now(), {
                cache: 'no-store',
                signal: controller.signal
            });
        } finally {
            clearTimeout(timeoutId);
        }
        const data = await res.json();
        if (currentToken !== inventoryFetchToken) return;

        if (data && (data.status === 'error' || data.ok === false)) {
            throw new Error(data.message || data.error || 'Error del Apps Script');
        }

        var rawProducts = Array.isArray(data) ? data : (data?.data || data?.productos);
        if(!Array.isArray(rawProducts))throw new Error('La respuesta del inventario no es válida.');
        var nextInventory = normalizeInventoryList(rawProducts);
        writeInventoryCache(nextInventory);
        paintInventory(nextInventory);
        if (typeof window.renderUploadedBanners === 'function') {
            window.renderUploadedBanners();
        }
        return;
    } catch (err) {
        console.error("Error al cargar datos:", err);
        if (tbody && inventario.length === 0) {
            tbody.innerHTML = `<tr><td colspan="8" style="text-align:center;color:#ff6b6b;">Error al cargar el inventario: ${escapeHtml(err.message)}</td></tr>`;
        } else {
            showToast('No se pudo actualizar inventario: ' + err.message, 'error');
        }

        const quickSaleResults = document.getElementById('quick-sale-results');
        if (quickSaleResults && inventario.length === 0) {
            quickSaleResults.innerHTML = `
                <div class="quick-sale-empty">
                    <strong>No se pudo cargar el catálogo.</strong><br>
                    Revisa la conexión y vuelve a intentarlo.<br><br>
                    <button class="admin-btn secondary" type="button" onclick="cargarInventario({ force: true }).then(renderQuickSaleResults)">Reintentar catálogo</button>
                </div>
            `;
        }
        if(options.throwOnError)throw err;
    }
    };

    inventoryLoadingPromise = loadInventory().finally(() => {
        inventoryLoadingPromise = null;
    });
    return inventoryLoadingPromise;
}

function renderInventoryInBatches() {
    const tbody = document.getElementById('inventory-tbody');
    if (!tbody) return;

    inventoryRenderToken++;
    inventoryRenderedRows = 0;
    filteredInventario = getFilteredInventory();
    tbody.innerHTML = '';

    if (inventoryLoadMoreObserver) {
        inventoryLoadMoreObserver.disconnect();
        inventoryLoadMoreObserver = null;
    }

    if (!filteredInventario.length) {
        const hasFilters = adminInventorySearchQuery || (adminInventoryCategoryFilter && adminInventoryCategoryFilter !== 'todos');
        tbody.innerHTML = `<tr><td colspan="8" style="text-align:center;">No se encontraron productos${hasFilters ? ' para los filtros aplicados' : ''}.</td></tr>`;
        return;
    }

    renderNextInventoryBatch(inventoryRenderToken);
}

function renderNextInventoryBatch(renderToken = inventoryRenderToken) {
    const tbody = document.getElementById('inventory-tbody');
    if (!tbody || renderToken !== inventoryRenderToken) return;

    tbody.querySelector('.inventory-load-more-row')?.remove();

    const start = inventoryRenderedRows;
    let end = Math.min(start + INVENTORY_BATCH_SIZE, filteredInventario.length);
    while (end < filteredInventario.length && filteredInventario[end]?.isChild) {
        end++;
    }
    const rows = filteredInventario
        .slice(start, end)
        .map(item => inventoryRowTemplate(item.product, item.index, item))
        .join('');

    tbody.insertAdjacentHTML('beforeend', rows);
    inventoryRenderedRows = end;

    if (inventoryRenderedRows < filteredInventario.length) {
        tbody.insertAdjacentHTML('beforeend', `
            <tr class="inventory-load-more-row">
                <td colspan="8" style="text-align:center;padding:18px;">
                    <button class="admin-btn" type="button" data-inventory-action="load-more" style="max-width:240px;">Cargar mas productos</button>
                    <div style="font-size:11px;color:var(--text-muted);margin-top:8px;">
                        Mostrando ${inventoryRenderedRows} de ${filteredInventario.length}
                    </div>
                </td>
            </tr>
        `);
        observeInventoryLoadMore(renderToken);
    }
}

function escapeHtml(value) {
    return String(value == null ? '' : value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

function getVariantAttributesLabel(product) {
    const attributes = [
        cleanProductStyleValue(product?.Estilo || product?.estilo),
        product?.Tamano || product?.Talla || product?.['Tamaño'] || product?.['Tamaño'],
        product?.Color || product?.color
    ]
        .map(value => String(value || '').trim())
        .filter(Boolean);

    return attributes.length ? attributes.join(' / ') : '-';
}

function getVariantAttributesLabel(product) {
    function isReferenceValue(value) {
        const raw = String(value || '').trim();
        const clean = normalizeSearchText(raw);
        if (!raw) return false;
        if (/^prod-.+-v\d+$/i.test(raw) || /^var-/i.test(raw)) return true;
        return [product?.idVariacion, product?.idProducto, product?.ID, product?.SKU]
            .some(ref => ref && clean === normalizeSearchText(ref));
    }

    const attributes = [
        cleanProductStyleValue(getProductField(product, ['Estilo', 'estilo'], '')),
        getProductField(product, ['Tamano', 'Tamaño', 'Tamaño', 'Talla'], ''),
        getProductField(product, ['Color', 'color'], '')
    ]
        .map(value => String(value || '').trim())
        .filter(value => value && !isReferenceValue(value));

    return attributes.length ? attributes.join(' / ') : '-';
}

function cleanInventoryId(value) {
    return String(value || '').replace(/[^a-zA-Z0-9_-]/g, '');
}

function getInventoryProductKey(product) {
    if (!product) return '';
    var key = getInventoryVariationId(product) || product._rowIndex || '';
    if (!key) {
        if (!product._inventoryKey) product._inventoryKey = 'tmp-' + Math.random().toString(36).slice(2);
        key = product._inventoryKey;
    }
    return String(key);
}

function getInventoryIndexByKey(key) {
    key = String(key || '');
    return inventario.findIndex(function (product) {
        return getInventoryProductKey(product) === key;
    });
}

function getInventoryProductByKey(key) {
    var index = getInventoryIndexByKey(key);
    return index === -1 ? null : inventario[index];
}

function getInventoryQrReference(product) {
    const mother=getInventoryMotherId(product),variation=getInventoryVariationId(product);
    if(mother&&(variation===mother||variation===mother+'-V01'))return normalizeBarcodeValue(mother);
    return normalizeBarcodeValue(
        getProductBarcode(product) ||
        product?.SKU ||
        getInventoryVariationId(product) ||
        getInventoryMotherId(product) ||
        product?.Nombre ||
        ''
    );
}

function getInventoryQrImageUrl(reference, size = 440) {
    const cleanReference = String(reference || '').trim();
    const dimension = Math.max(180, Math.min(800, Number(size) || 440));
    const localQr = qrcode(0, 'H');
    localQr.addData(cleanReference); localQr.make();
    return localQr.createDataURL(Math.max(2,Math.floor(dimension/(localQr.getModuleCount()+8))),16);
}

function encodeInventoryWholesalePrice(value) {
    const map = {
        '1': 'L',
        '2': 'Z',
        '3': 'E',
        '4': 'A',
        '5': 'S',
        '6': 'G',
        '7': 'F',
        '8': 'B',
        '9': 'P',
        '0': 'Q'
    };
    const digits = String(Math.round(Number(value) || 0)).replace(/\D/g, '').replace(/^0+/, '');
    if (!digits) return '';
    return digits.slice(0, 2).split('').map(digit => map[digit] || '').join('');
}

function getInventoryQrTicketData(product) {
    const reference = getInventoryQrReference(product);
    const retailPrice = parseAdminInvoiceMoney(product?.Precio || 0);
    const wholesalePrice = parseAdminInvoiceMoney(product?.Precio_Mayorista || product?.['Precio Mayor'] || product?.['Precio Mayorista'] || 0);
    return {
        reference,
        name: product?.Nombre || product?.Producto || 'Producto Original Store',
        sku: String(product?.SKU || '').trim(),
        variationId: reference === normalizeBarcodeValue(getInventoryMotherId(product)) ? getInventoryMotherId(product) : getInventoryVariationId(product),
        motherId: getInventoryMotherId(product),
        category: product?.Categoria || '-',
        stock: Number(product?.Stock || product?.Cantidad || 0) || 0,
        price: retailPrice,
        wholesalePrice,
        wholesaleCode: encodeInventoryWholesalePrice(wholesalePrice),
        imageUrl: getInventoryQrImageUrl(reference)
    };
}

function getProductFormQrTicketData(source = null) {
    const data = source || {};
    const variationId = String(data['ID Variacion'] || data['ID Variación'] || data.idVariacion || getInputValue('prod-id') || '').trim();
    const motherId = String(data['ID Producto'] || data.idProducto || getInputValue('prod-id-producto') || '').trim();
    const sku = String(data.SKU || getInputValue('prod-sku') || '').trim();
    const reference = normalizeBarcodeValue(motherId || variationId);
    const wholesalePrice = parseAdminInvoiceMoney(data['Precio Mayor'] || data['Precio Mayorista'] || getInputValue('prod-precio-mayorista') || 0);
    return {
        reference,
        name: data.Nombre || data['Nombre del Producto'] || getInputValue('prod-nombre') || 'Producto Original Store',
        sku,
        variationId: motherId || variationId,
        motherId,
        category: data.Categoria || data['Categoría'] || getInputValue('prod-categoria') || '-',
        stock: Number(data.Stock || data.Cantidad || data['Stock Inicial'] || getInputValue('prod-stock-inicial') || 0) || 0,
        price: parseAdminInvoiceMoney(data.Precio || getInputValue('prod-precio') || 0),
        wholesalePrice,
        wholesaleCode: encodeInventoryWholesalePrice(wholesalePrice),
        imageUrl: getInventoryQrImageUrl(reference)
    };
}

function showProductQrTicket(ticket) {
    const modal = document.getElementById('inventory-qr-modal');
    if (!modal || !ticket?.reference) {
        showToast('Primero genera o escanea una referencia para el producto', 'warning');
        return;
    }

    modal.dataset.productKey = '';
    modal.dataset.reference = ticket.reference;
    modal.dataset.ticketJson = JSON.stringify(ticket);
    const qrImg = document.getElementById('inventory-qr-image');
    if (qrImg) {
        qrImg.src = getInventoryQrImageUrl(ticket.reference);
        qrImg.alt = `QR ${ticket.reference}`;
    }
    setInventoryQrText('inventory-qr-ref', ticket.reference);
    setInventoryQrText('inventory-qr-name', ticket.name);
    setInventoryQrText('inventory-qr-category', ticket.category || '-');
    setInventoryQrText('inventory-qr-sku', ticket.sku || ticket.variationId || '-');
    setInventoryQrText('inventory-qr-stock', `${ticket.stock} und.`);
    setInventoryQrText('inventory-qr-price', formatAdminMoney(ticket.price));
    setInventoryQrText('inventory-qr-pm', ticket.wholesaleCode ? `PM: ${ticket.wholesaleCode}` : 'PM: -');
    modal.classList.add('open');
    updateInventoryQrPreviewOptions();
}

window.openProductFormQrPreview = function() {
    ensureProductHierarchyIds();
    showProductQrTicket(getProductFormQrTicketData());
};

function setInventoryQrText(id, value) {
    const el = document.getElementById(id);
    if (el) el.textContent = value;
}


// One physical layout for preview and thermal printing; QR payload remains unchanged.
const INVENTORY_LABEL_CSS = `
.os-label{box-sizing:border-box;background:#fff;color:#111;font-family:Arial,Helvetica,sans-serif;text-align:left;overflow:hidden;position:relative}
.os-label *{box-sizing:border-box}
.os-label-layout{position:absolute;inset:0;width:50mm;height:30mm;padding:1mm;display:grid;grid-template-columns:minmax(0,1fr) 23mm;gap:2mm;transform-origin:top left}
.os-label-content{min-width:0;display:flex;flex-direction:column;justify-content:space-between;gap:.15mm}
.os-label .os-label-logo{width:21mm;height:11.5mm;object-fit:contain;align-self:center;display:block;aspect-ratio:auto}
.os-label .os-label-qr{width:23mm;height:23mm;align-self:center;object-fit:contain;display:block;image-rendering:pixelated;aspect-ratio:1}
.os-label-id{font-size:6.5pt;line-height:1.05;font-weight:700;overflow-wrap:anywhere}
.os-label-name{font-size:5pt;line-height:1.05;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.os-label-price{font-size:12pt;line-height:1;font-weight:800;white-space:nowrap}
.os-label-pm{font-size:6pt;line-height:1;font-weight:400}
.os-label-compact .os-label-layout{width:40mm;height:15mm;grid-template-columns:9mm 13mm minmax(0,1fr);gap:1mm;padding:1mm}
.os-label-compact .os-label-logo{width:9mm;height:13mm;align-self:center}
.os-label-compact .os-label-qr{width:13mm;height:13mm}
.os-label-compact .os-label-content{justify-content:center;gap:1mm}
.os-label-compact .os-label-id{font-size:4.8pt}
.os-label-compact .os-label-price{font-size:8pt}
.os-label-compact .os-label-pm{font-size:5.5pt}
`;

function getInventoryLabelSize(options = {}) {
    const compact = ['40x15','30x15'].includes(options.format) || (!options.format && [30,40].includes(Number(options.width)) && Number(options.height) === 15);
    return compact ? {width:40,height:15,compact:true,format:'40x15'} : {width:50,height:30,compact:false,format:'50x30'};
}

function getInventoryLabelQrImage(reference, size = 800) {
    const qr = qrcode(0, 'M');
    qr.addData(String(reference || '').trim()); qr.make();
    const cell = Math.max(3,Math.floor(size / (qr.getModuleCount() + 8)));
    return qr.createDataURL(cell, cell * 4);
}

function renderInventoryLabel(ticket, options = {}, preview = false) {
    const id = ticket.variationId || ticket.sku || ticket.motherId || ticket.reference;
    const {width,height,compact} = getInventoryLabelSize(options);
    const fit = preview ? Math.min(1,230/(width*3.7795),160/(height*3.7795)) : 1;
    const logo = '<img class="os-label-logo" src="https://lh3.googleusercontent.com/d/1OTHvWFph2u3qFQMQVhE5ghmSWjBSgBeW=w180" alt="Original Store">';
    const qr = `<img class="os-label-qr" src="${escapeHtml(getInventoryLabelQrImage(ticket.reference))}" alt="QR de la referencia">`;
    const info = `<div class="os-label-content">
        ${!compact ? logo : ''}
        <div class="os-label-id">ID ${escapeHtml(id)}</div>
        ${options.name && !compact ? `<div class="os-label-name">${escapeHtml(ticket.name)}</div>` : ''}
        <div class="os-label-price">${escapeHtml(formatAdminMoney(ticket.price))}</div>
        <div class="os-label-pm">PM: ${escapeHtml(ticket.wholesaleCode || '-')}</div>
    </div>`;
    return `<div class="os-label${compact ? ' os-label-compact' : ''}" style="width:${width*fit}mm;height:${height*fit}mm"><div class="os-label-layout" style="transform:scale(${fit})">${compact ? logo + qr + info : info + qr}</div></div>`;
}

let inventoryLabelImage = { key: '', promise: null, file: null };
function prepareInventoryLabelImage(ticket, options) {
    const key = JSON.stringify([ticket.reference, ticket.variationId, ticket.sku, ticket.name, ticket.price, ticket.wholesaleCode, options.name, options.format, options.width, options.height]);
    if (inventoryLabelImage.key === key) return inventoryLabelImage.promise;
    const state = inventoryLabelImage = { key, promise: null, file: null };
    state.promise = (async () => {
        const loadImage = (src, cors = false) => new Promise((resolve, reject) => {
            const img = new Image();
            if (cors) img.crossOrigin = 'anonymous';
            img.onload = () => resolve(img);
            img.onerror = () => reject(new Error('No se pudo cargar el logo de la etiqueta. Intenta nuevamente.'));
            img.src = src;
        });
        const [qr, logo] = await Promise.all([
            loadImage(getInventoryLabelQrImage(ticket.reference)),
            loadImage('https://lh3.googleusercontent.com/d/1OTHvWFph2u3qFQMQVhE5ghmSWjBSgBeW=w180', true)
        ]);
        // Preserve QR proportions and fit all information within the chosen paper size.
        const canvas = document.createElement('canvas');
        const size = getInventoryLabelSize(options);
        canvas.width = Math.round(size.width * 300 / 25.4); canvas.height = Math.round(size.height * 300 / 25.4);
        const c = canvas.getContext('2d');
        c.fillStyle = '#fff'; c.fillRect(0, 0, canvas.width, canvas.height);
        // Work in millimetres so both presets retain square QR modules and readable type.
        c.setTransform(canvas.width/size.width,0,0,canvas.height/size.height,0,0);
        const leftWidth = size.compact ? 14 : 23;
        const qrSize = size.compact ? 13 : 23;
        const qrX = size.compact ? 11 : size.width - 1 - qrSize;
        c.imageSmoothingEnabled = false;
        c.drawImage(qr,qrX,(size.height-qrSize)/2,qrSize,qrSize);
        c.imageSmoothingEnabled = true;
        const logoHeight = size.compact ? 13 : 11.5;
        const logoWidth = size.compact ? 9 : leftWidth;
        const ratio = Math.min(logoWidth/logo.naturalWidth,logoHeight/logo.naturalHeight);
        const lw=logo.naturalWidth*ratio,lh=logo.naturalHeight*ratio;
        c.drawImage(logo,1+(logoWidth-lw)/2,1+(logoHeight-lh)/2,lw,lh);
        c.fillStyle='#111';c.textBaseline='top';
        const fontMm=(pt)=>pt*25.4/72;
        const infoX = size.compact ? 25 : 1;
        const id= 'ID '+String(ticket.variationId||ticket.sku||ticket.motherId||ticket.reference);
        let font=fontMm(size.compact?4.8:6.5),lines=[];
        const wrap=()=>{
            c.font='bold '+font+'px Arial';lines=[];let line='';
            for(const char of id){if(line&&c.measureText(line+char).width>leftWidth){lines.push(line);line='';}line+=char;}
            if(line)lines.push(line);
        };
        wrap();while(lines.length>2&&font>fontMm(size.compact?3:4)){font-=.1;wrap();}
        const idY=size.compact?2:13;
        lines.forEach((text,i)=>c.fillText(text,infoX,idY+i*font*1.05,leftWidth));
        if(options.name&&!size.compact){
            c.font=fontMm(5)+'px Arial';let name=String(ticket.name||'');
            if(c.measureText(name).width>leftWidth){while(name&&c.measureText(name+'…').width>leftWidth)name=name.slice(0,-1);name+='…';}
            c.fillText(name,1,19.1);
        }
        c.font='bold '+fontMm(size.compact?8:12)+'px Arial';
        c.fillText(formatAdminMoney(ticket.price),infoX,size.compact?7.7:22,leftWidth);
        c.font=fontMm(size.compact?5.5:6)+'px Arial';
        c.fillText('PM: '+(ticket.wholesaleCode||'-'),infoX,size.compact?11.2:27,leftWidth);
        const blob = await new Promise((resolve, reject) => canvas.toBlob(b => b ? resolve(b) : reject(new Error('No se pudo crear la imagen.')), 'image/png'));
        const filename = 'Original-Store-' + String(ticket.variationId || ticket.sku || ticket.reference).replace(/[^a-zA-Z0-9_-]/g, '-') + '-' + size.width + 'x' + size.height + '.png';
        const file = new File([blob], filename, { type: 'image/png' });
        state.file = file;
        return file;
    })();
    // Prepares sharing while the panel is open, preserving the click's user activation.
    state.promise.catch(() => {});
    return state.promise;
}

function getCurrentInventoryLabelImage() {
    const modal = document.getElementById('inventory-qr-modal');
    if (!modal?.dataset.ticketJson) throw new Error('Abre primero la etiqueta de un producto.');
    return prepareInventoryLabelImage(JSON.parse(modal.dataset.ticketJson), getInventoryQrTicketOptions());
}

function downloadInventoryLabelFile(file) {
    const url = URL.createObjectURL(file);
    const link = document.createElement('a');
    link.href = url; link.download = file.name;
    document.body.appendChild(link); link.click(); link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
}

window.downloadInventoryQrLabel = async function() {
    try { downloadInventoryLabelFile(await getCurrentInventoryLabelImage()); }
    catch (error) { inventoryLabelImage.key = ''; showToast(error.message || 'No se pudo descargar la etiqueta.', 'error'); }
};

window.shareInventoryQrLabel = async function() {
    try {
        const pending = getCurrentInventoryLabelImage();
        window.open('https://wa.me/573222431225', '_blank', 'noopener');
        downloadInventoryLabelFile(await pending);
        showToast('Etiqueta descargada. Adjunta la imagen en el chat de 3222431225 y pulsa Enviar.', 'info');
    } catch (error) {
        inventoryLabelImage.key = '';
        showToast('No se pudo preparar la imagen. Intenta Descargar imagen nuevamente.', 'warning');
    }
};

function getInventoryQrTicketOptions() {
    const modal = document.getElementById('inventory-qr-modal');
    const defaults = {
        name: true,
        reference: true,
        sku: true,
        category: true,
        stock: true,
        price: true,
        pm: true
    };
    if (!modal) return defaults;

    modal.querySelectorAll('[data-qr-option]').forEach(input => {
        defaults[input.dataset.qrOption] = input.checked;
    });
    defaults.format = document.getElementById('inventory-label-format')?.value || '50x30';
    defaults.sku = defaults.price = defaults.pm = true;
    return defaults;
}

window.updateInventoryQrPreviewOptions = function() {
    const modal = document.getElementById('inventory-qr-modal');
    if (!modal) return;
    if (!modal.dataset.sizeInitialized) {
        try {
            const saved = JSON.parse(localStorage.getItem('original-store-label-size') || '{}');
            const size = getInventoryLabelSize(saved);
            document.getElementById('inventory-label-format').value = size.format;
        } catch (error) {}
        modal.dataset.sizeInitialized = 'true';
    }
    const options = getInventoryQrTicketOptions();
    const size = getInventoryLabelSize(options);
    options.width = size.width; options.height = size.height;
    document.getElementById('inventory-label-format').value = size.format;
    const nameOption = modal.querySelector('[data-qr-option="name"]');
    if (nameOption) nameOption.disabled = size.compact;
    try { localStorage.setItem('original-store-label-size', JSON.stringify({format:size.format})); } catch(error) {}
    modal.querySelectorAll('[data-label-dimensions]').forEach(el => el.textContent = size.width + ' × ' + size.height + ' mm');
    const preview = document.getElementById('inventory-label-preview');
    if (preview && modal.dataset.ticketJson) {
        try {
            const ticket = JSON.parse(modal.dataset.ticketJson);
            preview.innerHTML = renderInventoryLabel(ticket, options, true);
            prepareInventoryLabelImage(ticket, options);
        }
        catch (error) { preview.textContent = 'No se pudo preparar la etiqueta.'; }
    }
    modal.querySelectorAll('[data-qr-element]').forEach(element => {
        const key = element.dataset.qrElement;
        element.hidden = options[key] === false;
    });
};

window.openInventoryQrTicket = function(key) {
    const product = getInventoryProductByKey(key);
    const modal = document.getElementById('inventory-qr-modal');
    if (!product || !modal) {
        showToast('No se encontro el producto para generar QR', 'error');
        return;
    }

    const ticket = getInventoryQrTicketData(product);
    if (!ticket.reference) {
        showToast('Este producto no tiene referencia, SKU o codigo para generar QR', 'warning');
        return;
    }

    modal.dataset.productKey = key;
    modal.dataset.reference = ticket.reference;
    modal.dataset.ticketJson = JSON.stringify(ticket);
    const qrImg = document.getElementById('inventory-qr-image');
    if (qrImg) {
        qrImg.src = ticket.imageUrl;
        qrImg.alt = `QR ${ticket.reference}`;
    }

    setInventoryQrText('inventory-qr-ref', ticket.reference);
    setInventoryQrText('inventory-qr-name', ticket.name);
    setInventoryQrText('inventory-qr-category', ticket.category || '-');
    setInventoryQrText('inventory-qr-sku', ticket.sku || ticket.variationId || '-');
    setInventoryQrText('inventory-qr-stock', `${ticket.stock} und.`);
    setInventoryQrText('inventory-qr-price', formatAdminMoney(ticket.price));
    setInventoryQrText('inventory-qr-pm', ticket.wholesaleCode ? `PM: ${ticket.wholesaleCode}` : 'PM: -');

    modal.classList.add('open');
    updateInventoryQrPreviewOptions();
};

window.closeInventoryQrTicket = function() {
    document.getElementById('inventory-qr-modal')?.classList.remove('open');
};

window.openInventoryQrImage = function() {
    const reference = document.getElementById('inventory-qr-modal')?.dataset.reference || '';
    if (!reference) return;
    window.open(getInventoryQrImageUrl(reference, 800), '_blank', 'noopener');
};

window.copyInventoryQrReference = function() {
    const reference = document.getElementById('inventory-qr-modal')?.dataset.reference || '';
    if (!reference) return;
    if (navigator.clipboard?.writeText) {
        navigator.clipboard.writeText(reference)
            .then(() => showToast('Referencia copiada', 'success'))
            .catch(() => showToast('No se pudo copiar la referencia', 'error'));
        return;
    }
    showToast('Copia manualmente la referencia del ticket', 'info');
};

window.printInventoryQrTicket = function() {
    const modal = document.getElementById('inventory-qr-modal');
    const product = getInventoryProductByKey(modal?.dataset.productKey || '');
    let ticket = product ? getInventoryQrTicketData(product) : null;
    if (!ticket && modal?.dataset.ticketJson) {
        try {
            ticket = JSON.parse(modal.dataset.ticketJson);
        } catch (error) {
            ticket = null;
        }
    }
    if (!ticket?.reference) {
        showToast('No se encontro el producto para imprimir', 'error');
        return;
    }
    const options = getInventoryQrTicketOptions();
    const {width, height} = getInventoryLabelSize(options);
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
        showToast('El navegador bloqueo la ventana de impresion', 'warning');
        return;
    }

    printWindow.document.open();
    printWindow.document.write(`<!DOCTYPE html><html lang="es"><head>
        <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
        <title>Etiqueta Original Store — ${width} × ${height} mm</title>
        <style>
            ${INVENTORY_LABEL_CSS}
            html,body{margin:0;background:#f4f4f5;color:#111}
            body{padding:20px;font-family:Arial,sans-serif}
            .os-label{margin:16px auto;box-shadow:0 0 0 1px #ddd}
            .toolbar{text-align:center;font-size:13px}
            .toolbar button{padding:12px 20px;border:0;border-radius:8px;background:#8a2846;color:white;cursor:pointer}
            @media print{
                @page{size:${width}mm ${height}mm;margin:0}
                html,body{width:${width}mm;height:${height}mm;padding:0;background:#fff}
                .toolbar{display:none}
                .os-label{margin:0;box-shadow:none;break-inside:avoid}
            }
        </style></head><body>
        <div class="toolbar"><p>${width} × ${height} mm · Escala 100 % · Sin márgenes ni encabezados</p><button onclick="window.print()">Imprimir etiqueta</button></div>
        ${renderInventoryLabel(ticket, options)}
        <script>
        window.addEventListener('load', function () {
            if (Array.from(document.images).every(function(img){return img.complete && img.naturalWidth > 0;})) window.print();
        });
        <\/script></body></html>`);
    printWindow.document.close();
};

function getInventoryEditLabel(product, index) {
    const name = product?.Nombre || product?.Producto || 'Producto sin nombre';
    const variant = getInventoryVariationId(product);
    const attrs = getVariantAttributesLabel(product);
    const suffix = attrs && attrs !== '-' ? ' - ' + attrs : (variant ? ' - ' + variant : '');
    return (index + 1) + '. ' + name + suffix;
}

function inventoryRowTemplate(p, index, itemMeta) {
    if (!itemMeta) itemMeta = {};
    const isChild = itemMeta.isChild;
    const groupSize = itemMeta.groupSize || 1;
    const motherId = itemMeta.motherId || (p.idProducto || p['ID Producto'] || 'desconocido');

    const isSearching = !!adminInventorySearchQuery;
    const displayStyle = (isChild && !isSearching) ? 'none' : 'table-row';
    const cleanMotherId = String(motherId).replace(/[^a-zA-Z0-9_-]/g, '');
    const rowClass = isChild ? 'variant-row mother-' + cleanMotherId : 'mother-row';

    if (!isChild) {
        var minP = itemMeta.minPrice || 0;
        var maxP = itemMeta.maxPrice || 0;
        if (!minP && !maxP) { minP = Number(p.Precio || 0); maxP = minP; }
        var priceStr = minP === maxP
            ? '$' + minP.toLocaleString('es-CO')
            : '$' + minP.toLocaleString('es-CO') + ' - $' + maxP.toLocaleString('es-CO');

        var stockTotal = itemMeta.totalStock;
        if (stockTotal === undefined) stockTotal = Number(p.Stock || p.Cantidad) || 0;
        var stockClass = stockTotal > 0 ? 'stock-positive' : 'stock-negative';
        var toggleBtnHtml = groupSize > 1
            ? '<button class="toggle-vars-btn" onclick="toggleVariants(\'' + cleanMotherId + '\', this)">Ver ' + (groupSize - 1) + ' variantes</button>'
            : '<span class="variant-count-badge">Producto único</span>';

        var catStyle = 'background:rgba(155,44,250,0.15);color:#d946ef;padding:3px 10px;border-radius:10px;font-size:11px;font-weight:700;display:inline-block;';

        var pIdVar = p.idVariacion || p.ID || p['ID Variacion'] || '';
        var badgeHtml = '<span class="mother-badge-id" title="ID Producto (Familia)">ID Prod: ' + motherId + '</span>';
        if (pIdVar && pIdVar !== motherId) {
            badgeHtml += ' <span class="variant-badge-id" title="ID Variación" style="margin-left:4px;">Var: ' + pIdVar + '</span>';
        }

        return '<tr class="' + rowClass + '">'
            + '<td><img src="' + (p.Imagen || 'https://lh3.googleusercontent.com/d/1OTHvWFph2u3qFQMQVhE5ghmSWjBSgBeW=w180') + '" width="46" height="46" loading="lazy" referrerpolicy="no-referrer" style="border-radius:8px;object-fit:cover;border:1px solid rgba(255,255,255,0.1);vertical-align:middle;" onerror="handleInventoryImageError(this)"></td>'
            + '<td><div style="font-weight:800;font-size:14px;color:#fff;">' + (p.Nombre || p.Producto || 'Producto General') + '</div>'
            + '<div style="font-size:10px;margin-top:5px;">' + badgeHtml
            + (groupSize > 1 ? ' <span class="variant-count-badge" style="margin-left:4px;">' + groupSize + ' variantes</span>' : '')
            + '</div></td>'
            + '<td><span style="' + catStyle + '">' + (p.Categoria || '-') + '</span></td>'
            + '<td style="font-weight:800;color:#fff;font-size:14px;">' + priceStr + (window.OriginalStoreRetailPricing?.inventoryControl(p) || '') + '</td>'
            + '<td><div class="' + stockClass + '">' + stockTotal + '</div><div style="font-size:9px;color:rgba(255,255,255,0.35);font-weight:700;text-transform:uppercase;letter-spacing:1px;">en stock</div></td>'
            + '<td>' + toggleBtnHtml + '</td>'
            + '<td style="white-space:nowrap;"><button class="action-btn-edit" onclick="editarProducto(' + index + ')">Editar</button>'
            + ' <button class="action-btn-delete-sm" onclick="eliminarProducto(' + index + ')">Eliminar</button>'
            + (groupSize > 1 ? ' <button class="action-btn-delete-sm" onclick="eliminarGrupo(\'' + cleanMotherId + '\')">Grupo</button>' : '')
            + '</td>'
            + '</tr>';
    } else {
        var stockVal = Number(p.Stock || p.Cantidad || 0);
        var catInfo = p.Color ? '<span style="font-size:11px;color:#9B2CFA;font-weight:600;">' + p.Color + '</span>' : '<span style="color:rgba(255,255,255,0.3);font-weight:500;">-</span>';
        var stockColor = stockVal > 0 ? '#10B981' : '#EF4444';

        return '<tr class="' + rowClass + '" style="display:' + displayStyle + ';">'
            + '<td><span class="tree-connector"></span><img src="' + (p.Imagen || 'https://lh3.googleusercontent.com/d/1OTHvWFph2u3qFQMQVhE5ghmSWjBSgBeW=w180') + '" width="30" height="30" loading="lazy" referrerpolicy="no-referrer" style="border-radius:4px;object-fit:cover;vertical-align:middle;" onerror="handleInventoryImageError(this)"></td>'
            + '<td><div style="font-size:12px;font-weight:600;color:rgba(255,255,255,0.7);">' + (p.Nombre || p.Producto || '') + '</div>'
            + '<div style="font-size:10px;margin-top:3px;"><span class="mother-badge-id" style="font-size:9px;">' + motherId + '</span>'
            + ' <span class="variant-badge-id">' + (p.idVariacion || p.ID || '-') + '</span>'
            + '</div></td>'
            + '<td>' + catInfo + '</td>'
            + '<td style="font-size:13px;color:rgba(255,255,255,0.85);font-weight:700;">$' + Number(p.Precio || 0).toLocaleString('es-CO') + '</td>'
            + '<td><span style="font-size:12px;font-weight:700;color:' + stockColor + ';">' + stockVal + ' und.</span></td>'
            + '<td><span style="font-size:10px;color:rgba(255,255,255,0.4);font-weight:600;">' + escapeHtml(getVariantAttributesLabel(p)) + '</span></td>'
            + '<td><button class="action-btn-edit-sm" onclick="editarProducto(' + index + ')">Editar</button>'
            + ' <button class="action-btn-delete-sm" onclick="eliminarProducto(' + index + ')">Borrar</button></td>'
            + '</tr>';
    }
}

function inventoryRowTemplate(p, index, itemMeta) {
    if (!itemMeta) itemMeta = {};
    var isChild = !!itemMeta.isChild;
    var groupSize = itemMeta.groupSize || 1;
    var motherId = itemMeta.motherId || getInventoryMotherId(p) || getInventoryVariationId(p) || 'sin-id';
    var cleanMotherId = cleanInventoryId(motherId);
    var rowClass = isChild ? 'variant-row mother-' + cleanMotherId : 'mother-row';
    var productKey = escapeHtml(getInventoryProductKey(p));
    var displayStyle = isChild && !adminInventorySearchQuery ? 'none' : 'table-row';
    var stockVal = Number(p.Stock || p.Cantidad || 0) || 0;
    var stockTotal = itemMeta.totalStock === undefined ? stockVal : itemMeta.totalStock;
    var stockClass = stockTotal > 0 ? 'stock-positive' : 'stock-negative';
    var image = escapeHtml(getInventoryProductImage(p, isChild ? 'thumb' : 'inventory'));
    var name = escapeHtml(p.Nombre || p.Producto || 'Producto General');
    var category = escapeHtml(p.Categoria || p.Color || '-');
    var idVar = getInventoryVariationId(p);
    var barcode = getProductBarcode(p);
    var price = Number(p.Precio || 0) || 0;
    var wholesalePrice = Number(p.Precio_Mayorista || p['Precio Mayor'] || 0) || 0;
    var minP = Number(itemMeta.minPrice || price) || 0;
    var maxP = Number(itemMeta.maxPrice || price) || 0;
    var minWholesaleP = Number(itemMeta.minWholesalePrice || wholesalePrice) || 0;
    var maxWholesaleP = Number(itemMeta.maxWholesalePrice || wholesalePrice) || 0;
    var priceStr = minP && maxP && minP !== maxP
        ? '$' + minP.toLocaleString('es-CO') + ' - $' + maxP.toLocaleString('es-CO')
        : '$' + (maxP || minP || price).toLocaleString('es-CO');
    var wholesalePriceStr = minWholesaleP && maxWholesaleP && minWholesaleP !== maxWholesaleP
        ? '$' + minWholesaleP.toLocaleString('es-CO') + ' - $' + maxWholesaleP.toLocaleString('es-CO')
        : (maxWholesaleP || minWholesaleP || wholesalePrice)
            ? '$' + (maxWholesaleP || minWholesaleP || wholesalePrice).toLocaleString('es-CO')
            : '-';
    var catStyle = 'background:rgba(155,44,250,0.15);color:#d946ef;padding:3px 10px;border-radius:10px;font-size:11px;font-weight:700;display:inline-block;';

    if (!isChild) {
        var toggleBtnHtml = groupSize > 1
            ? '<button class="toggle-vars-btn" type="button" data-inventory-action="toggle" data-mother-id="' + escapeHtml(cleanMotherId) + '">Ver ' + groupSize + ' Variantes</button>'
            : '<span class="variant-count-badge">Producto Unico</span>';
        var badgeHtml = '<span class="mother-badge-id" title="ID Producto">ID Prod: ' + escapeHtml(motherId) + '</span>';
        if (idVar && idVar !== motherId) {
            badgeHtml += ' <span class="variant-badge-id" title="ID Variacion" style="margin-left:4px;">Var: ' + escapeHtml(idVar) + '</span>';
        }
        if (barcode) {
            badgeHtml += ' <span class="variant-badge-id" title="Codigo de barras" style="margin-left:4px;">Cod: ' + escapeHtml(barcode) + '</span>';
        }

        return '<tr class="' + rowClass + '" data-product-key="' + productKey + '">'
            + '<td><img src="' + image + '" width="46" height="46" loading="lazy" referrerpolicy="no-referrer" style="border-radius:8px;object-fit:cover;border:1px solid rgba(255,255,255,0.1);vertical-align:middle;" onerror="handleInventoryImageError(this)"></td>'
            + '<td><div style="font-weight:800;font-size:14px;color:#fff;">' + name + '</div>'
            + '<div style="font-size:10px;margin-top:5px;">' + badgeHtml
            + (groupSize > 1 ? ' <span class="variant-count-badge" style="margin-left:4px;">' + groupSize + ' variantes</span>' : '')
            + '</div></td>'
            + '<td><span style="' + catStyle + '">' + category + '</span></td>'
            + '<td style="font-weight:800;color:#fff;font-size:14px;">' + priceStr + (window.OriginalStoreRetailPricing?.inventoryControl(p) || '') + '</td>'
            + '<td style="font-weight:800;color:#fbbf24;font-size:13px;">' + wholesalePriceStr + '</td>'
            + '<td><div class="' + stockClass + '">' + stockTotal + '</div><div style="font-size:9px;color:rgba(255,255,255,0.35);font-weight:700;text-transform:uppercase;letter-spacing:1px;">en stock</div></td>'
            + '<td>' + toggleBtnHtml + '</td>'
            + '<td style="white-space:nowrap;"><button class="action-btn-edit" type="button" data-inventory-action="edit" data-product-key="' + productKey + '">Editar</button>'
            + ' <button class="action-btn-edit-sm inventory-qr-btn" type="button" data-inventory-action="qr" data-product-key="' + productKey + '">QR</button>'
            + ' <button class="action-btn-delete-sm" type="button" data-inventory-action="delete" data-product-key="' + productKey + '">Borrar</button>'
            + (groupSize > 1 ? ' <button class="action-btn-delete-sm" type="button" data-inventory-action="delete-group" data-mother-id="' + escapeHtml(cleanMotherId) + '">Grupo</button>' : '')
            + '</td></tr>';
    }

    return '<tr class="' + rowClass + '" data-product-key="' + productKey + '" style="display:' + displayStyle + ';">'
        + '<td><span class="tree-connector"></span><img src="' + image + '" width="30" height="30" loading="lazy" referrerpolicy="no-referrer" style="border-radius:4px;object-fit:cover;vertical-align:middle;" onerror="handleInventoryImageError(this)"></td>'
        + '<td><div style="font-size:12px;font-weight:600;color:rgba(255,255,255,0.7);">' + name + '</div>'
        + '<div style="font-size:10px;margin-top:3px;"><span class="mother-badge-id" style="font-size:9px;">' + escapeHtml(motherId) + '</span>'
        + ' <span class="variant-badge-id">' + escapeHtml(idVar || '-') + '</span>'
        + (barcode ? ' <span class="variant-badge-id" title="Codigo de barras">Cod: ' + escapeHtml(barcode) + '</span>' : '')
        + '</div></td>'
        + '<td><span style="font-size:11px;color:#9B2CFA;font-weight:600;">' + category + '</span></td>'
        + '<td style="font-size:13px;color:rgba(255,255,255,0.85);font-weight:700;">$' + price.toLocaleString('es-CO') + (window.OriginalStoreRetailPricing?.inventoryControl(p) || '') + '</td>'
        + '<td style="font-size:13px;color:#fbbf24;font-weight:700;">' + (wholesalePrice ? '$' + wholesalePrice.toLocaleString('es-CO') : '-') + '</td>'
        + '<td><span style="font-size:12px;font-weight:700;color:' + (stockVal > 0 ? '#10B981' : '#EF4444') + ';">' + stockVal + ' und.</span></td>'
        + '<td><span style="font-size:10px;color:rgba(255,255,255,0.4);font-weight:600;">' + escapeHtml(getVariantAttributesLabel(p)) + getColorSwatchesHtml(p.Color || p.color) + '</span></td>'
        + '<td><button class="action-btn-edit-sm" type="button" data-inventory-action="edit" data-product-key="' + productKey + '">Editar</button>'
        + ' <button class="action-btn-edit-sm inventory-qr-btn" type="button" data-inventory-action="qr" data-product-key="' + productKey + '">QR</button>'
        + ' <button class="action-btn-delete-sm" type="button" data-inventory-action="delete" data-product-key="' + productKey + '">Borrar</button></td>'
        + '</tr>';
}

var inventoryLoadingMore = false;
function loadMoreInventoryBatch() {
    if (inventoryLoadingMore) return;
    inventoryLoadingMore = true;
    var btn = document.querySelector('.inventory-load-more-row .admin-btn');
    if (btn) { btn.disabled = true; btn.textContent = 'Cargando...'; }
    renderNextInventoryBatch();
    inventoryLoadingMore = false;
}

function observeInventoryLoadMore(renderToken) {
    const marker = document.querySelector('.inventory-load-more-row');
    if (!marker || !('IntersectionObserver' in window)) return;

    if (inventoryLoadMoreObserver) {
        inventoryLoadMoreObserver.disconnect();
    }

    inventoryLoadMoreObserver = new IntersectionObserver(entries => {
        if (renderToken !== inventoryRenderToken) {
            inventoryLoadMoreObserver.disconnect();
            return;
        }

        if (entries.some(entry => entry.isIntersecting)) {
            inventoryLoadMoreObserver.disconnect();
            renderNextInventoryBatch(renderToken);
        }
    }, { rootMargin: '250px' });

    inventoryLoadMoreObserver.observe(marker);
}

// === EXPORTACIÓN DE CATÁLOGO PDF POR CATEGORÍA CON TOGGLES ===
function getInventoryProductsForCatalogPdf(selectedCategory) {
    const selectedKeys = Array.isArray(selectedCategory)
        ? selectedCategory.map(normalizeInventoryCategoryKey).filter(Boolean)
        : (() => {
            const rawCategory = selectedCategory || adminInventoryCategoryFilter || 'todos';
            const cleanCategory = normalizeInventoryCategoryKey(rawCategory);
            return cleanCategory && cleanCategory !== 'todos' ? [cleanCategory] : [];
        })();
    const selectedKeySet = new Set(selectedKeys);
    const categoryOrder = new Map(selectedKeys.map((key, index) => [key, index]));

    // Filtrar productos visibles excluyendo BANNER e inactivos
    let list = (inventario || []).filter(p => {
        const cat = normalizeSearchText(p.Categoria);
        if (cat === 'banner') return false;
        const estado = String(p.Estado || p.estado || '').toLowerCase();
        if (estado === 'inactivo' || estado === 'eliminado') return false;
        return isVisibleInventoryProduct(p);
    });

    if (selectedKeySet.size) {
        list = list.filter(p => selectedKeySet.has(normalizeInventoryCategoryKey(p.Categoria)));
    }

    if (adminInventorySearchQuery) {
        const q = normalizeSearchText(adminInventorySearchQuery);
        list = list.filter(p => scoreInventorySearch(p, q) > 0);
    }

    // Agrupar y consolidar variantes ignorando diferencias de color y tamaño/talla (1 sola tarjeta por producto/modelo)
    const groupedMap = new Map();

    list.forEach(p => {
        const motherId = getInventoryMotherId(p);
        const name = String(p.Nombre || p.Producto || '').trim();
        const cat = normalizeInventoryCategoryKey(p.Categoria || '');

        // Clave única por producto madre o por nombre + categoría (ignora color, estilo y tamaño)
        const baseKey = motherId
            ? `mother___${motherId}`
            : `name___${normalizeSearchText(name)}___${cat}`;

        if (!groupedMap.has(baseKey)) {
            groupedMap.set(baseKey, {
                product: p,
                sizes: new Set(),
                colors: new Set(),
                allVariants: []
            });
        }

        const group = groupedMap.get(baseKey);
        group.allVariants.push(p);

        // Si encontramos una variante con mejor imagen o datos más completos, actualizar el producto base
        const currentImg = normalizeImageUrl(group.product?.Imagen || group.product?.['Imagen Principal'] || '');
        const candidateImg = normalizeImageUrl(p?.Imagen || p?.['Imagen Principal'] || '');
        if ((!currentImg || currentImg === 'https://lh3.googleusercontent.com/d/1OTHvWFph2u3qFQMQVhE5ghmSWjBSgBeW=w180') && candidateImg && candidateImg !== 'https://lh3.googleusercontent.com/d/1OTHvWFph2u3qFQMQVhE5ghmSWjBSgBeW=w180') {
            group.product = p;
        }

        const sizeVal = getInventoryPdfSizeValue(p);
        if (sizeVal && !['ambos', 'minorista', 'mayorista', '-', 'n/a'].includes(sizeVal.toLowerCase())) {
            group.sizes.add(sizeVal);
        }

        const colorVal = String(p.Color || '').trim();
        if (colorVal && !['ambos', 'minorista', 'mayorista', '-', 'n/a', 'unico'].includes(colorVal.toLowerCase())) {
            group.colors.add(colorVal);
        }
    });

    const consolidatedList = Array.from(groupedMap.values()).map(item => {
        const rep = { ...item.product };
        const sizesArr = Array.from(item.sizes).sort((a, b) => String(a).localeCompare(String(b), 'es', { numeric: true, sensitivity: 'base' }));
        const colorsArr = Array.from(item.colors);
        rep._availableSizes = sizesArr;
        rep._availableColors = colorsArr;

        const motherId = getInventoryMotherId(rep);
        rep._displayRef = motherId || rep.idVariacion || rep.ID || rep.SKU || '';
        return rep;
    });

    // Ordenar alfabéticamente por nombre
    consolidatedList.sort((a, b) => {
        const categoryA = normalizeInventoryCategoryKey(a.Categoria || a.categoria || '');
        const categoryB = normalizeInventoryCategoryKey(b.Categoria || b.categoria || '');
        const orderA = categoryOrder.has(categoryA) ? categoryOrder.get(categoryA) : 9999;
        const orderB = categoryOrder.has(categoryB) ? categoryOrder.get(categoryB) : 9999;
        if (orderA !== orderB) return orderA - orderB;
        if (categoryA !== categoryB) {
            return formatInventoryCategoryLabel(a.Categoria || categoryA)
                .localeCompare(formatInventoryCategoryLabel(b.Categoria || categoryB), 'es', { sensitivity: 'base' });
        }
        const nameA = String(a.Nombre || a.Producto || '').trim();
        const nameB = String(b.Nombre || b.Producto || '').trim();
        return nameA.localeCompare(nameB, 'es', { sensitivity: 'base' });
    });

    return consolidatedList;
}

function buildInventoryCatalogPrintHtml(products, options = {}) {
    const showDetal = options.showDetal !== false;
    const showMayorista = options.showMayorista !== false;
    const categoryTitle = options.categoryTitle || 'Todas las categorías';
    const items = Array.isArray(products) ? products : [];
    const itemsPerPage = 4; // 2 columnas x 2 filas por página (imágenes grandes e imponentes)

    const now = new Date();
    const dateFormatted = now.toLocaleDateString('es-CO', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
    const timeFormatted = now.toLocaleTimeString('es-CO', {
        hour: '2-digit',
        minute: '2-digit'
    });
    const fullDateString = `${dateFormatted} - ${timeFormatted}`;
    const dateShort = now.toLocaleDateString('es-CO', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit'
    });

    const pages = [];
    for (let i = 0; i < items.length; i += itemsPerPage) {
        pages.push(items.slice(i, i + itemsPerPage));
    }
    if (!pages.length) pages.push([]);

    const totalPages = pages.length;

    return pages.map((pageItems, pageIndex) => {
        const isLastPage = pageIndex === totalPages - 1;

        const cardsHtml = pageItems.map(p => {
            const name = p.Nombre || p.Producto || 'Producto Original Store';
            const rawImg = normalizeImageUrl(p.Imagen || p['Imagen Principal'] || '');
            const imgSrc = rawImg || 'https://lh3.googleusercontent.com/d/1OTHvWFph2u3qFQMQVhE5ghmSWjBSgBeW=w180';
            const ref = p._displayRef || p.idVariacion || p.ID || p.idProducto || p['ID Producto'] || p['ID Variacion'] || p.SKU || '';
            const price = Number(p.Precio || 0) || 0;
            const wholesalePrice = Number(p.Precio_Mayorista || p['Precio Mayor'] || p['Precio_Mayor'] || 0) || 0;

            const priceBadges = [];
            if (showDetal && price > 0) {
                priceBadges.push(`<span class="catalog-price-badge detal">Detal: $${price.toLocaleString('es-CO')}</span>`);
            }
            if (showMayorista && wholesalePrice > 0) {
                priceBadges.push(`<span class="catalog-price-badge mayor">Mayorista: $${wholesalePrice.toLocaleString('es-CO')}</span>`);
            }
            const pricesHtml = priceBadges.length
                ? `<div class="catalog-card-prices">${priceBadges.join('')}</div>`
                : '';

            const sizesLabel = (p._availableSizes && p._availableSizes.length > 1)
                ? `<span class="catalog-card-sizes" title="Tallas / Medidas disponibles">Tallas: ${escapeHtml(p._availableSizes.join(', '))}</span>`
                : (p._availableSizes && p._availableSizes.length === 1 && p._availableSizes[0]
                    ? `<span class="catalog-card-sizes" title="Talla / Medida">Talla: ${escapeHtml(p._availableSizes[0])}</span>`
                    : '');

            const refHtml = ref
                ? `<span class="catalog-card-ref">Ref: ${escapeHtml(ref)}</span>`
                : '<span class="catalog-card-ref"></span>';

            const metaLineHtml = (ref || sizesLabel)
                ? `<div class="catalog-card-meta-line">${refHtml}${sizesLabel}</div>`
                : '<div class="catalog-card-meta-line">&nbsp;</div>';

            return `
                <div class="catalog-card">
                    <div class="catalog-card-img-wrap">
                        <img src="${escapeHtml(imgSrc)}" alt="" class="catalog-card-img" loading="eager" crossorigin="anonymous" onerror="this.onerror=null;this.src='https://lh3.googleusercontent.com/d/1OTHvWFph2u3qFQMQVhE5ghmSWjBSgBeW=w180'">
                    </div>
                    <div class="catalog-card-name" title="${escapeHtml(name)}">${escapeHtml(name)}</div>
                    ${metaLineHtml}
                    ${pricesHtml}
                </div>
            `;
        }).join('');

        return `
            <div class="catalog-print-page${isLastPage ? ' last' : ''}">
                <div class="catalog-print-page-content">
                    <div class="catalog-print-header">
                        <div class="catalog-print-brand">
                            <img src="https://lh3.googleusercontent.com/d/1OTHvWFph2u3qFQMQVhE5ghmSWjBSgBeW=w180" alt="Original Store" class="catalog-print-logo-img" onerror="this.style.display='none'">
                            <div>
                                <h1>Catálogo de Productos</h1>
                                <p>Categoría: <strong>${escapeHtml(categoryTitle)}</strong></p>
                            </div>
                        </div>
                        <div class="catalog-print-meta">
                            <div>Fecha de expedición: <strong>${escapeHtml(fullDateString)}</strong></div>
                            <div>Total de productos: <strong>${items.length}</strong></div>
                        </div>
                    </div>
                    <div class="catalog-print-grid">
                        ${cardsHtml}
                    </div>
                </div>
                <div class="catalog-print-footer">
                    <span>Original Store · Catálogo Oficial (${escapeHtml(categoryTitle)})</span>
                    <span>Expedido el ${escapeHtml(dateShort)}</span>
                    <span>Página ${pageIndex + 1} de ${totalPages}</span>
                </div>
            </div>
        `;
    }).join('');
}

function loadJsPdfLibrary() {
    if (window.jspdf?.jsPDF) return Promise.resolve(window.jspdf.jsPDF);

    return new Promise((resolve, reject) => {
        const existing = document.querySelector('script[data-blyxu-jspdf="true"]');
        if (existing) {
            existing.addEventListener('load', () => resolve(window.jspdf?.jsPDF), { once: true });
            existing.addEventListener('error', () => reject(new Error('No se pudo cargar jsPDF')), { once: true });
            return;
        }

        const script = document.createElement('script');
        script.src = JSPDF_CDN_URL;
        script.async = true;
        script.dataset.blyxuJspdf = 'true';
        script.onload = () => {
            if (window.jspdf?.jsPDF) resolve(window.jspdf.jsPDF);
            else reject(new Error('jsPDF no quedo disponible'));
        };
        script.onerror = () => reject(new Error('No se pudo cargar jsPDF'));
        document.head.appendChild(script);
    });
}

function getPdfFriendlyImageUrl(url) {
    const normalized = normalizeImageUrl(url || '', 'thumb') || '';
    const driveId = normalized.match(/[?&]id=([^&]+)/)?.[1]
        || normalized.match(/drive\.google\.com\/file\/d\/([^/?&#]+)/)?.[1]
        || normalized.match(/googleusercontent\.com\/d\/([^=?&#]+)/)?.[1];
    if (driveId) {
        return `https://lh3.googleusercontent.com/d/${encodeURIComponent(driveId)}=w420`;
    }
    return normalized || 'https://lh3.googleusercontent.com/d/1OTHvWFph2u3qFQMQVhE5ghmSWjBSgBeW=w180';
}

function getInventoryPdfProductImage(product) {
    return getPdfFriendlyImageUrl(product?.Imagen || product?.['Imagen Principal'] || product?.imagen || product?.Foto || '');
}

function getInventoryPdfReference(product) {
    return product?._displayRef || getProductBarcode(product) || product?.SKU || getInventoryVariationId(product) || getInventoryMotherId(product) || product?.ID || '';
}

function getInventoryPdfSizeValue(product) {
    const directValue = getProductField(product, [
        'Tamano',
        'Tamaño',
        'Tamaño',
        'Tamaño',
        'Talla',
        'Talla Textil',
        'TallaTextil',
        'Medida',
        'Medidas'
    ], '');
    if (directValue) return String(directValue).trim();

    const unit = product?.UnidadMedida || product?.['Unidad Medida'] || '';
    const width = product?.Ancho || '';
    const length = product?.Largo || '';
    const depth = product?.Fondo || '';
    const capacity = product?.Capacidad || '';
    if (capacity) return `${capacity} ml`;
    if (width && length && depth) return `${width} x ${length} x ${depth} ${unit || 'cm'}`;
    if (width && length) return `${width} x ${length} ${unit || 'cm'}`;
    if (width) return `${width} ${unit || 'cm'}`;
    return '';
}

function resizeImageForPdf(src, maxEdge = 96) {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.onload = () => {
            try {
                const width = img.naturalWidth || img.width || maxEdge;
                const height = img.naturalHeight || img.height || maxEdge;
                const scale = Math.min(1, maxEdge / Math.max(width, height));
                const drawWidth = Math.max(1, Math.round(width * scale));
                const drawHeight = Math.max(1, Math.round(height * scale));
                const canvas = document.createElement('canvas');
                canvas.width = maxEdge;
                canvas.height = maxEdge;
                const ctx = canvas.getContext('2d');
                if (!ctx) throw new Error('Canvas no disponible');
                ctx.fillStyle = '#ffffff';
                ctx.fillRect(0, 0, canvas.width, canvas.height);
                ctx.drawImage(img, (maxEdge - drawWidth) / 2, (maxEdge - drawHeight) / 2, drawWidth, drawHeight);
                resolve(canvas.toDataURL('image/jpeg', 0.82));
            } catch (error) {
                reject(error);
            }
        };
        img.onerror = () => reject(new Error('No se pudo leer la imagen'));
        img.src = src;
    });
}

async function imageUrlToPdfDataUrl(url, maxEdge = 96) {
    const cleanUrl = normalizeImageUrl(url || '', Math.max(96, maxEdge)) || 'https://lh3.googleusercontent.com/d/1OTHvWFph2u3qFQMQVhE5ghmSWjBSgBeW=w180';
    try {
        const response = await fetch(cleanUrl, { mode: 'cors', cache: 'force-cache' });
        if (!response.ok) throw new Error('Imagen no disponible');
        const blob = await response.blob();
        const objectUrl = URL.createObjectURL(blob);
        try {
            return await resizeImageForPdf(objectUrl, maxEdge);
        } finally {
            URL.revokeObjectURL(objectUrl);
        }
    } catch (error) {
        try {
            return await resizeImageForPdf(cleanUrl, maxEdge);
        } catch (directError) {
            try {
                return await resizeImageForPdf('https://lh3.googleusercontent.com/d/1OTHvWFph2u3qFQMQVhE5ghmSWjBSgBeW=w180', maxEdge);
            } catch (fallbackError) {
                return '';
            }
        }
    }
}

function drawInventoryPdfHeader(doc, meta) {
    const pageWidth = doc.internal.pageSize.getWidth();
    doc.setDrawColor(234, 223, 229);
    doc.line(10, 31, pageWidth - 10, 31);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(135, 51, 79);
    doc.setFontSize(15);
    doc.text('Original Store', 10, 12);
    doc.setFontSize(8);
    doc.text('CATALOGO DE PRODUCTOS', pageWidth - 10, 12, {align:'right'});
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(112, 100, 107);
    doc.setFontSize(7);
    doc.text(meta.fullDateString, 10, 18);
    doc.text(meta.priceModeLabel, pageWidth - 10, 18, {align:'right'});
    doc.setTextColor(53, 42, 50);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.text(doc.splitTextToSize(meta.categoryTitle, pageWidth - 20).slice(0, 2), 10, 25);
}

function drawInventoryPdfFooter(doc, pageNumber) {
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    doc.setDrawColor(230, 230, 230);
    doc.line(10, pageHeight - 12, pageWidth - 10, pageHeight - 12);
    doc.setTextColor(120, 120, 120);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.text('Original Store - Catálogo de inventario', 10, pageHeight - 7);
    doc.text(`Página ${pageNumber}`, pageWidth - 10, pageHeight - 7, { align: 'right' });
}

function drawInventoryPdfTableHeader(doc, columns, y) {
    const pageWidth = doc.internal.pageSize.getWidth();
    doc.setFillColor(245, 242, 237);
    doc.rect(10, y, pageWidth - 20, 9, 'F');
    doc.setTextColor(65, 60, 55);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    columns.forEach(col => doc.text(col.label, col.x, y + 5.8, col.align ? { align: col.align } : undefined));
}

async function buildInventoryPdfRows(products) {
    const rows = new Array(products.length);
    const images = new Map();
    let nextIndex = 0;
    async function worker() {
        while (nextIndex < products.length) {
            const index = nextIndex++;
            const product = products[index];
            const priceDetal = Number(product.Precio || product.precio || 0) || 0;
            const priceMayor = Number(product.Precio_Mayorista || product.precio_mayorista || product.Mayorista || product['Precio Mayor'] || product['Precio_Mayor'] || 0) || 0;
            const imageUrl = getInventoryPdfProductImage(product);
            if (!images.has(imageUrl)) images.set(imageUrl, imageUrlToPdfDataUrl(imageUrl, 600));
            rows[index] = {
                image: await images.get(imageUrl),
                name: String(product.Nombre || product.Producto || 'Producto Original Store').trim(),
                reference: String(getInventoryPdfReference(product) || '').trim(),
                qrReference: getInventoryQrReference(product),
                categoryKey: normalizeInventoryCategoryKey(product.Categoria || product.categoria || '-'),
                categoryLabel: formatInventoryCategoryLabel(product.Categoria || product.categoria || '-'),
                detal: priceDetal > 0 ? formatAdminMoney(priceDetal) : '-',
                mayorista: priceMayor > 0 ? formatAdminMoney(priceMayor) : '-'
            };
        }
    }
    await Promise.all(Array.from({length:Math.min(4, products.length)}, worker));
    return rows;
}

function drawInventoryCatalogQr(doc, reference, x, y, size = 20) {
    if (!reference) return;
    const qr = qrcode(0, 'M');
    qr.addData(reference);
    qr.make();
    const count = qr.getModuleCount();
    const quiet = 4;
    const unit = size / (count + quiet * 2);
    doc.setFillColor(255, 255, 255);
    doc.rect(x, y, size, size, 'F');
    doc.setFillColor(0, 0, 0);
    for (let row = 0; row < count; row++) {
        for (let col = 0; col < count;) {
            if (!qr.isDark(row, col)) {col++;continue;}
            const start = col;
            while (col < count && qr.isDark(row, col)) col++;
            doc.rect(x + (start + quiet) * unit, y + (row + quiet) * unit, (col - start) * unit, unit, 'F');
        }
    }
}

function drawInventoryCatalogCard(doc, row, x, y, options) {
    const width = 92;
    doc.setDrawColor(234, 223, 229);
    doc.setFillColor(255, 255, 255);
    doc.roundedRect(x, y, width, 118, 3, 3, 'FD');
    if (row.image) doc.addImage(row.image, 'JPEG', x + 6, y + 3, 80, 80);
    else {
        doc.setFillColor(250, 247, 249);
        doc.roundedRect(x + 6, y + 3, 80, 80, 2, 2, 'F');
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(118, 103, 113);
        doc.setFontSize(8);
        doc.text('Imagen no disponible', x + width / 2, y + 44, {align:'center'});
    }
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(53, 42, 50);
    doc.setFontSize(8);
    const nameLines = doc.splitTextToSize(row.name, 60);
    if (nameLines.length > 2) nameLines[1] = nameLines[1].replace(/\s+\S*$/, '') + '...';
    doc.text(nameLines.slice(0, 2), x + 4, y + 88);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(6.3);
    doc.setTextColor(112, 100, 107);
    doc.text(doc.splitTextToSize('Ref: ' + (row.reference || '-'), 60).slice(0, 2), x + 4, y + 98);
    const prices = [
        ...(options.showDetal ? [{label:'DETAL', value:row.detal}] : []),
        ...(options.showMayorista ? [{label:'MAYORISTA', value:row.mayorista}] : [])
    ];
    prices.forEach((price, index) => {
        const px = x + 4 + index * 31;
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(6);
        doc.setTextColor(112, 100, 107);
        doc.text(price.label, px, y + 106);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(135, 51, 79);
        const availableWidth = prices.length === 1 ? 60 : 29;
        let fontSize = 12;
        doc.setFontSize(fontSize);
        while (fontSize > 8 && doc.getTextWidth(price.value) > availableWidth) doc.setFontSize(fontSize -= 0.5);
        doc.text(price.value, px, y + 112);
    });
    drawInventoryCatalogQr(doc, row.qrReference, x + 68, y + 88, 20);
    if (row.qrReference) {
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(5.5);
        doc.setTextColor(112, 100, 107);
        doc.text('QR pedido', x + 78, y + 112, {align:'center'});
    }
}

function renderInventoryCatalogCards(doc, rows, meta, options) {
    const categories = new Map();
    rows.forEach(row => {
        if (!categories.has(row.categoryKey)) categories.set(row.categoryKey, []);
        categories.get(row.categoryKey).push(row);
    });
    let pageNumber = 0;
    for (const categoryRows of categories.values()) {
        for (let start = 0; start < categoryRows.length; start += 4) {
            if (pageNumber) doc.addPage();
            pageNumber++;
            drawInventoryPdfHeader(doc, {...meta, categoryTitle:categoryRows[0].categoryLabel});
            categoryRows.slice(start, start + 4).forEach((row, index) => {
                drawInventoryCatalogCard(doc, row, 10 + (index % 2) * 98, 36 + Math.floor(index / 2) * 126, options);
            });
            drawInventoryPdfFooter(doc, pageNumber);
        }
    }
}

async function downloadInventoryCatalogPdf() {
    const selectedCategoryKeys = getSelectedInventoryPdfCategoryKeys();
    const pdfCategoryGroups = getInventoryPdfCategoryGroups();
    const allPdfCategoryKeys = pdfCategoryGroups.map(group => group.key);
    const selectedCategorySet = new Set(selectedCategoryKeys);
    const selectedCategoryLabels = pdfCategoryGroups
        .filter(group => selectedCategorySet.has(group.key))
        .map(group => group.label);
    const categoryText = selectedCategoryKeys.length === allPdfCategoryKeys.length
        ? 'Todas las categorías'
        : selectedCategoryLabels.length > 4
            ? `${selectedCategoryLabels.length} categorías: ${selectedCategoryLabels.slice(0, 4).join(', ')}...`
            : selectedCategoryLabels.join(', ');

    const showDetal = document.getElementById('inventory-pdf-show-detal')?.checked !== false;
    const showMayorista = document.getElementById('inventory-pdf-show-mayorista')?.checked !== false;
    const products = selectedCategoryKeys.length
        ? getInventoryProductsForCatalogPdf(selectedCategoryKeys)
        : [];

    if (!products.length) {
            showToast(selectedCategoryKeys.length ? 'No hay productos disponibles para exportar en estas categorías' : 'Selecciona al menos una categoría para el PDF', 'warning');
        return;
    }

    const btn = document.getElementById('btn-download-inventory-pdf');
    const originalText = btn?.textContent || 'Ver PDF';
    if (btn) {
        btn.disabled = true;
        btn.textContent = 'Generando PDF...';
    }

    try {
        if (!showDetal && !showMayorista) {
            showToast('Selecciona Detal, Mayorista o ambos para incluir precios en el PDF', 'warning');
            return;
        }

        showToast('Generando PDF de inventario...', 'info');
        const JsPDF = await loadJsPdfLibrary();
        const doc = new JsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4', compress: true });
        const rows = await buildInventoryPdfRows(products);

        const now = new Date();
        const fullDateString = now.toLocaleString('es-CO', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
        const dateSlug = now.toISOString().slice(0, 10);
        const priceModeLabel = [
            showDetal ? 'Detal' : '',
            showMayorista ? 'Mayorista' : ''
        ].filter(Boolean).join(' + ');
        const meta = {
            categoryTitle: categoryText,
            fullDateString,
            totalProducts: rows.length,
            priceModeLabel: `Precios: ${priceModeLabel}`
        };

        renderInventoryCatalogCards(doc, rows, meta, {showDetal, showMayorista});
        const cleanCategorySlug = String(categoryText || 'inventario')
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .replace(/[^a-zA-Z0-9_-]+/g, '-')
            .replace(/-+/g, '-')
            .replace(/^-|-$/g, '') || 'inventario';
        const fileName = `Catalogo-Original-Store-${cleanCategorySlug}-${dateSlug}.pdf`;
        const blobUrl = URL.createObjectURL(doc.output('blob'));
        const previewWindow = window.open(blobUrl, '_blank');
        if (!previewWindow) {
            doc.save(fileName);
            URL.revokeObjectURL(blobUrl);
            showToast('No se pudo abrir la vista previa. PDF descargado directamente.', 'warning');
        } else {
            previewWindow.document.title = fileName;
            setTimeout(() => URL.revokeObjectURL(blobUrl), 60000);
            showToast('Vista previa del PDF abierta. Puedes descargarlo desde el visor.', 'success');
        }
    } catch (error) {
        console.error('Error generando PDF de inventario:', error);
        showToast(error.message || 'No se pudo generar el PDF de inventario', 'error');
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.textContent = originalText;
        }
    }
}

function initInventoryPdfExport() {
    initInventoryPdfCategoryPicker();
    const btn = document.getElementById('btn-download-inventory-pdf');
    if (!btn || btn.dataset.ready === 'true') return;
    btn.dataset.ready = 'true';
    btn.addEventListener('click', downloadInventoryCatalogPdf);
}

function buildVariantEditorCardHtml(v, idProducto) {
    var vid = getInventoryVariationId(v) || '-';
    var safeVid = escapeHtml(vid);
    var vEstilo = cleanProductStyleValue(getProductField(v, ['Estilo', 'estilo'], ''));
    var vTamano = getProductField(v, ['Tamano', 'Tamaño', 'Talla'], '');
    var vTipoMedida = normalizeSearchText(v.TipoMedida || v['Tipo Medida'] || '');
    var vUnidadMedida = v.UnidadMedida || v['Unidad Medida'] || 'cm';
    var vAncho = v.Ancho || '';
    var vLargo = v.Largo || '';
    var vFondo = v.Fondo || '';
    var vRadio = v.Radio || '';
    var vCapacidad = v.Capacidad || (vUnidadMedida === 'ml' ? vAncho : '');
    var vTallaTextil = v.TallaTextil || v['Talla Textil'] || '';
    var vColor = v.Color || '-';
    var vStock = v.Stock || v.Cantidad || 0;
    var vPrecio = Number(v.Precio || 0).toLocaleString('es-CO');
    var vSku = v.SKU || '-';
    var vBarcode = getProductBarcode(v);
    var vImage = normalizeImageUrl(v.Imagen || v['Imagen Principal'] || '') || 'https://lh3.googleusercontent.com/d/1OTHvWFph2u3qFQMQVhE5ghmSWjBSgBeW=w180';
    var barcodeInputId = 've-barcode-' + cleanInventoryId(vid);
    var html = '';

    html += '<article class="variant-edit-card" data-varid="' + safeVid + '">';
    html += '<div class="variant-edit-summary">';
    html += '<div class="variant-edit-thumb"><img src="' + escapeHtml(vImage) + '" alt="" onerror="handleInventoryImageError(this)"></div>';
    html += '<div><span>ID variante</span><strong>' + escapeHtml(vid) + '</strong></div>';
    html += '<div><span>Atributos</span><b>' + escapeHtml(getVariantAttributesLabel(v) || 'Sin atributos') + '</b>' + getColorSwatchesHtml(vColor !== '-' ? vColor : '') + '</div>';
    html += '<div><span>Stock</span><b style="color:' + (Number(vStock) > 0 ? '#10B981' : '#EF4444') + ';">' + escapeHtml(vStock) + '</b></div>';
    html += '<div><span>Precio</span><b>$' + escapeHtml(vPrecio) + '</b></div>';
    html += '<div><span>SKU</span><b>' + escapeHtml(vSku) + '</b></div>';
    html += '<button type="button" class="admin-btn secondary variant-edit-toggle" aria-expanded="false" onclick="expandirVarianteEdicion(\'' + vid + '\')">Editar</button>';
    html += '</div>';

    html += '<div class="variant-edit-panel var-edit-expanded" id="var-expand-' + safeVid + '" data-original-varid="' + safeVid + '">';
    html += '<section class="variant-edit-section"><h5><span>01</span> Identidad e imagen</h5><div class="variant-edit-grid">';
    html += '<div><label>ID</label><input class="form-control ve-id" value="' + escapeHtml(vid) + '"></div>';
    html += '<div><label>SKU</label><input class="form-control ve-sku" value="' + escapeHtml(v.SKU || '') + '"></div>';
    html += '<div><label>Codigo barras</label><div style="display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px;"><input class="form-control ve-barcode" id="' + barcodeInputId + '" value="' + escapeHtml(vBarcode) + '"><button type="button" class="admin-btn secondary" onclick="scanBarcodeToElement(\'' + barcodeInputId + '\')" style="width:auto;min-height:40px;padding:8px 12px;font-size:10px;">Scan</button></div></div>';
    html += '<div style="grid-column:1/-1;"><label class="variant-image-switch"><input type="checkbox" role="switch" class="ve-use-general-image" '+(v['Modo Imagen']==='general'?'checked':'')+'> Usar foto del producto general</label><div class="variant-general-preview"><img alt="Foto general"></div><div class="variant-own-image"><label>Imagen URL</label><input class="form-control ve-imagen" value="' + escapeHtml(v.Imagen || '') + '" placeholder="https://..."></div></div>';
    html += '</div></section>';

    html += '<section class="variant-edit-section"><h5><span>02</span> Atributos visibles</h5><div class="variant-edit-grid">';
    html += '<div><label>Estilo</label><input class="form-control ve-estilo" value="' + escapeHtml(vEstilo) + '"></div>';
    html += '<div><label>Tamano / medida</label><input class="form-control ve-tamano" value="' + escapeHtml(vTamano) + '"></div>';
    html += '<div><label>Color</label><input type="hidden" class="ve-color" value="' + escapeHtml(vColor !== '-' ? vColor : '') + '"><div class="color-picker" data-color-target=".ve-color" aria-label="Seleccionar color de variante"></div></div>';
    html += '</div></section>';

    html += '<section class="variant-edit-section"><h5><span>03</span> Precios e inventario</h5><div class="variant-edit-grid">';
    html += '<div><label>Stock</label><input type="number" class="form-control ve-stock" value="' + escapeHtml(vStock) + '"></div>';
    html += '<div><label>Precio detal</label><input class="form-control ve-precio" value="' + escapeHtml(v.Precio || '') + '"></div>';
    html += '<div><label>Precio mayorista</label><input class="form-control ve-precio-mayorista" value="' + escapeHtml(v.Precio_Mayorista || v.precio_mayorista || v.Mayorista || v['Precio Mayor'] || '') + '"></div>';
    html += '</div></section>';

    html += '<section class="variant-edit-section"><h5><span>04</span> Medidas opcionales</h5><div class="variant-edit-grid four">';
    html += '<div><label>Tipo tamano</label><select class="form-control ve-size-kind"><option value=""' + (!vTipoMedida ? ' selected' : '') + '>Normal</option><option value="textil"' + (vTipoMedida === 'textil' ? ' selected' : '') + '>Textil</option><option value="medidas"' + (vTipoMedida === 'medidas' ? ' selected' : '') + '>Medidas</option><option value="liquido"' + (vTipoMedida === 'liquido' ? ' selected' : '') + '>Liquidos / ml</option></select></div>';
    html += '<div><label>Unidad</label><select class="form-control ve-measure-unit"><option value="cm"' + (vUnidadMedida === 'cm' ? ' selected' : '') + '>cm</option><option value="m"' + (vUnidadMedida === 'm' ? ' selected' : '') + '>m</option><option value="m3"' + (vUnidadMedida === 'm3' ? ' selected' : '') + '>m3</option><option value="ml"' + (vUnidadMedida === 'ml' ? ' selected' : '') + '>ml</option></select></div>';
    html += '<div><label>Capacidad ml</label><input class="form-control ve-measure-capacity" value="' + escapeHtml(vCapacidad) + '" placeholder="500"></div>';
    html += '<div><label>Talla textil</label><input class="form-control ve-textile-size" value="' + escapeHtml(vTallaTextil) + '" placeholder="XS, S, M..."></div>';
    html += '<div><label>Ancho</label><input class="form-control ve-measure-width" value="' + escapeHtml(vAncho) + '"></div>';
    html += '<div><label>Largo</label><input class="form-control ve-measure-length" value="' + escapeHtml(vLargo) + '"></div>';
    html += '<div><label>Fondo</label><input class="form-control ve-measure-depth" value="' + escapeHtml(vFondo) + '"></div>';
    html += '<div><label>Radio</label><input class="form-control ve-measure-radius" value="' + escapeHtml(vRadio) + '"></div>';
    html += '</div></section>';

    html += '<div class="variant-edit-actions">';
    html += '<button type="button" class="admin-btn secondary" onclick="cerrarVarianteEdicion(\'' + vid + '\')" style="width:auto;padding:9px 16px;font-size:11px;">Cerrar editor</button>';
    html += '<button type="button" class="admin-btn" onclick="guardarVarianteEditada(\'' + vid + '\',\'' + idProducto + '\')" style="width:auto;padding:9px 18px;font-size:11px;">Guardar variante</button>';
    html += '</div></div></article>';
    return html;
}

function buildVariantEditorCardsHtml(variantes, idProducto) {
    return '<div class="variant-editor-shell"><div class="variant-editor-head"><div><h4>Variantes de este ID (' + variantes.length + ')</h4><span>Ordenadas igual que el alta de producto: identidad, atributos, precios y medidas.</span></div></div>'
        + variantes.map(function (variant) { return buildVariantEditorCardHtml(variant, idProducto); }).join('')
        + '</div>';
}

function syncEditModalProductNavigator(activeIndex) {
    var modal = document.getElementById('edit-product-modal');
    var select = document.getElementById('edit-modal-product-jump');
    var prevBtn = document.getElementById('edit-modal-prev-product');
    var nextBtn = document.getElementById('edit-modal-next-product');
    if (!modal || !select || !Array.isArray(inventario)) return;

    modal.dataset.activeProductIndex = String(activeIndex);
    var currentValue = String(activeIndex);
    select.innerHTML = inventario.map(function (product, index) {
        return '<option value="' + index + '">' + escapeHtml(getInventoryEditLabel(product, index)) + '</option>';
    }).join('');
    select.value = currentValue;
    select.disabled = inventario.length < 2;
    if (prevBtn) prevBtn.disabled = activeIndex <= 0;
    if (nextBtn) nextBtn.disabled = activeIndex >= inventario.length - 1;
}

function initEditModalProductNavigator() {
    var select = document.getElementById('edit-modal-product-jump');
    var prevBtn = document.getElementById('edit-modal-prev-product');
    var nextBtn = document.getElementById('edit-modal-next-product');
    if (!select || select.dataset.ready === 'true') return;
    select.dataset.ready = 'true';

    select.addEventListener('change', function () {
        var nextIndex = Number(select.value);
        if (Number.isInteger(nextIndex) && inventario[nextIndex]) editarProducto(nextIndex);
    });

    prevBtn?.addEventListener('click', function () {
        var current = Number(document.getElementById('edit-product-modal')?.dataset.activeProductIndex || 0);
        if (inventario[current - 1]) editarProducto(current - 1);
    });

    nextBtn?.addEventListener('click', function () {
        var current = Number(document.getElementById('edit-product-modal')?.dataset.activeProductIndex || 0);
        if (inventario[current + 1]) editarProducto(current + 1);
    });
}

function cargarVariantesAlFormulario(idProducto, idVariacionActual) {
    var container = document.getElementById('variants-container');
    if (!container) return;
    delete container.dataset.activePreviewVariantKey;
    container.innerHTML = '';
    if (!idProducto) return;

    var variantes = inventario.filter(function (prod) {
        var mid = getInventoryMotherId(prod);
        var vid = getInventoryVariationId(prod);
        return mid === idProducto && vid !== idVariacionActual;
    });

    if (!variantes.length) {
        container.innerHTML = '<div style="padding:16px;text-align:center;font-size:12px;color:rgba(255,255,255,0.3);border:1px dashed rgba(255,165,0,0.2);border-radius:12px;">Este producto no tiene variantes aún</div>';
        return;
    }

    var tableHtml = '<div style="margin-bottom:12px;"><h4 style="font-size:10px;text-transform:uppercase;letter-spacing:1px;color:#FFA500;font-weight:800;margin:0;padding:0 4px 10px;">VARIANTES DE ESTE ID (' + variantes.length + ')</h4></div>';
    container.innerHTML = buildVariantEditorCardsHtml(variantes, idProducto);
    initColorPickers(container);
    container.querySelectorAll('.var-edit-expanded').forEach(syncVariantImageMode);
    return;

    tableHtml += '<div style="overflow-x:auto;"><table style="width:100%;border-collapse:separate;border-spacing:0 4px;font-size:11px;">';
    tableHtml += '<thead><tr style="color:rgba(255,255,255,0.25);font-size:9px;text-transform:uppercase;letter-spacing:1px;font-weight:700;">';
    tableHtml += '<th style="padding:4px 8px;text-align:left;">ID Var</th><th style="padding:4px 8px;text-align:left;">Color</th><th style="padding:4px 8px;text-align:left;">Stock</th><th style="padding:4px 8px;text-align:left;">Precio</th><th style="padding:4px 8px;text-align:left;">SKU</th><th style="padding:4px 8px;text-align:center;">Acción</th>';
    tableHtml = tableHtml.replace('>Color</th>', '>Atributos</th>');
    tableHtml += '</tr></thead><tbody>';

    variantes.forEach(function (v) {
        var vid = getInventoryVariationId(v) || '-';
        var vEstilo = cleanProductStyleValue(getProductField(v, ['Estilo', 'estilo'], ''));
        var vTamano = getProductField(v, ['Tamano', 'Tamaño', 'Tamaño', 'Talla'], '');
        var vTipoMedida = normalizeSearchText(v.TipoMedida || v['Tipo Medida'] || '');
        var vUnidadMedida = v.UnidadMedida || v['Unidad Medida'] || 'cm';
        var vAncho = v.Ancho || '';
        var vLargo = v.Largo || '';
        var vFondo = v.Fondo || '';
        var vRadio = v.Radio || '';
        var vCapacidad = v.Capacidad || (vUnidadMedida === 'ml' ? vAncho : '');
        var vTallaTextil = v.TallaTextil || v['Talla Textil'] || '';
        var vColor = v.Color || '-';
        var vStock = v.Stock || v.Cantidad || 0;
        var vPrecio = Number(v.Precio || 0).toLocaleString('es-CO');
        var vSku = v.SKU || '-';
        var vBarcode = getProductBarcode(v);
        var barcodeInputId = 've-barcode-' + cleanInventoryId(vid);
        tableHtml += '<tr class="var-edit-row" data-varid="' + vid + '">';
        tableHtml += '<td style="padding:6px 8px;background:rgba(255,255,255,0.02);border-radius:6px 0 0 6px;font-weight:700;color:#FFA500;white-space:nowrap;">' + vid + '</td>';
        tableHtml += '<td style="padding:6px 8px;background:rgba(255,255,255,0.02);color:#fff;">' + escapeHtml(getVariantAttributesLabel(v)) + '</td>';
        tableHtml += '<td style="padding:6px 8px;background:rgba(255,255,255,0.02);font-weight:700;color:' + (vStock > 0 ? '#10B981' : '#EF4444') + ';">' + vStock + '</td>';
        tableHtml += '<td style="padding:6px 8px;background:rgba(255,255,255,0.02);color:#9B2CFA;font-weight:700;">$' + vPrecio + '</td>';
        tableHtml += '<td style="padding:6px 8px;background:rgba(255,255,255,0.02);color:rgba(255,255,255,0.5);">' + vSku + '</td>';
        tableHtml += '<td style="padding:6px 8px;background:rgba(255,255,255,0.02);border-radius:0 6px 6px 0;text-align:center;"><button class="admin-btn secondary" style="width:auto;padding:3px 10px;font-size:9px;border-radius:6px;" onclick="expandirVarianteEdicion(\'' + vid + '\')">Editar</button></td>';
        tableHtml += '</tr>';

        // Hidden expanded edit row
        tableHtml += '<tr class="var-edit-expanded" id="var-expand-' + vid + '" style="display:none;"><td colspan="6" style="padding:12px 16px;background:rgba(255,165,0,0.03);border-radius:8px;border-left:2px solid #FFA500;">';
        tableHtml += '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:10px;">';
        tableHtml += '<div><label style="font-size:9px;color:rgba(255,255,255,0.4);display:block;margin-bottom:2px;">ID</label><input class="form-control ve-id" value="' + vid + '" style="padding:6px 10px;font-size:11px;"></div>';
        tableHtml += '<div><label style="font-size:9px;color:rgba(255,255,255,0.4);display:block;margin-bottom:2px;">Estilo</label><input class="form-control ve-estilo" value="' + escapeHtml(vEstilo) + '" style="padding:6px 10px;font-size:11px;"></div>';
        tableHtml += '<div><label style="font-size:9px;color:rgba(255,255,255,0.4);display:block;margin-bottom:2px;">Tamano</label><input class="form-control ve-tamano" value="' + escapeHtml(vTamano) + '" style="padding:6px 10px;font-size:11px;"></div>';
        tableHtml += '<div><label style="font-size:9px;color:rgba(255,255,255,0.4);display:block;margin-bottom:2px;">Color</label><input type="hidden" class="ve-color" value="' + escapeHtml(vColor !== '-' ? vColor : '') + '"><div class="color-picker" data-color-target=".ve-color" aria-label="Seleccionar color de variante"></div></div>';
        tableHtml += '<div><label style="font-size:9px;color:rgba(255,255,255,0.4);display:block;margin-bottom:2px;">Stock</label><input type="number" class="form-control ve-stock" value="' + vStock + '" style="padding:6px 10px;font-size:11px;"></div>';
        tableHtml += '<div><label style="font-size:9px;color:rgba(255,255,255,0.4);display:block;margin-bottom:2px;">Precio</label><input class="form-control ve-precio" value="' + (v.Precio || '') + '" style="padding:6px 10px;font-size:11px;"></div>';
        tableHtml += '<div><label style="font-size:9px;color:rgba(255,255,255,0.4);display:block;margin-bottom:2px;">Precio Mayor</label><input class="form-control ve-precio-mayorista" value="' + (v.Precio_Mayorista || v.precio_mayorista || v.Mayorista || v['Precio Mayor'] || '') + '" style="padding:6px 10px;font-size:11px;"></div>';
        tableHtml += '<div><label style="font-size:9px;color:rgba(255,255,255,0.4);display:block;margin-bottom:2px;">SKU</label><input class="form-control ve-sku" value="' + (v.SKU || '') + '" style="padding:6px 10px;font-size:11px;"></div>';
        tableHtml += '<div><label style="font-size:9px;color:rgba(255,255,255,0.4);display:block;margin-bottom:2px;">Codigo barras</label><div style="display:flex;gap:6px;"><input class="form-control ve-barcode" id="' + barcodeInputId + '" value="' + escapeHtml(vBarcode) + '" style="padding:6px 10px;font-size:11px;"><button type="button" class="admin-btn secondary" onclick="scanBarcodeToElement(\'' + barcodeInputId + '\')" style="width:auto;min-height:30px;padding:5px 9px;font-size:9px;">Scan</button></div></div>';
        tableHtml += '<div><label style="font-size:9px;color:rgba(255,255,255,0.4);display:block;margin-bottom:2px;">Imagen URL</label><input class="form-control ve-imagen" value="' + (v.Imagen || '') + '" style="padding:6px 10px;font-size:11px;"></div>';
        tableHtml += '<div><label style="font-size:9px;color:rgba(255,255,255,0.4);display:block;margin-bottom:2px;">Tipo tama&ntilde;o</label><select class="form-control ve-size-kind" style="padding:6px 10px;font-size:11px;"><option value=""' + (!vTipoMedida ? ' selected' : '') + '>Normal</option><option value="textil"' + (vTipoMedida === 'textil' ? ' selected' : '') + '>Textil</option><option value="medidas"' + (vTipoMedida === 'medidas' ? ' selected' : '') + '>Medidas</option><option value="liquido"' + (vTipoMedida === 'liquido' ? ' selected' : '') + '>Liquidos / ml</option></select></div>';
        tableHtml += '<div><label style="font-size:9px;color:rgba(255,255,255,0.4);display:block;margin-bottom:2px;">Unidad</label><select class="form-control ve-measure-unit" style="padding:6px 10px;font-size:11px;"><option value="cm"' + (vUnidadMedida === 'cm' ? ' selected' : '') + '>cm</option><option value="m"' + (vUnidadMedida === 'm' ? ' selected' : '') + '>m</option><option value="m3"' + (vUnidadMedida === 'm3' ? ' selected' : '') + '>m3</option><option value="ml"' + (vUnidadMedida === 'ml' ? ' selected' : '') + '>ml</option></select></div>';
        tableHtml += '<div><label style="font-size:9px;color:rgba(255,255,255,0.4);display:block;margin-bottom:2px;">Capacidad ml</label><input class="form-control ve-measure-capacity" value="' + escapeHtml(vCapacidad) + '" placeholder="500" style="padding:6px 10px;font-size:11px;"></div>';
        tableHtml += '<div><label style="font-size:9px;color:rgba(255,255,255,0.4);display:block;margin-bottom:2px;">Talla textil</label><input class="form-control ve-textile-size" value="' + escapeHtml(vTallaTextil) + '" placeholder="XS, S, M..." style="padding:6px 10px;font-size:11px;"></div>';
        tableHtml += '<div><label style="font-size:9px;color:rgba(255,255,255,0.4);display:block;margin-bottom:2px;">Ancho</label><input class="form-control ve-measure-width" value="' + escapeHtml(vAncho) + '" style="padding:6px 10px;font-size:11px;"></div>';
        tableHtml += '<div><label style="font-size:9px;color:rgba(255,255,255,0.4);display:block;margin-bottom:2px;">Largo</label><input class="form-control ve-measure-length" value="' + escapeHtml(vLargo) + '" style="padding:6px 10px;font-size:11px;"></div>';
        tableHtml += '<div><label style="font-size:9px;color:rgba(255,255,255,0.4);display:block;margin-bottom:2px;">Fondo</label><input class="form-control ve-measure-depth" value="' + escapeHtml(vFondo) + '" style="padding:6px 10px;font-size:11px;"></div>';
        tableHtml += '<div><label style="font-size:9px;color:rgba(255,255,255,0.4);display:block;margin-bottom:2px;">Radio</label><input class="form-control ve-measure-radius" value="' + escapeHtml(vRadio) + '" style="padding:6px 10px;font-size:11px;"></div>';
        tableHtml += '</div>';
        tableHtml += '<div style="display:flex;gap:8px;"><button type="button" class="admin-btn" onclick="guardarVarianteEditada(\'' + vid + '\',\'' + idProducto + '\')" style="width:auto;padding:6px 16px;font-size:10px;background:linear-gradient(135deg,#FFA500,#FF6347);">Guardar cambios</button>';
        tableHtml += '<button type="button" class="admin-btn secondary" onclick="cerrarVarianteEdicion(\'' + vid + '\')" style="width:auto;padding:6px 16px;font-size:10px;">Cancelar</button></div>';
        tableHtml += '</td></tr>';
    });

    tableHtml += '</tbody></table></div>';
    container.innerHTML = tableHtml;
    initColorPickers(container);
}

function getVariantEditPanel(vid) {
    var direct = document.getElementById('var-expand-' + vid);
    if (direct) return direct;
    var panels = document.querySelectorAll('.var-edit-expanded');
    for (var i = 0; i < panels.length; i++) {
        if (panels[i].dataset.originalVarid === vid) return panels[i];
    }
    return null;
}

window.expandirVarianteEdicion = function (vid) {
    var row = getVariantEditPanel(vid);
    if (!row) return;
    var card = row.closest('.variant-edit-card');
    var isOpen = !row.classList.contains('is-open');
    row.style.display = '';
    row.classList.toggle('is-open', isOpen);
    card?.classList.toggle('is-editing', isOpen);
    if (isOpen && card) {
        openProductEntryStep(document.getElementById('product-variants-step'));
        document.querySelectorAll('#variants-container .variant-draft-fold').forEach(fold=>fold.open=false);
        document.querySelectorAll('#variants-container .variant-edit-card.is-editing').forEach(other=>{if(other!==card)cerrarVarianteEdicion(other.dataset.varid);});
        syncVariantImageMode(row);
        setActiveVariantPreviewCard(card);
        updateLivePreview();
    }
    var button = card?.querySelector('.variant-edit-toggle');
    if (button) {
        button.textContent = isOpen ? 'Ocultar' : 'Editar';
        button.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    }
    if (isOpen) row.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
};
window.cerrarVarianteEdicion = function (vid) {
    var row = getVariantEditPanel(vid);
    if (!row) return;
    var card = row.closest('.variant-edit-card');
    var container = document.getElementById('variants-container');
    if (container && card && container.dataset.activePreviewVariantKey === getVariantPreviewCardKey(card)) {
        delete container.dataset.activePreviewVariantKey;
    }
    row.classList.remove('is-open');
    row.style.display = '';
    card?.classList.remove('is-editing');
    var button = card?.querySelector('.variant-edit-toggle');
    if (button) {
        button.textContent = 'Editar';
        button.setAttribute('aria-expanded', 'false');
    }
    updateLivePreview();
};

function getVariantEditMeasurementPayload(row, tamano = '') {
    const kind = row.querySelector('.ve-size-kind')?.value || '';
    const unit = kind === 'liquido' ? 'ml' : (row.querySelector('.ve-measure-unit')?.value || 'cm');
    const capacity = cleanMeasurementValue(row.querySelector('.ve-measure-capacity')?.value || '');
    const data = {
        kind,
        unit,
        capacity,
        width: unit === 'ml' ? capacity : cleanMeasurementValue(row.querySelector('.ve-measure-width')?.value || ''),
        length: cleanMeasurementValue(row.querySelector('.ve-measure-length')?.value || ''),
        depth: cleanMeasurementValue(row.querySelector('.ve-measure-depth')?.value || ''),
        radius: cleanMeasurementValue(row.querySelector('.ve-measure-radius')?.value || ''),
        textileSize: cleanMeasurementValue(row.querySelector('.ve-textile-size')?.value || (kind === 'textil' ? tamano : ''))
    };
    const size=getVariantEditSizeValue(row);
    return {...buildProductMeasurementPayload(data),Tamano:size,Talla:size,'Tamaño':size};
}

window.guardarVarianteEditada = async function (vid, idProducto) {
    try { window.OriginalStoreProductIdentity.assertValid(); } catch(error) { showToast(error.message,'error');return; }
    idProducto=getInputValue('prod-id-producto')||idProducto;
    var row = document.getElementById('var-expand-' + vid);
    if (!row) return;
    var editedTamano = row.querySelector('.ve-tamano')?.value || '';
    var data = {
        __adminOriginalId: vid,
        'ID Variacion': row.querySelector('.ve-id').value,
        'ID Producto': idProducto,
        'Nombre del Producto': getInputValue('prod-nombre'),
        Nombre: getInputValue('prod-nombre'),
        Categoria: getInputValue('prod-categoria'),
        'Categoría': getInputValue('prod-categoria'),
        Precio: parseAmount(row.querySelector('.ve-precio').value || getInputValue('prod-precio')),
        'Precio Mayor': parseAmount(row.querySelector('.ve-precio-mayorista')?.value || getInputValue('prod-precio-mayorista')),
        Cantidad: Number(row.querySelector('.ve-stock').value || 0),
        'Stock Inicial': Number(row.querySelector('.ve-stock').value || 0),
        Descripcion: getInputValue('prod-descripcion'),
        Tamano: editedTamano,
        Talla: editedTamano,
        'Tamaño': row.querySelector('.ve-tamano')?.value || '',
        ...getVariantEditMeasurementPayload(row, editedTamano),
        Color: row.querySelector('.ve-color').value,
        Estilo: cleanProductStyleValue(row.querySelector('.ve-estilo')?.value || ''),
        'Codigo Barras': row.querySelector('.ve-barcode')?.value || makeProductBarcode(idProducto, row.querySelector('.ve-id').value),
        SKU: row.querySelector('.ve-sku').value,
        'Modo Imagen': getVariantImageMode(row),
        Imagen: getVariantImageValue(row),
        'Imagen Principal': getVariantImageValue(row),
        Catalogo: getInputValue('prod-catalogo') || 'Ambos',
        Estado: getInputValue('prod-estado') || 'Activo'
    };
    try {
        await postProductToGoogleSheets(data, true);
        clearPublicProductsCache();
        showToast('Variante actualizada', 'success');
        cerrarVarianteEdicion(vid);
        setTimeout(function () { cargarInventario({ silent: true }); }, 1000);
    } catch (err) {
        showToast('Error: ' + err.message, 'error');
    }
};

window.guardarGrupoCompleto = async function (idProducto) {
    try { window.OriginalStoreProductIdentity.assertValid(); } catch(error) { showToast(error.message,'error');return; }
    idProducto=getInputValue('prod-id-producto')||idProducto;
    showToast('Guardando grupo completo...');

    const itemsToSave = [];
    
    // 1. Mother product
    var motherData = buildProductPayload();
    const originalVariationId = document.getElementById('product-form')?.dataset.originalVariationId || '';
    if (isEditingProduct && originalVariationId) motherData.__adminOriginalId = originalVariationId;
    itemsToSave.push(motherData);

    // 2. Save all variants in the group, including collapsed edit rows.
    var expandedRows = document.querySelectorAll('.var-edit-expanded');
    for (var i = 0; i < expandedRows.length; i++) {
        var row = expandedRows[i];
        var vid = row.querySelector('.ve-id')?.value || '';
        var editedTamano = row.querySelector('.ve-tamano')?.value || '';
        var vdata = {
            __adminOriginalId: row.getAttribute('id')?.replace('var-expand-', '') || vid,
            'ID Variacion': vid,
            'ID Producto': idProducto,
            'Nombre del Producto': getInputValue('prod-nombre'),
            Nombre: getInputValue('prod-nombre'),
            Categoria: getInputValue('prod-categoria'),
            'Categoría': getInputValue('prod-categoria'),
            Precio: parseAmount(row.querySelector('.ve-precio')?.value || getInputValue('prod-precio')),
            'Precio Mayor': parseAmount(row.querySelector('.ve-precio-mayorista')?.value || getInputValue('prod-precio-mayorista')),
            Cantidad: Number(row.querySelector('.ve-stock')?.value || 0),
            'Stock Inicial': Number(row.querySelector('.ve-stock')?.value || 0),
            Descripcion: getInputValue('prod-descripcion'),
            Tamano: editedTamano,
            Talla: editedTamano,
            'Tamaño': row.querySelector('.ve-tamano')?.value || '',
            ...getVariantEditMeasurementPayload(row, editedTamano),
            Color: row.querySelector('.ve-color')?.value || '',
            Estilo: cleanProductStyleValue(row.querySelector('.ve-estilo')?.value || ''),
            'Codigo Barras': row.querySelector('.ve-barcode')?.value || makeProductBarcode(idProducto, vid),
            SKU: row.querySelector('.ve-sku')?.value || '',
            'Modo Imagen': getVariantImageMode(row),
            Imagen: getVariantImageValue(row),
            'Imagen Principal': getVariantImageValue(row),
            Catalogo: getInputValue('prod-catalogo') || 'Ambos',
            Estado: getInputValue('prod-estado') || 'Activo'
        };
        itemsToSave.push(vdata);
    }

    try {
        const savedList = await saveProductListToGoogleSheets(itemsToSave, {
            fallbackEditOverride: true
        });
        clearPublicProductsCache();
        try {
            mergeSavedProductsIntoInventory(savedList);
        } catch (renderError) {
            console.warn('Grupo guardado, pero no se pudo refrescar el inventario local:', renderError);
        }
        showToast(`Grupo guardado exitosamente: ${savedList.length} producto(s)`, 'success');
        setTimeout(function () { cargarInventario({ silent: true }); }, 1500);
    } catch (err) {
        showToast('Error guardando el grupo: ' + err.message, 'error');
    }
};

function editarProducto(index) {
    window.OriginalStoreSharedScan?.invalidate();
    var p = inventario[index];
    var idVar = p.idVariacion || p.ID || p['ID Variacion'] || p['ID Variación'] || '';
    var idProd = getInventoryMotherId(p);
    idVar = getInventoryVariationId(p);
    var isVariant = idProd && idVar && idProd !== idVar;
    var form = document.getElementById('product-form');
    if (form) form.dataset.originalVariationId = idVar;

    setInputValue('prod-id', idVar);
    setMotherProductId(idProd);
    document.getElementById('prod-nombre').value = p.Nombre || p.Producto || '';
    document.getElementById('prod-categoria').value = p.Categoria || '';
    document.getElementById('prod-precio').value = p.Precio || '';
    document.getElementById('prod-precio-mayorista').value = p.Precio_Mayorista || p.precio_mayorista || p.Mayorista || p['Precio Mayor'] || '';
    window.OriginalStoreRetailPricing?.edit(p);
    document.getElementById('prod-catalogo').value = p.Catalogo || p.catalogo || 'Ambos';
    var stockVal = [p.Stock, p.Cantidad, ''].find(v => v !== undefined && String(v).trim() !== '');
    if (stockVal === undefined) stockVal = '';
    var elStock = document.getElementById('prod-stock');
    if (elStock) elStock.value = stockVal;
    document.getElementById('prod-imagen').value = p.Imagen || '';
    updateProductImagePreviewBox(p.Imagen || '');
    setInputValue('prod-color', p.Color || '');
    var stockInicialVal = [p.Stock_Inicial, p['Stock Inicial'], p.Stock, p.Cantidad, ''].find(v => v !== undefined && String(v).trim() !== '');
    if (stockInicialVal === undefined) stockInicialVal = '';
    setInputValue('prod-stock-inicial', stockInicialVal);
    setInputValue('prod-descripcion', p.Descripcion || p['Caracteristicas del producto'] || '');
    setInputValue('prod-tamano', p.Tamano || p['Tamano'] || '');
    var storedSizeKind = normalizeSearchText(p.TipoMedida || p['Tipo Medida'] || '');
    var storedTextileSize = p.TallaTextil || p['Talla Textil'] || '';
    var legacyMeasures = parseProductMeasurementText(p.Tamano || p['Tamano'] || '');
    var editAncho = p.Ancho || legacyMeasures.width || '';
    var editLargo = p.Largo || legacyMeasures.length || '';
    var editFondo = p.Fondo || legacyMeasures.depth || '';
    var editRadio = p.Radio || legacyMeasures.radius || '';
    var editCapacidad = p.Capacidad || (normalizeSearchText(p.UnidadMedida || p['Unidad Medida'] || legacyMeasures.unit || '') === 'ml' ? editAncho : '');
    var hasPhysicalMeasure = [editAncho, editLargo, editFondo, editRadio].some(function (value) {
        return value !== undefined && String(value).trim() !== '';
    });
    if (!storedSizeKind && storedTextileSize) storedSizeKind = 'textil';
    if (!storedSizeKind && normalizeSearchText(p.UnidadMedida || p['Unidad Medida'] || legacyMeasures.unit || '') === 'ml') storedSizeKind = 'liquido';
    if (!storedSizeKind && hasPhysicalMeasure) storedSizeKind = 'medidas';
    if (!storedTextileSize && storedSizeKind === 'textil') storedTextileSize = p.Tamano || p['Tamano'] || '';
    setInputValue('prod-size-kind', storedSizeKind);
    setInputValue('prod-textile-size', storedTextileSize);
    setInputValue('prod-textile-custom', '');
    setInputValue('prod-measure-unit', p.UnidadMedida || p['Unidad Medida'] || legacyMeasures.unit || 'cm');
    setInputValue('prod-measure-capacity', editCapacidad);
    setInputValue('prod-measure-width', editAncho);
    setInputValue('prod-measure-length', editLargo);
    setInputValue('prod-measure-depth', editFondo);
    setInputValue('prod-measure-radius', editRadio);
    updateProductMeasurementFields();
    setInputValue('prod-estilo', cleanProductStyleValue(p.Estilo || ''));
    
    var promoScope = getProductPromotionValue(p, 'FALSO');
    var promoSelect = document.getElementById('prod-promocion');
    if (promoSelect) promoSelect.value = promoScope;

    setInputValue('prod-galeria', stringifyAdminGallery(p.Galeria || p['Galeria JSON'] || p['Galería JSON'] || ''));
    renderProductGalleryManager();
    setInputValue('prod-sku', p.SKU || '');
    const storedBarcode = getProductField(p, PRODUCT_BARCODE_FIELD_KEYS, '');
    const resolvedBarcode = getProductBarcode(p);
    setInputValue('prod-barcode', resolvedBarcode);
    const barcodeInput = document.getElementById('prod-barcode');
    const childIdInput = document.getElementById('prod-id');
    if (barcodeInput) {
        const generatedBarcode = makeProductBarcode(getInputValue('prod-id-producto'), getInputValue('prod-id'));
        const hasRealBarcode = Boolean(storedBarcode) && normalizeBarcodeValue(storedBarcode) !== normalizeBarcodeValue(generatedBarcode);
        if (childIdInput) {
            childIdInput.dataset.scannedReference = hasRealBarcode && normalizeBarcodeValue(idVar) === normalizeBarcodeValue(resolvedBarcode) ? '1' : '0';
        }
        barcodeInput.dataset.generatedBarcode = generatedBarcode;
        barcodeInput.dataset.autoBarcode = hasRealBarcode ? '0' : '1';
        setProductBarcodeScanMode(hasRealBarcode);
        if (!hasRealBarcode) {
            barcodeInput.value = resolvedBarcode || generatedBarcode;
            updateProductBarcodeField(true);
        }
    }
    setInputValue('prod-estado', p.Estado || 'Activo');
    setInputValue('prod-fecha-creacion', p.Fecha_Creacion || p['Fecha de Creacion'] || '');
    setProductFormMode(true);
    updateLivePreview();

    var variantBadge = document.getElementById('variant-editing-badge');
    if (!variantBadge) {
        var titleRow = document.querySelector('.admin-title-row');
        if (titleRow) {
            variantBadge = document.createElement('span');
            variantBadge.id = 'variant-editing-badge';
            variantBadge.style.cssText = 'font-size:10px;padding:4px 10px;border-radius:8px;font-weight:700;margin-left:8px;';
            titleRow.querySelector('h2')?.after(variantBadge);
        }
    }
    if (variantBadge) {
        if (isVariant) {
            variantBadge.textContent = 'VARIANTE (' + idVar + ')';
            variantBadge.style.background = 'rgba(255,165,0,0.2)';
            variantBadge.style.color = '#FFA500';
            variantBadge.style.display = 'inline';
        } else {
            variantBadge.textContent = 'PRODUCTO PRINCIPAL (' + idProd + ')';
            variantBadge.style.background = 'rgba(155,44,250,0.2)';
            variantBadge.style.color = '#9B2CFA';
            variantBadge.style.display = 'inline';
        }
    }

    if (idProd) {
        cargarVariantesAlFormulario(idProd, idVar);
        document.getElementById('btn-save-group')?.remove();
        // El guardado principal ya cubre el grupo completo.
        var saveGroupBtn = document.getElementById('btn-save-group');
        if (false && !saveGroupBtn) {
            var formFooter = document.querySelector('#product-form > div:last-child');
            if (formFooter) {
                var newBtn = document.createElement('button');
                newBtn.type = 'button';
                newBtn.className = 'admin-btn';
                newBtn.id = 'btn-save-group';
                newBtn.style.cssText = 'background:linear-gradient(135deg,#FFA500,#FF6347);margin-top:12px;';
                newBtn.textContent = 'Guardar grupo completo (madre + variantes)';
                newBtn.addEventListener('click', function () { guardarGrupoCompleto(idProd); });
                formFooter.parentNode.insertBefore(newBtn, formFooter.nextSibling);
            }
        }
    } else {
        var oldBtn = document.getElementById('btn-save-group');
        if (oldBtn) oldBtn.remove();
    }

    window.OriginalStoreProductIdentity?.adopt();

    // MOVER EL FORMULARIO AL MODAL INDEPENDIENTE EN LUGAR DE CAMBIAR DE VISTA
    var modal = document.getElementById('edit-product-modal');
    var contentArea = document.getElementById('edit-modal-content-area');
    var viewProducts = document.getElementById('view-products');
    var gridSplit = contentArea?.querySelector('.grid-split') || viewProducts?.querySelector('.grid-split');

    if (modal && contentArea && gridSplit) {
        if (gridSplit.parentElement !== contentArea) contentArea.appendChild(gridSplit);
        modal.style.display = '';
        modal.classList.add('open');
        syncEditModalProductNavigator(index);
        modal.querySelector('.modal-card')?.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
        // Fallback al comportamiento original si no hay modal
        window.scrollTo({ top: 0, behavior: 'smooth' });
        if (typeof switchDashboardView === 'function') {
            switchDashboardView('products', 'Gestión de Productos');
        }
    }
}

window.cerrarModalEdicion = function () {
    var modal = document.getElementById('edit-product-modal');
    if (modal) {
        modal.classList.remove('open');
        modal.style.display = '';
    }
    var contentArea = document.getElementById('edit-modal-content-area');
    var viewProducts = document.getElementById('view-products');
    if (contentArea && viewProducts && contentArea.firstElementChild) {
        viewProducts.appendChild(contentArea.firstElementChild);
    }
    resetProductForm();
};

document.addEventListener('DOMContentLoaded', function () {
    initEditModalProductNavigator();
    document.getElementById('edit-product-modal')?.addEventListener('click', function (e) {
        if (e.target === this) {
            cerrarModalEdicion();
        }
    });
});

// Limpiar formato de dinero para que la DB no se corrompa entre Precio y Stock
function parseAmount(val) {
    if (!val) return 0;
    return parseInt(String(val).replace(/[^0-9]/g, ''), 10) || 0;
}


// Modal de confirmación
var modalConfirmCallback = null;
var modalCancelCallback = null;
function showModal(title, body, confirmText, onConfirm, onCancel) {
    var el = document.getElementById('confirm-modal');
    if (!el) return;
    document.getElementById('modal-title').textContent = title || 'Confirmar';
    document.getElementById('modal-body').textContent = body || '¿Estás seguro?';
    var btn = document.getElementById('modal-confirm-btn');
    btn.textContent = confirmText || 'Eliminar';
    modalConfirmCallback = onConfirm || null;
    modalCancelCallback = onCancel || null;
    el.style.display = 'flex';
}
function closeModal() {
    var el = document.getElementById('confirm-modal');
    if (el) el.style.display = 'none';
    modalConfirmCallback = null;
    modalCancelCallback = null;
}
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('modal-confirm-btn')?.addEventListener('click', function () {
        var cb = modalConfirmCallback;
        closeModal();
        if (cb) cb();
    });
    document.getElementById('modal-cancel-btn')?.addEventListener('click', function () {
        if (modalCancelCallback) modalCancelCallback();
        closeModal();
    });
    document.getElementById('confirm-modal')?.addEventListener('click', function (e) {
        if (e.target === this) {
            if (modalCancelCallback) modalCancelCallback();
            closeModal();
        }
    });
});

async function delFromSheet(id, idProd, rowMeta) {
    var rowIndex = rowMeta && rowMeta.rowIndex ? rowMeta.rowIndex : 0;
    if (!id && !idProd && !rowIndex) throw new Error('No hay ID para eliminar');
    var lastError = 'Google Sheets no confirmo el borrado fisico';

    var deleteStrategies = [
        {
            resource: 'productos',
            action: 'delete_product',
            id: id,
            ID_Producto: idProd,
            'ID Variacion': id,
            'ID Variación': id
        },
        {
            resource: 'productos',
            action: 'delete',
            id: id,
            ID_Producto: idProd,
            'ID Variacion': id,
            'ID Variación': id
        },
        {
            resource: 'productos',
            action: 'eliminar',
            id: id,
            ID_Producto: idProd,
            'ID Variacion': id,
            'ID Variación': id
        }
    ];

    if (rowMeta) {
        deleteStrategies.forEach(function (p) {
            if (rowMeta.nombre) p.nombre = rowMeta.nombre;
            if (!id && rowMeta.rowIndex) p._rowIndex = rowMeta.rowIndex;
        });
    }

    for (var i = 0; i < deleteStrategies.length; i++) {
        try {
            var res = await fetch(GOOGLE_SHEET_API, {
                method: 'POST',
                body: JSON.stringify(deleteStrategies[i])
            });
            var result = await res.json();
            if (result && (result.deleted > 0 || result.status === 'success' || result.ok === true)) {
                console.log('Producto eliminado fisicamente de Google Sheets');
                return true;
            }
            lastError = result?.error || result?.message || lastError;
        } catch (e) {
            lastError = e.message || lastError;
            console.warn('Delete strategy ' + i + ' failed:', e.message);
        }
    }

    throw new Error('No se pudo borrar fisicamente de Google Sheets: ' + lastError);
}

async function eliminarProducto(index) {
    var p = inventario[index];
    if (!p) { showToast('Error: producto no encontrado en el índice ' + index, 'error'); return; }
    var idVar = p.idVariacion || p.ID || p['ID Variacion'] || p['ID Variación'] || '';
    var idProd = p.idProducto || p['ID Producto'] || idVar;
    var nombre = p.Nombre || p.Producto || 'este producto';
    var rowIndex = p._rowIndex || 0;

    if (!idVar && !nombre) { showToast('Error: producto sin ID ni Nombre', 'error'); return; }

    showModal(
        'Eliminar Producto',
        '¿Eliminar permanentemente "' + nombre + '"' + (idVar ? ' (ID: ' + idVar + ')' : '') + '?',
        'Sí, eliminar',
        async function () {
            showToast('Eliminando "' + nombre + '"...');
            try {
                await delFromSheet(idVar, idProd, { nombre: nombre, rowIndex: rowIndex });
                showToast('Producto "' + nombre + '" eliminado correctamente', 'success');
                // Remove the row visually immediately for better UX
                inventario.splice(index, 1);
                writeInventoryCache(inventario);
                renderInventoryInBatches();
                // Reload from server to sync
                setTimeout(function () { cargarInventario({ silent: true }); }, 2000);
            } catch (err) {
                console.error('Error eliminando producto:', err);
                showToast('Error al eliminar: ' + err.message, 'error');
            }
        }
    );
}

async function eliminarProductoPorClave(key) {
    var p = getInventoryProductByKey(key);
    if (!p) {
        showToast('Error: producto no encontrado para borrar', 'error');
        return;
    }

    var idVar = p.idVariacion || p.ID || p['ID Variacion'] || p['ID Variación'] || '';
    var idProd = p.idProducto || p['ID Producto'] || idVar;
    var nombre = p.Nombre || p.Producto || 'este producto';
    var rowIndex = p._rowIndex || 0;
    var productKey = getInventoryProductKey(p);

    if (!idVar && !rowIndex && !nombre) {
        showToast('Error: producto sin ID para eliminar', 'error');
        return;
    }

    showModal(
        'Eliminar Producto',
        'Eliminar permanentemente "' + nombre + '"' + (idVar ? ' (ID: ' + idVar + ')' : '') + '?',
        'Si, eliminar',
        async function () {
            showToast('Eliminando "' + nombre + '"...');
            try {
                await delFromSheet(idVar, idProd, { nombre: nombre, rowIndex: rowIndex });
                inventario = inventario.filter(function (item) {
                    return getInventoryProductKey(item) !== productKey;
                });
                writeInventoryCache(inventario);
                renderInventoryInBatches();
                showToast('Producto "' + nombre + '" eliminado correctamente', 'success');
                setTimeout(function () { cargarInventario({ silent: true }); }, 1200);
            } catch (err) {
                console.error('Error eliminando producto:', err);
                showToast('Error al eliminar: ' + err.message, 'error');
            }
        }
    );
}

async function eliminarGrupo(motherIdClean) {
    showModal(
        'Eliminar Grupo Completo',
        '¿Eliminar TODAS las variantes de este grupo (ID: ' + motherIdClean + ')?',
        'Sí, eliminar grupo',
        async function () {
            showToast('Eliminando grupo...');
            var variants = inventario.filter(function (p) {
                var mid = getInventoryMotherId(p);
                var vid = getInventoryVariationId(p);
                return cleanInventoryId(mid) === motherIdClean || cleanInventoryId(vid) === motherIdClean;
            });
            if (variants.length === 0) { showToast('No se encontraron productos del grupo', 'error'); return; }
            var errors = 0;
            var lastErr = '';
            for (var i = 0; i < variants.length; i++) {
                try {
                    var v = variants[i];
                    var vId = getInventoryVariationId(v);
                    if (!vId) continue;
                    await delFromSheet(vId, motherIdClean, { nombre: v.Nombre || v.Producto || '', rowIndex: v._rowIndex || 0 });
                } catch (e) { errors++; lastErr = e.message; }
            }
            if (errors === 0) {
                showToast('Grupo eliminado (' + variants.length + ' productos)', 'success');
            } else if (errors === variants.length) {
                showToast('Error en todo el grupo: ' + lastErr, 'error');
            } else {
                showToast('Grupo: ' + (variants.length - errors) + ' ok, ' + errors + ' error(es)', 'warning');
            }
            if (errors < variants.length) {
                var deletedKeys = new Set(variants.map(function (item) { return getInventoryProductKey(item); }));
                inventario = inventario.filter(function (item) {
                    return !deletedKeys.has(getInventoryProductKey(item));
                });
                writeInventoryCache(inventario);
                renderInventoryInBatches();
                setTimeout(function () { cargarInventario({ silent: true }); }, 1000);
            }
        }
    );
}

function showToast(msg, type) {
    var t = document.getElementById('toast');
    if (!t) return;
    t.textContent = msg;
    t.className = 'toast';
    if (type) t.classList.add(type);
    t.classList.add('show');
    setTimeout(function () { t.classList.remove('show'); }, 3000);
}

function setDashboardText(id, value) {
    const el = document.getElementById(id);
    if (el) el.textContent = value;
}

function getDashboardMoney(value) {
    if (typeof formatAdminInvoiceMoney === 'function') return formatAdminInvoiceMoney(value);
    return '$' + (Number(value) || 0).toLocaleString('es-CO');
}

function getDashboardProductStock(product) {
    return Number(product?.Stock || product?.Cantidad || product?.['Stock Inicial'] || 0) || 0;
}

function getDashboardDateValue(row) {
    const raw = row?.Fecha || row?.fecha || row?.['Fecha Actualizacion'] || row?.['Fecha Actualización'] || '';
    if (!raw) return null;
    if (raw instanceof Date && !Number.isNaN(raw.getTime())) return raw;
    const parsed = new Date(raw);
    return Number.isNaN(parsed.getTime()) ? null : parsed;
}

function getDashboardTypeValue(row) {
    const raw = String(row?.['Tipo Cliente'] || row?.tipoCliente || row?.Tipo || row?.Catalogo || '').toLowerCase();
    if (raw.includes('mayor')) return 'mayor';
    if (raw.includes('consulta')) return 'consulta';
    const method = String(row?.['Metodo Contacto'] || row?.['Método Contacto'] || '').toLowerCase();
    if (method.includes('consulta')) return 'consulta';
    return 'detal';
}

function getDashboardStatusValue(row) {
    return String(row?.['Estado Pedido'] || row?.['Estado Factura'] || row?.Estado || 'Pendiente').trim() || 'Pendiente';
}

function getDashboardProductCategory(product) {
    if (typeof getProductField === 'function' && Array.isArray(PRODUCT_CATEGORY_FIELD_KEYS)) {
        return getProductField(product, PRODUCT_CATEGORY_FIELD_KEYS, '');
    }
    return product?.Categoria || product?.categoria || product?.CategoriaProducto || '';
}

function matchesDashboardDateRange(row, range) {
    if (!range || range === 'all') return true;
    const date = getDashboardDateValue(row);
    if (!date) return false;
    const now = new Date();
    const start = new Date(now);
    start.setHours(0, 0, 0, 0);
    if (range === 'today') return date >= start;
    const days = Number(range);
    if (!Number.isFinite(days)) return true;
    start.setDate(start.getDate() - Math.max(0, days - 1));
    return date >= start;
}

function getDashboardFilters() {
    return {
        range: document.getElementById('dashboard-range-filter')?.value || '30',
        type: document.getElementById('dashboard-type-filter')?.value || 'all',
        status: document.getElementById('dashboard-status-filter')?.value || 'all',
        category: document.getElementById('dashboard-category-filter')?.value || 'all',
        query: normalizeSearchText(document.getElementById('dashboard-query-filter')?.value || '')
    };
}

function filterDashboardRows(rows, filters) {
    return (rows || []).filter(row => {
        if (!matchesDashboardDateRange(row, filters.range)) return false;
        if (filters.type !== 'all' && getDashboardTypeValue(row) !== filters.type) return false;
        if (filters.status !== 'all' && normalizeSearchText(getDashboardStatusValue(row)) !== normalizeSearchText(filters.status)) return false;
        if (filters.query) {
            const blob = normalizeSearchText(JSON.stringify(row));
            if (!blob.includes(filters.query)) return false;
        }
        return true;
    });
}

function countByDashboardValue(rows, getValue) {
    return rows.reduce((acc, row) => {
        const key = String(getValue(row) || 'Sin dato').trim() || 'Sin dato';
        acc[key] = (acc[key] || 0) + 1;
        return acc;
    }, {});
}

function getDashboardPercent(value, total) {
    if (!total) return '0%';
    return Math.round((Number(value || 0) / total) * 100) + '%';
}

function renderDashboardChartRows(targetId, rows, options = {}) {
    const box = document.getElementById(targetId);
    if (!box) return;
    if (!rows.length) {
        box.innerHTML = '<div class="dashboard-empty">Sin datos para este filtro</div>';
        return;
    }
    const max = Math.max(...rows.map(row => Number(row.value || 0)), 1);
    box.innerHTML = rows.map(row => {
        const percent = Math.max(4, Math.round((Number(row.value || 0) / max) * 100));
        const valueText = options.money ? getDashboardMoney(row.value) : String(row.value);
        return `
            <div class="dashboard-chart-row">
                <div><strong>${escapeHtml(row.label)}</strong><span>${escapeHtml(row.detail || '')}</span></div>
                <div class="dashboard-bar-track"><div class="dashboard-chart-fill" style="width:${percent}%"></div></div>
                <em>${escapeHtml(valueText)}</em>
            </div>
        `;
    }).join('');
}

function syncDashboardSelectOptions(selectId, values, fallbackLabel) {
    const select = document.getElementById(selectId);
    if (!select) return;
    const current = select.value || 'all';
    const uniqueValues = Array.from(new Set((values || []).map(value => String(value || '').trim()).filter(Boolean)))
        .sort((a, b) => a.localeCompare(b, 'es'));
    select.innerHTML = `<option value="all">${fallbackLabel}</option>` + uniqueValues.map(value => `<option value="${escapeHtml(value)}">${escapeHtml(value)}</option>`).join('');
    select.value = uniqueValues.includes(current) ? current : 'all';
}

function syncDashboardDynamicFilters() {
    const orderStatuses = (window.pedidosList || []).map(getDashboardStatusValue);
    const productCategories = (inventario || [])
        .map(getDashboardProductCategory)
        .filter(category => normalizeSearchText(category) !== 'banner');
    syncDashboardSelectOptions('dashboard-status-filter', orderStatuses, 'Todos');
    syncDashboardSelectOptions('dashboard-category-filter', productCategories, 'Todas');
}

function ensureDashboardEnhancements() {
    const shell = document.querySelector('#view-dashboard .admin-dashboard-shell');
    if (!shell || shell.dataset.enhanced === '1') return;
    shell.dataset.enhanced = '1';

    const hero = shell.querySelector('.admin-dashboard-hero');
    hero?.insertAdjacentHTML('afterend', `
        <div class="dashboard-filter-bar">
            <label>Periodo
                <select class="form-control" id="dashboard-range-filter">
                    <option value="today">Hoy</option>
                    <option value="7">7 dias</option>
                    <option value="30" selected>30 dias</option>
                    <option value="90">90 dias</option>
                    <option value="all">Todo</option>
                </select>
            </label>
            <label>Tipo
                <select class="form-control" id="dashboard-type-filter">
                    <option value="all">Todos</option>
                    <option value="detal">Detal</option>
                    <option value="mayor">Mayorista</option>
                    <option value="consulta">Consultas</option>
                </select>
            </label>
            <label>Estado
                <select class="form-control" id="dashboard-status-filter">
                    <option value="all">Todos</option>
                </select>
            </label>
            <label>Categoria
                <select class="form-control" id="dashboard-category-filter">
                    <option value="all">Todas</option>
                </select>
            </label>
            <label>Buscar
                <input class="form-control" id="dashboard-query-filter" placeholder="Cliente, pedido, estado...">
            </label>
            <button type="button" class="admin-btn secondary" id="dashboard-clear-filters">Limpiar</button>
        </div>
    `);

    const statGrid = shell.querySelector('.dashboard-stat-grid');
    statGrid?.insertAdjacentHTML('afterend', `
        <details class="dashboard-extra-metrics"><summary>Ver métricas adicionales</summary><div class="dashboard-mini-grid">
            <article class="dashboard-stat-card"><span>Conversion</span><strong id="dash-conversion-rate">0%</strong><small>Facturas / pedidos filtrados</small></article>
            <article class="dashboard-stat-card"><span>Ticket promedio</span><strong id="dash-average-ticket">$0</strong><small>Promedio facturado</small></article>
            <article class="dashboard-stat-card"><span>Consultas</span><strong id="dash-consult-orders">0</strong><small>Pedidos por WhatsApp</small></article>
            <article class="dashboard-stat-card"><span>Valor inventario</span><strong id="dash-inventory-value">$0</strong><small>Stock x precio detal</small></article>
        </div></details>
    `);

    // Collapsible toggle buttons
    shell.querySelectorAll('.dashboard-toggle-btn').forEach(btn => {
        if (btn.dataset.bound) return;
        btn.dataset.bound = '1';
        const initialTarget = document.getElementById(btn.dataset.target);
        btn.setAttribute('aria-controls', btn.dataset.target);
        btn.setAttribute('aria-expanded', String(!initialTarget?.classList.contains('collapsed')));
        btn.querySelector('span').textContent = initialTarget?.classList.contains('collapsed') ? 'Mostrar' : 'Ocultar';
        btn.addEventListener('click', () => {
            const targetId = btn.dataset.target;
            const target = document.getElementById(targetId);
            if (!target) return;
            const isCollapsed = target.classList.toggle('collapsed');
            btn.classList.toggle('collapsed', isCollapsed);
            btn.setAttribute('aria-expanded', String(!isCollapsed));
            btn.querySelector('span').textContent = isCollapsed ? 'Mostrar' : 'Ocultar';
        });
    });

    ['dashboard-range-filter', 'dashboard-type-filter', 'dashboard-status-filter', 'dashboard-category-filter', 'dashboard-query-filter'].forEach(id => {
        document.getElementById(id)?.addEventListener('input', renderAdminDashboard);
        document.getElementById(id)?.addEventListener('change', renderAdminDashboard);
    });
    document.getElementById('dashboard-clear-filters')?.addEventListener('click', () => {
        setInputValue('dashboard-range-filter', '30');
        setInputValue('dashboard-type-filter', 'all');
        setInputValue('dashboard-status-filter', 'all');
        setInputValue('dashboard-category-filter', 'all');
        setInputValue('dashboard-query-filter', '');
        renderAdminDashboard();
    });
}

function renderAdminDashboard() {
    if (!document.getElementById('view-dashboard')) return;
    ensureDashboardEnhancements();
    syncDashboardDynamicFilters();
    const filters = getDashboardFilters();

    const allProducts = (inventario || []).filter(product => {
        const category = String(getDashboardProductCategory(product)).toUpperCase();
        const status = String(product?.Estado || product?.estado || 'Activo').toLowerCase();
        return category !== 'BANNER' && status !== 'inactivo';
    });
    const products = allProducts.filter(product => {
        const category = getDashboardProductCategory(product);
        return filters.category === 'all' || normalizeSearchText(category) === normalizeSearchText(filters.category);
    });
    const totalStock = products.reduce((sum, product) => sum + getDashboardProductStock(product), 0);
    const lowStockAll = products.filter(product => getDashboardProductStock(product) <= 3);
    const inventoryValue = products.reduce((sum, product) => {
        const stock = getDashboardProductStock(product);
        const price = Number(product?.Precio || 0) || 0;
        return sum + (stock * price);
    }, 0);

    const facturedOrderIds = typeof getFacturedOrderIds === 'function' ? getFacturedOrderIds() : new Set();
    const filteredOrders = filterDashboardRows(window.pedidosList || [], filters);
    const filteredInvoices = filterDashboardRows(window.facturasList || [], filters);
    const pendingOrders = filteredOrders.filter(order => {
        const id = String(typeof getOrderIdValue === 'function' ? getOrderIdValue(order) : (order?.['ID Pedido'] || '')).trim();
        const status = String(order?.['Estado Pedido'] || order?.Estado || '').toLowerCase();
        return !(id && facturedOrderIds.has(id)) && !status.includes('factur');
    });
    const consultOrders = filteredOrders.filter(order => getDashboardTypeValue(order) === 'consulta' || getDashboardStatusValue(order).toLowerCase().includes('consulta'));
    const totalSales = filteredInvoices.reduce((sum, invoice) => {
        const value = typeof parseAdminInvoiceMoney === 'function'
            ? parseAdminInvoiceMoney(invoice?.Subtotal || invoice?.Total || 0)
            : Number(invoice?.Subtotal || invoice?.Total || 0) || 0;
        return sum + value;
    }, 0);
    const averageTicket = filteredInvoices.length ? Math.round(totalSales / filteredInvoices.length) : 0;
    const conversionRate = getDashboardPercent(filteredInvoices.length, filteredOrders.length);

    setDashboardText('dash-total-sales', getDashboardMoney(totalSales));
    setDashboardText('dash-pending-orders', String(pendingOrders.length));
    setDashboardText('dash-active-products', String(products.length));
    setDashboardText('dash-total-stock', String(totalStock.toLocaleString('es-CO')));
    const stockSmall = document.querySelector('#dash-total-stock')?.closest('.dashboard-stat-card')?.querySelector('small');
    if (stockSmall) stockSmall.textContent = `${lowStockAll.length} en alerta (${getDashboardPercent(lowStockAll.length, products.length)})`;
    setDashboardText('dash-conversion-rate', conversionRate);
    setDashboardText('dash-average-ticket', getDashboardMoney(averageTicket));
    setDashboardText('dash-consult-orders', String(consultOrders.length));
    setDashboardText('dash-inventory-value', getDashboardMoney(inventoryValue));

    // â•â•â• Enhanced Low Stock with badges â•â•â•
    const lowStock = products
        .filter(product => getDashboardProductStock(product) <= 3)
        .sort((a, b) => getDashboardProductStock(a) - getDashboardProductStock(b))
        .slice(0, 8);
    const lowStockBox = document.getElementById('dash-low-stock');
    if (lowStockBox) {
        lowStockBox.innerHTML = lowStock.length ? lowStock.map(product => {
            const stock = getDashboardProductStock(product);
            const badgeClass = stock <= 1 ? 'critical' : 'warning';
            return `
            <div class="dashboard-stock-card">
                <div>
                    <strong style="display:block;font-size:12px;color:#fff">${escapeHtml(product.Nombre || product['Nombre del Producto'] || 'Producto')}</strong>
                    <span style="font-size:10.5px;font-weight:700;color:rgba(248,244,255,.56)">${escapeHtml(getDashboardProductCategory(product) || 'Sin categoria')}</span>
                </div>
                <span class="stock-badge ${badgeClass}">${stock} und.</span>
            </div>
        `;
        }).join('') : '<div class="dashboard-empty">No hay productos con stock bajo</div>';
    }
    setDashboardText('dash-stock-count', String(lowStock.length));

    // â•â•â• Enhanced Recent Orders with status dots â•â•â•
    const recentOrdersBox = document.getElementById('dash-recent-orders');
    if (recentOrdersBox) {
        const recent = [...filteredOrders]
            .sort((a, b) => (getDashboardDateValue(b)?.getTime() || 0) - (getDashboardDateValue(a)?.getTime() || 0))
            .slice(0, 8);
        recentOrdersBox.innerHTML = recent.length ? recent.map(order => {
            const id = typeof getOrderIdValue === 'function' ? getOrderIdValue(order) : (order?.['ID Pedido'] || '-');
            const total = typeof parseAdminInvoiceMoney === 'function'
                ? parseAdminInvoiceMoney(order?.Subtotal || order?.Total || 0)
                : Number(order?.Subtotal || order?.Total || 0) || 0;
            const statusRaw = String(order?.['Estado Pedido'] || order?.Estado || 'Pendiente').trim();
            const statusLower = statusRaw.toLowerCase();
            let statusClass = 'pending';
            if (statusLower.includes('pag') || statusLower.includes('aprobad')) statusClass = 'paid';
            else if (statusLower.includes('factur')) statusClass = 'invoiced';
            else if (statusLower.includes('cancel') || statusLower.includes('rechaz')) statusClass = 'cancelled';
            const clientName = escapeHtml(order?.['Nombre Cliente'] || order?.Nombre || 'Cliente');
            const clientType = escapeHtml(order?.['Tipo Cliente'] || order?.tipoCliente || '');
            return `
                <div class="dashboard-order-card">
                    <div class="dashboard-order-status-dot ${statusClass}"></div>
                    <div class="dashboard-order-info">
                        <strong>${escapeHtml(id || 'Pedido')}</strong>
                        <div class="order-meta">
                            <span>${clientName}${clientType ? ' · ' + clientType : ''}</span>
                            <span class="order-status-pill ${statusClass}">${escapeHtml(statusRaw)}</span>
                        </div>
                    </div>
                    <div class="dashboard-order-amount">${getDashboardMoney(total)}</div>
                </div>
            `;
        }).join('') : '<div class="dashboard-empty">No hay pedidos cargados</div>';
        setDashboardText('dash-orders-count', String(recent.length));
    }

    // â•â•â• Status bars â•â•â•
    const statusBars = document.getElementById('dash-status-bars');
    if (statusBars) {
        const statusCounts = countByDashboardValue(filteredOrders, getDashboardStatusValue);
        const rows = Object.entries(statusCounts)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 6);
        if (!rows.length) rows.push(['Sin pedidos', 0]);
        const max = Math.max(...rows.map(([, count]) => count), 1);
        statusBars.innerHTML = rows.map(([label, count]) => `
            <div class="dashboard-bar-row">
                <span>${escapeHtml(label)}</span>
                <div class="dashboard-bar-track"><div class="dashboard-bar-fill" style="width:${Math.max(8, Math.round((count / max) * 100))}%"></div></div>
                <strong>${count} (${getDashboardPercent(count, filteredOrders.length)})</strong>
            </div>
        `).join('');
    }

    // â•â•â• Canvas: Sales Line/Area Chart â•â•â•
    const salesByDay = {};
    filteredInvoices.forEach(invoice => {
        const date = getDashboardDateValue(invoice);
        const label = date ? date.toLocaleDateString('es-CO', { month: 'short', day: '2-digit' }) : 'Sin fecha';
        const value = typeof parseAdminInvoiceMoney === 'function'
            ? parseAdminInvoiceMoney(invoice?.Subtotal || invoice?.Total || 0)
            : Number(invoice?.Subtotal || invoice?.Total || 0) || 0;
        salesByDay[label] = (salesByDay[label] || 0) + value;
    });
    const salesEntries = Object.entries(salesByDay).slice(-12);
    drawDashboardAreaChart('dash-sales-canvas', 'dash-sales-legend', salesEntries, totalSales);

    // â•â•â• Canvas: Category Donut Chart â•â•â•
    const categoryCounts = countByDashboardValue(products, product => getDashboardProductCategory(product) || 'Sin categoria');
    const categoryEntries = Object.entries(categoryCounts)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 8);
    drawDashboardDonutChart('dash-category-canvas', 'dash-category-legend', categoryEntries, products.length);
}

// â•â•â• Canvas Drawing: Area Chart â•â•â•
function drawDashboardAreaChart(canvasId, legendId, entries, total) {
    const canvas = document.getElementById(canvasId);
    const legendBox = document.getElementById(legendId);
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.parentElement.getBoundingClientRect();
    const w = rect.width || 400;
    const h = 220;
    canvas.width = w * dpr;
    canvas.height = h * dpr;
    canvas.style.width = w + 'px';
    canvas.style.height = h + 'px';
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, w, h);

    if (!entries.length) {
        ctx.fillStyle = '#766771';
        ctx.font = '600 13px Inter, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('Sin datos de ventas', w / 2, h / 2);
        if (legendBox) legendBox.innerHTML = '';
        return;
    }

    const values = entries.map(([, v]) => v);
    const labels = entries.map(([l]) => l);
    const maxVal = Math.max(...values, 1);
    const padL = 62, padR = 16, padT = 24, padB = 38;
    const chartW = w - padL - padR;
    const chartH = h - padT - padB;

    // Grid lines + Y-axis labels
    const gridSteps = 4;
    ctx.strokeStyle = '#eadfe5';
    ctx.lineWidth = 1;
    ctx.fillStyle = '#766771';
    ctx.font = '700 10px Inter, sans-serif';
    ctx.textAlign = 'right';
    for (let i = 0; i <= gridSteps; i++) {
        const y = padT + (chartH / gridSteps) * i;
        ctx.beginPath();
        ctx.moveTo(padL, y);
        ctx.lineTo(w - padR, y);
        ctx.stroke();
        const val = maxVal - (maxVal / gridSteps) * i;
        ctx.fillText(getDashboardMoney(Math.round(val)), padL - 8, y + 4);
    }

    // X-axis labels
    ctx.textAlign = 'center';
    ctx.fillStyle = '#766771';
    ctx.font = '700 9px Inter, sans-serif';
    const step = entries.length > 1 ? chartW / (entries.length - 1) : 0;
    const points = values.map((v, i) => ({
        x: padL + step * i,
        y: padT + chartH - (v / maxVal) * chartH
    }));
    labels.forEach((l, i) => {
        ctx.fillText(l, points[i].x, h - padB + 16);
    });

    // Area gradient
    const grad = ctx.createLinearGradient(0, padT, 0, padT + chartH);
    grad.addColorStop(0, 'rgba(138,40,70,.18)');
    grad.addColorStop(1, 'rgba(138,40,70,.01)');
    ctx.beginPath();
    ctx.moveTo(points[0].x, padT + chartH);
    points.forEach(p => ctx.lineTo(p.x, p.y));
    ctx.lineTo(points[points.length - 1].x, padT + chartH);
    ctx.closePath();
    ctx.fillStyle = grad;
    ctx.fill();

    // Line
    const lineGrad = ctx.createLinearGradient(padL, 0, w - padR, 0);
    lineGrad.addColorStop(0, '#8a2846');
    lineGrad.addColorStop(1, '#087e80');
    ctx.beginPath();
    ctx.moveTo(points[0].x, points[0].y);
    for (let i = 1; i < points.length; i++) {
        const prev = points[i - 1];
        const curr = points[i];
        const cpx = (prev.x + curr.x) / 2;
        ctx.bezierCurveTo(cpx, prev.y, cpx, curr.y, curr.x, curr.y);
    }
    ctx.strokeStyle = lineGrad;
    ctx.lineWidth = 2.5;
    ctx.stroke();

    // Dots
    points.forEach((p, i) => {
        ctx.beginPath();
        ctx.arc(p.x, p.y, 4, 0, Math.PI * 2);
        ctx.fillStyle = i === points.length - 1 ? '#087e80' : '#8a2846';
        ctx.fill();
        ctx.strokeStyle = '#fff';
        ctx.lineWidth = 1.5;
        ctx.stroke();
    });

    if (legendBox) {
        const totalFormatted = getDashboardMoney(total);
        legendBox.innerHTML = `<div class="dashboard-chart-legend-item"><div class="dashboard-chart-legend-dot" style="background:linear-gradient(135deg,#8a2846,#087e80)"></div>Total: ${totalFormatted}</div><div class="dashboard-chart-legend-item"><div class="dashboard-chart-legend-dot" style="background:#087e80"></div>${entries.length} dias con ventas</div>`;
    }
}

// â•â•â• Canvas Drawing: Donut Chart â•â•â•
function drawDashboardDonutChart(canvasId, legendId, entries, total) {
    const canvas = document.getElementById(canvasId);
    const legendBox = document.getElementById(legendId);
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.parentElement.getBoundingClientRect();
    const w = rect.width || 300;
    const h = 220;
    canvas.width = w * dpr;
    canvas.height = h * dpr;
    canvas.style.width = w + 'px';
    canvas.style.height = h + 'px';
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, w, h);

    if (!entries.length) {
        ctx.fillStyle = '#766771';
        ctx.font = '600 13px Inter, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('Sin datos de categorias', w / 2, h / 2);
        if (legendBox) legendBox.innerHTML = '';
        return;
    }

    const donutColors = [
        '#8a2846', '#a55273', '#087e80', '#43aaa1',
        '#b9375e', '#ac7c55', '#746179', '#b52c46'
    ];

    const cx = w / 2;
    const cy = h / 2;
    const outerR = Math.min(cx, cy) - 12;
    const innerR = outerR * 0.58;
    const totalVal = entries.reduce((s, [, v]) => s + v, 0) || 1;

    let startAngle = -Math.PI / 2;
    entries.forEach(([label, value], i) => {
        const sliceAngle = (value / totalVal) * Math.PI * 2;
        const color = donutColors[i % donutColors.length];

        ctx.beginPath();
        ctx.arc(cx, cy, outerR, startAngle, startAngle + sliceAngle);
        ctx.arc(cx, cy, innerR, startAngle + sliceAngle, startAngle, true);
        ctx.closePath();
        ctx.fillStyle = color;
        ctx.fill();

        // Slice separator
        ctx.beginPath();
        ctx.arc(cx, cy, outerR, startAngle, startAngle + sliceAngle);
        ctx.arc(cx, cy, innerR, startAngle + sliceAngle, startAngle, true);
        ctx.closePath();
        ctx.strokeStyle = '#fff';
        ctx.lineWidth = 2;
        ctx.stroke();

        startAngle += sliceAngle;
    });

    // Center text
    ctx.fillStyle = '#352a32';
    ctx.font = '950 22px Inter, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(String(total), cx, cy - 8);
    ctx.fillStyle = '#766771';
    ctx.font = '800 10px Inter, sans-serif';
    ctx.fillText('PRODUCTOS', cx, cy + 12);

    if (legendBox) {
        legendBox.innerHTML = entries.map(([label, value], i) => {
            const color = donutColors[i % donutColors.length];
            const pct = getDashboardPercent(value, totalVal);
            return `<div class="dashboard-chart-legend-item"><div class="dashboard-chart-legend-dot" style="background:${color}"></div>${escapeHtml(label)} (${pct})</div>`;
        }).join('');
    }
}


function switchDashboardView(viewId, title) {
    if (viewId === 'inventory' || viewId === 'products') window.OriginalStoreRetailPricing?.load().catch(() => {});
    document.querySelectorAll('.dashboard-section').forEach(function (el) { el.classList.remove('active'); });
    document.querySelectorAll('.sidebar-btn').forEach(function (el) { el.classList.remove('active'); });
    var target = document.getElementById('view-' + viewId);
    if (target) target.classList.add('active');
    var btn = document.querySelector('.sidebar-btn[data-view="' + viewId + '"]') || document.querySelector('.sidebar-btn[onclick*="' + viewId + '"]');
    document.querySelectorAll('.sidebar-btn[data-view="' + viewId + '"]').forEach(el => el.classList.add('active'));
    var titleEl = document.getElementById('current-section-title');
    if (titleEl) titleEl.textContent = title || 'Panel';
    var mobileSelect = document.getElementById('admin-mobile-view-select');
    if (mobileSelect && mobileSelect.value !== viewId) mobileSelect.value = viewId;
    var sectionDrawer = document.getElementById('admin-section-drawer');
    if (sectionDrawer) {
        sectionDrawer.classList.remove('open');
        document.getElementById('admin-section-toggle')?.setAttribute('aria-expanded', 'false');
    }
    var area = document.querySelector('.dashboard-content-area');
    if (area) {
        area.scrollTop = 0;
        area.scrollLeft = 0;
    }

    if (viewId === 'users' && typeof loadCustomerUsers === 'function')loadCustomerUsers();
    if (viewId === 'quick-sale') {
        syncQuickSaleMobilePane();
        if (!Array.isArray(inventario) || !inventario.length) {
            cargarInventario({ silent: true }).then(renderQuickSaleResults).catch(() => {});
        } else {
            renderQuickSaleResults();
        }
    }
    if (viewId === 'orders') {
        cargarPedidos();
    }
    if (viewId === 'china-orders') {
        fetchChinaOrdersFromServer();
    }
    if (viewId === 'dashboard') {
        renderAdminDashboard();
    }
    if (viewId === 'settings' && typeof window.activateSettingsTab === 'function') {
        window.activateSettingsTab('storefront');
    }
}

window.switchDashboardView = switchDashboardView;

// Compatibility for existing shortcuts: the ticket now has its own section.
function openQuickSaleInOrders() {
    switchDashboardView('quick-sale', 'Caja rápida');
}

// === LÃ“GICA DE PEDIDOS Y FACTURACIÃ“N DIGITAL ===
const CHINA_ORDER_DRAFT_KEY = 'blyxu_admin_china_order_draft_v1';
const CHINA_ORDER_SAVED_KEY = 'blyxu_admin_china_saved_orders_v1';
const CHINA_ORDER_DB_NAME = 'blyxu_admin_china_orders_db';
const CHINA_ORDER_DB_VERSION = 1;
const CHINA_ORDER_STORE_NAME = 'chinaOrders';
const CHINA_ORDER_SAVED_RECORD_KEY = 'savedOrders';
const CHINA_ORDER_DRAFT_RECORD_KEY = 'draft';
const ADMIN_COST_CALCULATOR_KEY = 'blyxu_admin_cost_calculator_v1';
const ADMIN_MARKET_RATES_CACHE_KEY = 'blyxu_admin_market_rates_cache_v1';
const ADMIN_MARKET_RATES_URL = 'https://open.er-api.com/v6/latest/USD';
let activeChinaOrderId = '';
let chinaOrdersDbPromise = null;
let savedChinaOrdersCache = [];
let chinaOrderDraftSaveTimer = null;
let isHydratingChinaOrder = false;

function openChinaOrdersDb() {
    if (!window.indexedDB) {
        return Promise.reject(new Error('IndexedDB no esta disponible'));
    }
    if (chinaOrdersDbPromise) return chinaOrdersDbPromise;

    chinaOrdersDbPromise = new Promise((resolve, reject) => {
        const request = indexedDB.open(CHINA_ORDER_DB_NAME, CHINA_ORDER_DB_VERSION);
        request.onupgradeneeded = event => {
            const db = event.target.result;
            if (!db.objectStoreNames.contains(CHINA_ORDER_STORE_NAME)) {
                db.createObjectStore(CHINA_ORDER_STORE_NAME, { keyPath: 'key' });
            }
        };
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error || new Error('No se pudo abrir el almacen local'));
    });

    return chinaOrdersDbPromise;
}

function readChinaOrderStoreValue(key) {
    return openChinaOrdersDb().then(db => new Promise((resolve, reject) => {
        const transaction = db.transaction(CHINA_ORDER_STORE_NAME, 'readonly');
        const request = transaction.objectStore(CHINA_ORDER_STORE_NAME).get(key);
        request.onsuccess = () => resolve(request.result ? request.result.value : null);
        request.onerror = () => reject(request.error || new Error('No se pudo leer el almacen local'));
    }));
}

function writeChinaOrderStoreValue(key, value) {
    return openChinaOrdersDb().then(db => new Promise((resolve, reject) => {
        const transaction = db.transaction(CHINA_ORDER_STORE_NAME, 'readwrite');
        transaction.objectStore(CHINA_ORDER_STORE_NAME).put({
            key,
            value,
            updatedAt: Date.now()
        });
        transaction.oncomplete = () => resolve(true);
        transaction.onerror = () => reject(transaction.error || new Error('No se pudo guardar en el almacen local'));
        transaction.onabort = () => reject(transaction.error || new Error('Guardado local cancelado'));
    }));
}

function deleteChinaOrderStoreValue(key) {
    return openChinaOrdersDb().then(db => new Promise((resolve, reject) => {
        const transaction = db.transaction(CHINA_ORDER_STORE_NAME, 'readwrite');
        transaction.objectStore(CHINA_ORDER_STORE_NAME).delete(key);
        transaction.oncomplete = () => resolve(true);
        transaction.onerror = () => reject(transaction.error || new Error('No se pudo borrar del almacen local'));
        transaction.onabort = () => reject(transaction.error || new Error('Borrado local cancelado'));
    }));
}

function formatChinaUsd(value) {
    return 'US$' + (Number(value) || 0).toLocaleString('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

function formatChinaCop(value) {
    return '$' + Math.round(Number(value) || 0).toLocaleString('es-CO');
}

function parseChinaNumber(value) {
    const raw = String(value ?? '').trim();
    if (!raw) return 0;
    const normalized = raw.includes(',') && !raw.includes('.')
        ? raw.replace(',', '.')
        : raw.replace(/,/g, '');
    return parseFloat(normalized.replace(/[^0-9.-]/g, '')) || 0;
}

function formatCostCny(value) {
    return 'CNY ' + (Number(value) || 0).toLocaleString('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

function convertAdminCostToCop(value, currency, rates) {
    const amount = Math.max(0, parseChinaNumber(value));
    const selectedCurrency = String(currency || 'COP').toUpperCase();
    if (selectedCurrency === 'USD') return amount * Math.max(0, rates.usdRate || 0);
    if (selectedCurrency === 'CNY') return amount * Math.max(0, rates.cnyRate || 0);
    return amount;
}

function formatAdminCostAlt(copValue, rates) {
    const cop = Math.max(0, Number(copValue) || 0);
    const usdRate = Math.max(0, rates.usdRate || 0);
    const cnyRate = Math.max(0, rates.cnyRate || 0);
    const usd = usdRate ? cop / usdRate : 0;
    const cny = cnyRate ? cop / cnyRate : 0;
    return `${formatChinaUsd(usd)} / ${formatCostCny(cny)}`;
}

function readAdminCostCalculatorState() {
    try {
        const state = JSON.parse(localStorage.getItem(ADMIN_COST_CALCULATOR_KEY) || 'null');
        return state && typeof state === 'object' ? state : {};
    } catch (error) {
        return {};
    }
}

function writeAdminCostCalculatorState(state) {
    try {
        localStorage.setItem(ADMIN_COST_CALCULATOR_KEY, JSON.stringify(state));
    } catch (error) {
        console.warn('No se pudo guardar calculadora de costos:', error);
    }
}

function setAdminMarketRateStatus(message, type = 'info') {
    const el = document.getElementById('calc-market-status');
    if (!el) return;
    const color = type === 'error'
        ? 'rgba(217,176,176,.88)'
        : type === 'success'
            ? 'rgba(186,208,194,.88)'
            : 'rgba(244,242,238,.54)';
    el.style.color = color;
    el.innerHTML = `${escapeHtml(message)} Tasas por <a href="https://www.exchangerate-api.com" target="_blank" rel="noopener">ExchangeRate-API</a>.`;
}

function readAdminMarketRatesCache() {
    try {
        const cached = JSON.parse(localStorage.getItem(ADMIN_MARKET_RATES_CACHE_KEY) || 'null');
        return cached && typeof cached === 'object' ? cached : null;
    } catch (error) {
        return null;
    }
}

function writeAdminMarketRatesCache(payload) {
    try {
        localStorage.setItem(ADMIN_MARKET_RATES_CACHE_KEY, JSON.stringify(payload));
    } catch (error) {
        console.warn('No se pudo guardar cache de tasas:', error);
    }
}

function isAdminMarketRatesCacheFresh(cached) {
    if (!cached?.usdRate || !cached?.cnyRate) return false;
    const now = Date.now();
    if (cached.nextUpdateUnix && now < (Number(cached.nextUpdateUnix) * 1000)) return true;
    return cached.savedAt && now - Number(cached.savedAt) < 6 * 60 * 60 * 1000;
}

function formatAdminMarketDate(value) {
    const date = value ? new Date(value) : null;
    if (!date || Number.isNaN(date.getTime())) return '';
    return date.toLocaleString('es-CO', {
        day: '2-digit',
        month: 'short',
        hour: '2-digit',
        minute: '2-digit'
    });
}

async function fetchAdminMarketRates(options = {}) {
    const cached = readAdminMarketRatesCache();
    if (!options.force && isAdminMarketRatesCacheFresh(cached)) return cached;

    const response = await fetch(ADMIN_MARKET_RATES_URL, { cache: 'no-store' });
    if (!response.ok) throw new Error('No se pudo consultar la tasa de mercado');
    const data = await response.json();
    if (data?.result !== 'success' || !data?.rates?.COP || !data?.rates?.CNY) {
        throw new Error('La respuesta de mercado no trae COP o CNY');
    }

    const usdRate = Number(data.rates.COP) || 0;
    const usdToCny = Number(data.rates.CNY) || 0;
    const cnyRate = usdToCny ? usdRate / usdToCny : 0;
    if (!usdRate || !cnyRate) throw new Error('Tasa de mercado invalida');

    const payload = {
        usdRate,
        cnyRate,
        savedAt: Date.now(),
        lastUpdateUtc: data.time_last_update_utc || '',
        nextUpdateUnix: data.time_next_update_unix || 0
    };
    writeAdminMarketRatesCache(payload);
    return payload;
}

function applyAdminMarketRatesToCalculator(rates, target = 'all') {
    const usdInput = document.getElementById('calc-usd-rate');
    const cnyInput = document.getElementById('calc-cny-rate');
    if ((target === 'all' || target === 'USD') && usdInput) {
        usdInput.value = String(Math.round(Number(rates.usdRate) || 0));
    }
    if ((target === 'all' || target === 'CNY') && cnyInput) {
        cnyInput.value = String((Number(rates.cnyRate) || 0).toFixed(2));
    }
    calculateAdminCostCalculator({ save: true });
}

async function useAdminMarketRate(target = 'all') {
    const label = target === 'USD' ? 'TRM USD' : target === 'CNY' ? 'Yuan' : 'tasas';
    setAdminMarketRateStatus(`Actualizando ${label} de mercado...`);
    try {
        const rates = await fetchAdminMarketRates({ force: false });
        applyAdminMarketRatesToCalculator(rates, target);
        const updatedAt = formatAdminMarketDate(rates.lastUpdateUtc || rates.savedAt);
        setAdminMarketRateStatus(`Tasa de mercado aplicada${updatedAt ? ` (${updatedAt})` : ''}. Puedes editarla manualmente si necesitas otro TRM.`, 'success');
    } catch (error) {
        console.warn('No se pudo actualizar tasa de mercado:', error);
        const cached = readAdminMarketRatesCache();
        if (cached?.usdRate && cached?.cnyRate) {
            applyAdminMarketRatesToCalculator(cached, target);
            setAdminMarketRateStatus('No se pudo actualizar en vivo; use la ultima tasa guardada.', 'error');
            return;
        }
        setAdminMarketRateStatus('No se pudo consultar el mercado; conserva o escribe tu TRM manual.', 'error');
    }
}

function getAdminCostCalculatorState() {
    const usdRateFallback = document.getElementById('china-order-rate')?.value || '4000';
    return {
        quantity: document.getElementById('calc-quantity')?.value || '1',
        currency: document.getElementById('calc-currency')?.value || 'USD',
        unitCost: document.getElementById('calc-unit-cost')?.value || '',
        usdRate: document.getElementById('calc-usd-rate')?.value || usdRateFallback,
        cnyRate: document.getElementById('calc-cny-rate')?.value || '560',
        shipping: document.getElementById('calc-shipping')?.value || '',
        shippingCurrency: document.getElementById('calc-shipping-currency')?.value || 'COP',
        taxPercent: document.getElementById('calc-tax-percent')?.value || '',
        profitPercent: document.getElementById('calc-profit-percent')?.value || '50'
    };
}

function setAdminCostText(id, value) {
    const el = document.getElementById(id);
    if (el) el.textContent = value;
}

function calculateAdminCostCalculator(options = {}) {
    const state = getAdminCostCalculatorState();
    const quantity = Math.max(1, parseChinaNumber(state.quantity || 1));
    const rates = {
        usdRate: Math.max(0, parseChinaNumber(state.usdRate || 0)),
        cnyRate: Math.max(0, parseChinaNumber(state.cnyRate || 0))
    };
    const unitCostCop = convertAdminCostToCop(state.unitCost, state.currency, rates);
    const shippingCop = convertAdminCostToCop(state.shipping, state.shippingCurrency, rates);
    const productSubtotalCop = unitCostCop * quantity;
    const baseCostCop = productSubtotalCop + shippingCop;
    const taxPercent = Math.max(0, parseChinaNumber(state.taxPercent || 0));
    const profitPercent = Math.max(0, parseChinaNumber(state.profitPercent || 0));
    const taxCop = baseCostCop * (taxPercent / 100);
    const totalCostCop = baseCostCop + taxCop;
    const finalUnitCostCop = totalCostCop / quantity;
    const saleUnitCop = finalUnitCostCop * (1 + (profitPercent / 100));
    const saleTotalCop = saleUnitCop * quantity;
    const profitCop = Math.max(0, saleTotalCop - totalCostCop);

    setAdminCostText('calc-result-unit-cost', formatChinaCop(finalUnitCostCop));
    setAdminCostText('calc-result-unit-cost-alt', formatAdminCostAlt(finalUnitCostCop, rates));
    setAdminCostText('calc-result-total-cost', formatChinaCop(totalCostCop));
    setAdminCostText('calc-result-total-cost-alt', formatAdminCostAlt(totalCostCop, rates));
    setAdminCostText('calc-result-sale-unit', formatChinaCop(saleUnitCop));
    setAdminCostText('calc-result-sale-unit-alt', formatAdminCostAlt(saleUnitCop, rates));
    setAdminCostText('calc-result-profit', formatChinaCop(profitCop));
    setAdminCostText(
        'calc-result-breakdown',
        `Base ${formatChinaCop(productSubtotalCop)} + envio ${formatChinaCop(shippingCop)} + impuesto ${formatChinaCop(taxCop)} | Venta total ${formatChinaCop(saleTotalCop)}`
    );

    if (options.save !== false) writeAdminCostCalculatorState(state);
    return { state, rates, totalCostCop, finalUnitCostCop, saleUnitCop, saleTotalCop, profitCop, taxCop, shippingCop, productSubtotalCop };
}

function copyAdminCostCalculatorResult() {
    const result = calculateAdminCostCalculator({ save: true });
    const lines = [
        'Calculadora Original Store',
        `Cantidad: ${result.state.quantity || 1}`,
        `Costo unitario origen: ${result.state.unitCost || 0} ${result.state.currency}`,
        `Tasa USD: ${formatChinaCop(result.rates.usdRate)} | Tasa Yuan: ${formatChinaCop(result.rates.cnyRate)}`,
        `Costo unitario final: ${formatChinaCop(result.finalUnitCostCop)} (${formatAdminCostAlt(result.finalUnitCostCop, result.rates)})`,
        `Costo total final: ${formatChinaCop(result.totalCostCop)} (${formatAdminCostAlt(result.totalCostCop, result.rates)})`,
        `Precio sugerido unidad: ${formatChinaCop(result.saleUnitCop)} (${formatAdminCostAlt(result.saleUnitCop, result.rates)})`,
        `Venta total sugerida: ${formatChinaCop(result.saleTotalCop)}`,
        `Ganancia estimada: ${formatChinaCop(result.profitCop)}`
    ].join('\n');

    if (navigator.clipboard?.writeText) {
        navigator.clipboard.writeText(lines).then(() => {
            if (typeof showToast === 'function') showToast('Resultado copiado', 'success');
        }).catch(() => fallbackCopyChinaOrderSummary(lines));
        return;
    }
    fallbackCopyChinaOrderSummary(lines);
}

function clearAdminCostCalculator() {
    const usdRate = document.getElementById('china-order-rate')?.value || '4000';
    const defaults = {
        'calc-quantity': '1',
        'calc-currency': 'USD',
        'calc-unit-cost': '',
        'calc-usd-rate': usdRate,
        'calc-cny-rate': '560',
        'calc-shipping': '',
        'calc-shipping-currency': 'COP',
        'calc-tax-percent': '',
        'calc-profit-percent': '50'
    };
    Object.entries(defaults).forEach(([id, value]) => {
        const el = document.getElementById(id);
        if (el) el.value = value;
    });
    calculateAdminCostCalculator({ save: true });
}

function initAdminCostCalculator() {
    const drawer = document.getElementById('admin-cost-calculator');
    const toggle = document.getElementById('cost-calculator-toggle');
    if (!drawer || drawer.dataset.ready === 'true') return;
    drawer.dataset.ready = 'true';

    const saved = readAdminCostCalculatorState();
    const usdRateFallback = document.getElementById('china-order-rate')?.value || '4000';
    const values = {
        'calc-quantity': saved.quantity || '1',
        'calc-currency': saved.currency || 'USD',
        'calc-unit-cost': saved.unitCost || '',
        'calc-usd-rate': saved.usdRate || usdRateFallback,
        'calc-cny-rate': saved.cnyRate || '560',
        'calc-shipping': saved.shipping || '',
        'calc-shipping-currency': saved.shippingCurrency || 'COP',
        'calc-tax-percent': saved.taxPercent || '',
        'calc-profit-percent': saved.profitPercent || '50'
    };
    Object.entries(values).forEach(([id, value]) => {
        const el = document.getElementById(id);
        if (el) el.value = value;
    });

    const setOpen = open => {
        drawer.classList.toggle('open', Boolean(open));
        toggle?.setAttribute('aria-expanded', open ? 'true' : 'false');
    };

    toggle?.addEventListener('click', () => setOpen(!drawer.classList.contains('open')));
    document.getElementById('cost-calculator-close')?.addEventListener('click', () => setOpen(false));
    document.querySelectorAll('[data-cost-calc]').forEach(input => {
        input.addEventListener('input', () => calculateAdminCostCalculator());
        input.addEventListener('change', () => calculateAdminCostCalculator());
    });
    document.getElementById('calc-usd-rate')?.addEventListener('input', () => {
        setAdminMarketRateStatus('TRM USD personalizado activo.');
    });
    document.getElementById('calc-cny-rate')?.addEventListener('input', () => {
        setAdminMarketRateStatus('Tasa Yuan personalizada activa.');
    });
    document.getElementById('calc-copy-result')?.addEventListener('click', copyAdminCostCalculatorResult);
    document.getElementById('calc-clear')?.addEventListener('click', clearAdminCostCalculator);
    document.getElementById('calc-usd-market-rate')?.addEventListener('click', () => useAdminMarketRate('USD'));
    document.getElementById('calc-cny-market-rate')?.addEventListener('click', () => useAdminMarketRate('CNY'));
    document.getElementById('china-order-rate')?.addEventListener('change', event => {
        const usdRateEl = document.getElementById('calc-usd-rate');
        const savedState = readAdminCostCalculatorState();
        if (usdRateEl && !savedState.usdRate) {
            usdRateEl.value = event.target.value || '4000';
            calculateAdminCostCalculator();
        }
    });

    calculateAdminCostCalculator({ save: false });
    const cachedRates = readAdminMarketRatesCache();
    if (cachedRates?.savedAt) {
        const cachedAt = formatAdminMarketDate(cachedRates.lastUpdateUtc || cachedRates.savedAt);
        setAdminMarketRateStatus(`Ultima tasa de mercado guardada${cachedAt ? `: ${cachedAt}` : ''}. Puedes usar Mercado o escribir tu TRM manual.`);
    }
}

function getChinaOrderRows() {
    return Array.from(document.querySelectorAll('#china-order-items tr[data-china-order-row]'));
}

function collectChinaOrderDraft() {
    const rows = getChinaOrderRows().map(row => ({
        product: row.querySelector('[data-china-field="product"]')?.value || '',
        reference: row.querySelector('[data-china-field="reference"]')?.value || '',
        quantity: row.querySelector('[data-china-field="quantity"]')?.value || '1',
        unitUsd: row.querySelector('[data-china-field="unitUsd"]')?.value || '',
        image: row.dataset.image || ''
    }));

    const showUsdEl = document.getElementById('china-show-usd');
    const showCopEl = document.getElementById('china-show-cop');
    const showRefEl = document.getElementById('china-show-ref');

    return {
        id: activeChinaOrderId || '',
        factory: document.getElementById('china-order-factory')?.value || '',
        rate: document.getElementById('china-order-rate')?.value || '4000',
        notes: document.getElementById('china-order-notes')?.value || '',
        showUsd: showUsdEl ? showUsdEl.checked : true,
        showCop: showCopEl ? showCopEl.checked : true,
        showRef: showRefEl ? showRefEl.checked : true,
        rows
    };
}

function getChinaOrderTotalsFromDraft(draft) {
    const rate = parseChinaNumber(draft?.rate || 0);
    const rows = Array.isArray(draft?.rows) ? draft.rows : [];
    const totalUsd = rows.reduce((sum, item) => {
        const quantity = Math.max(0, parseChinaNumber(item.quantity || 0));
        const unitUsd = Math.max(0, parseChinaNumber(item.unitUsd || 0));
        return sum + (quantity * unitUsd);
    }, 0);

    return {
        rate,
        totalUsd,
        totalCop: totalUsd * rate,
        itemCount: rows.length,
        totalQuantity: rows.reduce((sum, item) => sum + Math.max(0, parseChinaNumber(item.quantity || 0)), 0)
    };
}

function getSavedChinaOrders() {
    return savedChinaOrdersCache;
}

function readSavedChinaOrdersFromLocalStorage() {
    try {
        const list = JSON.parse(localStorage.getItem(CHINA_ORDER_SAVED_KEY) || '[]');
        return Array.isArray(list) ? list : [];
    } catch (error) {
        return [];
    }
}

function readChinaOrderDraftFromLocalStorage() {
    try {
        const draft = JSON.parse(localStorage.getItem(CHINA_ORDER_DRAFT_KEY) || 'null');
        return draft && Array.isArray(draft.rows) ? draft : null;
    } catch (error) {
        return null;
    }
}

async function readSavedChinaOrdersFromStorage() {
    try {
        const list = await readChinaOrderStoreValue(CHINA_ORDER_SAVED_RECORD_KEY);
        if (Array.isArray(list)) return list;
    } catch (error) {
        console.warn('No se pudo leer IndexedDB para pedidos a China:', error);
    }
    return readSavedChinaOrdersFromLocalStorage();
}

async function readChinaOrderDraftFromStorage() {
    try {
        const draft = await readChinaOrderStoreValue(CHINA_ORDER_DRAFT_RECORD_KEY);
        if (draft && Array.isArray(draft.rows)) return draft;
    } catch (error) {
        console.warn('No se pudo leer el borrador grande:', error);
    }
    return readChinaOrderDraftFromLocalStorage();
}

async function migrateLegacyChinaOrdersToIndexedDb() {
    if (!window.indexedDB) return;

    const legacySaved = readSavedChinaOrdersFromLocalStorage();
    const legacyDraft = readChinaOrderDraftFromLocalStorage();

    if (legacySaved.length) {
        const savedInDb = await readChinaOrderStoreValue(CHINA_ORDER_SAVED_RECORD_KEY);
        if (!Array.isArray(savedInDb) || !savedInDb.length) {
            await writeChinaOrderStoreValue(CHINA_ORDER_SAVED_RECORD_KEY, legacySaved);
        }
        localStorage.removeItem(CHINA_ORDER_SAVED_KEY);
    }

    if (legacyDraft) {
        const draftInDb = await readChinaOrderStoreValue(CHINA_ORDER_DRAFT_RECORD_KEY);
        if (!draftInDb || !Array.isArray(draftInDb.rows)) {
            await writeChinaOrderStoreValue(CHINA_ORDER_DRAFT_RECORD_KEY, legacyDraft);
        }
        localStorage.removeItem(CHINA_ORDER_DRAFT_KEY);
    }
}

async function writeSavedChinaOrders(list) {
    const rawList = Array.isArray(list) ? list : [];
    const seen = new Set();
    const normalizedList = [];
    for (const item of rawList) {
        const id = String(item?.id || '').trim();
        if (id) {
            if (seen.has(id)) continue;
            seen.add(id);
        }
        normalizedList.push(item);
    }
    try {
        await writeChinaOrderStoreValue(CHINA_ORDER_SAVED_RECORD_KEY, normalizedList);
        savedChinaOrdersCache = normalizedList;
        try {
            localStorage.removeItem(CHINA_ORDER_SAVED_KEY);
        } catch (error) {
            console.warn('No se pudo limpiar historial viejo:', error);
        }
        return true;
    } catch (error) {
        console.warn('IndexedDB fallo al guardar pedido a China. Intentando respaldo pequeno:', error);
    }

    try {
        localStorage.setItem(CHINA_ORDER_SAVED_KEY, JSON.stringify(normalizedList));
        savedChinaOrdersCache = normalizedList;
        return true;
    } catch (error) {
        showToast('No se pudo guardar: el navegador se quedo sin espacio. Quita fotos muy pesadas o libera almacenamiento del sitio.', 'error');
        return false;
    }
}

function makeChinaOrderId() {
    const datePart = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    return 'CHN-' + datePart + '-' + String(Date.now()).slice(-5);
}

function makeChinaOrderRecord(draft = collectChinaOrderDraft(), existing = null) {
    const totals = getChinaOrderTotalsFromDraft(draft);
    const now = new Date().toISOString();
    const orderId = existing?.id || draft?.id || activeChinaOrderId || makeChinaOrderId();
    activeChinaOrderId = orderId;
    return {
        id: orderId,
        createdAt: existing?.createdAt || draft?.createdAt || now,
        updatedAt: now,
        factory: draft.factory || '',
        rate: draft.rate || '4000',
        notes: draft.notes || '',
        showUsd: draft.showUsd !== false,
        showCop: draft.showCop !== false,
        showRef: draft.showRef !== false,
        rows: Array.isArray(draft.rows) ? draft.rows : [],
        totalUsd: totals.totalUsd,
        totalCop: totals.totalCop,
        totalQuantity: totals.totalQuantity
    };
}

function formatChinaOrderImageUrl(url) {
    if (!url) return '';
    if (typeof url !== 'string') return '';
    const raw = url.trim();
    if (!raw) return '';
    if (raw.startsWith('data:image/')) return raw;
    if (raw.startsWith('blob:')) return raw;

    const driveMatch = raw.match(/drive\.google\.com\/file\/d\/([^/?&#]+)/) ||
                       raw.match(/drive\.google\.com\/uc\?(?:[^&]+&)*id=([^&#]+)/) ||
                       raw.match(/drive\.google\.com\/open\?(?:[^&]+&)*id=([^&#]+)/) ||
                       raw.match(/drive\.google\.com\/thumbnail\?(?:[^&]+&)*id=([^&#]+)/) ||
                       raw.match(/lh3\.googleusercontent\.com\/d\/([^/?&#]+)/) ||
                       raw.match(/[?&]id=([^&#]+)/);

    if (driveMatch && driveMatch[1]) {
        return `https://drive.google.com/thumbnail?id=${encodeURIComponent(driveMatch[1])}&sz=w800`;
    }

    if (raw.startsWith('//')) return `https:${raw}`;
    return raw;
}

async function uploadChinaImageToDrive(dataUrl) {
    if (!dataUrl || !dataUrl.startsWith('data:image/')) return dataUrl;
    try {
        const parts = dataUrl.split(',');
        const mimeMatch = parts[0].match(/:(.*?);/);
        const mimeType = mimeMatch ? mimeMatch[1] : 'image/jpeg';
        const base64Data = parts[1];
        const fileName = 'china_' + Date.now() + '_' + Math.floor(Math.random() * 1000) + '.jpg';
        
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 14000);

        const res = await fetch(GOOGLE_SHEET_API, {
            method: 'POST',
            body: JSON.stringify({
                action: 'uploadimage',
                mimeType,
                fileName,
                base64Data
            }),
            signal: controller.signal
        });
        clearTimeout(timeoutId);
        const json = await res.json();
        if (json && (json.ok || json.status === 'success') && (json.url || json.directUrl)) {
            return json.url || json.directUrl;
        }
    } catch (e) {
        console.warn('Error subiendo imagen de China a Drive:', e);
    }
    return dataUrl;
}

async function fetchChinaOrdersFromServer() {
    try {
        const res = await fetch(`${GOOGLE_SHEET_API}?resource=pedidoschina&t=${Date.now()}`);
        const result = await res.json();
        if (result && (result.ok || result.status === 'success') && Array.isArray(result.data)) {
            const seen = new Set();
            const mapped = [];
            for (const row of result.data) {
                const id = String(row['ID Pedido'] || row.id || '').trim();
                if (id && seen.has(id)) continue;
                if (id) seen.add(id);

                let rows = row['Productos JSON'] || row.productos || [];
                if (typeof rows === 'string') {
                    try { rows = JSON.parse(rows); } catch (e) { rows = []; }
                }
                mapped.push({
                    id: id || makeChinaOrderId(),
                    createdAt: row['Fecha'] || row.createdAt || new Date().toISOString(),
                    updatedAt: row['Fecha Actualización'] || row['Fecha'] || new Date().toISOString(),
                    factory: row['Fábrica'] || row.fabrica || '',
                    rate: row['TRM'] || '4000',
                    notes: row['Notas'] || '',
                    showUsd: String(row['Mostrar USD'] || '').toLowerCase() !== 'falso',
                    showCop: String(row['Mostrar COP'] || '').toLowerCase() !== 'falso',
                    showRef: String(row['Mostrar Ref'] || '').toLowerCase() !== 'falso' && row.showRef !== false,
                    rows: Array.isArray(rows) ? rows : [],
                    totalUsd: Number(row['Total USD']) || 0,
                    totalCop: Number(row['Total COP']) || 0,
                    totalQuantity: Number(row['Total Piezas']) || 0
                });
            }
            savedChinaOrdersCache = mapped;
            await writeSavedChinaOrders(mapped);
            renderSavedChinaOrders();
            return mapped;
        }
    } catch (err) {
        console.warn('Error cargando pedidos a China desde la nube:', err);
    }
    return savedChinaOrdersCache;
}

async function saveCurrentChinaOrder(options = {}) {
    const draft = collectChinaOrderDraft();
    const hasProduct = draft.rows.some(item => String(item.product || item.reference || item.unitUsd || '').trim());
    if (!hasProduct) {
        if (!options.silent) showToast('Agrega al menos un producto antes de guardar', 'warning');
        return null;
    }

    const saveButton = document.getElementById('btn-save-china-order');
    const previousButtonText = saveButton ? saveButton.textContent : '';
    if (saveButton && !options.silent) {
        saveButton.disabled = true;
        saveButton.textContent = 'Guardando pedido...';
    }

    // 1. Guardar primero en almacenamiento local / borrador para respuesta y seguridad inmediata
    const currentId = activeChinaOrderId || draft.id;
    const saved = getSavedChinaOrders().slice();
    const existingIndex = currentId
        ? saved.findIndex(order => String(order.id).trim() === String(currentId).trim())
        : -1;
    const existing = existingIndex >= 0 ? saved[existingIndex] : null;
    const record = makeChinaOrderRecord(draft, existing);

    activeChinaOrderId = record.id;
    if (existingIndex >= 0) saved[existingIndex] = record;
    else saved.unshift(record);

    await writeSavedChinaOrders(saved);
    renderSavedChinaOrders();
    await saveChinaOrderDraft({ immediate: true });

    // 2. Subir fotos locales a Drive en PARALELO para máxima velocidad
    const domRows = getChinaOrderRows();
    const imagesToUpload = [];
    draft.rows.forEach((item, idx) => {
        if (item.image && item.image.startsWith('data:image/')) {
            imagesToUpload.push({ index: idx, dataUrl: item.image });
        }
    });

    if (imagesToUpload.length > 0) {
        if (saveButton && !options.silent) {
            saveButton.textContent = `Subiendo ${imagesToUpload.length} foto(s)...`;
        }
        await Promise.all(imagesToUpload.map(async entry => {
            const uploadedUrl = await uploadChinaImageToDrive(entry.dataUrl);
            draft.rows[entry.index].image = uploadedUrl;
            record.rows[entry.index].image = uploadedUrl;
            if (domRows[entry.index]) {
                domRows[entry.index].dataset.image = uploadedUrl;
            }
        }));
        await writeSavedChinaOrders(saved);
    }

    try {
        // 3. Sincronizar con Google Sheets (Nube)
        if (saveButton && !options.silent) {
            saveButton.textContent = 'Sincronizando en la nube...';
        }
        try {
            await fetch(GOOGLE_SHEET_API, {
                method: 'POST',
                body: JSON.stringify({
                    action: existingIndex >= 0 ? 'actualizar' : 'crear',
                    resource: 'pedidoschina',
                    id: record.id,
                    data: {
                        'ID Pedido': record.id,
                        'Fecha': record.createdAt,
                        'Fábrica': record.factory,
                        'TRM': record.rate,
                        'Total USD': record.totalUsd,
                        'Total COP': record.totalCop,
                        'Total Productos': record.rows.length,
                        'Total Piezas': record.totalQuantity,
                        'Productos JSON': JSON.stringify(record.rows),
                        'Notas': record.notes,
                        'Mostrar USD': record.showUsd ? 'VERDADERO' : 'FALSO',
                        'Mostrar COP': record.showCop ? 'VERDADERO' : 'FALSO',
                        'Mostrar Ref': record.showRef ? 'VERDADERO' : 'FALSO'
                    }
                })
            });
        } catch (serverErr) {
            console.warn('Error guardando en Google Sheets:', serverErr);
        }

        if (!options.silent) showToast(`Pedido guardado en la nube (${record.rows.length} producto(s))`, 'success');
        return record;
    } finally {
        if (saveButton && !options.silent) {
            saveButton.disabled = false;
            saveButton.textContent = previousButtonText || 'Guardar pedido';
        }
    }
}

function hydrateChinaOrderForm(orderOrDraft) {
    const tbody = document.getElementById('china-order-items');
    const factory = document.getElementById('china-order-factory');
    const rate = document.getElementById('china-order-rate');
    const notes = document.getElementById('china-order-notes');
    const showUsdEl = document.getElementById('china-show-usd');
    const showCopEl = document.getElementById('china-show-cop');
    const showRefEl = document.getElementById('china-show-ref');
    if (!tbody) return;

    if (orderOrDraft?.id || orderOrDraft?.['ID Pedido']) {
        activeChinaOrderId = String(orderOrDraft.id || orderOrDraft['ID Pedido']).trim();
    }

    isHydratingChinaOrder = true;
    try {
        tbody.innerHTML = '';
        if (factory) factory.value = orderOrDraft?.factory || orderOrDraft?.['Fábrica'] || orderOrDraft?.fabrica || '';
        if (rate) rate.value = orderOrDraft?.rate || orderOrDraft?.['TRM'] || '4000';
        if (notes) notes.value = orderOrDraft?.notes || orderOrDraft?.['Notas'] || '';
        if (showUsdEl) showUsdEl.checked = String(orderOrDraft?.showUsd ?? orderOrDraft?.['Mostrar USD'] ?? '').toLowerCase() !== 'falso' && orderOrDraft?.showUsd !== false;
        if (showCopEl) showCopEl.checked = String(orderOrDraft?.showCop ?? orderOrDraft?.['Mostrar COP'] ?? '').toLowerCase() !== 'falso' && orderOrDraft?.showCop !== false;
        if (showRefEl) showRefEl.checked = String(orderOrDraft?.showRef ?? orderOrDraft?.['Mostrar Ref'] ?? '').toLowerCase() !== 'falso' && orderOrDraft?.showRef !== false;

        let rawRows = orderOrDraft?.rows || orderOrDraft?.['Productos JSON'] || orderOrDraft?.productos || [];
        if (typeof rawRows === 'string') {
            try { rawRows = JSON.parse(rawRows); } catch (e) { rawRows = []; }
        }
        const rows = Array.isArray(rawRows) && rawRows.length ? rawRows : [{}];
        rows.forEach(item => createChinaOrderRow(item, { append: true }));
    } finally {
        isHydratingChinaOrder = false;
    }
    calculateChinaOrderTotals();
}

async function loadSavedChinaOrder(id) {
    const saved = getSavedChinaOrders();
    const order = saved.find(item => String(item.id).trim() === String(id).trim());
    if (!order) {
        showToast('No se encontro el pedido guardado', 'error');
        return;
    }
    activeChinaOrderId = order.id;
    hydrateChinaOrderForm(order);
    await saveChinaOrderDraft({ immediate: true });
    showToast('Pedido cargado para editar', 'success');
}

async function deleteSavedChinaOrder(id) {
    showModal(
        'Eliminar Pedido a China',
        '¿Deseas eliminar permanentemente el pedido ' + id + ' de la base de datos?',
        'Sí, eliminar',
        async function () {
            showToast('Eliminando pedido...');
            try {
                await fetch(GOOGLE_SHEET_API, {
                    method: 'POST',
                    body: JSON.stringify({
                        action: 'eliminar',
                        resource: 'pedidoschina',
                        id: id
                    })
                });
            } catch (err) {
                console.warn('Error eliminando pedido en el servidor:', err);
            }

            const next = getSavedChinaOrders().filter(item => item.id !== id);
            await writeSavedChinaOrders(next);
            if (activeChinaOrderId === id) activeChinaOrderId = '';
            renderSavedChinaOrders();
            showToast('Pedido eliminado', 'success');
        }
    );
}

function formatChinaOrderDate(value) {
    if (!value) return new Date().toLocaleDateString('es-CO', { year: 'numeric', month: 'short', day: '2-digit' });
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return String(value);
    const day = date.getDate();
    const months = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sept', 'oct', 'nov', 'dic'];
    const month = months[date.getMonth()] || date.toLocaleDateString('es-CO', { month: 'short' });
    const year = date.getFullYear();
    return `${day} de ${month} de ${year}`;
}

function renderSavedChinaOrders() {
    const container = document.getElementById('china-saved-orders-list');
    const badge = document.getElementById('china-saved-count');
    if (!container) return;

    const saved = getSavedChinaOrders();
    if (badge) badge.textContent = saved.length;
    if (!saved.length) {
        container.innerHTML = '<div class="china-saved-empty">No hay pedidos guardados todavia.</div>';
        return;
    }

    container.innerHTML = saved.map(order => `
        <div class="china-saved-row" data-china-saved-id="${escapeHtml(order.id)}">
            <div>
                <strong>${escapeHtml(order.id)}</strong>
                <span>${order.factory ? `Fábrica: <strong>${escapeHtml(order.factory)}</strong> · ` : ''}${formatChinaOrderDate(order.updatedAt || order.createdAt)} - ${Number(order.rows?.length || 0)} producto(s)</span>
            </div>
            <div>
                <strong>${formatChinaUsd(order.totalUsd || 0)}</strong>
                <span>Total USD</span>
            </div>
            <div>
                <strong>${formatChinaCop(order.totalCop || 0)}</strong>
                <span>Total COP</span>
            </div>
            <div class="china-saved-actions">
                <button type="button" class="china-mini-btn" data-china-saved-action="open">Abrir</button>
                <button type="button" class="china-mini-btn pdf" data-china-saved-action="pdf">PDF</button>
                <button type="button" class="china-mini-btn danger" data-china-saved-action="delete">Borrar</button>
            </div>
        </div>
    `).join('');
}

function getChinaOrderPrintStyles() {
    return `
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');

        * {
            box-sizing: border-box !important;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
        }

        html, body {
            background: #f8fafc;
            color: #0f172a;
            margin: 0;
            padding: 0;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            font-size: 12px;
        }

        .china-print-toolbar {
            position: sticky;
            top: 0;
            left: 0;
            right: 0;
            z-index: 99999;
            background: #1e1b4b;
            padding: 12px 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 16px rgba(0,0,0,0.15);
        }

        .china-print-toolbar-title {
            color: #ffffff;
            font-weight: 700;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .china-print-toolbar-actions {
            display: flex;
            gap: 10px;
        }

        .china-print-btn {
            padding: 9px 18px;
            font-size: 13px;
            font-weight: 700;
            border-radius: 8px;
            cursor: pointer;
            border: none;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .china-print-btn.primary {
            background: #7c3aed;
            color: #ffffff;
        }
        .china-print-btn.primary:hover {
            background: #6d28d9;
            transform: translateY(-1px);
        }

        .china-print-btn.secondary {
            background: rgba(255,255,255,0.16);
            color: #ffffff;
        }
        .china-print-btn.secondary:hover {
            background: rgba(255,255,255,0.26);
        }

        #china-order-print-container {
            padding: 14px 0;
        }

        .china-print-page {
            box-sizing: border-box !important;
            width: 100% !important;
            max-width: 210mm !important;
            min-height: 270mm !important;
            margin: 0 auto 24px auto !important;
            display: flex !important;
            flex-direction: column !important;
            justify-content: space-between !important;
            page-break-inside: avoid !important;
            break-inside: avoid !important;
            page-break-after: always !important;
            break-after: page !important;
            background: #ffffff !important;
            padding: 12mm 13mm !important;
            border-radius: 4px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.07);
        }

        .china-print-page:last-child,
        .china-print-page.last {
            page-break-after: auto !important;
            break-after: auto !important;
            margin-bottom: 0 !important;
        }

        .china-print-page-content {
            flex: 1 0 auto !important;
            display: flex !important;
            flex-direction: column !important;
        }

        /* CABECERA PÁGINA 1 */
        .china-print-header {
            border: 2px solid #7c3aed !important;
            border-radius: 14px !important;
            padding: 12px 16px !important;
            margin-bottom: 12px !important;
            background: #ffffff !important;
            display: flex !important;
            justify-content: space-between !important;
            align-items: center !important;
            page-break-inside: avoid !important;
        }

        .china-print-brand {
            display: flex !important;
            align-items: center !important;
            gap: 16px !important;
        }

        .china-print-logo-box {
            display: flex !important;
            align-items: center !important;
            gap: 10px !important;
        }

        .china-print-logo-img {
            height: 38px !important;
            width: auto !important;
            object-fit: contain !important;
        }

        .china-print-logo-title {
            margin: 0 !important;
            font-size: 26px !important;
            font-weight: 900 !important;
            color: #581c87 !important;
            letter-spacing: 0.5px !important;
            line-height: 1 !important;
        }

        .china-print-title-group {
            border-left: 2px solid #ddd6fe !important;
            padding-left: 14px !important;
        }

        .china-print-title-group h2 {
            margin: 0 !important;
            font-size: 15px !important;
            font-weight: 800 !important;
            color: #1e1b4b !important;
            line-height: 1.2 !important;
        }

        .china-print-title-group p {
            margin: 2px 0 0 0 !important;
            font-size: 11px !important;
            font-weight: 500 !important;
            color: #64748b !important;
        }

        .china-print-factory {
            margin: 3px 0 0 0 !important;
            font-size: 11px !important;
            color: #475569 !important;
        }

        .china-print-factory strong {
            color: #581c87 !important;
            font-weight: 700 !important;
        }

        .china-print-meta {
            text-align: right !important;
        }

        .china-print-order-id {
            font-size: 15.5px !important;
            font-weight: 900 !important;
            color: #581c87 !important;
            letter-spacing: 0.5px !important;
            margin-bottom: 3px !important;
        }

        .china-print-meta p {
            margin: 2px 0 0 0 !important;
            font-size: 11px !important;
            color: #475569 !important;
        }

        .china-print-meta strong {
            color: #0f172a !important;
        }

        /* CABECERA COMPACTA (PÁGINA 2+) */
        .china-print-header.compact {
            border: 1.5px solid #7c3aed !important;
            border-radius: 10px !important;
            padding: 8px 16px !important;
            margin-bottom: 12px !important;
            background: #ffffff !important;
            display: flex !important;
            justify-content: space-between !important;
            align-items: center !important;
            page-break-inside: avoid !important;
        }

        .china-print-header.compact .china-print-brand {
            display: flex !important;
            align-items: center !important;
            gap: 12px !important;
        }

        .china-print-header.compact h2 {
            margin: 0 !important;
            font-size: 14px !important;
            font-weight: 900 !important;
            color: #581c87 !important;
        }

        .china-print-header.compact h2 span {
            font-weight: 600 !important;
            font-size: 12px !important;
            color: #7c3aed !important;
        }

        .china-print-factory-compact {
            font-size: 11px !important;
            color: #475569 !important;
        }

        .china-print-factory-compact strong {
            color: #581c87 !important;
            font-weight: 700 !important;
        }

        .china-print-order-id-compact {
            font-size: 14px !important;
            font-weight: 800 !important;
            color: #581c87 !important;
            letter-spacing: 0.5px !important;
        }

        /* TABLA PRINCIPAL */
        .china-print-table {
            width: 100% !important;
            border-collapse: collapse !important;
            border: 1.5px solid #7c3aed !important;
            margin: 4px 0 9px 0 !important;
            table-layout: fixed !important;
        }

        .china-print-table thead th {
            border: 1px solid #c4b5fd !important;
            border-top: 1.5px solid #7c3aed !important;
            border-bottom: 1.5px solid #7c3aed !important;
            color: #581c87 !important;
            background: #ffffff !important;
            font-size: 10.5px !important;
            font-weight: 800 !important;
            letter-spacing: 0.5px !important;
            text-transform: uppercase !important;
            padding: 7px 5px !important;
        }

        .china-print-table tbody tr {
            border-bottom: 1px solid #ddd6fe !important;
            min-height: 76px !important;
            page-break-inside: avoid !important;
            break-inside: avoid !important;
        }

        .china-print-table td {
            padding: 5px 6px !important;
            vertical-align: middle !important;
            border: 1px solid #ddd6fe !important;
            overflow-wrap: anywhere !important;
            word-break: normal !important;
        }

        .china-print-img {
            width: 62px !important;
            height: 62px !important;
            max-width: 100% !important;
            object-fit: cover !important;
            background: #ffffff !important;
            border-radius: 6px !important;
            border: 1px solid #ddd6fe !important;
            display: block !important;
            margin: 0 auto !important;
            box-shadow: 0 1px 2px rgba(0,0,0,0.03) !important;
        }

        .china-print-no-photo {
            width: 62px !important;
            height: 62px !important;
            border-radius: 6px !important;
            border: 1px dashed #cbd5e1 !important;
            background: #f8fafc !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            margin: 0 auto !important;
            color: #94a3b8 !important;
            font-size: 9px !important;
            font-weight: 600 !important;
        }

        .china-print-prod-name {
            font-size: 12.5px !important;
            font-weight: 800 !important;
            line-height: 1.35 !important;
            color: #0f172a !important;
            margin-bottom: 3px !important;
            text-transform: uppercase !important;
        }

        .china-print-prod-ref {
            font-size: 10px !important;
            color: #64748b !important;
            font-weight: 600 !important;
        }

        .china-print-prod-ref strong {
            color: #334155 !important;
            font-weight: 700 !important;
        }

        /* RESUMEN Y TOTALES */
        .china-print-summary-wrap {
            display: flex !important;
            justify-content: flex-end !important;
            align-items: flex-start !important;
            gap: 16px !important;
            margin-top: 12px !important;
            margin-bottom: 6px !important;
            page-break-inside: avoid !important;
            break-inside: avoid !important;
        }

        .china-print-notes {
            flex: 1 !important;
            max-width: 55% !important;
            background: #fdf4ff !important;
            border: 1px solid #f0abfc !important;
            border-left: 3px solid #7c3aed !important;
            border-radius: 8px !important;
            padding: 8px 12px !important;
            font-size: 10.5px !important;
            color: #334155 !important;
            line-height: 1.4 !important;
        }

        .china-print-notes strong {
            display: block !important;
            color: #581c87 !important;
            font-size: 11px !important;
            margin-bottom: 2px !important;
        }

        .china-print-totals-box {
            border: 2px solid #7c3aed !important;
            border-radius: 12px !important;
            padding: 8px 18px !important;
            background: #ffffff !important;
            min-width: 210px !important;
        }

        .china-print-total-row {
            display: flex !important;
            justify-content: space-between !important;
            align-items: center !important;
            gap: 20px !important;
            padding: 3px 0 !important;
        }

        .china-print-total-row.main span {
            font-size: 12.5px !important;
            font-weight: 800 !important;
            color: #1e1b4b !important;
        }

        .china-print-total-row.main strong {
            font-size: 14px !important;
            font-weight: 900 !important;
            color: #581c87 !important;
        }

        /* PIE DE PÁGINA */
        .china-print-footer {
            margin-top: auto !important;
            padding-top: 6px !important;
            border-top: 1px solid #e2e8f0 !important;
            display: flex !important;
            justify-content: space-between !important;
            font-size: 9.5px !important;
            color: #64748b !important;
            font-weight: 500 !important;
            page-break-inside: avoid !important;
        }

        @media print {
            @page {
                size: A4 portrait;
                margin: 10mm;
            }

            html, body {
                background: #ffffff !important;
                color: #0f172a !important;
                margin: 0 !important;
                padding: 0 !important;
                width: 100% !important;
                height: auto !important;
            }

            .china-print-toolbar {
                display: none !important;
            }

            #china-order-print-container {
                padding: 0 !important;
                display: block !important;
            }

            .china-print-page {
                width: 100% !important;
                max-width: 100% !important;
                min-height: 274mm !important;
                max-height: none !important;
                margin: 0 !important;
                padding: 0 !important;
                box-shadow: none !important;
                border-radius: 0 !important;
            }

            body.printing-china-order > :not(#china-order-print-container) {
                display: none !important;
            }

            body.printing-china-order #china-order-print-container {
                display: block !important;
                visibility: visible !important;
                position: static !important;
                width: 100% !important;
                margin: 0 !important;
                padding: 0 !important;
                background: #ffffff !important;
            }
        }
    `;
}

function ensureChinaPrintStyles() {
    let styleTag = document.getElementById('china-order-print-styles');
    if (!styleTag) {
        styleTag = document.createElement('style');
        styleTag.id = 'china-order-print-styles';
        document.head.appendChild(styleTag);
    }
    styleTag.textContent = getChinaOrderPrintStyles();
}

function buildChinaOrderPrintHtml(order) {
    const totals = getChinaOrderTotalsFromDraft(order);
    const showUsd = order.showUsd !== false;
    const showCop = order.showCop !== false;
    const showRef = order.showRef !== false;
    const rows = Array.isArray(order.rows) ? order.rows : [];
    const productColumnWidth = showUsd && showCop ? 31 : (showUsd || showCop ? 55 : 79);

    // Exactamente 6 items por página para mantener fotos grandes y esquema visual perfecto
    const rowsPerPage = 6;

    const headers = [
        '<th style="width:13%; text-align:center;">FOTO</th>',
        `<th style="width:${productColumnWidth}%; text-align:left; padding-left:12px;">${showRef ? 'PRODUCTO / REFERENCIA' : 'PRODUCTO'}</th>`,
        '<th style="width:8%; text-align:center;">PCS</th>',
        showUsd ? '<th style="width:11%; text-align:center;">UNIT. USD</th>' : '',
        showCop ? '<th style="width:11%; text-align:right;">UNIT. COP</th>' : '',
        showUsd ? '<th style="width:13%; text-align:center;">SUBTOTAL USD</th>' : '',
        showCop ? '<th style="width:13%; text-align:right;">SUBTOTAL COP</th>' : ''
    ].filter(Boolean).join('');

    const totalRowsHtml = `
        <div class="china-print-total-row main">
            <span>Total PCS</span>
            <strong>${Math.round(totals.totalQuantity || 0).toLocaleString('es-CO')}</strong>
        </div>
        ${showUsd ? `
            <div class="china-print-total-row" style="border-top:1px dashed #ddd6fe; padding-top:4px; margin-top:3px;">
                <span style="font-size:12px; color:#475569; font-weight:600;">Total USD</span>
                <strong style="color:#581c87; font-size:14px; font-weight:900;">${formatChinaUsd(totals.totalUsd)}</strong>
            </div>
        ` : ''}
        ${showCop ? `
            <div class="china-print-total-row" style="border-top:1px dashed #ddd6fe; padding-top:4px; margin-top:3px;">
                <span style="font-size:12px; color:#475569; font-weight:600;">Total COP</span>
                <strong style="color:#0f172a; font-size:13.5px; font-weight:800;">${formatChinaCop(totals.totalCop)}</strong>
            </div>
        ` : ''}
    `;

    function chunkRowsForPrint(items) {
        const pages = [];
        for (let index = 0; index < items.length; index += rowsPerPage) {
            pages.push(items.slice(index, index + rowsPerPage));
        }
        if (!pages.length) pages.push([]);
        return pages;
    }

    function buildPagedItemRows(pageRows, startIndex) {
        return pageRows.map((item, offset) => {
            const index = startIndex + offset;
            const quantity = Math.max(0, parseChinaNumber(item.quantity || 0));
            const unitUsd = Math.max(0, parseChinaNumber(item.unitUsd || 0));
            const subtotalUsd = quantity * unitUsd;
            const unitCop = unitUsd * (totals.rate || 0);
            const subtotalCop = subtotalUsd * (totals.rate || 0);
            const imageSrc = formatChinaOrderImageUrl(item.image);

            const imageHtml = imageSrc
                ? `<img src="${escapeHtml(imageSrc)}" alt="" loading="eager" crossorigin="anonymous" class="china-print-img" onerror="this.style.display='none'; if(this.nextElementSibling) this.nextElementSibling.style.display='flex';">
                   <div class="china-print-no-photo" style="display:none;"><span>Sin foto</span></div>`
                : `<div class="china-print-no-photo"><span>Sin foto</span></div>`;

            const refHtml = showRef
                ? (item.reference
                    ? `<div class="china-print-prod-ref">Ref: <strong>${escapeHtml(item.reference)}</strong></div>`
                    : '<div class="china-print-prod-ref" style="color:#94a3b8;">Ref: S/N</div>')
                : '';

            return `
                <tr>
                    <td style="text-align:center; padding:5px 5px; width:13%;">${imageHtml}</td>
                    <td style="padding:8px 12px; vertical-align:middle;">
                        <div class="china-print-prod-name">${index + 1}. ${escapeHtml(item.product || 'Producto sin nombre')}</div>
                        ${refHtml}
                    </td>
                    <td style="text-align:center; font-weight:800; font-size:14px; width:8%; color:#0f172a;">${quantity.toLocaleString('es-CO')}</td>
                    ${showUsd ? `<td style="text-align:center; font-size:12px; color:#334155; font-weight:600; font-variant-numeric:tabular-nums;">${formatChinaUsd(unitUsd)}</td>` : ''}
                    ${showCop ? `<td style="text-align:right; font-size:12px; color:#334155; font-weight:600; font-variant-numeric:tabular-nums;">${formatChinaCop(unitCop)}</td>` : ''}
                    ${showUsd ? `<td style="text-align:center; font-weight:800; color:#581c87; font-size:13px; font-variant-numeric:tabular-nums;">${formatChinaUsd(subtotalUsd)}</td>` : ''}
                    ${showCop ? `<td style="text-align:right; font-weight:800; color:#581c87; font-size:13px; font-variant-numeric:tabular-nums;">${formatChinaCop(subtotalCop)}</td>` : ''}
                </tr>
            `;
        }).join('');
    }

    const pages = chunkRowsForPrint(rows);
    let printedRows = 0;
    const totalPages = pages.length;

    return pages.map((pageRows, pageIndex) => {
        const isFirstPage = pageIndex === 0;
        const isLastPage = pageIndex === totalPages - 1;

        const headerHtml = isFirstPage ? `
            <div class="china-print-header">
                <div class="china-print-brand">
                    <div class="china-print-logo-box">
                        <img src="https://lh3.googleusercontent.com/d/1OTHvWFph2u3qFQMQVhE5ghmSWjBSgBeW=w180" alt="Original Store" class="china-print-logo-img" onerror="this.style.display='none';">
                        <h1 class="china-print-logo-title">Original Store</h1>
                    </div>
                    <div class="china-print-title-group">
                        <h2>Pedido a China</h2>
                        <p>Orden de compra proveedor</p>
                        ${order.factory ? `<p class="china-print-factory">Fábrica: <strong>${escapeHtml(order.factory)}</strong></p>` : ''}
                    </div>
                </div>
                <div class="china-print-meta">
                    <div class="china-print-order-id">${escapeHtml(order.id || makeChinaOrderId())}</div>
                    <p>Fecha: <strong>${formatChinaOrderDate(order.updatedAt || order.createdAt || new Date().toISOString())}</strong></p>
                    ${showCop && totals.rate ? `<p>TRM: <strong>${formatChinaCop(totals.rate)}</strong> / USD</p>` : ''}
                </div>
            </div>
        ` : `
            <div class="china-print-header compact">
                <div class="china-print-brand">
                    <h2>Original Store <span>| Pedido a China</span></h2>
                    ${order.factory ? `<span class="china-print-factory-compact">Fábrica: <strong>${escapeHtml(order.factory)}</strong></span>` : ''}
                </div>
                <div class="china-print-meta compact">
                    <strong class="china-print-order-id-compact">${escapeHtml(order.id || makeChinaOrderId())}</strong>
                </div>
            </div>
        `;

        const pageHtml = `
            <div class="china-print-page${isLastPage ? ' last' : ''}">
                <div class="china-print-page-content">
                    ${headerHtml}
                    <table class="china-print-table">
                        <thead>
                            <tr>${headers}</tr>
                        </thead>
                        <tbody>${buildPagedItemRows(pageRows, printedRows)}</tbody>
                    </table>
                    ${isLastPage ? `
                        <div class="china-print-summary-wrap">
                            ${order.notes ? `<div class="china-print-notes"><strong>Notas del Pedido:</strong><p style="margin:0; white-space:pre-wrap;">${escapeHtml(order.notes)}</p></div>` : '<div style="flex:1;"></div>'}
                            <div class="china-print-totals-box">${totalRowsHtml}</div>
                        </div>
                    ` : ''}
                </div>
                <div class="china-print-footer">
                    <span>Original Store Promociones · Pedido a China ${escapeHtml(order.id || '')}</span>
                    <span>Página ${pageIndex + 1} de ${totalPages}</span>
                </div>
            </div>
        `;
        printedRows += pageRows.length;
        return pageHtml;
    }).join('');
}

async function waitForPrintImages(container) {
    const images = Array.from(container.querySelectorAll('img'));
    if (!images.length) return;

    const promises = images.map(img => {
        if (img.complete && img.naturalWidth > 0) return Promise.resolve();
        return new Promise(resolve => {
            let settled = false;
            const finish = () => {
                if (!settled) {
                    settled = true;
                    resolve();
                }
            };
            const timer = setTimeout(finish, 3500);

            img.onload = () => {
                clearTimeout(timer);
                finish();
            };
            img.onerror = () => {
                clearTimeout(timer);
                const src = img.src || '';
                const driveMatch = src.match(/[?&]id=([^&#]+)/) || src.match(/lh3\.googleusercontent\.com\/d\/([^/?&#]+)/);
                if (driveMatch && driveMatch[1] && !img.dataset.retried) {
                    img.dataset.retried = '1';
                    img.src = `https://lh3.googleusercontent.com/d/${driveMatch[1]}`;
                    img.onload = finish;
                    img.onerror = finish;
                } else {
                    finish();
                }
            };
        });
    });

    await Promise.all(promises);
    await new Promise(resolve => setTimeout(resolve, 100));
}

function openChinaOrderPrintWindow(order) {
    if (!order) return false;
    const printWindow = window.open('', '_blank');
    if (!printWindow) return false;

    const baseUrl = window.location.href.replace(/[^/]*$/, '');
    const htmlContent = `<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <base href="${escapeHtml(baseUrl)}">
    <title>Pedido-China-${escapeHtml(order.id || 'Original Store')}</title>
    <style>${getChinaOrderPrintStyles()}</style>
</head>
<body>
    <div class="china-print-toolbar">
        <div class="china-print-toolbar-title">
            <span style="font-size:16px;">CN</span>
            <span>Pedido a China: <strong>${escapeHtml(order.id || '')}</strong></span>
        </div>
        <div class="china-print-toolbar-actions">
            <button type="button" class="china-print-btn secondary" onclick="window.close()">Cerrar</button>
            <button type="button" class="china-print-btn primary" onclick="window.print()">Imprimir / Guardar PDF</button>
        </div>
    </div>
    <div id="china-order-print-container" style="display:block !important;">
        ${buildChinaOrderPrintHtml(order)}
    </div>
    <script>
        async function initPrint() {
            const images = Array.from(document.querySelectorAll('img'));
            await Promise.all(images.map(img => {
                if (img.complete && img.naturalWidth > 0) return Promise.resolve();
                return new Promise(res => {
                    img.onload = res;
                    img.onerror = () => {
                        const src = img.src || '';
                        const driveMatch = src.match(/[?&]id=([^&#]+)/) || src.match(/lh3\\.googleusercontent\\.com\\/d\\/([^/?&#]+)/);
                        if (driveMatch && driveMatch[1] && !img.dataset.retried) {
                            img.dataset.retried = '1';
                            img.src = 'https://lh3.googleusercontent.com/d/' + driveMatch[1];
                            img.onload = res;
                            img.onerror = res;
                        } else {
                            res();
                        }
                    };
                    setTimeout(res, 3000);
                });
            }));
            setTimeout(() => {
                window.print();
            }, 350);
        }
        window.addEventListener('load', initPrint);
    <\/script>
</body>
</html>`;

    printWindow.document.open();
    printWindow.document.write(htmlContent);
    printWindow.document.close();
    return true;
}

async function printChinaOrderPdf(order) {
    if (!order) return;

    // Intentar abrir en ventana limpia independiente para PDF sin interferencia de estilos de panel
    const opened = openChinaOrderPrintWindow(order);
    if (opened) return;

    // Respaldo de impresión en misma ventana si los popups están bloqueados
    ensureChinaPrintStyles();

    let container = document.getElementById('china-order-print-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'china-order-print-container';
        document.body.appendChild(container);
    }
    container.innerHTML = buildChinaOrderPrintHtml(order);

    const parent = container.parentElement;
    const nextSib = container.nextSibling;
    if (container.parentElement !== document.body) {
        document.body.appendChild(container);
    }

    const previousTitle = document.title;
    document.title = 'Pedido-China-' + String(order.id || 'Original Store').replace(/[^a-z0-9_-]/gi, '');
    document.body.classList.add('printing-china-order');

    let cleanedUp = false;
    const cleanup = () => {
        if (cleanedUp) return;
        cleanedUp = true;
        document.body.classList.remove('printing-china-order');
        document.title = previousTitle;
        if (parent && parent !== document.body && container.parentElement === document.body) {
            if (nextSib && parent.contains(nextSib)) parent.insertBefore(container, nextSib);
            else parent.appendChild(container);
        }
        window.removeEventListener('afterprint', cleanup);
    };

    window.addEventListener('afterprint', cleanup, { once: true });
    setTimeout(cleanup, 45000);

    await waitForPrintImages(container);
    await new Promise(resolve => setTimeout(resolve, 200));

    window.print();
}

async function downloadCurrentChinaOrderPdf() {
    const draft = collectChinaOrderDraft();
    const hasProduct = draft.rows.some(item => String(item.product || item.reference || item.unitUsd || item.quantity || '').trim());
    if (!hasProduct) {
        showToast('Agrega al menos un producto antes de descargar el PDF', 'warning');
        return;
    }
    const currentId = activeChinaOrderId || draft.id;
    const saved = getSavedChinaOrders();
    const existing = currentId ? saved.find(item => String(item.id).trim() === String(currentId).trim()) : null;
    const order = makeChinaOrderRecord(draft, existing);
    activeChinaOrderId = order.id;

    showToast('Preparando PDF de pedido a China...', 'info');
    await printChinaOrderPdf(order);
    saveCurrentChinaOrder({ silent: true }).catch(err => console.warn('Error en guardado segundo plano:', err));
}

async function persistChinaOrderDraft(draft) {
    try {
        await writeChinaOrderStoreValue(CHINA_ORDER_DRAFT_RECORD_KEY, draft);
        try {
            localStorage.removeItem(CHINA_ORDER_DRAFT_KEY);
        } catch (cleanupError) {
            console.warn('No se pudo limpiar borrador viejo:', cleanupError);
        }
        return true;
    } catch (error) {
        console.warn('No se pudo guardar el borrador grande en IndexedDB:', error);
    }

    try {
        localStorage.setItem(CHINA_ORDER_DRAFT_KEY, JSON.stringify(draft));
        return true;
    } catch (error) {
        console.warn('No se pudo guardar el borrador del pedido a China:', error);
        return false;
    }
}

function saveChinaOrderDraft(options = {}) {
    if (isHydratingChinaOrder) return Promise.resolve(false);

    const draft = collectChinaOrderDraft();
    if (options.immediate) {
        clearTimeout(chinaOrderDraftSaveTimer);
        return persistChinaOrderDraft(draft);
    }

    clearTimeout(chinaOrderDraftSaveTimer);
    chinaOrderDraftSaveTimer = setTimeout(() => {
        persistChinaOrderDraft(draft);
    }, 250);
    return Promise.resolve(true);
}

function calculateChinaOrderTotals() {
    const rate = parseChinaNumber(document.getElementById('china-order-rate')?.value || 0);
    let totalUsd = 0;
    let totalPieces = 0;
    const rows = getChinaOrderRows();

    rows.forEach(row => {
        const quantity = Math.max(0, parseChinaNumber(row.querySelector('[data-china-field="quantity"]')?.value || 0));
        const unitUsd = Math.max(0, parseChinaNumber(row.querySelector('[data-china-field="unitUsd"]')?.value || 0));
        const unitCop = unitUsd * rate;
        const subtotalUsd = quantity * unitUsd;
        const subtotalCop = subtotalUsd * rate;

        const unitCopEl = row.querySelector('[data-china-output="unitCop"]');
        const subtotalUsdEl = row.querySelector('[data-china-output="subtotalUsd"]');
        const subtotalCopEl = row.querySelector('[data-china-output="subtotalCop"]');
        if (unitCopEl) unitCopEl.textContent = formatChinaCop(unitCop);
        if (subtotalUsdEl) subtotalUsdEl.textContent = formatChinaUsd(subtotalUsd);
        if (subtotalCopEl) subtotalCopEl.textContent = formatChinaCop(subtotalCop);

        totalUsd += subtotalUsd;
        totalPieces += quantity;
    });

    const totalUsdEl = document.getElementById('china-order-total-usd');
    const totalCopEl = document.getElementById('china-order-total-cop');
    const totalProductsEl = document.getElementById('china-order-total-products');
    const totalPiecesEl = document.getElementById('china-order-total-pieces');
    if (totalUsdEl) totalUsdEl.textContent = formatChinaUsd(totalUsd);
    if (totalCopEl) totalCopEl.textContent = formatChinaCop(totalUsd * rate);
    if (totalProductsEl) totalProductsEl.textContent = rows.length.toLocaleString('es-CO');
    if (totalPiecesEl) totalPiecesEl.textContent = Math.round(totalPieces).toLocaleString('es-CO');
    saveChinaOrderDraft();
}

function openChinaPhotoModal(src, title = 'Foto del producto') {
    if (!src) return;
    let modal = document.getElementById('china-photo-modal');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'china-photo-modal';
        modal.className = 'china-photo-modal';
        modal.innerHTML = `
            <div class="china-photo-modal-backdrop"></div>
            <div class="china-photo-modal-content">
                <button type="button" class="china-photo-modal-close" title="Cerrar">&times;</button>
                <div class="china-photo-modal-title"></div>
                <div class="china-photo-modal-img-wrap">
                    <img src="" alt="Foto ampliada">
                </div>
            </div>
        `;
        document.body.appendChild(modal);

        modal.querySelector('.china-photo-modal-backdrop').addEventListener('click', () => modal.classList.remove('active'));
        modal.querySelector('.china-photo-modal-close').addEventListener('click', () => modal.classList.remove('active'));
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && modal.classList.contains('active')) {
                modal.classList.remove('active');
            }
        });
    }

    const img = modal.querySelector('img');
    const titleEl = modal.querySelector('.china-photo-modal-title');
    const formatted = formatChinaOrderImageUrl(src) || src;
    img.src = formatted;
    if (titleEl) titleEl.textContent = title || 'Foto del producto';
    modal.classList.add('active');
}

function setChinaOrderImage(row, src) {
    if (!row || !src) return;
    row.dataset.image = src;
    const formatted = formatChinaOrderImageUrl(src);
    const wrapper = row.querySelector('.china-order-photo-wrapper');
    const drop = row.querySelector('.china-order-photo-drop');
    const img = row.querySelector('.china-order-photo-drop img');
    if (wrapper) wrapper.classList.add('has-image');
    if (drop) drop.classList.add('has-image');
    if (img) {
        img.src = formatted || src;
        img.onerror = () => {
            const driveMatch = (formatted || src).match(/[?&]id=([^&#]+)/) || (formatted || src).match(/lh3\.googleusercontent\.com\/d\/([^/?&#]+)/);
            if (driveMatch && driveMatch[1] && !img.dataset.retried) {
                img.dataset.retried = '1';
                img.src = `https://lh3.googleusercontent.com/d/${driveMatch[1]}`;
            }
        };
    }
    saveChinaOrderDraft();
}

async function prepareChinaOrderImageDataUrl(file) {
    if (file.type === 'image/gif') {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result);
            reader.onerror = () => reject(reader.error || new Error('No se pudo leer la imagen'));
            reader.readAsDataURL(file);
        });
    }

    const img = await loadImageFile(file);
    const maxEdge = 600;
    const scale = Math.min(1, maxEdge / Math.max(img.naturalWidth || img.width || 1, img.naturalHeight || img.height || 1));
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round((img.naturalWidth || img.width || 1) * scale));
    canvas.height = Math.max(1, Math.round((img.naturalHeight || img.height || 1) * scale));
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('No se pudo preparar la imagen');
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', 0.72);
}

async function readChinaOrderImageFile(row, file) {
    if (!file || !file.type || !file.type.startsWith('image/')) {
        showToast('Arrastra una imagen valida para el producto', 'warning');
        return;
    }
    try {
        const dataUrl = await prepareChinaOrderImageDataUrl(file);
        setChinaOrderImage(row, dataUrl);
    } catch (error) {
        showToast('No se pudo leer la imagen', 'error');
    }
}

function createChinaOrderRow(item = {}, options = {}) {
    const tbody = document.getElementById('china-order-items');
    if (!tbody) return null;

    const row = document.createElement('tr');
    row.dataset.chinaOrderRow = 'true';
    row.dataset.image = item.image || '';
    row.innerHTML = `
        <td>
            <div class="china-order-photo-wrapper${item.image ? ' has-image' : ''}">
                <label class="china-order-photo-drop" title="Arrastra una foto o haz clic para subir">
                    <input type="file" accept="image/*" data-china-field="imageFile">
                    <img alt="Foto del producto">
                    <span>Arrastra<br>foto</span>
                </label>
                <button type="button" class="china-photo-preview-btn" title="Ver foto ampliada">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                        <circle cx="12" cy="12" r="3"></circle>
                    </svg>
                </button>
            </div>
        </td>
        <td>
            <div class="china-order-product-fields">
                <input type="text" class="form-control" data-china-field="product" placeholder="Producto" value="${escapeHtml(item.product || '')}">
                <input type="text" class="form-control" data-china-field="reference" placeholder="Referencia opcional" value="${escapeHtml(item.reference || '')}">
            </div>
        </td>
        <td><input type="number" class="form-control" data-china-field="quantity" min="0" step="1" value="${escapeHtml(item.quantity || '1')}"></td>
        <td><input type="number" class="form-control" data-china-field="unitUsd" min="0" step="0.01" placeholder="0.00" value="${escapeHtml(item.unitUsd || '')}"></td>
        <td class="china-order-money muted" data-china-output="unitCop">$0</td>
        <td class="china-order-money" data-china-output="subtotalUsd">US$0.00</td>
        <td class="china-order-money" data-china-output="subtotalCop">$0</td>
        <td><button type="button" class="china-order-remove" title="Eliminar producto">x</button></td>
    `;
    if (options.append) tbody.appendChild(row);
    else tbody.prepend(row);

    const fileInput = row.querySelector('[data-china-field="imageFile"]');
    const drop = row.querySelector('.china-order-photo-drop');
    const previewBtn = row.querySelector('.china-photo-preview-btn');

    if (item.image) setChinaOrderImage(row, item.image);

    previewBtn?.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const imgSrc = row.dataset.image;
        if (!imgSrc) return;
        const prodName = row.querySelector('[data-china-field="product"]')?.value || 'Producto';
        openChinaPhotoModal(imgSrc, prodName);
    });

    row.querySelectorAll('input:not([type="file"])').forEach(input => {
        input.addEventListener('input', calculateChinaOrderTotals);
        input.addEventListener('change', calculateChinaOrderTotals);
    });
    fileInput?.addEventListener('change', event => readChinaOrderImageFile(row, event.target.files?.[0]));
    drop?.addEventListener('dragover', event => {
        event.preventDefault();
        drop.classList.add('drag-over');
    });
    drop?.addEventListener('dragleave', () => drop.classList.remove('drag-over'));
    drop?.addEventListener('drop', event => {
        event.preventDefault();
        drop.classList.remove('drag-over');
        readChinaOrderImageFile(row, event.dataTransfer.files?.[0]);
    });
    row.querySelector('.china-order-remove')?.addEventListener('click', () => {
        row.remove();
        if (!getChinaOrderRows().length) createChinaOrderRow();
        calculateChinaOrderTotals();
    });

    calculateChinaOrderTotals();
    return row;
}

function buildChinaOrderSummary() {
    const draft = collectChinaOrderDraft();
    const rate = parseChinaNumber(draft.rate || 0);
    let totalUsd = 0;
    let totalPieces = 0;
    const lines = draft.rows.map((item, index) => {
        const quantity = Math.max(0, parseChinaNumber(item.quantity || 0));
        const unitUsd = Math.max(0, parseChinaNumber(item.unitUsd || 0));
        const subtotalUsd = quantity * unitUsd;
        totalUsd += subtotalUsd;
        totalPieces += quantity;
        const reference = item.reference ? ` | Ref: ${item.reference}` : '';
        return `${index + 1}. ${item.product || 'Producto sin nombre'}${reference} | Cant: ${quantity} | Unit: ${formatChinaUsd(unitUsd)} / ${formatChinaCop(unitUsd * rate)} | Subtotal: ${formatChinaUsd(subtotalUsd)} / ${formatChinaCop(subtotalUsd * rate)}`;
    });

    return [
        'Pedido a China - Original Store',
        draft.factory ? `Fábrica: ${draft.factory}` : '',
        `TRM: ${formatChinaCop(rate)} por USD`,
        '',
        ...lines,
        '',
        `TOTAL PIEZAS: ${Math.round(totalPieces).toLocaleString('es-CO')}`,
        `TOTAL USD: ${formatChinaUsd(totalUsd)}`,
        `TOTAL COP: ${formatChinaCop(totalUsd * rate)}`,
        draft.notes ? `Notas: ${draft.notes}` : ''
    ].filter(line => line !== '').join('\n');
}

function fallbackCopyChinaOrderSummary(summary) {
    const textarea = document.createElement('textarea');
    textarea.value = summary;
    textarea.style.position = 'fixed';
    textarea.style.left = '-9999px';
    document.body.appendChild(textarea);
    textarea.focus();
    textarea.select();
    try {
        document.execCommand('copy');
        showToast('Resumen del pedido copiado', 'success');
    } catch (error) {
        showToast('No se pudo copiar el resumen', 'error');
    }
    textarea.remove();
}

function copyChinaOrderSummary() {
    const summary = buildChinaOrderSummary();
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(summary)
            .then(() => showToast('Resumen del pedido copiado', 'success'))
            .catch(() => fallbackCopyChinaOrderSummary(summary));
        return;
    }
    fallbackCopyChinaOrderSummary(summary);
}

function clearChinaOrderDraft() {
    clearTimeout(chinaOrderDraftSaveTimer);
    try {
        localStorage.removeItem(CHINA_ORDER_DRAFT_KEY);
    } catch (error) {
        console.warn('No se pudo limpiar el borrador:', error);
    }
    deleteChinaOrderStoreValue(CHINA_ORDER_DRAFT_RECORD_KEY).catch(error => {
        console.warn('No se pudo limpiar el borrador grande:', error);
    });
    activeChinaOrderId = '';
    const tbody = document.getElementById('china-order-items');
    if (tbody) tbody.innerHTML = '';
    const factory = document.getElementById('china-order-factory');
    const rate = document.getElementById('china-order-rate');
    const notes = document.getElementById('china-order-notes');
    const showUsdEl = document.getElementById('china-show-usd');
    const showCopEl = document.getElementById('china-show-cop');
    const showRefEl = document.getElementById('china-show-ref');
    if (factory) factory.value = '';
    if (rate) rate.value = '4000';
    if (notes) notes.value = '';
    if (showUsdEl) showUsdEl.checked = true;
    if (showCopEl) showCopEl.checked = true;
    if (showRefEl) showRefEl.checked = true;
    createChinaOrderRow();
    calculateChinaOrderTotals();
}

async function initChinaOrdersBuilder() {
    const tbody = document.getElementById('china-order-items');
    if (!tbody || tbody.dataset.ready === 'true') return;
    tbody.dataset.ready = 'true';

    const factory = document.getElementById('china-order-factory');
    const rate = document.getElementById('china-order-rate');
    const notes = document.getElementById('china-order-notes');

    factory?.addEventListener('input', saveChinaOrderDraft);
    factory?.addEventListener('change', saveChinaOrderDraft);
    rate?.addEventListener('input', calculateChinaOrderTotals);
    rate?.addEventListener('change', calculateChinaOrderTotals);
    notes?.addEventListener('input', saveChinaOrderDraft);
    document.getElementById('china-show-usd')?.addEventListener('change', saveChinaOrderDraft);
    document.getElementById('china-show-cop')?.addEventListener('change', saveChinaOrderDraft);
    document.getElementById('china-show-ref')?.addEventListener('change', saveChinaOrderDraft);
    document.getElementById('btn-add-china-order-item')?.addEventListener('click', () => createChinaOrderRow());
    document.getElementById('btn-save-china-order')?.addEventListener('click', () => saveCurrentChinaOrder());
    document.getElementById('btn-print-china-order')?.addEventListener('click', downloadCurrentChinaOrderPdf);
    document.getElementById('btn-copy-china-order')?.addEventListener('click', copyChinaOrderSummary);
    document.getElementById('btn-clear-china-order')?.addEventListener('click', clearChinaOrderDraft);
    document.getElementById('china-saved-orders-list')?.addEventListener('click', event => {
        const button = event.target.closest('[data-china-saved-action]');
        const row = event.target.closest('[data-china-saved-id]');
        if (!button || !row) return;
        const id = row.dataset.chinaSavedId;
        const action = button.dataset.chinaSavedAction;
        if (action === 'open') loadSavedChinaOrder(id);
        if (action === 'pdf') {
            const order = getSavedChinaOrders().find(item => item.id === id);
            if (order) printChinaOrderPdf(order);
        }
        if (action === 'delete') deleteSavedChinaOrder(id);
    });

    tbody.innerHTML = '<tr><td colspan="8" style="text-align:center; padding:22px; color:rgba(255,255,255,0.55);">Cargando pedidos guardados...</td></tr>';
    try {
        await migrateLegacyChinaOrdersToIndexedDb();
    } catch (error) {
        console.warn('No se pudo migrar el historial de pedidos a China:', error);
    }

    savedChinaOrdersCache = await readSavedChinaOrdersFromStorage();
    const draft = await readChinaOrderDraftFromStorage();

    if (draft) {
        hydrateChinaOrderForm(draft);
    } else {
        tbody.innerHTML = '';
        createChinaOrderRow();
    }

    renderSavedChinaOrders();
    calculateChinaOrderTotals();
    fetchChinaOrdersFromServer();
}

window.pedidosList = [];
window.facturasList = [];
window.activeOrdersAdminTab = 'orders-mayor';
const ADMIN_ORDERS_CACHE_KEY = 'blyxu_admin_orders_invoices_cache_v2';
try { localStorage.removeItem(ADMIN_ORDERS_CACHE_KEY); } catch (_) {}
window.addEventListener('pagehide', () => {
    revokeAdminSession();
    sessionStorage.removeItem(ADMIN_ORDERS_CACHE_KEY);
    const screen = document.getElementById('admin-login-screen');
    const main = document.getElementById('admin-main-content');
    if (screen) screen.style.display = '';
    if (main) main.style.display = 'none';
});
const ADMIN_ORDERS_CACHE_TTL = 45 * 1000;
let adminOrdersLoadPromise = null;

function readAdminOrdersCache() {
    try {
        const cached = JSON.parse(sessionStorage.getItem(ADMIN_ORDERS_CACHE_KEY) || 'null');
        return cached && Array.isArray(cached.pedidos) && Array.isArray(cached.facturas) ? cached : null;
    } catch (error) {
        return null;
    }
}

function writeAdminOrdersCache() {
    try {
        sessionStorage.setItem(ADMIN_ORDERS_CACHE_KEY, JSON.stringify({
            savedAt: Date.now(),
            pedidos: window.pedidosList || [],
            facturas: window.facturasList || []
        }));
    } catch (error) {
        console.warn('No se pudo guardar cache de pedidos:', error);
    }
}

function isAdminOrdersCacheFresh(cached) {
    return Boolean(cached?.savedAt && Date.now() - Number(cached.savedAt) < ADMIN_ORDERS_CACHE_TTL);
}

async function cargarPedidos(options = {}) {
    const force = Boolean(options && options.force);
    const orderBodies = ['orders-mayor-tbody', 'orders-detal-tbody', 'orders-tbody']
        .map(id => document.getElementById(id))
        .filter(Boolean);
    const invoiceBodies = ['invoices-mayor-tbody', 'invoices-detal-tbody', 'invoices-tbody']
        .map(id => document.getElementById(id))
        .filter(Boolean);
    const cached = readAdminOrdersCache();
    if (cached && !force) {
        window.pedidosList = cached.pedidos;
        window.facturasList = cached.facturas;
        renderPedidos();
        renderFacturas();
        renderAdminDashboard();
        if (!force && isAdminOrdersCacheFresh(cached)) return;
        if (!force && adminOrdersLoadPromise) return adminOrdersLoadPromise;
    } else if (!cached) {
        orderBodies.forEach(tbody => { tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding: 40px;">Sincronizando pedidos...</td></tr>'; });
        invoiceBodies.forEach(tbody => { tbody.innerHTML = '<tr><td colspan="7" style="text-align:center; padding: 40px;">Sincronizando facturas...</td></tr>'; });
    }

    if (adminOrdersLoadPromise && !force) return adminOrdersLoadPromise;
    
    adminOrdersLoadPromise = (async () => {
    try {
        const [pedidosResponse, facturasResponse] = await Promise.all([
            fetch(GOOGLE_SHEET_API + "?resource=pedidos&action=get&_=" + Date.now(), { cache: 'no-store' }),
            fetch(GOOGLE_SHEET_API + "?resource=facturas&action=get&_=" + Date.now(), { cache: 'no-store' })
        ]);
        const [pedidosResult, facturasResult] = await Promise.all([
            pedidosResponse.json(),
            facturasResponse.json()
        ]);

        if (pedidosResult && pedidosResult.status === 'success' && Array.isArray(pedidosResult.data)) {
            // Validate both responses before replacing the displayed records.
        } else {
            throw new Error(pedidosResult.error || 'Error al cargar los pedidos');
        }

        if (facturasResult && facturasResult.status === 'success' && Array.isArray(facturasResult.data)) {
            window.facturasList = facturasResult.data.slice().reverse();
        } else {
            throw new Error(facturasResult?.error || 'No se pudieron cargar las facturas.');
        }

        window.pedidosList = pedidosResult.data.slice().reverse();
        writeAdminOrdersCache();
        renderPedidos();
        renderFacturas();
        renderAdminDashboard();
    } catch (err) {
        console.error(err);
        if (!cached) {
            orderBodies.forEach(tbody => { tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding: 40px; color: #ff4d4d;">Error conectando con la base de datos: ${escapeHtml(err.message)}</td></tr>`; });
            invoiceBodies.forEach(tbody => { tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding: 40px; color: #ff4d4d;">Error conectando con la base de datos: ${escapeHtml(err.message)}</td></tr>`; });
        }
        showToast(cached ? 'No se actualizaron los pedidos. Se conserva el listado anterior.' : 'Error cargando pedidos', cached ? 'warning' : 'error');
        if(options.throwOnError)throw err;
    } finally {
        adminOrdersLoadPromise = null;
    }
    })();

    return adminOrdersLoadPromise;
}

function getOrderIdValue(order) {
    return order && (order['ID Pedido'] || order.ID || order.id || '');
}

function getInvoiceIdValue(invoice) {
    return invoice && (invoice['ID Factura'] || invoice.ID || invoice.id || '');
}

function getInvoiceOrderIdValue(invoice) {
    return invoice && (invoice['ID Pedido'] || invoice['Pedido'] || '');
}

function getInvoiceCustomerName(invoice) {
    return invoice && (invoice.Nombre || invoice['Nombre Cliente'] || invoice.Cliente || '-');
}

function parseAdminInvoiceMoney(value) {
    if (value === undefined || value === null || value === '') return 0;
    if (typeof value === 'number') return Number.isFinite(value) ? value : 0;
    const cleaned = String(value)
        .replace(/[^\d,.-]/g, '')
        .replace(/\.(?=\d{3}(\D|$))/g, '')
        .replace(',', '.');
    const parsed = Number(cleaned);
    return Number.isFinite(parsed) ? parsed : 0;
}

function formatAdminInvoiceMoney(value) {
    const number = Math.max(0, Math.round(Number(value) || 0));
    return '$' + number.toLocaleString('es-CO');
}

function getInvoiceTotalFromItems(items) {
    return (items || []).reduce((sum, item) => {
        const qty = Number(item.cantidad || item.Cantidad || item.qty || 1) || 1;
        const price = Number(item.precio || item.Precio || item.price || 0) || 0;
        return sum + (qty * price);
    }, 0);
}

function getInvoicePaidValue(invoice) {
    if (!invoice) return 0;
    return parseAdminInvoiceMoney(
        invoice['Valor Abonado'] ??
        invoice['Total Abonado'] ??
        invoice.Abonado ??
        invoice.abonado ??
        invoice['Pago Recibido'] ??
        invoice.Pagado ??
        0
    );
}

function getInvoiceBalanceInfo(invoice, totalOverride) {
    const total = Number(totalOverride) || parseAdminInvoiceMoney(invoice?.Subtotal || invoice?.Total || 0);
    let paid = Math.min(Math.max(0, getInvoicePaidValue(invoice)), Math.max(0, total));
    const storedBalance = parseAdminInvoiceMoney(invoice?.['Saldo Pendiente'] ?? invoice?.Saldo ?? invoice?.saldo ?? '');
    if (paid === 0 && storedBalance > 0 && total > storedBalance) {
        paid = total - storedBalance;
    }
    const balance = Math.max(0, total - paid);
    return { total, paid, balance };
}

function normalizeAdminCustomerType(value) {
    const clean = String(value || '')
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .toLowerCase()
        .trim();
    if (clean.includes('mayor') || clean.includes('wholesale')) return 'mayor';
    if (clean.includes('detal') || clean.includes('minor') || clean.includes('retail')) return 'detal';
    return '';
}

function getInvoiceCustomerTypeLabel(value, fallback = 'Detal') {
    const raw = String(value || fallback || '').trim();
    const normalized = normalizeAdminCustomerType(raw);
    if (normalized === 'mayor') return 'Mayorista';
    if (normalized === 'detal') return 'Detal';
    return raw || 'Detal';
}

function inferAdminCustomerTypeFromId(value) {
    const id = String(value || '').toLowerCase().trim();
    if (id.startsWith('fac-may') || id.startsWith('may-') || id.includes('-may-')) return 'mayor';
    if (id.startsWith('fac-det') || id.startsWith('det-') || id.includes('-det-')) return 'detal';
    return '';
}

function setInvoiceCustomerTypeControl(value, fallback = 'Detal') {
    const control = document.getElementById('inv-edit-tipo');
    if (!control) return;
    const label = getInvoiceCustomerTypeLabel(value, fallback);
    if (control.tagName === 'SELECT' && !Array.from(control.options).some(option => option.value === label)) {
        const option = document.createElement('option');
        option.value = label;
        option.textContent = label;
        control.appendChild(option);
    }
    control.value = label;
}

function inferOrderCustomerType(order) {
    if (!order) return 'detal';
    const idType = inferAdminCustomerTypeFromId(getOrderIdValue(order));
    if (idType) return idType;

    const explicit = normalizeAdminCustomerType(order['Tipo Cliente'] || order.Tipo || order.tipo || order.ClienteTipo);
    if (explicit) return explicit;

    const id = String(getOrderIdValue(order) || '').toLowerCase();
    if (id.startsWith('may-')) return 'mayor';
    if (id.startsWith('det-')) return 'detal';

    const method = String(order['Método Contacto'] || order['Metodo Contacto'] || order.Metodo || '').toLowerCase();
    const methodType = normalizeAdminCustomerType(method);
    if (methodType) return methodType;

    try {
        const jsonStr = order['Productos JSON'] || order.Productos;
        const items = typeof jsonStr === 'string' ? JSON.parse(jsonStr) : (Array.isArray(jsonStr) ? jsonStr : []);
        if (items.some(item => normalizeAdminCustomerType(item.modo || item.mode || item.tipo) === 'mayor')) return 'mayor';
    } catch (error) {
        // Si no se puede leer el JSON, dejamos el pedido como detal por compatibilidad.
    }

    return 'detal';
}

function inferInvoiceCustomerType(invoice) {
    if (!invoice) return 'detal';
    const invoiceIdType = inferAdminCustomerTypeFromId(getInvoiceIdValue(invoice));
    if (invoiceIdType) return invoiceIdType;

    const orderIdType = inferAdminCustomerTypeFromId(getInvoiceOrderIdValue(invoice));
    if (orderIdType) return orderIdType;

    const explicit = normalizeAdminCustomerType(invoice['Tipo Cliente'] || invoice.Tipo || invoice.tipo || invoice.ClienteTipo);
    if (explicit) return explicit;

    const idPedido = String(getInvoiceOrderIdValue(invoice) || '').trim();
    if (idPedido) {
        const linkedOrder = (window.pedidosList || []).find(order => String(getOrderIdValue(order)).trim() === idPedido);
        if (linkedOrder) return inferOrderCustomerType(linkedOrder);
        const lowerId = idPedido.toLowerCase();
        if (lowerId.startsWith('may-')) return 'mayor';
        if (lowerId.startsWith('det-')) return 'detal';
    }

    try {
        const jsonStr = invoice['Productos JSON'] || invoice.Productos;
        const items = typeof jsonStr === 'string' ? JSON.parse(jsonStr) : (Array.isArray(jsonStr) ? jsonStr : []);
        if (items.some(item => normalizeAdminCustomerType(item.modo || item.mode || item.tipo) === 'mayor')) return 'mayor';
    } catch (error) {
        // Mantener compatibilidad con facturas manuales.
    }

    return 'detal';
}

function getInvoiceStatusColor(estado) {
    const value = String(estado || '').toLowerCase();
    if (value.includes('final') || value.includes('complet') || value.includes('enviado') || value.includes('pagado') || value.includes('pago') || value.includes('abon')) return '#10B981';
    if (value.includes('cancel')) return '#EF4444';
    return '#9ca3af';
}

function buildInvoiceStatusSelect(idx, estado) {
    const options = ['Pendiente', 'Abonada', 'Pago', 'Enviado', 'Finalizada'];
    const current = String(estado || 'Pendiente').trim();
    const allOptions = options.includes(current) ? options : [current, ...options];
    return `<select class="invoice-status-select" onchange="updateAdminInvoiceStatus(${idx}, this.value, this)" aria-label="Cambiar estado de factura">
        ${allOptions.map(option => `<option value="${escapeHtml(option)}"${option === current ? ' selected' : ''}>${escapeHtml(option)}</option>`).join('')}
    </select>`;
}

function getOrdersSearchQuery() {
    return String(document.getElementById('admin-orders-search')?.value || '').toLowerCase().trim();
}

function recordMatchesOrdersSearch(record, fields) {
    const query = getOrdersSearchQuery();
    if (!query) return true;
    return fields.map(value => String(value || '')).join(' ').toLowerCase().includes(query);
}

function getFacturedOrderIds() {
    return new Set((window.facturasList || [])
        .map(f => String(getInvoiceOrderIdValue(f)).trim())
        .filter(Boolean));
}

function formatInvoiceListDate(fecha) {
    if (!fecha) return '-';
    const date = new Date(fecha);
    if (Number.isNaN(date.getTime())) return String(fecha);
    return date.toLocaleDateString();
}

function getOrderTableTargets() {
    const targets = [
        { type: 'mayor', tbodyId: 'orders-mayor-tbody', badgeId: 'orders-mayor-count-badge' },
        { type: 'detal', tbodyId: 'orders-detal-tbody', badgeId: 'orders-detal-count-badge' }
    ].filter(target => document.getElementById(target.tbodyId));

    if (!targets.length && document.getElementById('orders-tbody')) {
        targets.push({ type: 'all', tbodyId: 'orders-tbody', badgeId: 'orders-count-badge' });
    }

    return targets;
}

function getInvoiceTableTargets() {
    const targets = [
        { type: 'mayor', tbodyId: 'invoices-mayor-tbody', badgeId: 'invoices-mayor-count-badge' },
        { type: 'detal', tbodyId: 'invoices-detal-tbody', badgeId: 'invoices-detal-count-badge' }
    ].filter(target => document.getElementById(target.tbodyId));

    if (!targets.length && document.getElementById('invoices-tbody')) {
        targets.push({ type: 'all', tbodyId: 'invoices-tbody', badgeId: 'invoices-count-badge' });
    }

    return targets;
}

function buildOrderRowHtml(p, idx) {
    const id=getOrderIdValue(p)||'-',quoted=window.OriginalStoreOrderAdmin?.kind(p)==='quote';
    const total=Number(p.Subtotal||p.Total||0),state=p['Estado Pedido']||p.Estado||'Pendiente';
    const totalLabel=total>0?formatAdminInvoiceMoney(total)+(quoted?' · estimado':'')+(Number(p['Precios Pendientes'])>0?' · parcial':''):'Por cotizar';
    return `<tr><td data-label="Pedido">${escapeHtml(id)}<br><small>${escapeHtml(OriginalStoreOrderFlow.labels[OriginalStoreOrderFlow.kindOf(p)].document)}</small></td>
        <td data-label="Fecha">${escapeHtml(formatInvoiceListDate(p.Fecha||''))}</td>
        <td data-label="Cliente">${escapeHtml(p['Nombre Cliente']||p.Nombre||'-')}<br><small>${escapeHtml(p['Teléfono']||p.Telefono||'')}</small></td>
        <td data-label="Total">${totalLabel}</td><td data-label="Estado">${escapeHtml(state)}</td>
        <td data-label="Accion" class="orders-actions-cell"><button class="orders-action-btn" type="button" onclick="${quoted?`OriginalStoreOrderAdmin.review(${idx})`:`abrirEditorFactura(${idx})`}">${quoted?'Revisar cotización':'Facturar'}</button></td></tr>`;
}

function buildInvoiceRowHtml(f, idx) {
    const idFactura = getInvoiceIdValue(f) || '-';
    const idPedido = getInvoiceOrderIdValue(f) || '-';
    const fecha = f.Fecha || '-';
    const cliente = getInvoiceCustomerName(f);
    const total = parseAdminInvoiceMoney(f.Subtotal || f.Total || 0);
    const balanceInfo = getInvoiceBalanceInfo(f, total);
    const estado = f['Estado Factura'] || f.Estado || 'Finalizada';
    const colorEstado = getInvoiceStatusColor(estado);

    return `
        <tr style="background: rgba(255,255,255,0.02); border-bottom: 1px solid rgba(255,255,255,0.05);">
            <td data-label="Factura" style="font-weight:700;">${escapeHtml(idFactura)}</td>
            <td data-label="Pedido" style="font-size:12px; color:var(--text-muted);">${escapeHtml(idPedido)}</td>
            <td data-label="Fecha" style="font-size:12px; color:var(--text-muted);">${formatInvoiceListDate(fecha)}</td>
            <td data-label="Cliente" style="font-weight:600;">${escapeHtml(cliente)} <br><span style="font-size:10px; color:var(--primary);">${escapeHtml(f['ID Cliente'] || '')}</span></td>
            <td data-label="Total" style="font-weight:800; color:#fff;">
                <div>${formatAdminInvoiceMoney(total)}</div>
                <div style="font-size:10px; color:#34d399; font-weight:800;">Abonado: ${formatAdminInvoiceMoney(balanceInfo.paid)}</div>
                <div style="font-size:10px; color:${balanceInfo.balance > 0 ? '#fbbf24' : '#34d399'}; font-weight:800;">Saldo: ${formatAdminInvoiceMoney(balanceInfo.balance)}</div>
            </td>
            <td data-label="Estado">${buildInvoiceStatusSelect(idx, estado)}<div style="margin-top:5px;"><span style="background:rgba(255,255,255,0.1); color:${colorEstado}; padding:4px 8px; border-radius:12px; font-size:10px; font-weight:800;">${escapeHtml(estado)}</span></div></td>
            <td data-label="Accion" class="orders-actions-cell" style="display:flex; gap:6px; flex-wrap:wrap;">
                <button class="orders-action-btn invoice-pay" onclick="openQuickInvoicePayment(${idx})" type="button" title="${balanceInfo.balance > 0 ? 'Registrar abono rapido' : 'Factura sin saldo pendiente'}" ${balanceInfo.balance > 0 ? '' : 'disabled'}>
                    <svg viewBox="0 0 24 24" aria-hidden="true" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2"><rect x="2" y="5" width="20" height="14" rx="2"></rect><path d="M2 10h20"></path><path d="M7 15h4"></path><path d="M17 13v4"></path><path d="M15 15h4"></path></svg>
                    Abonar
                </button>
                <button class="orders-action-btn invoice-done" onclick="abrirEditorFactura(${idx}, 'factura')" type="button" title="Ver / Editar factura">
                    <svg viewBox="0 0 24 24" aria-hidden="true" width="14" height="14"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"></path><path d="M14 2v6h6"></path><path d="M9 15h6"></path><path d="M9 11h2"></path></svg>
                    Ver
                </button>
                <button class="orders-action-btn orders-whatsapp-btn" onclick="sendAdminInvoiceRowToWhatsApp(${idx})" type="button" title="Enviar PDF de factura a cliente por WhatsApp">
                    <svg viewBox="0 0 24 24" aria-hidden="true" width="14" height="14" fill="currentColor"><path d="M12.012 2c-5.506 0-9.989 4.478-9.99 9.984 0 1.758.459 3.474 1.33 4.982L2 22l5.176-1.348c1.45.791 3.097 1.207 4.832 1.208h.004c5.505 0 9.987-4.478 9.988-9.985 0-2.667-1.038-5.174-2.924-7.06A9.923 9.923 0 0 0 12.012 2zm5.666 14.155c-.234.66-1.164 1.213-1.61 1.264-.42.047-.962.217-3.237-.723-2.73-1.127-4.48-3.9-4.617-4.084-.136-.184-1.11-1.48-1.11-2.822 0-1.343.702-2.003.953-2.274.252-.27.548-.338.732-.338.183 0 .366.002.525.01.17.007.397-.064.62.47.234.56.797 1.946.866 2.086.069.14.115.303.023.486-.092.183-.138.297-.275.457-.137.16-.289.358-.413.481-.137.137-.28.287-.12.562.16.275.71 1.173 1.526 1.9 1.05.937 1.936 1.228 2.21 1.365.275.137.435.115.596-.068.16-.184.686-.8.869-1.075.183-.275.366-.229.617-.137.251.092 1.597.753 1.871.89.275.137.458.206.526.32.069.115.069.664-.165 1.324z"/></svg>
                    WhatsApp
                </button>
            </td>
        </tr>
    `;
}

function renderPedidos() {
    const tbody = document.getElementById('orders-tbody');
    const facturedOrderIds = getFacturedOrderIds();
    const pendingOrders = (window.pedidosList || [])
        .map((p, idx) => ({ p, idx }))
        .filter(({ p }) => {
            if(window.OriginalStoreOrderAdmin && !OriginalStoreOrderAdmin.filter(p))return false;
            const id = String(getOrderIdValue(p)).trim();
            if (id && facturedOrderIds.has(id)) return false;
            const estado = p['Estado Pedido'] || p.Estado || '';
            if (String(estado).toLowerCase().includes('factur')) return false;
            return recordMatchesOrdersSearch(p, [
                id,
                p.Fecha,
                p['Nombre Cliente'],
                p.Nombre,
                p['Teléfono'],
                p.Telefono,
                estado
            ]);
        });

    getOrderTableTargets().forEach(target => {
        const tbody = document.getElementById(target.tbodyId);
        const rows = target.type === 'all'
            ? pendingOrders
            : pendingOrders.filter(({ p }) => inferOrderCustomerType(p) === target.type);
        const badge = document.getElementById(target.badgeId);
        if (badge) badge.textContent = rows.length;

        if (!tbody) return;
        tbody.innerHTML = rows.length
            ? rows.map(({ p, idx }) => buildOrderRowHtml(p, idx)).join('')
            : '<tr><td colspan="6" style="text-align:center; padding: 40px;">No hay pedidos pendientes en esta vista.</td></tr>';
    });
    return;

    const badge = document.getElementById('orders-count-badge');
    if (badge) badge.textContent = pendingOrders.length;

    if (pendingOrders.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding: 40px;">No hay pedidos pendientes en esta vista.</td></tr>';
        return;
    }

    const html = pendingOrders.map(({ p, idx }) => {
        const id = getOrderIdValue(p) || '-';
        const fecha = p.Fecha || '-';
        const cliente = p['Nombre Cliente'] || p.Nombre || '-';
        const total = parseFloat(p.Subtotal || p.Total || 0);
        const estado = p['Estado Pedido'] || p.Estado || 'Pendiente';
        
        const colorEstado = getInvoiceStatusColor(estado);

        return `
            <tr style="background: rgba(255,255,255,0.02); border-bottom: 1px solid rgba(255,255,255,0.05);">
                <td style="font-weight:700;">${escapeHtml(id)}</td>
                <td style="font-size:12px; color:var(--text-muted);">${formatInvoiceListDate(fecha)}</td>
                <td style="font-weight:600;">${escapeHtml(cliente)} <br><span style="font-size:10px; color:var(--primary);">${escapeHtml(p['Teléfono'] || p.Telefono || '')}</span></td>
                <td style="font-weight:800; color:#fff;">$${total.toLocaleString('es-CO')}</td>
                <td><span style="background:rgba(255,255,255,0.1); color:${colorEstado}; padding:4px 8px; border-radius:12px; font-size:11px; font-weight:700;">${escapeHtml(estado)}</span></td>
                <td class="orders-actions-cell">
                    <button class="orders-action-btn" onclick="abrirEditorFactura(${idx})" type="button" title="Ajustar factura">
                        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20h9"></path><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"></path></svg>
                        Facturar
                    </button>
                </td>
            </tr>
        `;
    }).join('');
    
    tbody.innerHTML = html;
}

function renderFacturas() {
    const tbody = document.getElementById('invoices-tbody');
    if (!getInvoiceTableTargets().length) return;

    const invoices = (window.facturasList || [])
        .map((f, idx) => ({ f, idx }))
        .filter(({ f }) => recordMatchesOrdersSearch(f, [
            getInvoiceIdValue(f),
            getInvoiceOrderIdValue(f),
            f.Fecha,
            getInvoiceCustomerName(f),
            f['ID Cliente'],
            f['Estado Factura'],
            f.Estado,
            f.Subtotal,
            f['Valor Abonado'],
            f['Saldo Pendiente']
        ]));

    getInvoiceTableTargets().forEach(target => {
        const tbody = document.getElementById(target.tbodyId);
        const rows = target.type === 'all'
            ? invoices
            : invoices.filter(({ f }) => inferInvoiceCustomerType(f) === target.type);
        const badge = document.getElementById(target.badgeId);
        if (badge) badge.textContent = rows.length;

        if (!tbody) return;
        tbody.innerHTML = rows.length
            ? rows.map(({ f, idx }) => buildInvoiceRowHtml(f, idx)).join('')
            : '<tr><td colspan="7" style="text-align:center; padding: 40px;">No hay facturas finalizadas en esta vista.</td></tr>';
    });
    return;

    const badge = document.getElementById('invoices-count-badge');
    if (badge) badge.textContent = invoices.length;

    if (invoices.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" style="text-align:center; padding: 40px;">No hay facturas finalizadas en esta vista.</td></tr>';
        return;
    }

    tbody.innerHTML = invoices.map(({ f, idx }) => {
        const idFactura = getInvoiceIdValue(f) || '-';
        const idPedido = getInvoiceOrderIdValue(f) || '-';
        const fecha = f.Fecha || '-';
        const cliente = getInvoiceCustomerName(f);
        const total = parseFloat(f.Subtotal || f.Total || 0);
        const estado = f['Estado Factura'] || f.Estado || 'Finalizada';
        const colorEstado = getInvoiceStatusColor(estado);

        return `
            <tr style="background: rgba(255,255,255,0.02); border-bottom: 1px solid rgba(255,255,255,0.05);">
                <td style="font-weight:700;">${escapeHtml(idFactura)}</td>
                <td style="font-size:12px; color:var(--text-muted);">${escapeHtml(idPedido)}</td>
                <td style="font-size:12px; color:var(--text-muted);">${formatInvoiceListDate(fecha)}</td>
                <td style="font-weight:600;">${escapeHtml(cliente)} <br><span style="font-size:10px; color:var(--primary);">${escapeHtml(f['ID Cliente'] || '')}</span></td>
                <td style="font-weight:800; color:#fff;">$${total.toLocaleString('es-CO')}</td>
                <td><span style="background:rgba(255,255,255,0.1); color:${colorEstado}; padding:4px 8px; border-radius:12px; font-size:11px; font-weight:700;">${escapeHtml(estado)}</span></td>
                <td class="orders-actions-cell">
                    <button class="orders-action-btn invoice-done" onclick="abrirEditorFactura(${idx}, 'factura')" type="button" title="Ver factura">
                        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"></path><path d="M14 2v6h6"></path><path d="M9 15h6"></path><path d="M9 11h2"></path></svg>
                        Ver factura
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

function initOrdersAdminTabs() {
    const container = document.getElementById('view-orders');
    if (!container || container.dataset.ordersTabsReady === 'true') return;
    container.dataset.ordersTabsReady = 'true';

    const tabs = Array.from(container.querySelectorAll('[data-orders-tab-target]'));
    const panels = Array.from(container.querySelectorAll('[data-orders-tab]'));
    const searchInput = document.getElementById('admin-orders-search');

    function activate(tabId) {
        if (tabId === 'quick-sale') {
            switchDashboardView('quick-sale', 'Caja rápida');
            return;
        }
        if (!tabs.some(btn => btn.dataset.ordersTabTarget === tabId)) tabId = 'orders-mayor';
        window.activeOrdersAdminTab = tabId;
        tabs.forEach(btn => {
            const active = btn.dataset.ordersTabTarget === tabId;
            btn.classList.toggle('active', active);
            btn.setAttribute('aria-selected', active ? 'true' : 'false');
        });
        panels.forEach(panel => {
            const active = panel.dataset.ordersTab === tabId;
            panel.classList.toggle('active', active);
            panel.hidden = !active;
        });
        const ordersShell = container.querySelector('.orders-admin-shell');
        if (ordersShell) ordersShell.scrollLeft = 0;
        container.scrollLeft = 0;
        if (searchInput) {
            searchInput.style.display = '';
        }

    }

    window.switchOrdersAdminTab = activate;
    tabs.forEach(btn => btn.addEventListener('click', () => activate(btn.dataset.ordersTabTarget)));
    if (searchInput) {
        searchInput.addEventListener('input', () => {
            renderPedidos();
            renderFacturas();
        });
    }

    activate(window.activeOrdersAdminTab || 'orders-mayor');
}

// === CREADOR Y EDITOR DE FACTURAS ===
window.invoiceItems = [];
window.invoiceEditIndex = null; // null si es nueva, o el index de la lista activa
window.invoiceEditSource = 'manual';
window.invoiceOriginalInvoiceId = '';
window.invoiceCustomerType = 'Detal';
window.invoiceSearchResults = [];
window.invoiceInventoryLoadingPromise = null;
window.invoiceInventoryLoadTried = false;
window.invoicePreviousPayment = 0;
window.quickSaleCart = [];
window.quickSaleResults = [];
window.quickSaleGroups = new Map();
window.quickSaleSelectedKey = '';
window.quickSaleCategory = 'all';
window.quickSaleMobilePane = 'client';
window.quickSaleHeldTicket = null;

function readInvoiceField(source, fields, fallback = '') {
    return getProductField(source || {}, fields, fallback);
}

function formatDateForInvoiceInput(value) {
    if (!value) return new Date().toISOString().slice(0, 10);
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return new Date().toISOString().slice(0, 10);
    return date.toISOString().slice(0, 10);
}

function getInvoiceProductId(product) {
    return readInvoiceField(product, ['idVariacion', 'ID', 'ID Variacion', 'ID Variación', 'ID Variación', 'SKU'], '') || ('ITEM-' + Date.now());
}

function getInvoiceProductName(product) {
    return readInvoiceField(product, ['Nombre', 'Nombre del Producto', 'Producto'], 'Producto');
}

function getInvoiceProductSku(product) {
    return readInvoiceField(product, ['SKU', 'Referencia', 'ID Variacion', 'ID Variación', 'ID Variación'], '');
}

function getInvoiceProductPrice(product) {
    const wholesale = parseFloat(readInvoiceField(product, ['Precio Mayor', 'Precio Mayorista', 'precioMayorista'], 0));
    if (wholesale > 0) return wholesale;
    return parseFloat(readInvoiceField(product, ['Precio', 'Precio Unitario', 'price'], 0)) || 0;
}

async function ensureInvoiceInventoryLoaded() {
    if (Array.isArray(inventario) && inventario.length > 0) return;
    if (window.invoiceInventoryLoadingPromise) return window.invoiceInventoryLoadingPromise;
    if (window.invoiceInventoryLoadTried) return;
    window.invoiceInventoryLoadTried = true;

    const resultsContainer = document.getElementById('inv-search-results');
    const searchInput = document.getElementById('inv-product-search');
    if (resultsContainer && searchInput && searchInput.value.trim().length >= 2) {
        resultsContainer.innerHTML = '<div class="inv-search-empty">Cargando productos...</div>';
        resultsContainer.classList.add('active');
    }

    window.invoiceInventoryLoadingPromise = cargarInventario({ silent: true }).finally(() => {
        window.invoiceInventoryLoadingPromise = null;
        if (document.getElementById('invoice-editor-modal')?.classList.contains('open')) renderItemsFactura();
    });
    return window.invoiceInventoryLoadingPromise;
}

function getQuickSaleStock(product) {
    return Number(getProductField(product || {}, ['Cantidad', 'Stock', 'Stock Inicial'], 0)) || 0;
}

function getQuickSalePrice(product, customerType) {
    const type = normalizeAdminCustomerType(customerType || document.getElementById('quick-sale-customer-type')?.value || 'Detal');
    const retail = parseAdminInvoiceMoney(getProductField(product || {}, ['Precio'], 0));
    const wholesale = parseAdminInvoiceMoney(getProductField(product || {}, ['Precio Mayor', 'Precio Mayorista', 'Precio_Mayorista'], 0));
    return type === 'mayor' && wholesale > 0 ? wholesale : retail;
}

function getQuickSaleProductMeta(product) {
    const key = getInventoryProductKey(product);
    const name = getInvoiceProductName(product);
    const sku = getInvoiceProductSku(product) || getInvoiceProductId(product);
    const image = getInventoryProductImage(product, 'inventory') || normalizeImageUrl(product?.Imagen || product?.['Imagen Principal'] || '', 'inventory') || 'https://lh3.googleusercontent.com/d/1OTHvWFph2u3qFQMQVhE5ghmSWjBSgBeW=w180';
    const category = getProductField(product, PRODUCT_CATEGORY_FIELD_KEYS, '');
    const color = getProductField(product, ['Color', 'color'], '');
    const size = getProductField(product, ['Tamano', 'Tamaño', 'Talla', 'Talla Textil'], '');
    const style = cleanProductStyleValue(getProductField(product, ['Estilo', 'estilo'], ''));
    const description = getProductField(product, ['Caracteristicas del producto', 'Características del producto', 'Descripcion', 'Descripción'], '');
    return { key, name, sku, image, category, color, size, style, description, stock: getQuickSaleStock(product) };
}

function getQuickSaleSearchText(product) {
    return normalizeSearchText([
        getInvoiceProductName(product),
        getInvoiceProductSku(product),
        getInvoiceProductId(product),
        getProductBarcode(product),
        getProductField(product, PRODUCT_CATEGORY_FIELD_KEYS, ''),
        product?.Color,
        product?.Estilo,
        product?.Tamano,
        product?.Descripcion
    ].join(' '));
}

function getQuickSaleGroupKey(product) {
    const motherId = getInventoryMotherId(product);
    const variationId = getInventoryVariationId(product);
    if (motherId && normalizeSearchText(motherId) !== normalizeSearchText(variationId)) {
        return `mother:${motherId}`;
    }
    return `item:${getInventoryProductKey(product)}`;
}

function getQuickSaleVariantLabel(product) {
    const meta = getQuickSaleProductMeta(product);
    const attributes = [meta.color, meta.size, meta.style].filter(Boolean).join(' / ');
    return String(attributes || meta.sku || getInvoiceProductId(product) || 'Variante');
}

function groupQuickSaleProducts(products) {
    const groups = new Map();
    products.forEach(product => {
        const groupKey = getQuickSaleGroupKey(product);
        if (!groups.has(groupKey)) groups.set(groupKey, { key: groupKey, variants: [] });
        groups.get(groupKey).variants.push(product);
    });

    return Array.from(groups.values()).map(group => {
        group.variants.sort((a, b) => {
            const stockOrder = Number(getQuickSaleStock(b) > 0) - Number(getQuickSaleStock(a) > 0);
            return stockOrder || getQuickSaleVariantLabel(a).localeCompare(getQuickSaleVariantLabel(b), 'es');
        });
        group.product = group.variants.find(product => getInventoryProductKey(product) === window.quickSaleSelectedKey)
            || group.variants[0];
        return group;
    });
}

function findQuickSaleProductByReference(rawCode) {
    const code = normalizeBarcodeValue(rawCode);
    if (!code || !Array.isArray(inventario)) return null;
    return inventario.find(product => {
        if (isBannerInventoryProduct(product)) return false;
        const references = [
            getProductBarcode(product),
            getInvoiceProductSku(product),
            getInvoiceProductId(product),
            getInventoryVariationId(product),
            getInventoryMotherId(product)
        ].map(normalizeBarcodeValue).filter(Boolean);
        return references.includes(code);
    }) || null;
}

async function handleQuickSaleScannedCode(rawCode, addToSale = true) {
    const code = normalizeBarcodeValue(rawCode);
    const input = document.getElementById('quick-sale-search');
    if (!code || !input) return false;

    input.value = code;
    if (!Array.isArray(inventario) || !inventario.length) {
        await cargarInventario({ silent: true });
    }
    renderQuickSaleResults();

    let product = findQuickSaleProductByReference(code);
    if (!product) {
        await cargarInventario({ silent: true });
        product = findQuickSaleProductByReference(code);
        renderQuickSaleResults();
    }
    if (!product) {
        showToast('No se encontro un producto con esa referencia', 'warning');
        input.focus();
        input.select();
        return false;
    }

    const key = getInventoryProductKey(product);
    selectQuickSaleProduct(key);
    if (addToSale && getQuickSaleStock(product) > 0) {
        addQuickSaleProduct(key, 1);
        showToast('Producto escaneado y agregado a la venta', 'success');
    } else if (getQuickSaleStock(product) <= 0) {
        showToast('Producto encontrado, pero esta agotado', 'warning');
    } else {
        showToast('Producto encontrado por referencia', 'success');
    }
    return true;
}

window.handleQuickSaleScannedCode = handleQuickSaleScannedCode;

function openQuickSaleScanner() {
    openBarcodeScanner({
        targetInputId: 'quick-sale-search',
        scannerMode: 'qr',
        onDetected: code => {
            handleQuickSaleScannedCode(code, true).catch(error => {
                console.error('No se pudo procesar el codigo escaneado:', error);
                showToast('No se pudo procesar el codigo escaneado', 'error');
            });
        }
    });
}

window.openQuickSaleScanner = openQuickSaleScanner;

function syncQuickSaleMobilePane(pane = window.quickSaleMobilePane) {
    const catalog = document.querySelector('.quick-sale-catalog-panel');
    const checkout = document.querySelector('.quick-sale-checkout-panel');
    const buttons = document.querySelectorAll('[data-quick-sale-pane]');
    if (!catalog || !checkout) return;

    window.quickSaleMobilePane = ['client', 'catalog', 'checkout'].includes(pane) ? pane : 'client';
    const layout = document.querySelector('.enterprise-pos-layout');
    if (layout) layout.dataset.activePane = window.quickSaleMobilePane;
    const client = document.querySelector('.quick-sale-client-panel');
    const compact = window.matchMedia('(max-width: 1024px)').matches;
    client?.classList.toggle('pos-mobile-hidden', compact && window.quickSaleMobilePane !== 'client');
    catalog.classList.toggle('pos-mobile-hidden', compact && window.quickSaleMobilePane !== 'catalog');
    checkout.classList.toggle('pos-mobile-hidden', compact && window.quickSaleMobilePane !== 'checkout');
    buttons.forEach(button => {
        const active = button.dataset.quickSalePane === window.quickSaleMobilePane;
        button.classList.toggle('active', active);
        button.setAttribute('aria-selected', active ? 'true' : 'false');
    });
}

window.setQuickSaleMobilePane = function(pane) {
    syncQuickSaleMobilePane(pane);
    document.querySelector('.quick-sale-mobile-tabs')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
};

function renderQuickSaleCategories() {
    const container = document.getElementById('quick-sale-categories');
    if (!container) return;
    const categories = Array.from(new Set((inventario || [])
        .filter(product => !isBannerInventoryProduct(product))
        .map(product => String(getProductField(product, PRODUCT_CATEGORY_FIELD_KEYS, '') || '').trim())
        .filter(Boolean)))
        .sort((a, b) => a.localeCompare(b, 'es'));
    const activeCategory = window.quickSaleCategory || 'all';
    const buttons = [{ value: 'all', label: 'Todos' }, ...categories.map(category => ({ value: category, label: category }))];
    container.innerHTML = buttons.map(item => `
        <button class="quick-sale-category-btn${item.value === activeCategory ? ' active' : ''}" type="button" data-quick-sale-category="${escapeHtml(item.value)}">
            ${escapeHtml(item.label)}
        </button>
    `).join('');
}

window.setQuickSaleCategory = function(category) {
    window.quickSaleCategory = String(category || 'all');
    renderQuickSaleCategories();
    renderQuickSaleResults();
};

function renderQuickSaleResults() {
    const container = document.getElementById('quick-sale-results');
    const input = document.getElementById('quick-sale-search');
    if (!container || !input) return;

    if (!Array.isArray(inventario) || !inventario.length) {
        container.innerHTML = '<div class="quick-sale-empty">Cargando inventario...</div>';
        cargarInventario({ silent: true }).then(renderQuickSaleResults).catch(() => {});
        return;
    }

    renderQuickSaleCategories();
    const q = normalizeSearchText(input.value || '');
    const terms = q.split(/\s+/).filter(Boolean);
    const activeCategory = window.quickSaleCategory === 'all' ? '' : normalizeSearchText(window.quickSaleCategory);
    const matchingProducts = inventario
        .filter(product => !isBannerInventoryProduct(product))
        .filter(product => !activeCategory || normalizeSearchText(getProductField(product, PRODUCT_CATEGORY_FIELD_KEYS, '')) === activeCategory)
        .map(product => {
            const text = getQuickSaleSearchText(product);
            const matches = terms.every(term => text.includes(term));
            if (!matches) return null;
            let score = 0;
            terms.forEach(term => {
                if (normalizeSearchText(getInvoiceProductName(product)).startsWith(term)) score += 50;
                if (normalizeSearchText(getInvoiceProductSku(product)).includes(term)) score += 30;
                if (normalizeSearchText(getProductBarcode(product)).includes(term)) score += 35;
            });
            if (getQuickSaleStock(product) > 0) score += 5;
            return { product, score };
        })
        .filter(Boolean)
        .sort((a, b) => b.score - a.score || getInvoiceProductName(a.product).localeCompare(getInvoiceProductName(b.product), 'es'))
        .map(entry => entry.product);
    const groups = groupQuickSaleProducts(matchingProducts).slice(0, 24);
    const toggle = document.getElementById('quick-sale-catalog-toggle');
    if (toggle) toggle.hidden = groups.length <= 2;
    const results = groups.map(group => group.product);

    window.quickSaleResults = results;
    window.quickSaleGroups = new Map(groups.map(group => [group.key, group]));

    if (!results.length) {
        const detail = q ? ` para "${escapeHtml(input.value)}"` : ' en esta categoria';
        container.innerHTML = `<div class="quick-sale-empty">Sin productos${detail}.</div>`;
        return;
    }

    container.innerHTML = groups.map(group => {
        const product = group.product;
        const meta = getQuickSaleProductMeta(product);
        const price = getQuickSalePrice(product);
        const stockClass = meta.stock <= 0 ? 'out' : (meta.stock <= 3 ? 'low' : '');
        const active = meta.key === window.quickSaleSelectedKey ? ' active' : '';
        const hasVariants = group.variants.length > 1;
        const variantControl = hasVariants ? `
            <label class="quick-sale-variant-field">
                <span>Elegir variante · ${group.variants.length} opciones</span>
                <select class="quick-sale-variant-select" data-quick-sale-group="${escapeHtml(group.key)}" aria-label="Elegir color o variante de ${escapeHtml(meta.name)}">
                    ${group.variants.map(variant => {
                        const variantMeta = getQuickSaleProductMeta(variant);
                        const variantPrice = getQuickSalePrice(variant);
                        const selected = variantMeta.key === meta.key ? ' selected' : '';
                        const availability = variantMeta.stock > 0 ? `${variantMeta.stock} und.` : 'Agotado';
                        return `<option value="${escapeHtml(variantMeta.key)}"${selected}>${escapeHtml(getQuickSaleVariantLabel(variant))} · ${availability} · ${formatAdminInvoiceMoney(variantPrice)}</option>`;
                    }).join('')}
                </select>
            </label>
        ` : `<small class="quick-sale-variant-current">${escapeHtml(getQuickSaleVariantLabel(product))}</small>`;
        return `
            <article class="quick-sale-product-tile${hasVariants ? ' has-variants' : ''}${active}" data-quick-sale-group="${escapeHtml(group.key)}" data-quick-sale-key="${escapeHtml(meta.key)}" tabindex="0">
                <div class="quick-sale-tile-image">
                    <img src="${escapeHtml(meta.image)}" alt="${escapeHtml(meta.name)}" loading="lazy" decoding="async" referrerpolicy="no-referrer" onerror="this.src='https://lh3.googleusercontent.com/d/1OTHvWFph2u3qFQMQVhE5ghmSWjBSgBeW=w180'">
                    <span class="quick-sale-stock-pill ${stockClass}">${meta.stock > 0 ? meta.stock + ' und.' : 'Agotado'}</span>
                </div>
                <div class="quick-sale-tile-copy">
                    <strong>${escapeHtml(meta.name)}</strong>
                    <span class="quick-sale-tile-meta">${escapeHtml(meta.category || 'Sin categoria')} · ${escapeHtml(meta.sku || 'S/N')}</span>
                    ${variantControl}
                </div>
                <div class="quick-sale-tile-bottom">
                    <b class="quick-sale-tile-price">${formatAdminInvoiceMoney(price)}</b>
                    <button class="quick-sale-info-card" type="button" data-quick-sale-info-group="${escapeHtml(group.key)}" aria-label="Información de ${escapeHtml(meta.name)}" title="Información del producto">ⓘ</button>
                    <button class="quick-sale-add-card" type="button" data-quick-sale-add-group="${escapeHtml(group.key)}" ${meta.stock <= 0 ? 'disabled' : ''} aria-label="Añadir ${escapeHtml(meta.name)}">+</button>
                </div>
            </article>
        `;
    }).join('');
}

function refreshQuickSaleTileForVariant(tile, product) {
    if (!tile || !product) return;
    const meta = getQuickSaleProductMeta(product);
    const image = tile.querySelector('.quick-sale-tile-image img');
    const stock = tile.querySelector('.quick-sale-stock-pill');
    const metaLine = tile.querySelector('.quick-sale-tile-meta');
    const variantLine = tile.querySelector('.quick-sale-variant-current');
    const price = tile.querySelector('.quick-sale-tile-price');
    const addButton = tile.querySelector('[data-quick-sale-add-group]');

    tile.dataset.quickSaleKey = meta.key;
    if (image) {
        image.src = meta.image;
        image.alt = meta.name;
    }
    if (stock) {
        stock.classList.remove('out', 'low');
        if (meta.stock <= 0) stock.classList.add('out');
        else if (meta.stock <= 3) stock.classList.add('low');
        stock.textContent = meta.stock > 0 ? `${meta.stock} und.` : 'Agotado';
    }
    if (metaLine) metaLine.textContent = `${meta.category || 'Sin categoria'} · ${meta.sku || 'S/N'}`;
    if (variantLine) variantLine.textContent = getQuickSaleVariantLabel(product);
    if (price) price.textContent = formatAdminInvoiceMoney(getQuickSalePrice(product));
    if (addButton) addButton.disabled = meta.stock <= 0;
}

function getQuickSaleGroupVariant(groupKey) {
    const group = window.quickSaleGroups.get(String(groupKey || ''));
    if (!group) return null;
    const tile = Array.from(document.querySelectorAll('.quick-sale-product-tile'))
        .find(item => item.dataset.quickSaleGroup === String(groupKey || ''));
    const selectedKey = tile?.querySelector('.quick-sale-variant-select')?.value
        || tile?.dataset.quickSaleKey
        || getInventoryProductKey(group.product);
    return getInventoryProductByKey(selectedKey) || group.product;
}

window.previewQuickSaleGroupVariant = function(groupKey, variantKey = '') {
    const tile = Array.from(document.querySelectorAll('.quick-sale-product-tile'))
        .find(item => item.dataset.quickSaleGroup === String(groupKey || ''));
    const group = window.quickSaleGroups.get(String(groupKey || ''));
    if (!tile || !group) return;

    const select = tile.querySelector('.quick-sale-variant-select');
    const key = String(variantKey || select?.value || tile.dataset.quickSaleKey || '');
    const product = group.variants.find(variant => getInventoryProductKey(variant) === key) || group.product;
    if (select) select.value = getInventoryProductKey(product);
    refreshQuickSaleTileForVariant(tile, product);
    selectQuickSaleProduct(getInventoryProductKey(product));
};

window.addQuickSaleGroupVariant = function(groupKey) {
    const product = getQuickSaleGroupVariant(groupKey);
    if (!product) return showToast('No se encontro la variante seleccionada', 'error');
    const key = getInventoryProductKey(product);
    selectQuickSaleProduct(key);
    addQuickSaleProduct(key, 1);
};

function renderQuickSaleDetail(product) {
    const detail = document.getElementById('quick-sale-product-detail');
    if (!detail) return;

    if (!product) {
        detail.innerHTML = '<div class="quick-sale-empty">Selecciona un producto para ver imagen, stock y características.</div>';
        return;
    }

    const meta = getQuickSaleProductMeta(product);
    const price = getQuickSalePrice(product);
    const stockClass = meta.stock <= 0 ? 'out' : (meta.stock <= 3 ? 'low' : '');
    detail.innerHTML = `
        <div class="quick-sale-product-card">
            <div class="quick-sale-detail-top">
                <div class="quick-sale-detail-image"><img src="${escapeHtml(meta.image)}" alt="${escapeHtml(meta.name)}" decoding="async" referrerpolicy="no-referrer" onerror="this.src='https://lh3.googleusercontent.com/d/1OTHvWFph2u3qFQMQVhE5ghmSWjBSgBeW=w180'"></div>
                <div>
                <span class="quick-sale-stock-pill ${stockClass}">${meta.stock > 0 ? meta.stock + ' unidades disponibles' : 'Agotado'}</span>
                <h3 class="quick-sale-detail-title">${escapeHtml(meta.name)}</h3>
                <div class="quick-sale-detail-price">${formatAdminInvoiceMoney(price)}</div>
                </div>
            </div>
            <div class="quick-sale-detail-specs">
                <div><span>SKU / ID</span><strong>${escapeHtml(meta.sku || 'S/N')}</strong></div>
                <div><span>Categoria</span><strong>${escapeHtml(meta.category || '-')}</strong></div>
                <div><span>Color</span><strong>${escapeHtml(meta.color || '-')}</strong></div>
                <div><span>Talla / medida</span><strong>${escapeHtml(meta.size || '-')}</strong></div>
                <div><span>Estilo</span><strong>${escapeHtml(meta.style || '-')}</strong></div>
            </div>
            ${meta.description ? `<div class="quick-sale-empty" style="text-align:left;">${escapeHtml(meta.description)}</div>` : ''}
            <div class="quick-sale-add-row">
                <input class="form-control" id="quick-sale-add-qty" type="number" min="1" max="${Math.max(1, meta.stock)}" value="1" ${meta.stock <= 0 ? 'disabled' : ''}>
                <input class="form-control" id="quick-sale-add-price" type="number" min="0" value="${price}" ${meta.stock <= 0 ? 'disabled' : ''}>
                <button class="admin-btn" type="button" onclick="addQuickSaleProduct('${escapeHtml(meta.key)}')" ${meta.stock <= 0 ? 'disabled' : ''}>Añadir a caja</button>
            </div>
        </div>
    `;
}

window.selectQuickSaleProduct = function(key) {
    window.quickSaleSelectedKey = String(key || '');
    const product = getInventoryProductByKey(window.quickSaleSelectedKey);
    document.querySelectorAll('.quick-sale-product-tile').forEach(tile => {
        const select = tile.querySelector('.quick-sale-variant-select');
        const containsKey = select
            ? Array.from(select.options).some(option => option.value === window.quickSaleSelectedKey)
            : tile.dataset.quickSaleKey === window.quickSaleSelectedKey;
        if (containsKey && product) {
            if (select) select.value = window.quickSaleSelectedKey;
            refreshQuickSaleTileForVariant(tile, product);
        }
        tile.classList.toggle('active', containsKey);
    });
    renderQuickSaleDetail(product);
};

window.addQuickSaleProduct = function(key, qtyOverride = null, priceOverride = null) {
    const product = getInventoryProductByKey(key);
    if (!product) return showToast('No se encontro el producto seleccionado', 'error');

    const meta = getQuickSaleProductMeta(product);
    const qtyInput = document.getElementById('quick-sale-add-qty');
    const priceInput = document.getElementById('quick-sale-add-price');
    const detailMatches = window.quickSaleSelectedKey === String(key || '');
    const qtySource = qtyOverride !== null ? qtyOverride : (detailMatches ? qtyInput?.value : 1);
    const priceSource = priceOverride !== null ? priceOverride : (detailMatches ? priceInput?.value : getQuickSalePrice(product));
    const qty = Math.max(1, parseInt(qtySource || 1, 10));
    const price = Math.max(0, parseAdminInvoiceMoney(priceSource || getQuickSalePrice(product)));

    if (meta.stock <= 0) return showToast('Este producto esta agotado', 'warning');
    const existing = window.quickSaleCart.find(item => item.key === meta.key);
    const currentQty = existing ? Number(existing.cantidad || 0) : 0;
    if (currentQty + qty > meta.stock) {
        return showToast(`Stock insuficiente. Disponible: ${meta.stock}`, 'warning');
    }

    if (existing) {
        existing.cantidad += qty;
        existing.precio = price;
    } else {
        window.quickSaleCart.push({
            key: meta.key,
            idVariacion: getInvoiceProductId(product),
            nombre: meta.name,
            sku: meta.sku,
            cantidad: qty,
            precio: price,
            stock: meta.stock,
            image: meta.image
        });
    }

    renderQuickSaleCart();
    document.querySelectorAll('.quick-sale-product-tile').forEach(tile => {
        if (tile.dataset.quickSaleKey !== meta.key) return;
        const button = tile.querySelector('.quick-sale-add-card');
        if (!button) return;
        clearTimeout(button.quickSaleFeedbackTimer);
        button.classList.add('is-added');
        button.textContent = '✓';
        button.setAttribute('aria-label', 'Producto añadido');
        button.quickSaleFeedbackTimer = setTimeout(() => {
            button.classList.remove('is-added');
            button.textContent = '+';
            button.setAttribute('aria-label', 'Añadir ' + meta.name);
        }, 850);
    });
    const status = document.getElementById('quick-sale-add-status');
    if (status) {
        clearTimeout(status.quickSaleFeedbackTimer);
        status.textContent = 'Producto añadido';
        status.quickSaleFeedbackTimer = setTimeout(() => { status.textContent = ''; }, 1100);
    }
};

window.updateQuickSaleQty = function(key, value) {
    const item = window.quickSaleCart.find(row => row.key === key);
    if (!item) return;
    const requested = Math.max(1, parseInt(value || 1, 10));
    item.cantidad = Math.min(requested, Math.max(1, Number(item.stock || requested)));
    renderQuickSaleCart();
};

window.changeQuickSaleQty = function(key, change) {
    const item = window.quickSaleCart.find(row => row.key === key);
    if (!item) return;
    const next = (Number(item.cantidad) || 1) + Number(change || 0);
    if (next <= 0) {
        removeQuickSaleItem(key);
        return;
    }
    updateQuickSaleQty(key, next);
};

window.removeQuickSaleItem = function(key) {
    window.quickSaleCart = window.quickSaleCart.filter(item => item.key !== key);
    renderQuickSaleCart();
};

window.clearQuickSaleCart = function() {
    window.quickSaleCart = [];
    renderQuickSaleCart();
};

window.holdQuickSaleTicket = function() {
    const button = document.getElementById('quick-sale-hold-btn');
    if (window.quickSaleHeldTicket) {
        const held = window.quickSaleHeldTicket;
        window.quickSaleCart = held.items || [];
        ['quick-sale-customer', 'quick-sale-phone', 'quick-sale-address', 'quick-sale-advisor', 'quick-sale-note', 'quick-sale-cash-received'].forEach(id => {
            const input = document.getElementById(id);
            if (input) input.value = held.fields?.[id] || '';
        });
        const method = document.getElementById('quick-sale-method');
        if (method && held.fields?.method) method.value = held.fields.method;
        window.quickSaleHeldTicket = null;
        try { localStorage.removeItem('blyxu_quick_sale_held_ticket'); } catch (error) { console.warn(error); }
        if (button) button.textContent = 'Pausar';
        renderQuickSaleCart();
        showToast('Ticket reanudado', 'success');
        return;
    }

    if (!window.quickSaleCart.length) {
        showToast('Agrega productos antes de pausar el ticket', 'warning');
        return;
    }

    const fields = {};
    ['quick-sale-customer', 'quick-sale-phone', 'quick-sale-address', 'quick-sale-advisor', 'quick-sale-note', 'quick-sale-cash-received'].forEach(id => {
        fields[id] = document.getElementById(id)?.value || '';
    });
    fields.method = document.getElementById('quick-sale-method')?.value || 'Efectivo / Caja';
    window.quickSaleHeldTicket = { items: window.quickSaleCart, fields };
    try { localStorage.setItem('blyxu_quick_sale_held_ticket', JSON.stringify(window.quickSaleHeldTicket)); } catch (error) { console.warn(error); }
    window.quickSaleCart = [];
    if (button) button.textContent = 'Reanudar';
    renderQuickSaleCart();
    showToast('Ticket pausado para continuar después', 'success');
};

function getQuickSaleTotals() {
    return (window.quickSaleCart || []).reduce((acc, item) => {
        const qty = Number(item.cantidad) || 1;
        const price = Number(item.precio) || 0;
        acc.count += qty;
        acc.total += qty * price;
        return acc;
    }, { count: 0, total: 0 });
}

function updateQuickSaleCashChange() {
    const method = document.getElementById('quick-sale-method')?.value || '';
    const cashRow = document.getElementById('quick-sale-cash-row');
    const cashInput = document.getElementById('quick-sale-cash-received');
    const changeEl = document.getElementById('quick-sale-change');
    const usesCash = /Efectivo|Mixto/i.test(method);
    cashRow?.classList.toggle('is-hidden', !usesCash);
    if (!usesCash && cashInput) cashInput.value = '';
    const received = Number(cashInput?.value || 0);
    const change = Math.max(0, received - getQuickSaleTotals().total);
    if (changeEl) changeEl.textContent = formatAdminInvoiceMoney(change);
}

window.updateQuickSaleCashChange = updateQuickSaleCashChange;

function syncQuickSalePaymentMethods() {
    const method = document.getElementById('quick-sale-method')?.value || 'Efectivo / Caja';
    document.querySelectorAll('[data-quick-sale-method]').forEach(button => {
        button.classList.toggle('active', button.dataset.quickSaleMethod === method);
    });
}

window.selectQuickSalePaymentMethod = function(method) {
    const select = document.getElementById('quick-sale-method');
    if (!select || !method) return;
    select.value = method;
    select.dispatchEvent(new Event('change', { bubbles: true }));
    syncQuickSalePaymentMethods();
};

function renderQuickSaleCart() {
    const cartEl = document.getElementById('quick-sale-cart');
    const totals = getQuickSaleTotals();

    ['quick-sale-count', 'quick-sale-summary-count'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.textContent = String(totals.count);
    });
    const ticketCount = document.getElementById('quick-sale-ticket-count');
    if (ticketCount) ticketCount.textContent = `${totals.count} ${totals.count === 1 ? 'ítem' : 'ítems'}`;
    const mobileCount = document.getElementById('quick-sale-mobile-count');
    if (mobileCount) mobileCount.textContent = String(totals.count);
    ['quick-sale-total', 'quick-sale-summary-total', 'quick-sale-subtotal'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.textContent = formatAdminInvoiceMoney(totals.total);
    });
    const discount = document.getElementById('quick-sale-discount');
    const tax = document.getElementById('quick-sale-tax');
    if (discount) discount.textContent = '-$0';
    if (tax) tax.textContent = '$0';

    const saveButton = document.getElementById('quick-sale-save-btn');
    if (saveButton) saveButton.disabled = !window.quickSaleCart.length;
    updateQuickSaleCashChange();
    syncQuickSalePaymentMethods();

    if (!cartEl) return;
    if (!window.quickSaleCart.length) {
        cartEl.innerHTML = '<div class="quick-sale-empty">Escanea un producto o toca + para iniciar la venta.</div>';
        return;
    }

    cartEl.innerHTML = window.quickSaleCart.map(item => {
        const subtotal = (Number(item.precio) || 0) * (Number(item.cantidad) || 1);
        return `
            <div class="quick-sale-cart-item">
                <button type="button" class="quick-sale-cart-thumb" onclick="openQuickSaleImage(this)" aria-label="Ampliar imagen de ${escapeHtml(item.nombre)}"><img src="${escapeHtml(item.image || 'https://lh3.googleusercontent.com/d/1OTHvWFph2u3qFQMQVhE5ghmSWjBSgBeW=w180')}" alt="${escapeHtml(item.nombre)}" onerror="this.src='https://lh3.googleusercontent.com/d/1OTHvWFph2u3qFQMQVhE5ghmSWjBSgBeW=w180'"></button>
                <div class="quick-sale-cart-copy">
                    <strong>${escapeHtml(item.nombre)}</strong>
                    <span>${escapeHtml(item.sku || item.idVariacion || 'S/N')} · ${formatAdminInvoiceMoney(item.precio)} · Subtotal ${formatAdminInvoiceMoney(subtotal)}</span>
                </div>
                <div class="quick-sale-qty-control">
                    <button type="button" onclick="changeQuickSaleQty('${escapeHtml(item.key)}', -1)" aria-label="Restar una unidad">−</button>
                    <input type="number" min="1" max="${Math.max(1, Number(item.stock || 1))}" value="${Number(item.cantidad) || 1}" onchange="updateQuickSaleQty('${escapeHtml(item.key)}', this.value)" aria-label="Cantidad de ${escapeHtml(item.nombre)}">
                    <button type="button" onclick="changeQuickSaleQty('${escapeHtml(item.key)}', 1)" aria-label="Sumar una unidad">+</button>
                </div>
                <button class="quick-sale-cart-remove" type="button" onclick="removeQuickSaleItem('${escapeHtml(item.key)}')" title="Quitar">x</button>
            </div>
        `;
    }).join('');
}

function applyQuickSaleLocalStockDiscount() {
    (window.quickSaleCart || []).forEach(item => {
        const product = getInventoryProductByKey(item.key);
        if (!product) return;
        const current = getQuickSaleStock(product);
        const next = Math.max(0, current - (Number(item.cantidad) || 1));
        product.Cantidad = next;
        product.Stock = next;
    });
    writeInventoryCache(inventario);
    clearPublicProductsCache();
}

function hydrateInvoiceEditorFromQuickSale(invoiceIdOverride = '') {
    const totals = getQuickSaleTotals();
    window.invoiceItems = (window.quickSaleCart || []).map(item => ({
        idVariacion: item.idVariacion,
        nombre: item.nombre,
        sku: item.sku || item.idVariacion,
        img: item.img || item.imagen || '',
        opcion: item.opcion || item.variantLabel || '',
        cantidad: Number(item.cantidad) || 1,
        precio: Number(item.precio) || 0
    }));
    window.invoiceEditIndex = null;
    window.invoiceEditSource = 'manual';
    window.invoiceOriginalInvoiceId = '';
    window.invoiceCustomerType = document.getElementById('quick-sale-customer-type')?.value || 'Detal';
    window.invoicePreviousPayment = 0;

    document.getElementById('inv-original-id').value = 'VENTA-CAJA';
    document.getElementById('inv-edit-id').value = invoiceIdOverride || `CAJA-${Date.now()}`;
    document.getElementById('inv-edit-nombre').value = document.getElementById('quick-sale-customer')?.value.trim() || 'Cliente mostrador';
    document.getElementById('inv-edit-tel').value = document.getElementById('quick-sale-phone')?.value.trim() || '';
    document.getElementById('inv-edit-dir').value = document.getElementById('quick-sale-address')?.value.trim() || 'Venta por caja';
    document.getElementById('inv-edit-ciudad').value = 'Mostrador';
    document.getElementById('inv-edit-fecha').value = new Date().toISOString().slice(0, 10);
    document.getElementById('inv-edit-estado').value = 'Pago';
    document.getElementById('inv-edit-metodo').value = document.getElementById('quick-sale-method')?.value || 'Efectivo / Caja';
    const advisor = document.getElementById('quick-sale-advisor')?.value.trim();
    const note = document.getElementById('quick-sale-note')?.value.trim();
    document.getElementById('inv-edit-nota').value = [advisor ? `Asesor: ${advisor}` : '', note || 'Venta realizada por caja / mostrador.'].filter(Boolean).join(' · ');
    document.getElementById('inv-edit-abono').value = String(totals.total);
    setInvoiceCustomerTypeControl(window.invoiceCustomerType, 'Detal');
    renderItemsFactura();
}

window.openQuickSaleInvoicePreview = function() {
    if (!window.quickSaleCart.length) {
        showToast('Agrega al menos un producto a la caja', 'warning');
        return;
    }
    if (typeof window.abrirEditorFactura === 'function') {
        window.abrirEditorFactura(null);
    }
    hydrateInvoiceEditorFromQuickSale();
    document.getElementById('inv-editor-title').textContent = 'Factura de venta por caja';
    document.getElementById('invoice-editor-modal').classList.add('open');
};

window.saveQuickSaleInvoice = async function() {
    if (!window.quickSaleCart.length) {
        showToast('Agrega al menos un producto a la caja', 'warning');
        return;
    }

    const totals = getQuickSaleTotals();
    const idFactura = `CAJA-${Date.now()}`;
    const customer = document.getElementById('quick-sale-customer')?.value.trim() || 'Cliente mostrador';
    const phone = document.getElementById('quick-sale-phone')?.value.trim() || '';
    const address = document.getElementById('quick-sale-address')?.value.trim() || '';
    const advisor = document.getElementById('quick-sale-advisor')?.value.trim() || '';
    const method = document.getElementById('quick-sale-method')?.value || 'Efectivo / Caja';
    const tipoCliente = getInvoiceCustomerTypeLabel(document.getElementById('quick-sale-customer-type')?.value, 'Detal');
    const note = document.getElementById('quick-sale-note')?.value.trim();
    const cashReceived = Number(document.getElementById('quick-sale-cash-received')?.value || 0);
    const change = Math.max(0, cashReceived - totals.total);
    if (/^Efectivo/i.test(method) && cashReceived < totals.total) {
        showToast('El efectivo recibido es menor al total de la venta', 'warning');
        document.getElementById('quick-sale-cash-received')?.focus();
        return;
    }
    const items = window.quickSaleCart.map(item => ({
        idVariacion: item.idVariacion,
        id: item.idVariacion,
        nombre: item.nombre,
        sku: item.sku || item.idVariacion,
        cantidad: Number(item.cantidad) || 1,
        precio: Number(item.precio) || 0,
        canal: 'Caja'
    }));

    const payload = {
        resource: 'facturas',
        action: 'crear',
        'ID Factura': idFactura,
        'ID Pedido': 'VENTA-CAJA',
        'ID Cliente': phone,
        'Tipo Cliente': tipoCliente,
        Fecha: new Date().toISOString().slice(0, 10),
        Nombre: customer,
        'Productos JSON': JSON.stringify(items),
        'Cantidad Total': totals.count,
        Subtotal: totals.total,
        'Valor Abonado': totals.total,
        'Saldo Pendiente': 0,
        'Ultimo Abono': totals.total,
        'Estado Factura': 'Pago',
        pago: method,
        entrega: address || 'Venta por caja / mostrador',
        'Canal Venta': 'Caja',
        Asesor: advisor,
        'Efectivo Recibido': cashReceived,
        Cambio: change,
        Observaciones: note || 'Venta realizada por caja / mostrador.'
    };

    const btn = document.getElementById('quick-sale-save-btn');
    if (btn) {
        btn.disabled = true;
        btn.textContent = 'Registrando...';
    }

    try {
        const res = await fetch(GOOGLE_SHEET_API, {
            method: 'POST',
            body: JSON.stringify(payload)
        });
        const result = await res.json();
        if (!result || result.status !== 'success') {
            throw new Error(result?.error || result?.message || 'No se pudo registrar la venta');
        }

        window.facturasList = [payload, ...(window.facturasList || [])];
        applyQuickSaleLocalStockDiscount();
        renderFacturas();
        renderQuickSaleResults();
        renderQuickSaleDetail(getInventoryProductByKey(window.quickSaleSelectedKey));
        renderAdminDashboard();
        hydrateInvoiceEditorFromQuickSale(idFactura);
        document.getElementById('inv-editor-title').textContent = 'Factura de venta por caja';
        if (typeof window.imprimirFacturaEditor === 'function') {
            window.imprimirFacturaEditor();
        }
        if (typeof window.switchOrdersAdminTab === 'function') {
            window.switchOrdersAdminTab('invoices-mayor');
        }
        clearQuickSaleCart();
        document.getElementById('quick-sale-customer').value = '';
        document.getElementById('quick-sale-phone').value = '';
        document.getElementById('quick-sale-address').value = '';
        document.getElementById('quick-sale-note').value = '';
        document.getElementById('quick-sale-cash-received').value = '';
        updateQuickSaleCashChange();
        showToast('Venta por caja registrada como factura', 'success');
    } catch (error) {
        console.error(error);
        showToast('Error registrando venta: ' + error.message, 'error');
    } finally {
        if (btn) {
            btn.disabled = !window.quickSaleCart.length;
            btn.textContent = 'Cobrar y generar PDF';
        }
    }
};

document.addEventListener('DOMContentLoaded', () => {
    const quickSearch = document.getElementById('quick-sale-search');
    const quickResults = document.getElementById('quick-sale-results');
    const quickScanButton = document.getElementById('btn-scan-quick-sale');
    const customerType = document.getElementById('quick-sale-customer-type');
    const categoryStrip = document.getElementById('quick-sale-categories');
    const clearClientButton = document.getElementById('quick-sale-clear-client');
    const paymentMethod = document.getElementById('quick-sale-method');
    const cashReceived = document.getElementById('quick-sale-cash-received');
    const mobilePaneTabs = document.querySelector('.quick-sale-mobile-tabs');
    const mobileViewSelect = document.getElementById('admin-mobile-view-select');

    quickSearch?.addEventListener('input', renderQuickSaleResults);
    quickSearch?.addEventListener('keydown', event => {
        if (event.key !== 'Enter') return;
        event.preventDefault();
        handleQuickSaleScannedCode(quickSearch.value, true).catch(error => {
            console.error('No se pudo buscar la referencia ingresada:', error);
        });
    });
    quickSearch?.addEventListener('focus', () => {
        if (!Array.isArray(inventario) || !inventario.length) cargarInventario({ silent: true }).then(renderQuickSaleResults).catch(() => {});
    });
    quickScanButton?.addEventListener('click', openQuickSaleScanner);
    categoryStrip?.addEventListener('click', event => {
        const button = event.target.closest('[data-quick-sale-category]');
        if (button) setQuickSaleCategory(button.dataset.quickSaleCategory);
    });
    clearClientButton?.addEventListener('click', () => {
        ['quick-sale-customer', 'quick-sale-phone', 'quick-sale-address', 'quick-sale-advisor'].forEach(id => {
            const input = document.getElementById(id);
            if (input) input.value = '';
        });
    });
    paymentMethod?.addEventListener('change', updateQuickSaleCashChange);
    document.querySelectorAll('[data-quick-sale-method]').forEach(button => {
        button.addEventListener('click', () => selectQuickSalePaymentMethod(button.dataset.quickSaleMethod));
    });
    cashReceived?.addEventListener('input', updateQuickSaleCashChange);
    mobilePaneTabs?.addEventListener('click', event => {
        const button = event.target.closest('[data-quick-sale-pane]');
        if (button) setQuickSaleMobilePane(button.dataset.quickSalePane);
    });
    window.addEventListener('resize', () => syncQuickSaleMobilePane());
    quickResults?.addEventListener('click', event => {
        const infoBtn = event.target.closest('[data-quick-sale-info-group]');
        if (infoBtn) {
            event.stopPropagation();
            openQuickSaleProductInfo(infoBtn.dataset.quickSaleInfoGroup);
            return;
        }
        const addBtn = event.target.closest('[data-quick-sale-add-group]');
        if (addBtn) {
            event.stopPropagation();
            addQuickSaleGroupVariant(addBtn.dataset.quickSaleAddGroup);
            return;
        }
        if (event.target.closest('select, option, button, input')) return;
        const item = event.target.closest('[data-quick-sale-key]');
        if (!item) return;
        selectQuickSaleProduct(item.dataset.quickSaleKey);
    });
    quickResults?.addEventListener('change', event => {
        const select = event.target.closest('.quick-sale-variant-select');
        if (!select) return;
        previewQuickSaleGroupVariant(select.dataset.quickSaleGroup, select.value);
    });
    quickResults?.addEventListener('keydown', event => {
        if (event.key !== 'Enter') return;
        if (event.target.closest('select, button, input')) return;
        const item = event.target.closest('[data-quick-sale-key]');
        if (!item) return;
        selectQuickSaleProduct(item.dataset.quickSaleKey);
    });
    customerType?.addEventListener('change', () => {
        renderQuickSaleResults();
        renderQuickSaleDetail(getInventoryProductByKey(window.quickSaleSelectedKey));
    });
    mobileViewSelect?.addEventListener('change', event => {
        const value = event.target.value;
        if (value === 'logout') {
            revokeAdminSession();
            sessionStorage.removeItem(ADMIN_ORDERS_CACHE_KEY);
            window.location.href = 'index.html';
            return;
        }
        const label = event.target.options[event.target.selectedIndex]?.textContent || 'Panel';
        switchDashboardView(value, label);
    });
    const updateQuickSaleClock = () => {
        const clock = document.getElementById('quick-sale-clock');
        if (clock) clock.textContent = new Date().toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit' });
    };
    updateQuickSaleClock();
    setInterval(updateQuickSaleClock, 30000);
    syncQuickSaleMobilePane();
    renderQuickSaleCart();
    syncQuickSalePaymentMethods();
    try {
        const held = JSON.parse(localStorage.getItem('blyxu_quick_sale_held_ticket') || 'null');
        if (held?.items?.length) {
            window.quickSaleHeldTicket = held;
            const holdButton = document.getElementById('quick-sale-hold-btn');
            if (holdButton) holdButton.textContent = 'Reanudar';
        }
    } catch (error) {
        console.warn('No se pudo recuperar el ticket pausado:', error);
    }
});

window.abrirEditorFactura = function(idx = null, source = 'pedido') {
    if(source==='pedido' && idx!==null && window.OriginalStoreOrderAdmin?.kind(window.pedidosList?.[idx])==='quote'){
        showToast('Revisa la cotización y confirma que el cliente aceptó antes de convertirla y facturar.','error');
        OriginalStoreOrderAdmin.review(idx);return;
    }
    window.invoiceItems = [];
    window.invoiceEditIndex = idx;
    window.invoiceEditSource = idx === null ? 'manual' : source;
    window.invoiceOriginalInvoiceId = '';
    window.invoiceCustomerType = 'Detal';
    window.invoicePreviousPayment = 0;
    
    document.getElementById('inv-original-id').value = '';
    document.getElementById('inv-edit-nombre').value = '';
    document.getElementById('inv-edit-tel').value = '';
    document.getElementById('inv-edit-dir').value = '';
    document.getElementById('inv-edit-ciudad').value = '';
    document.getElementById('inv-edit-fecha').value = new Date().toISOString().slice(0, 10);
    document.getElementById('inv-edit-estado').value = 'Pendiente';
    document.getElementById('inv-edit-metodo').value = 'Mostrador / Manual';
    document.getElementById('inv-edit-nota').value = '';
    setInvoiceCustomerTypeControl('Detal');
    document.getElementById('inv-product-search').value = '';
    document.getElementById('inv-search-results').classList.remove('active');
    document.getElementById('inv-custom-name').value = '';
    document.getElementById('inv-custom-sku').value = '';
    document.getElementById('inv-custom-price').value = '';
    if (document.getElementById('inv-edit-abono')) {
        document.getElementById('inv-edit-abono').value = '';
    }
    
    if (idx !== null) {
        const editingInvoice = source === 'factura';
        const p = editingInvoice ? window.facturasList[idx] : window.pedidosList[idx];
        if (!p) {
            showToast('No se encontro el registro seleccionado', 'error');
            return;
        }

        const orderId = editingInvoice ? getInvoiceOrderIdValue(p) : getOrderIdValue(p);
        const invoiceId = editingInvoice ? getInvoiceIdValue(p) : '';
        const linkedExistingInvoice = (!editingInvoice && orderId)
            ? (window.facturasList || []).find(f => String(getInvoiceOrderIdValue(f)).trim() === String(orderId).trim())
            : null;
        const linkedExistingInvoiceId = linkedExistingInvoice ? getInvoiceIdValue(linkedExistingInvoice) : '';
        window.invoiceOriginalInvoiceId = invoiceId || linkedExistingInvoiceId || '';
        window.invoicePreviousPayment = editingInvoice ? getInvoicePaidValue(p) : getInvoicePaidValue(linkedExistingInvoice);
        window.invoiceCustomerType = editingInvoice
            ? (inferInvoiceCustomerType(p) === 'mayor' ? 'Mayor' : 'Detal')
            : (inferOrderCustomerType(p) === 'mayor' ? 'Mayor' : 'Detal');

        document.getElementById('inv-editor-title').textContent = editingInvoice
            ? 'Editar Factura: ' + (invoiceId || orderId)
            : 'Ajustar Factura del Pedido: ' + orderId;
        document.getElementById('inv-original-id').value = orderId;
        document.getElementById('inv-edit-id').value = editingInvoice ? (invoiceId || orderId) : (linkedExistingInvoiceId || `FAC-${orderId}`);
        
        document.getElementById('inv-edit-nombre').value = editingInvoice ? getInvoiceCustomerName(p) : (p['Nombre Cliente'] || p.Nombre || '');
        document.getElementById('inv-edit-tel').value = editingInvoice ? (p['ID Cliente'] || '') : (p['Teléfono'] || p.Telefono || '');
        setInvoiceCustomerTypeControl(window.invoiceCustomerType, 'Detal');
        document.getElementById('inv-edit-dir').value = editingInvoice
            ? (p['Método Entrega'] || p['Metodo Entrega'] || p.entrega || p['Dirección'] || p.Direccion || '')
            : (p['Dirección'] || p.Direccion || '');
        document.getElementById('inv-edit-ciudad').value = p.Ciudad || '';
        document.getElementById('inv-edit-fecha').value = formatDateForInvoiceInput(p.Fecha);
        document.getElementById('inv-edit-estado').value = editingInvoice
            ? (p['Estado Factura'] || p.Estado || 'Pendiente')
            : (linkedExistingInvoice ? (linkedExistingInvoice['Estado Factura'] || linkedExistingInvoice.Estado || 'Pendiente') : 'Pendiente');
        document.getElementById('inv-edit-metodo').value = editingInvoice
            ? (p['Método Pago'] || p['Metodo Pago'] || p.pago || '')
            : (p['Método Contacto'] || p['Metodo Contacto'] || p.Metodo || '');
        document.getElementById('inv-edit-nota').value = editingInvoice ? (p.Observaciones || '') : (p['Nota Cliente'] || p.Nota || '');
        
        try {
            const jsonStr = p['Productos JSON'] || p.Productos;
            let items = typeof jsonStr === 'string' ? JSON.parse(jsonStr) : (Array.isArray(jsonStr) ? jsonStr : []);
            window.invoiceItems = items.map((i, itemIndex) => ({
                idVariacion: i.idVariacion || i.id || i.sku || ('ITEM-' + Date.now() + '-' + itemIndex),
                nombre: i.nombre || i.Nombre || i.Producto || 'Producto',
                sku: i.sku || i.id || '',
                img: i.img || i.imagen || i.Imagen || '',
                opcion: i.opcion || i.variantLabel || '',
                color: i.color || i.Color || '',
                talla: i.talla || i.Talla || i.tamano || i['Tamaño'] || '',
                cantidad: parseInt(i.cantidad || i.Cantidad || i.qty || 1),
                precio: parseFloat(i.precio || i.Precio || 0)
            }));
        } catch(e) { console.error("Error cargando ítems", e); }
        if (editingInvoice || linkedExistingInvoice) {
            window.invoicePreviousPayment = getInvoiceBalanceInfo(
                editingInvoice ? p : linkedExistingInvoice,
                getInvoiceTotalFromItems(window.invoiceItems)
            ).paid;
        }
    } else {
        // Nueva
        window.invoiceEditSource = 'manual';
        document.getElementById('inv-editor-title').textContent = 'Nueva Factura';
        document.getElementById('inv-edit-id').value = `FAC-${Date.now()}`;
    }
    
    renderItemsFactura();
    document.getElementById('invoice-editor-modal').classList.add('open');
    if (!Array.isArray(inventario) || inventario.length === 0) {
        window.invoiceInventoryLoadTried = false;
    }
    ensureInvoiceInventoryLoaded();
};

if (typeof window.getProductPrice !== 'function') {
    window.getProductPrice = function(product) {
        return getInvoiceProductPrice(product);
    };
}

function renderInvoiceProductSearch(query) {
    const q = String(query || '').toLowerCase().trim();
    const resultsContainer = document.getElementById('inv-search-results');
    if (!resultsContainer) return;

    if (q.length < 2) {
        resultsContainer.classList.remove('active');
        return;
    }

    const source = Array.isArray(inventario) ? inventario : [];
    if (!source.length) {
        resultsContainer.innerHTML = (window.invoiceInventoryLoadingPromise || !window.invoiceInventoryLoadTried)
            ? '<div class="inv-search-empty">Cargando productos...</div>'
            : '<div class="inv-search-empty">No hay productos cargados. Puedes agregar una linea manual abajo.</div>';
        resultsContainer.classList.add('active');
        const loadPromise = ensureInvoiceInventoryLoaded();
        if (loadPromise && typeof loadPromise.then === 'function') {
            loadPromise.then(() => renderInvoiceProductSearch(q));
        }
        return;
    }

    const results = source.filter(p => {
        if (String(p.Categoria || '').toLowerCase() === 'banner') return false;
        const searchable = [
            getInvoiceProductName(p),
            getInvoiceProductSku(p),
            p.Categoria,
            p.Color,
            p.Estilo,
            getProductBarcode(p),
            getInvoiceProductId(p)
        ].join(' ').toLowerCase();
        return searchable.includes(q);
    }).slice(0, 15);

    window.invoiceSearchResults = results;

    if (results.length > 0) {
        resultsContainer.innerHTML = results.map((p, index) => {
            const img = normalizeImageUrl(p.Imagen || p['Imagen Principal'] || (p.Galeria && p.Galeria[0]));
            const price = getInvoiceProductPrice(p);
            const stock = readInvoiceField(p, ['Cantidad', 'Stock', 'Stock Inicial'], '');
            return `
                <button type="button" class="inv-search-item" data-invoice-product-result="${index}" style="width:100%; border:0; text-align:left; background:transparent;">
                    <img src="${escapeHtml(img || 'https://lh3.googleusercontent.com/d/1OTHvWFph2u3qFQMQVhE5ghmSWjBSgBeW=w180')}" alt="">
                    <div class="inv-search-item-info">
                        <div class="inv-search-item-title">${escapeHtml(getInvoiceProductName(p))}</div>
                        <div class="inv-search-item-sub">
                            <span style="background:rgba(168,85,247,0.15); color:var(--primary-light); padding:2px 6px; border-radius:4px; font-weight:600; margin-right:6px;">Ref: ${escapeHtml(getInvoiceProductSku(p) || 'S/N')}</span>
                            <span style="color:#10B981; font-weight:700;">$${price.toLocaleString('es-CO')}</span>
                            ${stock !== '' ? `<span style="color:rgba(255,255,255,0.45);">Stock: ${escapeHtml(stock)}</span>` : ''}
                        </div>
                    </div>
                </button>
            `;
        }).join('');
    } else {
        resultsContainer.innerHTML = `
            <div class="inv-search-empty">
                <div style="font-size:24px; margin-bottom:8px;">?</div>
                <div>No encontramos productos que coincidan con "${escapeHtml(q)}"</div>
            </div>`;
    }

    resultsContainer.classList.add('active');
}

document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('inv-product-search');
    const resultsContainer = document.getElementById('inv-search-results');
    if (!searchInput || !resultsContainer) return;

    searchInput.addEventListener('input', (e) => {
        setTimeout(() => renderInvoiceProductSearch(e.target.value), 0);
    });

    resultsContainer.addEventListener('click', (e) => {
        const item = e.target.closest('[data-invoice-product-result]');
        if (!item) return;
        const product = window.invoiceSearchResults[parseInt(item.dataset.invoiceProductResult, 10)];
        if (!product) return;
        agregarItemBusqueda(
            getInvoiceProductId(product),
            getInvoiceProductName(product),
            getInvoiceProductSku(product),
            getInvoiceProductPrice(product)
        );
    });
});

// Buscador Inteligente
document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('inv-product-search');
    if (!searchInput) return;
    
    searchInput.addEventListener('input', (e) => {
        const q = e.target.value.toLowerCase().trim();
        const resultsContainer = document.getElementById('inv-search-results');
        
        if (q.length < 2) {
            resultsContainer.classList.remove('active');
            return;
        }
        
        const results = inventario.filter(p => {
            if (String(p.Categoria || '').toLowerCase() === 'banner') return false;
            const str = (p.Nombre + ' ' + (p.SKU || '') + ' ' + (p.Categoria || '')).toLowerCase();
            return str.includes(q);
        }).slice(0, 10);
        
        if (results.length > 0) {
            resultsContainer.innerHTML = results.map(p => {
                const img = normalizeImageUrl(p.Imagen || (p.Galeria && p.Galeria[0]));
                const price = getProductPrice(p, 'wholesale'); // Usa precio mayorista como default, ajustable después
                const idVar = p.idVariacion || p.ID || p['ID Variacion'] || p['ID Variación'] || p.Producto || '';
                // Escapando comillas simples en el nombre
                const safeName = (p.Nombre || '').replace(/'/g, "\\'");
                return `
                    <div class="inv-search-item" onclick="agregarItemBusqueda('${idVar}', '${safeName}', '${p.SKU || ''}', ${price})">
                        <img src="${img || 'https://lh3.googleusercontent.com/d/1OTHvWFph2u3qFQMQVhE5ghmSWjBSgBeW=w180'}" alt="">
                        <div class="inv-search-item-info">
                            <div class="inv-search-item-title">${p.Nombre}</div>
                            <div class="inv-search-item-sub">
                                <span style="background:rgba(168,85,247,0.15); color:var(--primary-light); padding:2px 6px; border-radius:4px; font-weight:600; margin-right:6px;">Ref: ${p.SKU || 'S/N'}</span>
                                <span style="color:#10B981; font-weight:700;">$${price.toLocaleString('es-CO')}</span>
                            </div>
                        </div>
                    </div>
                `;
            }).join('');
            resultsContainer.classList.add('active');
        } else {
            resultsContainer.innerHTML = `
                <div style="padding:32px 16px; color:rgba(255,255,255,0.4); text-align:center;">
                    <div style="font-size:13px; margin-bottom:8px;">Buscar</div>
                    <div>No encontramos productos que coincidan con "${q}"</div>
                </div>`;
            resultsContainer.classList.add('active');
        }
    });

    // Cerrar resultados si hace clic afuera
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.inv-search-container')) {
            const rc = document.getElementById('inv-search-results');
            if (rc) rc.classList.remove('active');
        }
    });
});

window.agregarItemBusqueda = function(idVar, nombre, sku, precio) {
    const product = findInvoiceItemProduct({idVariacion: idVar, sku});
    const existing = window.invoiceItems.find(i => i.idVariacion === idVar);
    if (existing) {
        existing.cantidad += 1;
    } else {
        window.invoiceItems.push({
            idVariacion: idVar,
            nombre: nombre,
            sku: sku,
            img: product ? getInventoryProductImage(product) : '',
            opcion: product ? [product.Estilo, product.Color, getInventoryPdfSizeValue(product)].filter(Boolean).join(' · ') : '',
            cantidad: 1,
            precio: parseFloat(precio)
        });
    }
    
    document.getElementById('inv-product-search').value = '';
    document.getElementById('inv-search-results').classList.remove('active');
    renderItemsFactura();
};

window.agregarItemManualFactura = function() {
    const nameInput = document.getElementById('inv-custom-name');
    const skuInput = document.getElementById('inv-custom-sku');
    const priceInput = document.getElementById('inv-custom-price');
    const nombre = nameInput.value.trim();
    const precio = parseFloat(priceInput.value);

    if (!nombre) {
        showToast('Escribe el nombre del producto manual', 'warning');
        nameInput.focus();
        return;
    }

    if (Number.isNaN(precio) || precio < 0) {
        showToast('Escribe un precio valido', 'warning');
        priceInput.focus();
        return;
    }

    window.invoiceItems.push({
        idVariacion: 'MANUAL-' + Date.now(),
        nombre,
        sku: skuInput.value.trim(),
        cantidad: 1,
        precio
    });

    nameInput.value = '';
    skuInput.value = '';
    priceInput.value = '';
    renderItemsFactura();
};

window.modificarNombreItemFactura = function(index, value) {
    if (!window.invoiceItems[index]) return;
    window.invoiceItems[index].nombre = String(value || '').trim() || 'Producto';
};

window.modificarSkuItemFactura = function(index, value) {
    if (!window.invoiceItems[index]) return;
    window.invoiceItems[index].sku = String(value || '').trim();
};

window.modificarCantidadFactura = function(index, qty) {
    const val = parseInt(qty);
    if (val > 0) {
        window.invoiceItems[index].cantidad = val;
    } else {
        window.invoiceItems[index].cantidad = 1;
    }
    renderItemsFactura();
};

window.modificarPrecioFactura = function(index, price) {
    const val = parseFloat(price);
    if (!isNaN(val)) {
        window.invoiceItems[index].precio = val;
    }
    renderItemsFactura();
};

window.eliminarItemFactura = function(index) {
    window.invoiceItems.splice(index, 1);
    renderItemsFactura();
};

function findInvoiceItemProduct(item) {
    const source = Array.isArray(inventario) ? inventario : [];
    const id = String(item.idVariacion || item.id || '').trim();
    const byId = id && source.find(product => [product.id, product.idVariacion, product.ID, product['ID Variacion'], product['ID Variación']].some(value => value != null && String(value).trim() === id));
    if (byId) return byId;
    const sku = String(item.sku || '').trim();
    const matches = sku ? source.filter(product => String(getInvoiceProductSku(product)).trim() === sku) : [];
    return matches.length === 1 ? matches[0] : null;
}

function getInvoiceItemVisual(item) {
    const product = findInvoiceItemProduct(item);
    const image = normalizeImageUrl(item.img || item.imagen || '') || (product ? getInventoryProductImage(product) : '');
    const optionParts = [item.opcion, item.color || product?.Color, item.talla || (product ? getInventoryPdfSizeValue(product) : '')].filter(Boolean);
    const option = optionParts.filter((part, index) => !optionParts.slice(0, index).some(previous => String(previous).includes(String(part)))).join(' · ') || product?.Estilo || '';
    // Guardar la imagen de la variante para conservarla al ajustar/guardar la factura.
    if (image && !item.img) item.img = image;
    if (option && !item.opcion) item.opcion = option;
    return {image, option};
}

function renderItemsFactura() {
    const tbody = document.getElementById('inv-edit-items');
    let total = 0;
    
    if (window.invoiceItems.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; color:rgba(248,244,255,0.45); padding:28px 16px; font-size:13px;">Busca productos arriba o agrega una línea manual para comenzar</td></tr>';
        document.getElementById('inv-edit-total').textContent = '$0';
        updateInvoicePaymentSummary();
        return;
    }
    
    tbody.innerHTML = window.invoiceItems.map((item, i) => {
        const visual = getInvoiceItemVisual(item);
        const subtotal = item.precio * item.cantidad;
        total += subtotal;
        return `
            <tr>
                <td data-label="Producto">
                    <div class="inv-item-visual">
                        ${visual.image ? `<img class="inv-item-photo" src="${escapeHtml(visual.image)}" alt="${escapeHtml(item.nombre)}" loading="lazy" referrerpolicy="no-referrer" onerror="this.hidden=true;this.nextElementSibling.hidden=false"><span class="inv-item-photo-empty" hidden>Sin imagen</span>` : '<span class="inv-item-photo-empty">Sin imagen</span>'}
                        <div class="inv-item-fields">
                    <input type="text" class="inv-item-name-input" value="${escapeHtml(item.nombre)}" placeholder="Descripción del producto" onchange="modificarNombreItemFactura(${i}, this.value)">
                    <input type="text" class="inv-item-ref-input" value="${escapeHtml(item.sku || '')}" placeholder="Ref / SKU" onchange="modificarSkuItemFactura(${i}, this.value)">
                            ${visual.option ? `<span class="inv-item-option">${escapeHtml(visual.option)}</span>` : ''}
                        </div>
                    </div>
                </td>
                <td data-label="Cantidad" style="text-align:center;">
                    <input type="number" class="inv-qty-input" value="${item.cantidad}" min="1" onchange="modificarCantidadFactura(${i}, this.value)">
                </td>
                <td data-label="Precio unitario" style="text-align:right;">
                    <input type="number" class="inv-item-price-input" value="${item.precio}" onchange="modificarPrecioFactura(${i}, this.value)">
                </td>
                <td data-label="Subtotal" style="text-align:right; font-weight:900; color:#f4c441; font-size:14px; font-variant-numeric:tabular-nums;">$${subtotal.toLocaleString('es-CO')}</td>
                <td data-label="Acción" style="text-align:center;">
                    <button class="inv-remove-item-btn" type="button" onclick="eliminarItemFactura(${i})" title="Eliminar ítem">
                        <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                    </button>
                </td>
            </tr>
        `;
    }).join('');
    
    document.getElementById('inv-edit-total').textContent = formatAdminInvoiceMoney(total);
    updateInvoicePaymentSummary();
}

window.updateInvoicePaymentSummary = function() {
    const total = getInvoiceTotalFromItems(window.invoiceItems || []);
    const previousPaid = Math.min(Math.max(0, Number(window.invoicePreviousPayment) || 0), Math.max(0, total));
    const newPaymentInput = document.getElementById('inv-edit-abono');
    const newPayment = Math.max(0, parseAdminInvoiceMoney(newPaymentInput?.value || 0));
    const acceptedNewPayment = Math.min(newPayment, Math.max(0, total - previousPaid));
    const paidAfter = previousPaid + acceptedNewPayment;
    const balanceBefore = Math.max(0, total - previousPaid);
    const balanceAfter = Math.max(0, total - paidAfter);

    if (document.getElementById('inv-paid-before')) {
        document.getElementById('inv-paid-before').textContent = formatAdminInvoiceMoney(previousPaid);
    }
    if (document.getElementById('inv-balance-before')) {
        document.getElementById('inv-balance-before').textContent = formatAdminInvoiceMoney(balanceBefore);
    }
    const balanceAfterEl = document.getElementById('inv-balance-after');
    if (balanceAfterEl) {
        balanceAfterEl.textContent = formatAdminInvoiceMoney(balanceAfter);
        balanceAfterEl.style.color = balanceAfter > 0 ? '#fbbf24' : '#34d399';
    }
    const balanceCard = document.getElementById('inv-card-balance-box');
    if (balanceCard) {
        balanceCard.style.borderColor = balanceAfter > 0 ? 'rgba(251, 191, 36, 0.4)' : 'rgba(52, 211, 153, 0.4)';
    }
};

function isAdminInvoiceMobilePrint() {
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent)
        || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
    return isIOS || window.matchMedia('(max-width: 760px)').matches;
}

function getAdminInvoicePrintWindowStyles() {
    return `
        * { box-sizing: border-box; }
        :root {
            --invoice-purple: #6d28d9;
            --invoice-purple-soft: #ede9fe;
            --invoice-ink: #171717;
            --invoice-muted: #5f6470;
            --invoice-line: #d9d9e3;
            --invoice-soft-line: #ececf2;
        }
        html, body {
            margin: 0;
            background: #ffffff;
            color: var(--invoice-ink);
            font-family: Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
        }
        body { padding: 22px; }
        .invoice-print-toolbar {
            position: sticky;
            top: 0;
            z-index: 20;
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            max-width: 880px;
            margin: 0 auto 12px;
            padding: 8px 0;
            background: #ffffff;
            border-bottom: 1px solid var(--invoice-soft-line);
        }
        .invoice-print-button {
            min-height: 40px;
            border: 1px solid var(--invoice-purple);
            border-radius: 7px;
            padding: 0 18px;
            background: #ffffff;
            color: var(--invoice-purple);
            font: inherit;
            font-size: 11px;
            font-weight: 850;
            text-transform: uppercase;
            letter-spacing: 0.6px;
            cursor: pointer;
        }
        .invoice-print-button:hover { background: var(--invoice-purple-soft); }
        #invoice-print-container {
            display: block;
            max-width: 880px;
            margin: 0 auto;
            padding: 28px 34px 24px;
            background: #ffffff;
            border: 1px solid var(--invoice-line);
            border-radius: 4px;
            box-shadow: 0 8px 22px rgba(17, 17, 17, 0.06);
        }
        .admin-inv-top-banner {
            background: #ffffff;
            padding: 0 0 16px;
            border-bottom: 2px solid var(--invoice-purple);
            color: var(--invoice-ink);
            display: grid;
            grid-template-columns: minmax(0, 1fr) auto;
            gap: 24px;
            align-items: start;
            margin-bottom: 18px;
        }
        .admin-inv-brand-wrapper {
            display: flex;
            align-items: center;
            gap: 14px;
            min-width: 0;
        }
        .admin-inv-brand-wrapper img {
            height: 48px;
            width: auto;
            object-fit: contain;
        }
        .admin-inv-brand-wrapper h1 {
            margin: 0;
            font-size: 20px;
            font-weight: 900;
            letter-spacing: 0;
            color: var(--invoice-ink);
            text-transform: uppercase;
        }
        .admin-inv-brand-wrapper p {
            margin: 4px 0 0;
            font-size: 10.8px;
            color: var(--invoice-muted);
            font-weight: 500;
            line-height: 1.45;
        }
        .admin-inv-badge-box {
            background: #ffffff;
            border: 1px solid var(--invoice-line);
            border-top: 3px solid var(--invoice-purple);
            border-radius: 4px;
            padding: 10px 14px;
            text-align: right;
            min-width: 190px;
        }
        .admin-inv-badge-box h2 {
            margin: 0 0 3px;
            font-size: 10px;
            font-weight: 900;
            letter-spacing: 1.2px;
            color: var(--invoice-purple);
            text-transform: uppercase;
        }
        .admin-inv-badge-box .inv-num {
            font-size: 18px;
            font-weight: 900;
            color: var(--invoice-ink);
            margin: 0 0 2px;
            font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
            letter-spacing: 0.2px;
        }
        .admin-inv-badge-box .inv-date {
            font-size: 11px;
            color: var(--invoice-muted);
            font-weight: 650;
        }
        .admin-inv-badge-box .inv-status-chip {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            margin-top: 6px;
            background: #ffffff;
            border: 1px solid var(--invoice-line);
            color: var(--invoice-muted);
            padding: 2px 8px;
            border-radius: 999px;
            font-size: 8.8px;
            font-weight: 850;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .admin-inv-badge-box .status-dot {
            width: 5px;
            height: 5px;
            background: var(--invoice-purple);
            border-radius: 50%;
        }
        .invoice-details {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 14px;
            margin-bottom: 18px;
        }
        .invoice-details-box {
            background: #ffffff;
            border: 1px solid var(--invoice-line);
            border-radius: 4px;
            padding: 12px 14px;
            min-height: 132px;
        }
        .invoice-details-box.inv-box-cliente,
        .invoice-details-box.inv-box-emisor { border-left: 3px solid var(--invoice-purple); }
        .invoice-details-box .box-header-title {
            display: flex;
            align-items: center;
            margin: 0 0 8px;
            font-size: 9.5px;
            font-weight: 900;
            letter-spacing: 0.9px;
            color: var(--invoice-purple);
            text-transform: uppercase;
            border-bottom: 1px solid var(--invoice-soft-line);
            padding-bottom: 6px;
        }
        .invoice-details-box .cliente-nombre-title,
        .invoice-details-box .emisor-nombre-title {
            font-size: 14px;
            font-weight: 850;
            color: var(--invoice-ink);
            display: block;
            margin-bottom: 6px;
        }
        .invoice-details-box p {
            margin: 3px 0;
            font-size: 11.2px;
            color: var(--invoice-muted);
            line-height: 1.45;
            font-weight: 500;
        }
        .invoice-details-box p strong { color: #2f3138; font-weight: 760; }
        .invoice-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 18px;
            border-top: 2px solid var(--invoice-purple);
            border-bottom: 1px solid var(--invoice-line);
        }
        .invoice-table th {
            background: #ffffff;
            color: var(--invoice-purple);
            font-size: 9.5px;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: 0.75px;
            padding: 8px 10px;
            border-bottom: 1px solid var(--invoice-line);
        }
        .invoice-table td {
            padding: 9px 10px;
            border-bottom: 1px solid var(--invoice-soft-line);
            font-size: 12px;
            color: var(--invoice-ink);
            background: #ffffff;
            font-weight: 500;
            vertical-align: top;
        }
        .invoice-table tr:last-child td { border-bottom: none; }
        .invoice-bottom-grid {
            display: grid;
            grid-template-columns: minmax(0, 1fr) 300px;
            gap: 16px;
            align-items: start;
            margin-top: 14px;
        }
        .invoice-notes-box {
            background: #ffffff;
            border: 1px solid var(--invoice-line);
            border-left: 3px solid var(--invoice-purple);
            border-radius: 4px;
            padding: 11px 13px;
            font-size: 11px;
            color: var(--invoice-muted);
            line-height: 1.5;
        }
        .invoice-notes-box .notes-title {
            font-size: 9.5px;
            font-weight: 900;
            letter-spacing: 0.9px;
            color: var(--invoice-purple);
            margin-bottom: 5px;
            text-transform: uppercase;
        }
        .invoice-total-container { display: flex; justify-content: flex-end; }
        .invoice-total-box {
            background: #ffffff;
            color: var(--invoice-ink);
            padding: 13px 16px;
            border-radius: 4px;
            width: 100%;
            border: 1px solid var(--invoice-line);
            border-top: 3px solid var(--invoice-purple);
        }
        .invoice-total-box .total-row-item,
        .invoice-total-box .payment-row-item {
            display: flex;
            align-items: baseline;
            justify-content: space-between;
            gap: 14px;
        }
        .invoice-total-box .payment-row-item {
            margin-top: 7px;
            padding-top: 7px;
            border-top: 1px solid var(--invoice-soft-line);
            font-size: 11px;
            font-weight: 700;
            color: var(--invoice-muted);
        }
        .invoice-total-box .payment-row-item.balance {
            color: var(--invoice-ink);
            font-weight: 900;
            font-size: 12px;
        }
        .invoice-total-box .total-label {
            font-size: 10px;
            font-weight: 900;
            letter-spacing: 0.9px;
            color: var(--invoice-purple);
            text-transform: uppercase;
        }
        .invoice-total-box .total-amount {
            font-size: 22px;
            font-weight: 900;
            color: var(--invoice-ink);
            font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
        }
        .invoice-total-box .total-sub-info {
            margin-top: 8px;
            padding-top: 7px;
            border-top: 1px solid var(--invoice-soft-line);
            font-size: 9.8px;
            color: #777b85;
            text-align: right;
            font-weight: 600;
        }
        .invoice-footer-line {
            height: 1px;
            background: linear-gradient(90deg, transparent, var(--invoice-purple), var(--invoice-line), transparent);
            margin: 21px 0 9px;
        }
        .invoice-footer {
            text-align: center;
            font-size: 10.8px;
            color: var(--invoice-muted);
        }
        .invoice-footer .thank-you {
            font-size: 12px;
            font-weight: 850;
            color: var(--invoice-ink);
            margin-bottom: 2px;
            text-transform: uppercase;
            letter-spacing: 0.4px;
        }
        .invoice-footer .footer-subtext {
            margin: 0;
            font-size: 9.8px;
            color: #777b85;
            font-weight: 500;
        }
        @media (max-width: 640px) {
            body { padding: 0; background: #ffffff; }
            .invoice-print-toolbar { padding: 10px 12px; margin-bottom: 0; }
            .invoice-print-button { width: 100%; }
            #invoice-print-container { padding: 14px; box-shadow: none; border: none; }
            .admin-inv-top-banner,
            .admin-inv-brand-wrapper { grid-template-columns: 1fr; align-items: flex-start; flex-direction: column; }
            .admin-inv-badge-box { width: 100%; text-align: left; }
            .invoice-details,
            .invoice-bottom-grid { grid-template-columns: 1fr; }
            .invoice-table { display: block; overflow-x: auto; white-space: nowrap; }
        }
        @media print {
            @page { size: A4 portrait; margin: 9mm; }
            html, body { background: #ffffff !important; margin: 0 !important; padding: 0 !important; }
            body { padding: 0 !important; }
            .invoice-print-toolbar { display: none !important; }
            #invoice-print-container { max-width: none; padding: 0; border: none; box-shadow: none; }
            .admin-inv-top-banner,
            .invoice-details,
            .invoice-bottom-grid,
            .invoice-footer { page-break-inside: avoid; }
            .invoice-table tr { page-break-inside: avoid; }
            * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
        }
    `;
}
function openAdminInvoicePrintWindow(title) {
    const printContainer = document.getElementById('invoice-print-container');
    if (!printContainer) return false;

    const printWindow = window.open('', '_blank');
    if (!printWindow) return false;

    const baseUrl = window.location.href.replace(/[^/]*$/, '');
    printWindow.document.open();
    printWindow.document.write(`<!DOCTYPE html>
        <html lang="es">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <base href="${escapeHtml(baseUrl)}">
            <title>${escapeHtml(title || 'Factura Original Store')}</title>
            <style>${getAdminInvoicePrintWindowStyles()}</style>
        </head>
        <body>
            <div class="invoice-print-toolbar">
                <button type="button" class="invoice-print-button" onclick="window.print()">Imprimir / guardar PDF</button>
            </div>
            ${printContainer.outerHTML}
        </body>
        </html>`);
    printWindow.document.close();
    return true;
}

window.imprimirFacturaEditor = function() {
    const origTitle = document.title;
    const pId = document.getElementById('inv-edit-id').value || `PED-${Date.now().toString().slice(-6)}`;
    const nombre = document.getElementById('inv-edit-nombre').value || 'Cliente Original Store';
    const tel = document.getElementById('inv-edit-tel').value || '-';
    const dir = document.getElementById('inv-edit-dir').value || '-';
    const ciudad = document.getElementById('inv-edit-ciudad').value || '-';
    const fecha = document.getElementById('inv-edit-fecha').value || new Date().toISOString().slice(0, 10);
    const estado = document.getElementById('inv-edit-estado')?.value || 'Finalizada';
    const metodo = document.getElementById('inv-edit-metodo')?.value || 'Digital / Directo';
    const nota = document.getElementById('inv-edit-nota')?.value || '';
    const tipoCliente = getInvoiceCustomerTypeLabel(document.getElementById('inv-edit-tipo')?.value, window.invoiceCustomerType || 'Detal');
    window.invoiceCustomerType = normalizeAdminCustomerType(tipoCliente) === 'mayor' ? 'Mayor' : 'Detal';

    // Rellenar campos en plantilla de impresión
    document.getElementById('inv-id').textContent = pId;
    const consultUrl = new URL('facturas-pedidos.html', window.location.href);
    consultUrl.searchParams.set('buscar', pId);
    const qrImage = document.getElementById('inv-consult-qr-image');
    const qrLink = document.getElementById('inv-consult-qr-link');
    if (qrImage) qrImage.src = getInventoryQrImageUrl(consultUrl.href, 240);
    if (qrLink) { qrLink.href = consultUrl.href; qrLink.textContent = 'Factura ' + pId; }
    
    try {
        const dateObj = new Date(fecha.includes('T') ? fecha : fecha + 'T00:00:00');
        document.getElementById('inv-date').textContent = isNaN(dateObj.getTime()) ? fecha : dateObj.toLocaleDateString('es-CO');
    } catch(e) {
        document.getElementById('inv-date').textContent = fecha;
    }

    document.getElementById('inv-cliente-nombre').textContent = nombre;
    document.getElementById('inv-cliente-tel').textContent = tel;
    document.getElementById('inv-cliente-dir').textContent = dir;
    document.getElementById('inv-cliente-ciudad').textContent = ciudad;
    if (document.getElementById('inv-cliente-tipo')) {
        document.getElementById('inv-cliente-tipo').textContent = tipoCliente || 'Detal';
    }

    if (document.getElementById('inv-print-status')) {
        document.getElementById('inv-status-text').textContent = (estado || 'COMPROBANTE OFICIAL').toUpperCase();
    }
    if (document.getElementById('inv-print-metodo')) {
        document.getElementById('inv-print-metodo').textContent = metodo || 'Digital / Directo';
    }

    // Configuración dinámicas de empresa Original Store
    const cfg = window.storeConfig || {};
    const logoImg = document.getElementById('inv-company-logo');
    if (logoImg) logoImg.src = 'https://lh3.googleusercontent.com/d/1OTHvWFph2u3qFQMQVhE5ghmSWjBSgBeW=w180';

    if (document.getElementById('inv-company-name')) {
        document.getElementById('inv-company-name').textContent = cfg['Factura_Empresa'] || 'Original Store Joyería & Accesorios';
    }
    if (document.getElementById('inv-emisor-nombre')) {
        document.getElementById('inv-emisor-nombre').textContent = cfg['Factura_Empresa'] || 'Original Store Joyería & Accesorios';
    }
    if (document.getElementById('inv-company-nit')) {
        document.getElementById('inv-company-nit').textContent = cfg['Factura_NIT'] || '000.000.000-0';
    }
    if (document.getElementById('inv-company-contact')) {
        document.getElementById('inv-company-contact').textContent = 'WhatsApp: ' + (cfg['Factura_Telefono'] || '+57 311 2368622');
    }
    if (document.getElementById('inv-company-email')) {
        document.getElementById('inv-company-email').textContent = 'Email: ' + (cfg['Factura_Email'] || 'originalstorealmacen@gmail.com');
    }

    // Sección de observaciones y notas
    const notesElem = document.getElementById('inv-print-notes');
    if (notesElem) {
        if (nota.trim()) {
            notesElem.textContent = nota;
        } else {
            notesElem.textContent = 'N/A';
        }
    }

    // Renderizado de ítems con fuente ampliada
    const itemsTbody = document.getElementById('inv-items');
    let total = 0;
    let totalQty = 0;
    
    itemsTbody.innerHTML = (window.invoiceItems || []).map(item => {
        const cant = Number(item.cantidad) || 1;
        const precio = Number(item.precio) || 0;
        const sub = cant * precio;
        total += sub;
        totalQty += cant;
        return `
            <tr>
                <td style="text-align:center;">
                    <span style="background:#ffffff; color:#6d28d9; font-weight:850; padding:2px 8px; border-radius:4px; font-size:12px; display:inline-block; border:1px solid #d9d9e3;">${cant}</span>
                </td>
                <td>
                    <strong style="font-size:13.2px; color:#171717; display:block; margin-bottom:3px; font-weight:760;">${escapeHtml(item.nombre)}</strong>
                    <span style="display:inline-block; background:#ffffff; color:#5f6470; font-size:10.5px; font-weight:650; padding:1px 6px; border-radius:4px; border:1px solid #ececf2; font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;">Ref: ${escapeHtml(item.sku || item.idVariacion || '-')}</span>
                </td>
                <td style="text-align:right; font-variant-numeric: tabular-nums; font-weight:650; color:#3f4148; font-size:13px;">$${precio.toLocaleString('es-CO')}</td>
                <td style="text-align:right; font-variant-numeric: tabular-nums; font-weight:850; color:#171717; font-size:13.5px;">$${sub.toLocaleString('es-CO')}</td>
            </tr>
        `;
    }).join('');

    const previousPaid = Math.min(Math.max(0, Number(window.invoicePreviousPayment) || 0), Math.max(0, total));
    const requestedNewPayment = Math.max(0, parseAdminInvoiceMoney(document.getElementById('inv-edit-abono')?.value || 0));
    const acceptedNewPayment = Math.min(requestedNewPayment, Math.max(0, total - previousPaid));
    const paidAfter = previousPaid + acceptedNewPayment;
    const balanceAfter = Math.max(0, total - paidAfter);

    document.getElementById('inv-total').textContent = formatAdminInvoiceMoney(total);
    if (document.getElementById('inv-paid-total')) {
        document.getElementById('inv-paid-total').textContent = formatAdminInvoiceMoney(paidAfter);
    }
    if (document.getElementById('inv-balance-total')) {
        document.getElementById('inv-balance-total').textContent = formatAdminInvoiceMoney(balanceAfter);
    }
    if (document.getElementById('inv-total-items-count')) {
        document.getElementById('inv-total-items-count').textContent = totalQty + (totalQty === 1 ? ' Ítem' : ' Ítems');
    }

    // Nombre dinámico de archivo al imprimir/guardar PDF
    const safeName = nombre.replace(/[^a-zA-Z0-9]/g, '_');
    document.title = `Factura_${pId}_${safeName}`;

    if (openAdminInvoicePrintWindow(document.title)) {
        document.title = origTitle;
        return;
    }

    document.body.classList.add('invoice-print-mode');
    setTimeout(() => {
        window.print();
        setTimeout(() => {
            document.body.classList.remove('invoice-print-mode');
            document.title = origTitle;
        }, 1200);
    }, 200);
};

window.sendInvoiceWhatsAppEditor = function () {
    const telInput = document.getElementById('inv-edit-tel');
    let phone = telInput ? telInput.value.trim() : '';
    let cleanPhone = String(phone).replace(/\D/g, '');

    if (!cleanPhone || cleanPhone.length < 7) {
        const userPhone = prompt('Por favor ingresa o confirma el número de WhatsApp del cliente (ej: 3118527762):', phone || '');
        if (!userPhone) return;
        cleanPhone = String(userPhone).replace(/\D/g, '');
        if (telInput && cleanPhone) telInput.value = cleanPhone;
    }

    if (cleanPhone.length === 10 && cleanPhone.startsWith('3')) {
        cleanPhone = '57' + cleanPhone;
    }

    const id = document.getElementById('inv-edit-id').value || `FAC-${Date.now().toString().slice(-6)}`;
    const nombre = document.getElementById('inv-edit-nombre').value || 'Cliente Original Store';
    const fecha = document.getElementById('inv-edit-fecha').value || new Date().toISOString().slice(0, 10);
    const dir = document.getElementById('inv-edit-dir').value || '';
    const ciudad = document.getElementById('inv-edit-ciudad').value || '';

    let total = 0;
    const itemsText = (window.invoiceItems || []).length ? window.invoiceItems.map(item => {
        const sub = (Number(item.precio) || 0) * (Number(item.cantidad) || 1);
        total += sub;
        return `• *${item.cantidad}x* ${item.nombre} - $${sub.toLocaleString('es-CO')}`;
    }).join('\n') : '• Detalle de compra adjunto en la factura';

    const msg = `¡Hola, *${nombre}*!
¡Muchas gracias por tu preferencia y por elegir *Original Store Joyería & Accesorios*!

Aquí tienes el comprobante digital oficial de tu compra *#${id}*:

*RESUMEN DE TU COMPRA*
----------------------------------------
*Fecha:* ${fecha}
*Cliente:* ${nombre}
*Contacto:* ${phone || cleanPhone}
${ciudad ? `*Ciudad:* ${ciudad}\n` : ''}${dir ? `*Dirección de Envío:* ${dir}\n` : ''}
*Productos pedidos:*
${itemsText}

*TOTAL FACTURA:* $${total.toLocaleString('es-CO')}
----------------------------------------

*Adjunto encontrarás el documento PDF de tu factura listo para ver y guardar.*

¡Esperamos que disfrutes muchísimo tus accesorios! Cualquier duda estamos para ayudarte.
*Tienda web:* aloriginalstore.online
*Soporte Original Store:* +57 311 2368622`;

    // 1. Disparar el generador / diálogo de impresión PDF para que el usuario guarde o imprima el archivo PDF
    if (typeof window.imprimirFacturaEditor === 'function') {
        window.imprimirFacturaEditor();
    }

    // 2. Abrir la ventana de WhatsApp con el mensaje estructurado listo para enviar
    const waUrl = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(msg)}`;
    setTimeout(() => {
        window.open(waUrl, '_blank');
    }, 400);
};

window.sendAdminInvoiceRowToWhatsApp = function (idx) {
    if (typeof window.abrirEditorFactura === 'function') {
        window.abrirEditorFactura(idx, 'factura');
        setTimeout(() => {
            if (typeof window.sendInvoiceWhatsAppEditor === 'function') {
                window.sendInvoiceWhatsAppEditor();
            }
        }, 350);
    }
};

window.openQuickInvoicePayment = function(idx) {
    const invoice = (window.facturasList || [])[idx];
    const modal = document.getElementById('quick-payment-modal');
    if (!invoice || !modal) {
        showToast('No se encontro la factura seleccionada', 'error');
        return;
    }

    const total = parseAdminInvoiceMoney(invoice.Subtotal || invoice.Total || 0);
    const balanceInfo = getInvoiceBalanceInfo(invoice, total);
    if (balanceInfo.balance <= 0) {
        showToast('Esta factura no tiene saldo pendiente', 'info');
        return;
    }

    modal.dataset.invoiceIndex = String(idx);
    const invoiceId = getInvoiceIdValue(invoice) || '-';
    const customer = getInvoiceCustomerName(invoice) || 'Cliente';
    const currentMethod = invoice['Método Pago'] || invoice['Metodo Pago'] || invoice.pago || '';

    const setText = (id, value) => {
        const el = document.getElementById(id);
        if (el) el.textContent = value;
    };

    setText('quick-payment-invoice-id', invoiceId);
    setText('quick-payment-customer', customer);
    setText('quick-payment-total', formatAdminInvoiceMoney(balanceInfo.total));
    setText('quick-payment-paid', formatAdminInvoiceMoney(balanceInfo.paid));
    setText('quick-payment-balance', formatAdminInvoiceMoney(balanceInfo.balance));

    const amountInput = document.getElementById('quick-payment-amount');
    const methodInput = document.getElementById('quick-payment-method');
    if (amountInput) {
        amountInput.value = '';
        amountInput.placeholder = formatAdminInvoiceMoney(balanceInfo.balance);
        amountInput.dataset.maxAmount = String(balanceInfo.balance);
    }
    if (methodInput) methodInput.value = currentMethod || 'Abono';

    modal.classList.add('open');
    setTimeout(() => amountInput?.focus(), 80);
};

window.closeQuickInvoicePayment = function() {
    const modal = document.getElementById('quick-payment-modal');
    if (modal) modal.classList.remove('open');
};

window.updateAdminInvoiceStatus = async function(idx, nextStatus, selectEl) {
    const invoice = (window.facturasList || [])[idx];
    if (!invoice) {
        showToast('No se encontro la factura seleccionada', 'error');
        return;
    }

    const invoiceId = getInvoiceIdValue(invoice);
    if (!invoiceId) {
        showToast('La factura no tiene ID valido para actualizar', 'error');
        return;
    }

    const previousStatus = invoice['Estado Factura'] || invoice.Estado || 'Pendiente';
    const cleanStatus = String(nextStatus || '').trim() || previousStatus;
    if (cleanStatus === previousStatus) return;

    if (selectEl) selectEl.disabled = true;
    try {
        const res = await fetch(GOOGLE_SHEET_API, {
            method: 'POST',
            body: JSON.stringify({
                resource: 'facturas',
                action: 'actualizar',
                id: invoiceId,
                'ID Factura': invoiceId,
                'Estado Factura': cleanStatus
            })
        });
        const result = await res.json();
        if (!result || result.status !== 'success') {
            throw new Error(result?.error || 'No se pudo actualizar el estado');
        }

        invoice['Estado Factura'] = cleanStatus;
        invoice.Estado = cleanStatus;
        renderFacturas();
        showToast(`Factura marcada como ${cleanStatus}`, 'success');
    } catch (error) {
        if (selectEl) selectEl.value = previousStatus;
        showToast('Error actualizando estado: ' + error.message, 'error');
        console.error(error);
    } finally {
        if (selectEl) selectEl.disabled = false;
    }
};

window.saveQuickInvoicePayment = async function() {
    const modal = document.getElementById('quick-payment-modal');
    const saveBtn = document.getElementById('quick-payment-save-btn');
    const amountInput = document.getElementById('quick-payment-amount');
    const methodInput = document.getElementById('quick-payment-method');
    if (!modal || !amountInput) return;

    const idx = Number(modal.dataset.invoiceIndex);
    const invoice = (window.facturasList || [])[idx];
    if (!invoice) {
        showToast('No se encontro la factura seleccionada', 'error');
        return;
    }

    const invoiceId = getInvoiceIdValue(invoice);
    if (!invoiceId) {
        showToast('La factura no tiene ID valido para actualizar', 'error');
        return;
    }

    const total = parseAdminInvoiceMoney(invoice.Subtotal || invoice.Total || 0);
    const balanceInfo = getInvoiceBalanceInfo(invoice, total);
    const requestedPayment = Math.max(0, parseAdminInvoiceMoney(amountInput.value || 0));
    if (requestedPayment <= 0) {
        showToast('Escribe un valor de abono mayor a cero', 'warning');
        amountInput.focus();
        return;
    }

    const acceptedPayment = Math.min(requestedPayment, balanceInfo.balance);
    const paidAfter = Math.min(balanceInfo.total, balanceInfo.paid + acceptedPayment);
    const balanceAfter = Math.max(0, balanceInfo.total - paidAfter);
    const currentStatus = invoice['Estado Factura'] || invoice.Estado || 'Pendiente';
    const nextStatus = balanceAfter === 0
        ? 'Pago'
        : (paidAfter > 0 ? 'Abonada' : currentStatus);
    const method = String(methodInput?.value || invoice['Método Pago'] || invoice['Metodo Pago'] || invoice.pago || 'Abono').trim() || 'Abono';

    if (saveBtn) {
        saveBtn.disabled = true;
        saveBtn.textContent = 'Guardando...';
    }

    const payload = {
        resource: 'facturas',
        action: 'actualizar',
        id: invoiceId,
        'ID Factura': invoiceId,
        'Valor Abonado': paidAfter,
        'Saldo Pendiente': balanceAfter,
        'Ultimo Abono': acceptedPayment,
        'Estado Factura': nextStatus,
        pago: method
    };

    try {
        const res = await fetch(GOOGLE_SHEET_API, {
            method: 'POST',
            body: JSON.stringify(payload)
        });
        const result = await res.json();
        if (!result || result.status !== 'success') {
            throw new Error(result?.error || 'No se pudo guardar el abono');
        }

        Object.assign(invoice, {
            'Valor Abonado': paidAfter,
            'Saldo Pendiente': balanceAfter,
            'Ultimo Abono': acceptedPayment,
            'Estado Factura': nextStatus,
            'Método Pago': method,
            pago: method
        });

        renderFacturas();
        closeQuickInvoicePayment();
        showToast(`Abono registrado: ${formatAdminInvoiceMoney(acceptedPayment)}`, 'success');
        cargarPedidos({ force: true });
    } catch (err) {
        showToast('Error: ' + err.message, 'error');
        console.error(err);
    } finally {
        if (saveBtn) {
            saveBtn.disabled = false;
            saveBtn.textContent = 'Registrar abono';
        }
    }
};

window.guardarFacturaDB = async function() {
    if (window.invoiceItems.length === 0) return alert("Añade al menos un producto a la factura.");
    
    const btn = document.getElementById('btn-save-invoice');
    btn.disabled = true;
    btn.textContent = 'Guardando...';
    
    const originalOrderId = document.getElementById('inv-original-id').value.trim();
    const visibleId = document.getElementById('inv-edit-id').value.trim();
    const editingExistingInvoice = window.invoiceEditSource === 'factura' && window.invoiceOriginalInvoiceId;
    const existingInvoiceForOrder = originalOrderId
        ? (window.facturasList || []).find(f => String(getInvoiceOrderIdValue(f)).trim() === originalOrderId)
        : null;
    const existingInvoiceId = existingInvoiceForOrder ? getInvoiceIdValue(existingInvoiceForOrder) : '';
    const idPedido = window.invoiceEditSource === 'pedido'
        ? originalOrderId
        : (originalOrderId || '');
    const idFactura = editingExistingInvoice
        ? (visibleId || window.invoiceOriginalInvoiceId)
        : (existingInvoiceId || (idPedido ? (visibleId || `FAC-${idPedido}`) : (visibleId || `FAC-${Date.now()}`)));
    const isUpdate = Boolean(editingExistingInvoice || existingInvoiceId);
    const total = window.invoiceItems.reduce((sum, item) => sum + (item.precio * item.cantidad), 0);
    const cantTotal = window.invoiceItems.reduce((sum, item) => sum + item.cantidad, 0);
    const existingPaymentInfo = existingInvoiceForOrder ? getInvoiceBalanceInfo(existingInvoiceForOrder, total) : null;
    const previousPaid = Math.min(
        Math.max(0, existingPaymentInfo ? existingPaymentInfo.paid : (Number(window.invoicePreviousPayment) || 0)),
        Math.max(0, total)
    );
    const requestedNewPayment = Math.max(0, parseAdminInvoiceMoney(document.getElementById('inv-edit-abono')?.value || 0));
    const acceptedNewPayment = Math.min(requestedNewPayment, Math.max(0, total - previousPaid));
    const paidAfter = previousPaid + acceptedNewPayment;
    const saldoPendiente = Math.max(0, total - paidAfter);
    const metodo = document.getElementById('inv-edit-metodo').value.trim() || 'Mostrador / Manual';
    let estadoFactura = document.getElementById('inv-edit-estado').value.trim() || 'Finalizada';
    const entrega = [document.getElementById('inv-edit-dir').value.trim(), document.getElementById('inv-edit-ciudad').value.trim()]
        .filter(Boolean)
        .join(' - ');
    const tipoCliente = getInvoiceCustomerTypeLabel(document.getElementById('inv-edit-tipo')?.value, window.invoiceCustomerType || 'Detal');
    const tipoClienteTab = normalizeAdminCustomerType(tipoCliente) === 'mayor' ? 'Mayor' : 'Detal';
    window.invoiceCustomerType = tipoClienteTab;
    const linkedOrderStatus = /final|complet|pagad|factur/i.test(estadoFactura) ? 'Facturado' : estadoFactura;
    
    const payload = {
        resource: 'facturas',
        action: isUpdate ? 'actualizar' : 'crear',
        id: window.invoiceOriginalInvoiceId || existingInvoiceId || idFactura,
        'ID Factura': idFactura,
        'ID Pedido': idPedido,
        'ID Cliente': document.getElementById('inv-edit-tel').value,
        'Tipo Cliente': tipoCliente,
        'Fecha': document.getElementById('inv-edit-fecha').value || new Date().toISOString().slice(0, 10),
        'Nombre': document.getElementById('inv-edit-nombre').value,
        'Productos JSON': JSON.stringify(window.invoiceItems),
        'Cantidad Total': cantTotal,
        'Subtotal': total,
        'Valor Abonado': paidAfter,
        'Saldo Pendiente': saldoPendiente,
        'Ultimo Abono': acceptedNewPayment,
        'Estado Factura': estadoFactura,
        pago: metodo,
        entrega,
        'Observaciones': document.getElementById('inv-edit-nota').value
    };
    
    try {
        const res = await fetch(GOOGLE_SHEET_API, {
            method: 'POST',
            body: JSON.stringify(payload)
        });
        const result = await res.json();
        
        if (result && result.status === 'success') {
            if (window.invoiceEditSource === 'pedido' && originalOrderId) {
                fetch(GOOGLE_SHEET_API, {
                    method: 'POST',
                    body: JSON.stringify({
                        resource: 'pedidos',
                        action: 'estado',
                        id: originalOrderId,
                        estado: linkedOrderStatus
                    })
                }).catch(error => console.warn('No se pudo marcar el pedido como facturado:', error));
            }
            showToast('Factura guardada exitosamente', 'success');
            document.getElementById('invoice-editor-modal').classList.remove('open');
            if (typeof window.switchOrdersAdminTab === 'function') {
                window.switchOrdersAdminTab(tipoClienteTab === 'Mayor' ? 'invoices-mayor' : 'invoices-detal');
            }
            cargarPedidos({ force: true });
        } else {
            throw new Error(result.error || 'Error al guardar');
        }
    } catch (err) {
        showToast('Error: ' + err.message, 'error');
        console.error(err);
    } finally {
        btn.disabled = false;
        btn.innerHTML = `<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path><polyline points="17 21 17 13 7 13 7 21"></polyline><polyline points="7 3 7 8 15 8"></polyline></svg><span>Guardar Factura</span>`;
    }
};


window.toggleVariants = function (motherIdClass, btnEl) {
    var rows = document.querySelectorAll('.variant-row.mother-' + motherIdClass);
    var total = rows.length;
    var anyVisible = false;
    rows.forEach(function (row) {
        if (row.style.display !== 'none') anyVisible = true;
    });
    rows.forEach(function (row) {
        row.style.display = anyVisible ? 'none' : 'table-row';
    });
    if (btnEl) {
        if (anyVisible) {
            btnEl.innerHTML = 'Ver ' + total + ' variantes';
            btnEl.style.background = 'rgba(155,44,250,0.1)';
        } else {
            btnEl.innerHTML = 'Ocultar';
            btnEl.style.background = 'rgba(155,44,250,0.25)';
        }
    }
};



function toggleQuickSaleCatalog() {
    const grid = document.getElementById('quick-sale-results');
    const button = document.getElementById('quick-sale-catalog-toggle');
    if (!grid || !button) return;
    const expanded = grid.classList.toggle('is-expanded');
    button.setAttribute('aria-expanded', String(expanded));
    button.textContent = expanded ? 'Ver menos productos' : 'Ver más productos';
}

function openQuickSaleImage(button) {
    const source = button.querySelector('img');
    if (!source) return;
    let dialog = document.getElementById('quick-sale-image-dialog');
    if (!dialog) {
        dialog = document.createElement('dialog');
        dialog.id = 'quick-sale-image-dialog';
        dialog.className = 'quick-sale-image-dialog';
        dialog.innerHTML = '<header><strong></strong><button type="button" class="quick-sale-refresh-btn" data-zoom>Ampliar</button><button type="button" class="quick-sale-refresh-btn" data-close aria-label="Cerrar imagen">Cerrar</button></header><div class="quick-sale-image-viewport"><img alt=""></div>';
        document.body.appendChild(dialog);
        dialog.querySelector('[data-close]').onclick = () => dialog.close();
        dialog.querySelector('[data-zoom]').onclick = () => {
            const zoomed = dialog.querySelector('.quick-sale-image-viewport').classList.toggle('is-zoomed');
            dialog.querySelector('[data-zoom]').textContent = zoomed ? 'Reducir' : 'Ampliar';
        };
        dialog.addEventListener('click', event => { if (event.target === dialog) dialog.close(); });
    }
    dialog.querySelector('strong').textContent = source.alt;
    dialog.querySelector('img').src = source.currentSrc || source.src;
    dialog.querySelector('img').alt = source.alt;
    dialog.querySelector('.quick-sale-image-viewport').classList.remove('is-zoomed');
    dialog.querySelector('[data-zoom]').textContent = 'Ampliar';
    dialog.showModal();
}

function toggleDesktopSidebar() {
    const layout = document.getElementById('admin-main-content');
    if (!layout) return;
    const compact = layout.classList.toggle('sidebar-compact');
    syncDesktopSidebarToggle(compact);
    try { localStorage.setItem('blyxu-admin-sidebar-compact', String(compact)); } catch (_) {}
}
function syncDesktopSidebarToggle(compact) {
    const button = document.getElementById('desktop-sidebar-toggle');
    if (!button) return;
    button.setAttribute('aria-expanded', String(!compact));
    button.setAttribute('aria-label', compact ? 'Desplegar menú de secciones' : 'Plegar menú de secciones');
    button.title = compact ? 'Desplegar menú' : 'Plegar menú';
    button.textContent = compact ? '☰' : '‹';
}
function initDesktopSidebar() {
    let compact = false;
    try { compact = localStorage.getItem('blyxu-admin-sidebar-compact') === 'true'; } catch (_) {}
    document.getElementById('admin-main-content')?.classList.toggle('sidebar-compact', compact);
    syncDesktopSidebarToggle(compact);
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initDesktopSidebar);
else initDesktopSidebar();

function openQuickSaleProductInfo(groupKey) {
    const product = getQuickSaleGroupVariant(groupKey);
    if (!product) return;
    const meta = getQuickSaleProductMeta(product);
    let dialog = document.getElementById('quick-sale-info-dialog');
    if (!dialog) {
        dialog = document.createElement('dialog');
        dialog.id = 'quick-sale-info-dialog';
        dialog.className = 'quick-sale-info-dialog';
        dialog.setAttribute('aria-labelledby', 'quick-sale-info-title');
        document.body.appendChild(dialog);
        dialog.addEventListener('click', event => { if (event.target === dialog) dialog.close(); });
    }
    const fields = [['Referencia', meta.sku], ['Categoría', meta.category], ['Color', meta.color], ['Tamaño / talla', meta.size], ['Estilo', meta.style], ['Disponibilidad', meta.stock + ' unidades'], ['Precio', formatAdminInvoiceMoney(getQuickSalePrice(product))]];
    dialog.innerHTML = '<header><h3 id="quick-sale-info-title">' + escapeHtml(meta.name) + '</h3><button type="button" class="quick-sale-refresh-btn" aria-label="Cerrar información">Cerrar</button></header><p>' + escapeHtml(meta.description || 'Sin descripción disponible.') + '</p><dl>' + fields.map(([label, value]) => '<div><dt>' + escapeHtml(label) + '</dt><dd>' + escapeHtml(String(value || 'No especificado')) + '</dd></div>').join('') + '</dl>';
    dialog.querySelector('button').onclick = () => dialog.close();
    dialog.showModal();
}

function initializeOriginalStoreAdminSession() {
    const screen = document.getElementById('admin-login-screen'), main = document.getElementById('admin-main-content');
    const showLogin = () => {
        if(screen){screen.style.display='';screen.classList.remove('vault-success');screen.querySelector('[data-vault]')?.classList.remove('is-unlocking');}
        if(main)main.style.display='none';
        document.getElementById('edit-product-modal')?.classList.remove('open');
    };
    window.OriginalStoreAdminSession.initialize({
        resetForm:resetProductForm, setEditing:setProductFormMode,
        message(text){
            let notice=document.getElementById('admin-session-notice');
            if(!notice){notice=document.createElement('p');notice.id='admin-session-notice';notice.setAttribute('role','status');notice.style.cssText='font-size:13px;line-height:1.5;color:inherit;';document.getElementById('admin-login-box')?.prepend(notice);}
            notice.textContent=text;
            if(secureAdminCredential)showToast(text);
        },
        lock(){revokeAdminSession();sessionStorage.removeItem('blyxu_admin_orders_invoices_cache_v2');showLogin();},
        exit:revokeAdminSession,showLogin,
        async validate(){
            const credential=secureAdminCredential;if(!credential)return false;
            const response=await adminNativeFetch(GOOGLE_SHEET_API,{method:'POST',headers:{'Content-Type':'text/plain;charset=utf-8'},body:JSON.stringify({action:'adminsession',adminCredential:credential}),signal:AbortSignal.timeout(15000)});
            return (await response.json()).ok===true;
        },
        addDraftVariant(variant){
            const container=document.getElementById('variants-container');
            if(variant.kind==='new'){document.getElementById('btn-add-manual-variant').click();return container.lastElementChild;}
            if(variant.kind==='saved'&&variant.originalId){
                const record={'ID Variacion':variant.originalId,'ID Producto':getInputValue('prod-id-producto'),'Nombre del Producto':getInputValue('prod-nombre')};
                container.insertAdjacentHTML('beforeend',buildVariantEditorCardHtml(record,getInputValue('prod-id-producto')));
                return container.lastElementChild;
            }
        },
        finishDraftVariant(root,variant){
            syncVariantImageMode(root);if(root.querySelector('.var-size-mode'))syncVariantSizeField(root);
            const mode=root.querySelector('.var-barcode-mode');if(mode)mode.dispatchEvent(new Event('change',{bubbles:true}));
            const row=root.querySelector('.var-edit-expanded');if(row&&variant.open){row.classList.add('is-open');root.classList.add('is-editing');}
        },
        refreshDraft(draft){
            window.OriginalStoreProductIdentity.adopt({preserve:true,mother:draft.identityMother||getInputValue('prod-id-producto')});
            updateProductMeasurementFields();setProductBarcodeScanMode(document.getElementById('prod-barcode-scan-mode')?.checked);
            updateProductImagePreviewBox(getInputValue('prod-imagen'));renderProductGalleryManager();updateLivePreview();
            window.OriginalStoreSharedScan?.invalidate();
        }
    });
}
