import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import vm from 'node:vm';import {fixture} from './fixtures/order-lookup-api.mjs';
const auth={adminCredential:'TEST-GOOGLE-ID'};
test('image inheritance preference persists, rejects invalid modes and stays admin-only',async()=>{
 const f=fixture();const record={'ID Variación':'TEST-V02','ID Producto':'TEST-P1','Nombre del Producto':'Variante',Precio:1200,'Precio Mayor':800,Cantidad:4,'Modo Imagen':'general','Imagen Principal':'https://example.invalid/old-main.webp','Tipo Medida':'medidas','Unidad Medida':'cm',Ancho:'25',Largo:'30',Fondo:'5'};
 assert.equal((await f.post({resource:'productos',action:'crear',data:record})).ok,false);
 const created=await f.post({resource:'productos',action:'crear',data:record,...auth});assert.equal(created.ok,true,JSON.stringify(created));assert.equal(created.data['Modo Imagen'],'general');assert.equal(created.data.Ancho,'25');
 const changed=await f.post({resource:'productos',action:'editar',id:'TEST-V02',data:{'Modo Imagen':'propia','Imagen Principal':'https://example.invalid/own.webp'},...auth});assert.equal(changed.ok,true,JSON.stringify(changed));assert.equal(changed.data['Modo Imagen'],'propia');
 const invalid=await f.post({resource:'productos',action:'editar',id:'TEST-V02',data:{'Modo Imagen':'otro'},...auth});assert.equal(invalid.ok,false);
 const catalogue=await f.post({resource:'productos',action:'listar'});const rows=catalogue.data;assert.equal(rows.find(p=>p['ID Variación']==='TEST-V02')['Modo Imagen'],'propia');assert.equal(f.data.Pedidos.rows.length,0);assert.equal(f.data.Facturas.rows.length,0);
});
test('general photos resolve to the current principal while independent photos remain untouched',()=>{
 const source=fs.readFileSync(new URL('../blyxu-app.js',import.meta.url),'utf8');const fn=source.slice(source.indexOf('function resolveInheritedProductImages('),source.indexOf('function getPublicProductImage('));const context={getStableProductReference:p=>p.idVariacion};vm.createContext(context);vm.runInContext(fn,context);
 const rows=[{idProducto:'A',idVariacion:'A-V01',Imagen:'new-main.webp','Imagen Principal':'new-main.webp',Galeria:['angle.webp']},{idProducto:'A',idVariacion:'A-V02',Imagen:'old-main.webp','Modo Imagen':'general'},{idProducto:'A',idVariacion:'A-V03',Imagen:'independent.webp','Modo Imagen':'propia'},{idProducto:'B',idVariacion:'B-V01',Imagen:'other-family.webp'},{idProducto:'NO-PARENT',idVariacion:'ORPHAN',Imagen:'saved-fallback.webp','Modo Imagen':'general'}];
 context.resolveInheritedProductImages(rows);assert.equal(rows[1].Imagen,'new-main.webp');assert.equal(rows[1]['Imagen Principal'],'new-main.webp');assert.equal(rows[2].Imagen,'independent.webp');assert.equal(rows[4].Imagen,'saved-fallback.webp');
 rows[0].Imagen=rows[0]['Imagen Principal']='changed-main.webp';context.resolveInheritedProductImages(rows);assert.equal(rows[1].Imagen,'changed-main.webp');assert.equal(rows[2].Imagen,'independent.webp');
});
