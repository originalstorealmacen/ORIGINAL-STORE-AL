import assert from 'node:assert/strict';import {createRequire} from 'node:module';import {server,start,writes,inventory} from './fixtures/admin-identity-server.mjs';
const {chromium}=createRequire(import.meta.url)('C:/Users/kevin/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const browser=await chromium.launch({channel:'msedge',headless:true}),url=await start();
const originalInventory=JSON.stringify(inventory),errors=[];
async function setup(mobile=false){
 const context=await browser.newContext(mobile?{viewport:{width:390,height:844},isMobile:true,hasTouch:true}:{});
 await context.route('**/*',async route=>{
  const address=route.request().url();
  if(address.startsWith(url))return route.continue();
  if(address.startsWith('https://accounts.google.com/gsi/client'))return route.fulfill({contentType:'text/javascript',body:`window.google={accounts:{id:{initialize(o){window.fixtureGoogle=o.callback;},renderButton(element){const b=document.createElement('button');b.type='button';b.textContent='Entrar prueba';b.onclick=()=>fixtureGoogle({credential:'fixture.'+btoa(JSON.stringify({email:'originalstorealmacen@gmail.com',exp:Math.floor(Date.now()/1000)+7200}))+'.signature'});element.append(b);}}}};`});
  return route.abort();
 });
 const page=await context.newPage();page.setDefaultTimeout(12000);await page.clock.install({time:new Date()});page.on('pageerror',e=>{errors.push(e.message);console.log('ERROR',e.message);});await page.goto(url);await page.getByRole('button',{name:'Entrar prueba',exact:true}).click();
 await page.waitForFunction(()=>document.getElementById('admin-main-content').style.display!=='none'&&window.OriginalStoreProductIdentity);
 await page.evaluate(()=>switchDashboardView('products','Productos'));await page.locator('#prod-id-producto').waitFor({state:'visible'});return {context,page};
}
try{
 const {page:pc}=await setup();
 await pc.locator('#prod-nombre').fill('Peluche de prueba');await pc.locator('#prod-retail-mode').selectOption('manual');await pc.locator('#prod-precio').fill('28000');await pc.locator('#prod-stock-inicial').evaluate(input=>{input.value='7';input.dispatchEvent(new Event('input',{bubbles:true}));});
 await pc.locator('#prod-id-producto').fill('DNDJSA32');assert.equal(await pc.locator('#prod-id').inputValue(),'DNDJSA32-V01');assert.equal(await pc.locator('#prod-generated-qr-code').textContent(),'DNDJSA32');
 await pc.locator('#btn-add-manual-variant').evaluate(button=>button.click());await pc.locator('#btn-add-manual-variant').evaluate(button=>button.click());
 assert.deepEqual(await pc.locator('#variants-container .var-id').evaluateAll(xs=>xs.map(x=>x.value)),['DNDJSA32-V02','DNDJSA32-V03']);
 await pc.evaluate(()=>openProductEntryStep(document.getElementById('product-general-step')));
 await pc.locator('#prod-barcode-scan-mode').check();await pc.locator('#prod-barcode').fill('FISICO100');
 assert.equal(await pc.locator('#prod-id-producto').inputValue(),'FISICO100');assert.equal(await pc.locator('#prod-id').inputValue(),'FISICO100-V01');
 assert.deepEqual(await pc.locator('#variants-container .var-id').evaluateAll(xs=>xs.map(x=>x.value)),['FISICO100-V02','FISICO100-V03']);
 const first=pc.locator('#variants-container .admin-panel').first();await first.locator('.var-barcode-mode').evaluate(input=>input.click());await first.locator('.var-barcode').evaluate(input=>{input.value='ROJO-PROPIO';input.dispatchEvent(new Event('input',{bubbles:true}));});
 assert.equal(await first.locator('.var-id').inputValue(),'ROJO-PROPIO');await pc.locator('#prod-barcode').fill('MADRE200');
 assert.equal(await first.locator('.var-barcode').inputValue(),'ROJO-PROPIO');assert.equal(await first.locator('.var-id').inputValue(),'ROJO-PROPIO');
 await pc.locator('#btn-add-manual-variant').evaluate(button=>button.click());assert.equal(await pc.locator('#variants-container .var-id').last().inputValue(),'MADRE200-V03');
 const before=await pc.locator('#prod-id-producto').inputValue();
 await pc.evaluate(()=>{try{OriginalStoreProductIdentity.applyCode('ROJO-PROPIO',document.getElementById('prod-barcode'));}catch(error){window.duplicateError=error.message;}});
 assert.equal(await pc.locator('#prod-id-producto').inputValue(),before);assert.match(await pc.evaluate(()=>duplicateError),/otro|repetid/);

 await pc.evaluate(()=>{try{OriginalStoreProductIdentity.rebase('X'.repeat(48));}catch(error){window.longIdError=error.message;}});assert.match(await pc.evaluate(()=>longIdError),/QR.*únicos/);assert.equal(await pc.locator('#prod-id-producto').inputValue(),before);
 console.log('PASS manual IDs, main physical code, open/new variants, preserved physical variant, duplicates rejected');
 const {page:phone}=await setup(true);
 const localPhoneMother=await phone.locator('#prod-id-producto').inputValue();
 await pc.locator('[data-scan=create]').click();await pc.locator('[data-scan=pair]').waitFor({state:'visible'});const link=await pc.locator('[data-scan=link]').inputValue();
 await phone.evaluate(value=>{const hash=value.split('#os-scan=')[1];window.pairValue=hash;},link);
 await phone.locator('[data-scan=join]').click();await phone.locator('#barcode-scanner-manual').fill(link);await phone.locator('#barcode-scanner-use-manual').click();
 await phone.locator('[data-scan=scan]').waitFor({state:'visible'});
 assert.equal(await phone.locator('#product-form').isVisible(),false);assert.equal(await phone.locator('#admin-main-content').evaluate(el=>el.inert),true);
 await Promise.all([phone.waitForFunction(()=>document.querySelector('[data-scan=connection]').dataset.state==='connected'),pc.waitForFunction(()=>document.querySelector('[data-scan=connection]').dataset.state==='connected')]);
 assert.equal(await phone.locator('[data-scan=connection] i').evaluate(el=>getComputedStyle(el).backgroundColor),'rgb(22, 163, 74)');await phone.waitForFunction(()=>document.querySelector('[data-scan=destination]').textContent.includes('MADRE200-V01'));
 await phone.locator('[data-scan=scan]').click();await phone.locator('#barcode-scanner-manual').fill('CELULAR300');await phone.locator('#barcode-scanner-use-manual').click();
 await pc.waitForFunction(()=>document.getElementById('prod-id').value==='CELULAR300-V01');await phone.waitForFunction(()=>document.querySelector('[data-scan=destination]').textContent.includes('CELULAR300-V01'));
 assert.equal(await pc.locator('#prod-id-producto').inputValue(),'CELULAR300');assert.equal(await first.locator('.var-barcode').inputValue(),'ROJO-PROPIO');
 assert.equal(await pc.locator('#prod-nombre').inputValue(),'Peluche de prueba');assert.equal(await pc.locator('#prod-precio').inputValue(),'28000');assert.equal(await pc.locator('#prod-stock-inicial').inputValue(),'7');
 assert.equal(await phone.locator('#prod-id-producto').inputValue(),localPhoneMother);
 console.log('PASS linked phone is scanner-only, both indicators green, real PC IDs update and phone form stays unchanged');
 const individual=await first.locator('.var-barcode').getAttribute('id');
 await pc.locator('[data-scan=target]').selectOption(individual);await phone.waitForFunction(()=>document.querySelector('[data-scan=destination]').textContent.includes('ROJO-PROPIO'));
 await phone.locator('#barcode-scanner-manual').fill('VARIANTE-CELULAR');await phone.locator('#barcode-scanner-use-manual').click();
 await pc.waitForFunction(()=>document.querySelector('#variants-container .var-id').value==='VARIANTE-CELULAR');
 assert.equal(await pc.locator('#prod-id-producto').inputValue(),'CELULAR300');assert.equal(await pc.locator('#prod-id').inputValue(),'CELULAR300-V01');
 await phone.waitForFunction(()=>document.querySelector('[data-scan=destination]').textContent.includes('VARIANTE-CELULAR'));
 console.log('PASS a linked scan of one variant preserves the mother and sibling IDs');

 await phone.evaluate(()=>closeBarcodeScanner());await pc.locator('[data-scan=disconnect]').click();
 await phone.waitForFunction(()=>!document.body.classList.contains('os-phone-scanner-mode'));assert.equal(await phone.locator('#prod-id-producto').inputValue(),localPhoneMother);
 assert.equal(await pc.locator('[data-scan=connection]').getAttribute('data-state'),'disconnected');assert.equal(await phone.locator('[data-scan=connection]').getAttribute('data-state'),'disconnected');
 console.log('PASS disconnect restores phone editing and turns off the connection light');

 // Existing saved rows, including closed editors, use the same local hierarchy.
 await pc.evaluate(()=>editarProducto(0));
 await pc.evaluate(()=>openProductEntryStep(document.getElementById('product-general-step')));
 await pc.locator('#prod-id-producto').fill('EDITADA400');
 assert.equal(await pc.locator('#prod-id').inputValue(),'EDITADA400-V01');assert.equal(await pc.locator('.ve-id').inputValue(),'EDITADA400-V02');
 assert.equal(await pc.locator('.ve-barcode').inputValue(),'BLYXU-EDITADA400-V02');
 await pc.locator('#prod-barcode-scan-mode').check();await pc.locator('#btn-scan-product-barcode').click();await pc.locator('#barcode-scanner-manual').fill('CAMARA500');await pc.locator('#barcode-scanner-use-manual').click();
 await pc.waitForFunction(()=>document.getElementById('prod-id-producto').value==='CAMARA500');assert.equal(await pc.locator('.ve-id').inputValue(),'CAMARA500-V02');
 const qrText=await pc.locator('#prod-generated-qr-code').textContent();assert.equal(qrText,'CAMARA500');
 console.log('PASS saved/closed variants, direct existing scanner, automatic QR updates');

 await pc.locator('#btn-add-manual-variant').evaluate(button=>button.click());
 await pc.locator('#variants-container .var-nombre').evaluate(input=>{input.value='Variante sin guardar';input.dispatchEvent(new Event('input',{bubbles:true}));});
 await pc.evaluate(()=>OriginalStoreAdminSession.save());
 const editingOriginal=await pc.locator('#product-form').getAttribute('data-original-variation-id');
 const draftBefore=await pc.evaluate(()=>sessionStorage.getItem('original_store_product_draft_v1'));
 assert.ok(draftBefore.includes('CAMARA500'));assert.ok(draftBefore.includes('Variante sin guardar'));assert.ok(!/fixture\.|adminCredential|BLYXU-A3-|password|signature/.test(draftBefore));
 await pc.reload();await pc.getByRole('button',{name:'Entrar prueba',exact:true}).click();
 await pc.waitForFunction(()=>document.getElementById('prod-id-producto').value==='CAMARA500');
 assert.equal(await pc.locator('.ve-id').inputValue(),'CAMARA500-V02');assert.equal(await pc.locator('.var-nombre').inputValue(),'Variante sin guardar');
 assert.equal(await pc.locator('#product-form').getAttribute('data-original-variation-id'),editingOriginal);
 console.log('PASS reload/login restores edited and new variant drafts without credentials');
 await pc.clock.fastForward(25*60*1000);await pc.keyboard.press('Shift');await pc.clock.fastForward(10*60*1000);
 assert.equal(await pc.evaluate(()=>secureAdminCredential!==''),true);
 console.log('PASS administrator stays signed in after 35 minutes with actual activity');
 await pc.clock.fastForward(31*60*1000);
 assert.equal(await pc.evaluate(()=>secureAdminCredential===''),true);assert.equal(await pc.locator('#admin-main-content').evaluate(el=>el.style.display),'none');
 assert.ok((await pc.evaluate(()=>sessionStorage.getItem('original_store_product_draft_v1'))).includes('Variante sin guardar'));
 await pc.getByRole('button',{name:'Entrar prueba',exact:true}).click();await pc.clock.fastForward(1500);
 await pc.waitForFunction(()=>secureAdminCredential!=='');assert.equal(await pc.locator('.var-nombre').inputValue(),'Variante sin guardar');
 console.log('PASS real inactivity locks, revokes credentials and preserves the draft across reauthentication');
 await pc.evaluate(()=>fixtureGoogle({credential:'fixture.'+btoa(JSON.stringify({email:'originalstorealmacen@gmail.com',exp:Math.floor(Date.now()/1000)+5}))+'.signature'}));
 await pc.clock.fastForward(6500);assert.equal(await pc.evaluate(()=>secureAdminCredential===''),true);
 assert.equal(await pc.locator('#prod-id-producto').inputValue(),'CAMARA500');
 const after=await pc.evaluate(()=>sessionStorage.getItem('original_store_product_draft_v1'));assert.ok(!/fixture\.|adminCredential|BLYXU-A3-|password|signature/.test(after));
 console.log('PASS credential expiry still locks an active administrator and retains the draft');
 assert.deepEqual(writes,[]);assert.equal(JSON.stringify(inventory),originalInventory);console.log('PAGE ERRORS',JSON.stringify(errors));assert.deepEqual(errors,[]);
}finally{await browser.close();server.closeAllConnections();await new Promise(r=>server.close(r));}
