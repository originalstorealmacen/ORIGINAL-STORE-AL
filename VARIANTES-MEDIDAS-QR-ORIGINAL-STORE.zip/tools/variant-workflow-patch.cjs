module.exports=function(source){
 const marker="      'Imagen Principal',";
 if(!source.includes("      'Modo Imagen',")){if(!source.includes(marker))throw Error('Product image header not found');source=source.replace(marker,marker+"\n      'Modo Imagen',");}
 const validation="    if(sheetName === 'Productos' && header === 'Modo Imagen' && !['general','propia'].includes(value)) throw new Error('Elige foto general o propia.');";
 const optional="    if(sheetName === 'Productos' && header === 'Modo Imagen' && (value == null || value === '')) value = 'propia';";
 if(!source.includes(optional)&&source.includes(validation))source=source.replace(validation,optional+'\n'+validation);
 if(!source.includes(validation))source=source.replace('    let value = data[key];','    let value = data[key];\n'+optional+'\n'+validation);
 return source;
};
